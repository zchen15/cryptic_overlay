#!/bin/bash
clang-tidy example/example.cpp -- -I ./include 
