#!/bin/sh

wget -N https://raw.githubusercontent.com/cpplint/cpplint/master/cpplint.py
wget -N https://raw.githubusercontent.com/cpplint/cpplint/master/LICENSE
wget -N https://raw.githubusercontent.com/cpplint/cpplint/master/README.rst
