import typing

def add_test() -> None:
    '''blah'''

def add_value(key, value) -> None:
    '''blah'''

def compile_info() -> typing.Tuple[str, str, str]:
    '''blah'''

def n_parameters(int) -> int:
    '''blah'''

def n_tests() -> int:
    '''blah'''


def run_test(i, calls, args, cout, cerr) -> typing.Tuple[object, float, typing.List[int], str, str]:
    '''blah'''

def test_info(int) -> typing.Tuple[str, str, int, str]:
    '''blah'''

def test_names() -> typing.List[str]:
    '''blah'''
