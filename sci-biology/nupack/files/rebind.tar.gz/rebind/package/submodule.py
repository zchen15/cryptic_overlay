
def fun(i, d) -> float:
    '''Example docstring for fun'''

def fun2(i, d, function=None):
    '''Example docstring for fun2'''
    return function(i, d)