#pragma once
#include "Matrix.h"
#include <eigen3/Eigen/Dense>

namespace nupack {

namespace traits {
    template <class, class=void>  struct is_eigen : False {};
    template <class T> struct is_eigen<T, void_if<derives_from<T, Eigen::EigenBase<T>>>> : True {};
}

template <class T> static constexpr bool is_eigen = traits::is_eigen<T>::value;

static_assert(is_eigen<Eigen::MatrixXd>, "Should be Eigen type");

template <class M, class ...Ts, NUPACK_IF(is_eigen<M>)>
void resize(M &m, Ts &&...ts) {m.resize(fw<Ts>(ts)...);}

template <class M, NUPACK_IF(is_eigen<M>)>
auto fliplr(M const &m) {return m.colwise().reverse();}

template <class M, NUPACK_IF(is_eigen<M>)>
auto flipud(M const &m) {return m.rowwise().reverse();}

}
