#pragma once
#include "../algorithms/TypeSupport.h"

namespace nupack {

/******************************************************************************************/

template <class F, class ...Ts>
struct dict : std::tuple<Ts...> {
    using base_type = std::tuple<Ts...>;
    static_assert(tuple_size<decltype(F{}())> == sizeof...(Ts), "number of names does not match");

    template <class ...Us, NUPACK_IF(can_construct<base_type, Us &&...>)>
    dict(Us &&...us) : base_type{fw<Us>(us)...} {}

    template <std::size_t ...Is>
    auto members(indices_t<Is...>) {return make_members(std::get<Is>(static_cast<base_type &>(*this)));}

    auto members() {return make_members(indices_in<base_type>());}
    static auto names() {return empty_lambda<F>{}();}
};

NUPACK_DEFINE_VARIADIC(is_dict, dict, class);
NUPACK_EXTEND_VARIADIC(is_like_tuple, dict, class);

/******************************************************************************************/

template <bool decay=false, class ...Ts, class F>
auto as_dict(std::tuple<Ts...> members, F) {
    return dict<F, if_t<decay, decay<Ts>, Ts>...>{std::move(members)};
}

template <class ...Ts>
auto make_dict(Ts &&...ts) {
    auto args = std::forward_as_tuple(ts...);
    return as_dict<true>(slice<0, sizeof...(Ts)-1>(args), std::get<sizeof...(Ts)-1>(args));
}

template <class F>
struct namer {
    dict<F, decay<Ts>...> operator()(Ts &&...ts) const {return {fw<Ts>(ts)...};}
};

template <class F> namer<F> make_namer(F) {return {};}


#define NUPACK_DICT(...) ::nupack::namer([] {return NUPACK_NAMES_F(__VA_ARGS__);})

/******************************************************************************************/

}
