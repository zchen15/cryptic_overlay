#pragma once
#include "../reflect/Print.h"
#include "../common/Runtime.h"
#include "Matrix.h"

namespace nupack {

/******************************************************************************************/

struct Log {
    NUPACK_REFLECT(Log, os);

    std::ostream &os;

    template <class ...Args> Log(Args &&...args) : os(fw<Args>(args)...) {};
    Log() : os(io::out()) {};

    template <class T, NUPACK_IF(is_arma<T>)>
    friend Log & operator<<(Log &log, T const &t) {t.save(log.os); return log;}

    template <class T, NUPACK_IF(!is_arma<T>)>
    friend Log & operator<<(Log &log, T const &t) {dump_os(log.os, t); return log;}
};

/******************************************************************************************/

}
