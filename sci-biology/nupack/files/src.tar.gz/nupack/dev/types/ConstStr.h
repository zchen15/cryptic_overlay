
/******************************************************************************************/

/// compile-time string with some constraints obviously
class const_string {
    char const * const data;
    std::size_t const sz_;
public:
    template <std::size_t N> constexpr const_string(const char(&a)[N]) : data(a), sz_(N-1) {}

    constexpr char operator[](std::size_t n) {return n < sz_ ? data[n] : throw std::out_of_range("");}

    constexpr std::size_t size() const {return sz_;}

    constexpr bool operator==(const_string const &c) const {
        if (c.size() != size()) return false;
        for (std::size_t i = 0; i <= size(); ++i)
            if(data[i] != c.data[i]) return false;
        return true;
    }

    operator char const *() const {return data;}
};