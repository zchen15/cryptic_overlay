#pragma once
#include "Basics.h"

namespace nupack {

/******************************************************************************************/

template <class T> class Value_Holder {
    T m_value;
public:
    static constexpr auto is_shared = hana::false_c;
    T & value() & {return m_value;}
    T && value() && {return static_cast<T &&>(m_value);}
    T const & value() const & {return m_value;}
    T const && value() const && {return static_cast<T const &&>(m_value);}
    template <class ...Ts>
    Value_Holder(Ts &&...ts) : m_value(fw<Ts>(ts)...) {}
    using basic_type = T;
    constexpr decltype(auto) value_info() const {return typeid(T);}
};

/******************************************************************************************/

template <class T, class P, class M> struct Reference_Holder : public Value_Holder<T> {
    using Parent = P;
    using Parent_Model = M;

    Parent &parent;
    std::shared_ptr<Parent_Model const> resource;
    static constexpr auto is_shared = hana::true_c;
    template <class R, class ...Ts> Reference_Holder(Parent &p, R &&r, Ts &&...ts)
        : Value_Holder<T>(fw<Ts>(ts)...), resource(fw<R>(r)), parent(p) {}
};

/******************************************************************************************/

template <class P, class M, class ...Ts, NUPACK_IF(!std::decay_t<M>::is_shared)>
auto make_reference_holder(P &parent, M &&model, Ts &&...ts) {
    using T = decltype(model.value()(fw<decltype(ts)>(ts)...));
    return Reference_Holder<T, P, std::decay_t<M>>(parent, model.shared_from_this(), model.value()(fw<Ts>(ts)...));
}

template <class P_, class M_, class ...Ts, class M=std::decay_t<M_>, NUPACK_IF(M::is_shared)>
auto make_reference_holder(P_ &, M_ &&model, Ts &&...ts) {
    using T = decltype(model.value()(fw<decltype(ts)>(ts)...));
    return Reference_Holder<T, typename M::Parent, typename M::Parent_Model>(
        model.parent, model.resource, model.value()(fw<Ts>(ts)...));
}

/******************************************************************************************/

}
