#pragma once
#include "Basics.h"
#include "Iterator.h"

namespace nupack {

/******************************************************************************************/

template <class Base>
class Contiguous_Data : public Base {
    using T = typename Base::value_type;
public:
    template <class ...Ts> auto contiguous_at(Ts &&...ts) {
        return Base::origin() + Base::offset(fw<Ts>(ts)...);
    }

    auto contiguous_iterator() {return decl(Base::origin());}

    auto contiguous_begin() {return Base::origin();}
    auto contiguous_end() {return Base::origin() + Base::n_elem();}

    auto contiguous_begin() const {return Base::origin();}
    auto contiguous_end() const {return Base::origin() + Base::n_elem();}

    Contiguous_Data & operator=(T const &t) {
        std::fill(contiguous_begin(), contiguous_end(), t);
        return *this;
    }

    template <class A, NUPACK_IF(A::rank == Base::rank)>
    Contiguous_Data & operator=(A const &a) {
        if (this->shape() != a.shape()) NUPACK_ERROR("bad");
        std::copy(a.contiguous_begin(), a.contiguous_begin(), contiguous_begin());
        return *this;
    }

    template <bool B=true, NUPACK_IF(B && !Base::rank)>
    operator no_ref<decltype(*declref<Base const>().origin())>() const {return *Base::origin();}

    template <class ...Ts> Contiguous_Data(Ts &&...ts) : Base(fw<Ts>(ts)...) {}
};

static constexpr auto contiguous_data = type_template <Contiguous_Data>;

/******************************************************************************************/

// Needs Shape to figure out n_elem
template <class T, class Shape>
class Own_Data : public Shape {
public:
    using value_type = T;
    std::vector<T> storage;

    static constexpr auto names() {return extend_names<Shape>("Storage");}
    auto members() {return extend_members<Shape>(this, storage);}

    auto origin() {return Contiguous_Iterator<T>(storage.data());}
    auto origin() const {return Contiguous_Iterator<T const>(storage.data());}
    template <class ...Ts> Own_Data(Ts &&...ts) : Shape(fw<Ts>(ts)...), storage(Shape::n_elem()) {}
};

static constexpr auto owns_data = reorder_(type_template <Own_Data>, 0_c, 1_c);

/******************************************************************************************/

template <class It, class Shape>
class Ref_Data : public Shape {
    It iter;
public:
    using value_type = no_ref<decltype(*iter)>;

    static constexpr auto names() {return extend_names<Shape>("Iterator");}
    auto members() {return extend_members<Shape>(this, iter);}

    auto origin() {return iter;}
    auto origin() const {return iter;}
    template <class ...Ts> Ref_Data(It i, Ts &&...ts) : Shape(fw<Ts>(ts)...), iter(i) {}
};

static constexpr auto references_data = hana::curry<4>(reorder_(hana::template_<Ref_Data>, 0_c, 2_c));

/******************************************************************************************/

}
