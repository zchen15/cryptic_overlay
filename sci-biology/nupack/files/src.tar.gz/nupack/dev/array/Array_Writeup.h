

Base = things defined by scalar
Default = Owning, Contiguous version of things defined by scalar
Dense or Sparse. Dense for now.

usize Span

Element_Mutable
Dimension_Mutable<I>
Size_Mutable
Shape_Mutable

Adds
Mutating_Adds
Multiplies
Mutating_Multiplies
Divides
Mutating_Divides

Dot_Product
Invertible

Data_Owning
Data_Sharing
Contiguous
Square
Rectangular
Random_Access
Column_Major





template <class T, usize N>
struct Contiguous_Array : std::enable_shared_from_this<Contiguous_Array<T, N>> {
    std::shared_ptr<Array> parent;
    double *data;
    std::array<usize, N> lower_bounds, upper_bounds;

public:

    Contiguous_Array(usize n) : data(new double[n]) {}

    template <class T> Contiguous_Array & operator=(T &&) const & = delete;
    template <class T> Contiguous_Array & operator=(T &&) const && = delete;

    Contiguous_Array & operator=(T t) & {
        if (parent && parent.use_count() > 1) this->copy_on_write(); // avoid modifying shared views 2==self
        if (!parent && shared_from_this().use_count() > 2) this->copy_on_write(); // avoid modifying shared views 2==self
        fill(data, t);
        return  *this;
    }

    Contiguous_Array && operator=(T t) && {
        if (parent && parent.use_count() > 2) this->copy_on_write();
        if (!parent && shared_from_this().use_count() > 1) this->copy_on_write();
        fill(data, t);
        return std::move(*this);
    }

    ~Contiguous_Array() {
        if (parent.get() == this) delete data;
    }
}

Root array:
    Option 1: parent is empty -- then test if empty before doing stuff -- cant tell though...
    Option 3: parent is self -- hmm. if is self, do not increment use_count at start. problem: cannot use shared_ptr then. or, test if self

is there any way parent would be accessed if it was empty?
    array has child references and is moved from -- could be possible

or weak_ptr

or empty field. no

ITEM 1: GET DEFAULT TRAITS FROM TEMPLATE ARGUMENTS

template <class T, std::size_t N>
struct Array_Traits {
    struct Copy = ;
    struct Move = ;
    struct Add = ;
    struct Mutating_Add = ;
    struct Indexable = ;
    struct Spannable = ;
    struct Column_Major = ;
    struct Data_Ownership = ;
    struct Construct = ;
};



template <class T, std::size_N, class Base=>
class Array {

protected:

    struct Concept {};

    struct Model : public Concept {};

    std::shared_ptr<Concept> self;

public:

    template <class ...Ts>
    Array(Ts &&...ts) {}

    template <class A>
    Array(A const &)

    template <class A>
    Array(A &&)

    template <class A>
    Array()

};

template <class T, std::size_t N, class Base=Default_Base<T, N>>
class Array {

    struct Concept : public Base {

    };

    template <class M>
    struct Model : public Concept {

    };

    std::shared_ptr<Concept> data;

public:

    enum class Storage_Order {Col_Major, Row_Major, Lazy, Flat, Constant};

    constexpr auto n_dimensions() const {return N;}
    Array const & operator=(Other) const & = delete;
    Array const & operator=(Other) const && = delete;

    void swap(Array &other);
    void swap(Array &&other);

    Array(Array &&a) = default;
    // IF COPYABLE
    Array(Array const &a) {self = a.self->clone();}

    // IF COPYABLE AND ASSIGNABLE -- don't mess with parent!
    Array & operator=(Other) & {
        if (parent && parent.use_count() > 1) self = this->clone();
        if (!parent && shared_from_this().use_count() > 2) self = this->clone();
        self->set(data, t);
        return *this;
    }

    // IF COPYABLE AND ASSIGNABLE -- mess with parent
    Array && operator=(Other) && {
        if (parent && parent.use_count() > 2) self = parent->clone();
        if (!parent && shared_from_this().use_count() > 1) self = this->clone();
        self->set(data, t);
        return std::move(*this);
    }

    // IF CONSTRUCTIBLE ({SHAPE, T}, {SHAPE}, {}) I think? maybe others like Identity
    template <class ...Ts>
    Array(Ts &&...ts) {}

    // ALWAYS CALLABLE
    auto begin() {return self->begin();}
    // ALWAYS CALLABLE
    auto end() {return self->end();}
    // SOMETIMES CALLABLE {usize, Span, vector}
    decltype(auto) operator()(i, j...) {return self->get(i, j...);}

    // ALWAYS CALLABLE
    bool storage_order();
    // ALWAYS CALLABLE
    template <std::size_t I> bool Indexable();
    // ALWAYS CALLABLE
    template <std::size_t I> bool vector_Indexable();
    // ALWAYS CALLABLE
    template <std::size_t I> bool spannable();

    // USUALLY CALLABLE
    std::array<std::size_t, N> shape();
    // USUALLY CALLABLE
    template <std::size_t I> size();
    // USUALLY CALLABLE
    std::size_t n_elements();
    // SOMETIMES CALLABLE
    std::array<std::size_t, N> strides()
    // MAYBE USEFUL
    origin();
    // MAYBE USEFUL
    T * data();
};


=========Concepts=========
Dimension<>
Data_Owning, Data_Sharing<N>
Contiguous<I>
Column_Major
Random_Access
Rectangular
Square
Extendable<I>, Shrinkable<I>
Copyable
Assignable
Indexable<T>
Evaluable

Constructor should take arguments, do make_shared<Default<Concept>>

======Expression Treatment======
Much easier if I can do compile time stuff
So:
    A + B returns Glue(plus_t, A, B)[=G] &&

Options:
    G(G &&) = delete --> user must cast into preferred type
    G(G &&g) {this->evaluate(g)} --> now object needs to hold an abstract slot
    G(hold(G &&)) ---> user can explicitly force expression storage

Or:
    A + B returns Abstract

Options:
    Would have to build runtime tree
    Would have to decide when to hold or evaluate
    Could potentially do more optimizations based on runtime values

Other option:
    Multiple options.

Thinking:
    Any expression has an equivalent evaluated expression which is terminal
    (Except Einstein type things...)
    The terminal expression type is known from the type of the expression
    (Or at least a superclass is known)
    A runtime tree could be instantiated with binary variant for each expression node
        (evaluated or not evaluated yet)
    The terminal expression may not be a subset or superset of the expression
    Compile time logic can be put into the type
    The expression containing object has at least the functionality of the terminal expression
        since it may be cast into it
    Some types (Einstein compile time e.g.) would not have a terminal expression
        or I guess they could, just wouldn't be evaluated

So:
    the object could be cast into a terminal via (auto x = expr);
    the object could be retained with Full info if no casts
    extra logic would have to be put in to see if it was cast already

NOTE!!
    could an expression be an rvalue if it was evaluated == true?
        this would occur with:
        auto x = expr;
        auto y = std::move(x);
    that is a potential use case...
        can the evaluation status be constexpr? prob not
        well, might be

    could an expression be an lvalue if it was evaluated == false?
        -- yes-ish, but only by cast via hold() which would be different type I believe

Polymorphism would be useful for tackling Python in future.
OK. what is the point (what could be accomplished) by having compile time logic?
    easier storage of function operators
    easier storage of heterogeneous sequences
    probably easier use of template libraries for inner routines
    user customization with struct specialization, etc.

hmm.

structure design
we'd have something like:
template <class Expression_Concept, class Result_Concept>
class Array {

    std::shared_ptr<Expression_Concept> expr;
    std::shared_ptr<Result_Concept> result;
    bool evaluated;

public:

};

(combine if same)

should I store this as:
    2 shared_ptrs, 1 empty
or
    1 variant of a shared_ptr
or
    shared_ptr to base class of both
hmm.

other possibility is destructor driven thing
would be possible with current design except terminals must know about derivatives
I think that was too hard because of the issues of lifetime destruction order

I guess 32 bytes is tiny...just use 2 shared_ptr s and a bool

operator auto is dead for now

Another choice:

Contiguous_Array...

implement this as inherited final from a concept?
no, I dont think so.
implement via whatever means (could be separate inheritance) to fit the interface.


what is interface for contiguous array:
element access

constexpr is better to use hana-style
depend on return type deduction rather than return value
the same function can be used at runtime or compile time, substituting real types with
compile time ones


what are the computations being done?
input values --> output values
input values/types -> (input values --> output values)

the simplest (input -> routine function) is eager evaluation
---> complicated (input -> routine function) as subclass of eager one

if class is known, use compile time logic
if class is not known, use eager evaluation (+ runtime logic maybe)

use scalar type to define operations
(Matrix + Matrix) is subclass of Matrix

what defines an expression?
map of input elements to output elements
elementwise is simple 1:1
subarray --> map only some inputs to outputs

hana::Lazy to yield functions rather than output values
have to return rvalue references, gurbleh



what does C = Matrix A + Matrix B contain??

1. slot for evaluated data
    i.e. double *
2. slot for:
    type Glue(Matrix + Matrix)
    A and B

embeddable computation, interesting

arma style would be just 2. however then python, runtime work is impossible

OPTIONS
1: variant of the 2
2: have slot 2 be subclass of 1, follows interface
3: just have 1 virtual implementing eval()
4. 2 shared_ptrs for each concept

problem with variant: cannot do runtime variation on return types etc
problem with 4: redundant
problem with 3: have to make the class rather than follow the interface

2: it's either the known type or it's some subclass of the eval class
seems like many of the known type things would do eval(), f() instead of f()

what about A + B + C
B + C --> Array<double, Contiguous, Glue(Matrix + Matrix)
A + (B + C) --> ???.
cannot embed now...
    could be eval(A + B + C)
    or A + eval(B + C)
    or A + B + C
eval may have been called anywhere along the way
    ---> for n node expression, n possibilities (because eval of eval is eval)

Aim 1:
    code should work with Lazy matrix objects
    (via templating?) yes I think so, this is C++...

Aim 2:
    adaptable to Python (Lazy and not)

Quandary:
    when to eval.
        on cast to lvalue
        on destructor (no)
        on explicit eval() (yes, probably)
        an rvalue holds references

A + B with A, B Contiguous_Array


should return type info, not abstract class I think.
but then if eval is allowed on lvalue cast...is mess.
    because rvalue-ness does not guarantee that it's unevaluated
        could have evaluated then called std::move()
    though lvalue-ness should guarantee that it's evaluated
        as long as my functions return rvalue refs
        NO - const & can bind to &&

maybe should just rely on eval() ?

some usage would use for loops, --> need eval beforehand and eager evaluation

one possibility:
    remove std::move for (Array const) (change to cast to lvalue ref?)

rvalue references like A+B should be const &&, not && since they don't modify

unless they need to for ref counting...? I don't think so, that is just a read.

possibilities for input:
    & - must be user owned, then it must be eval
    const & - must be user owned, then it must be eval...wait

    && - could be user moved from
    const && - possibly user moved from, usually just my result type

doh. const & can bind to &&. could kill this approach :(
subarray should still be fine though, const & wont modify.

so, looks like lvalue binding is impossible!
because no matter what, user could pass rvalue reference into const lvalue function.
and library would think it was lvalue, therefore eval.

in sum, lvalue definitely does not imply evaluation, and rvalue almost certainly does not
imply unevaluation, unless some major hacking is done (for std::move etc.).

runtime checks would have to be done period. not much different than abandoning the reference
treatment and just putting a bool in. gurbleh!!

Quandary:
    when to eval.
        on cast to lvalue (dead! because of const & binding issue)
        on destructor (no!)
        on explicit eval() (yes, probably)
        on cast to specific value (sure, why not)

idea: |= for assignment things.

question, what happens if I say
    auto A=B+B;
    for (auto i : range(1000))
        A(i) += 1;

A has decltype Glue(B+B)
how can it do (1, 1)

option 1: dynamic_cast inside to eval type
option 2: prevent and force user to eval()

auto A_mod = A(1, :).transform([](auto i){return i + 1;})
implications for python....

auto B = A + C + D, eval;  --> if eval did not change type of B.

simple question now. glue is in place. but, does eval change type?

pro: can get rid of extra type junk after eval
     no runtime check needed for evaluation
con: can not treat glues as mutable

auto B = A + C

Concepts:
Element_Mutable
Dimension_Mutable<I>
Size_Mutable
Shape_Mutable

Dot_Product
Invertible

Contiguous
Square
Rectangular
Random_Access
Column_Major

operations:
elementwise
map input to output
what is useful beyond the concepts
    - can commute
    - can append other expression
    - can prepend other expression
    - can steal memory

symbolic stuff -> need functional style api
is there a way of couching functional style api inside mutable one
or do i have to use just functional


plus(A, B) + C --> plus(A, B, C)
times(A, B) * C --> times(A, B, C)

auto C = A + B | eval;
C(1, 2) = 3;
C(3, 4) = C(:, 2);

auto D = C | where([](auto i, auto j){return j < i;});

compile time
A + B --> +(Array, Array)  === (i -> double)
runtime
A + B -->


resolved on dynamic lookup.

contiguous_array {
    memory ---
}

should memory be a raw pointer/struct, or a shared_ptr to a struct, or a shared_ptr to a Contiguous_Array
Contiguous_Array should be immutable I think
how to do c o s?
do slices refer to the array or to the storage

if slice refers to the array, then can just store storage.
if slice refers to the storage, then storage needs to be shared_ptr
I think it should be a raw pointer/struct to avoid the double shared_ptr. Array IS the raw storage. Need a different name...
