#pragma once

namespace nupack {

/******************************************************************************************/

template <class Base, class ...Bases>
struct Array_Mixer : public Base, public Bases... {
    template <class ...Ts> Array_Mixer(Ts &&...ts) : Base(fw<Ts>(ts)...) {}

    template <class T, NUPACK_IF(std::is_assignable<Base, T>::value)>
    Array_Mixer & operator=(T const &t) {Base::operator=(t); return *this;}
};

/******************************************************************************************/

struct array_t {
    template <class C> auto operator()(C constraints) const {
        auto rank = constraints.rank();
        auto contiguity = maybe_c(constraints.contiguity(), rank);
        auto type = constraints.value_type_c();
        auto shape = rectangular(rank);

        auto ownership = owns_data(type, shape, contiguity);
        auto data = hana::make_tuple(contiguous_data(ownership));

        auto Indexable = all_access(hana::partial(contiguous_ref, CRTP), contiguity); // --> gives tuple of mixins
        auto spannable = span_access(hana::partial(contiguous_ref, CRTP), contiguity); // --> gives tuple of mixins

        return hana::unpack(hana::flatten(hana::make_tuple(data, Indexable, spannable)), hana::template_<Array_Mixer>);
    }
};

/******************************************************************************************/

}
