#pragma once
#include <nupack/standard/Ptr.h>
#include "Virtual.h"
#include "Constraints.h"
#include "Holder.h"

namespace nupack {

/******************************************************************************************/

class Typed {
    template <class T> struct Interface {using value_type = T;};
public:
    template <class M, class C> auto operator()(M, C constraints) const {
        return hana::make_tuple(type_template <Interface>(value_type_of(constraints)));
    }
};

/******************************************************************************************/

class Allocated {
    template <class C> struct Implementation {
        template <class ...Ts>
        static auto shared(Ts &&...ts) {return std::make_shared<C>(fw<Ts>(ts)...);}
    };
    template <class C> struct Interface {};
public:
    template <class M, class C> auto operator()(M meta, C constraints) const {
        return hana::make_tuple(type_template <Interface>(meta(constraints)), type_template <Implementation>);
    }
};

/******************************************************************************************/

struct Ranked {
    template <int N> struct Interface {static constexpr int const rank_value = N;};
public:
    template <class M, class C> auto operator()(M, C constraints) const {
        return hana::make_tuple(int_template <Interface>(rank_of(constraints)));
    }
};

template <int N> constexpr int Ranked::Interface<N>::rank_value;

/******************************************************************************************/

class Fillable {
    struct Tag {using type = Tag;};

    template <class O, class C> struct Implementation {
        auto operator()(Tag, O other) && {crtp_move<C>(this).value() = fw<decltype(other)>(other); return true;}
    };

    template <class O, class C> struct Interface {
        C && assign(O other) && {
            C &&c = crtp_move<C>(this);
            if (!c.ptr->vcall(std::move(*c.ptr), Tag(), fw<decltype(other)>(other)))
                NUPACK_ERROR("not implemented");//static_cast<C &>(*this) = C(other);
            return std::move(c);
        }
    };

    static constexpr auto implementation = hana::curry<2>(type_template <Implementation>);

public:

    template <class M, class C> auto operator()(M meta, C constraints) const {
        auto crtp = meta(constraints);
        auto vt = value_type_of(constraints);
        auto sig = signature(rvalue, bool_type, Tag(), const_lvalue(vt));
        return hana::make_tuple(type_template <Interface>(vt, crtp), implementation(vt), sig);
    }
};

/******************************************************************************************/

// A concept should return functionality which:
// fulfills the concept at compile time if the constraints can be met at compile time (never throw)
// fulfills the concept at runtime if the constraints can be met at runtime (throw otherwise)
// does not fulfill the concept at all if the constraints can never be met

// A type which is input should be checked against the compile time constraints
// If there are runtime constraints which it is also compatible with
// it should be constructed in a model with this extra functionality
// and a reference_obj should be constructed for a model with the requested functionality
// the reference_obj will hold a reference of the original model value (fully specified)
// as well as a shared_ptr of its owner. or maybe the deleter will have the owner?
// probably better to just put in the object (can maybe reduce to the base class, only use_count matters) (unless downcasting)
// downcast: give a more specific interface and construct an object to match it
// for Reference_Holder, easy. just use the reference object to make a new reference for that interface
// if it's not a reference_holder, value must not obey the concept (or the concept was not registered)
// then throw() with bad_concept_cast

class Contiguous_View {


public:
    struct Tag {};

//    template <class M, class C> constexpr auto operator()(M meta, C constraints) const {
//        auto crtp = meta(constraints);
//        auto sig = signature_c<CL_Tag, View<Contiguous_Iterator<typename C::type::value_type>>, Tag>;
//    }
};

/******************************************************************************************/

class Assignable {
    struct Tag {using type = Tag;};

    template <class O, class C> struct Implementation {
        void operator()(Tag, O other) && {
            crtp_move<C>(this).value() = fw<decltype(other)>(other);
        }
    };

    template <class C> struct Interface {
        template <class T> C && assign_array(T &&o) && {
            C &&c = crtp_move<C>(this);
            if (c.constraints.contiguity == c.constraints.rank &&
                o.constraints.contiguity == o.constraints.rank)
                copy_range(c.vcall(Contiguous_View::Tag()), o.vcall(Contiguous_View::Tag()));
            return std::move(c);
        }
    };

    static constexpr auto implementation = hana::curry<2>(type_template <Implementation>);

public:

    template <class M, class C> auto operator()(M meta, C constraints) const {
        auto crtp = meta(constraints);
        auto sig = signature(rvalue, void_type, Tag(), const_lvalue(crtp));
        return hana::make_tuple(type_template <Interface>(crtp, crtp), implementation(crtp), sig);
    }
};

/******************************************************************************************/

class Rectangular {
    struct Shape {using type = Shape;};
    struct N_Elem {using type = N_Elem;};

    template <class C> struct Implementation {
        auto operator()(Shape) const {return crtp_cast<C>(this).value().shape();}
        auto operator()(N_Elem) const {return crtp_cast<C>(this).value().n_elem();}
    };

    template <class C> struct Interface {
        auto shape() const {return crtp_cast<C>(this).vcall(Shape());}
        auto n_elem() const {return crtp_cast<C>(this).vcall(N_Elem());}
    };

public:

    template <class M, class C> constexpr auto operator()(M meta, C constraints) const {
        auto s = type_of(replicate(usize(), rank_of(constraints)));
        return hana::make_tuple(type_template <Interface>(meta(constraints)), type_template <Implementation>,
            signature(const_lvalue, s, Shape()), signature(const_lvalue, type_c<usize>, N_Elem()));
    }
};

/******************************************************************************************/

class Streamable {
    struct Tag {using type = Tag;};

    template <class C> struct Implementation {
        void operator()(Tag, std::ostream &os) const {print_os(os, crtp_cast<C>(this).value());}
    };

    template <class C> struct Interface {
        friend std::ostream & operator<<(std::ostream &os, Streamable const &s) {crtp_cast<C>(s).vcall(Tag(), os);}
    };

public:

    template <class M, class C> auto operator()(M meta, C constraints) const {
        return hana::make_tuple(type_template <Interface>(meta(constraints)), type_template <Implementation>,
                                signature(const_lvalue, void_type, Tag(), type_c<std::ostream &>));
    }
};

/******************************************************************************************/

struct Share_Accessible {
    struct Tag {using type = Tag;};

    NUPACK_LAMBDA3(get_signature) = [](auto meta, auto constraints, auto ref, auto ...ts) {
        auto ret = meta(type_of(replace_constraint(*constraints, *rank_constraint(result_rank(ts...)))));
        return signature(lvalue, ret, type_c<Tag>, ref, ts...);
    };

    template <class Ref, class C, class ...Ts> struct Implementation {
        decltype(auto) operator()(Tag, Ref p, Ts ...ts) {
            auto &self = crtp_cast<C>(this);
            return make_reference_holder(p, self, fw<decltype(ts)>(ts)...);
        }
    };

    template <class C, class ...Ts> struct Interface {
        decltype(auto) operator()(Ts ...ts) {
            auto &self = crtp_cast<C>(this);
            return self.vcall(Tag(), self, fw<decltype(ts)>(ts)...);
        }
    };

    static constexpr auto enable_shared = type_template <std::enable_shared_from_this>;

public:

    template <class M, class C> auto operator()(M meta, C constraints) const {
        auto ref = lvalue(meta(constraints));
        auto signature_gen = hana::partial(get_signature, meta, constraints, ref);
        auto signatures = all_access(signature_gen, rank_of(constraints));
        auto arguments = all_access(hana::make_tuple, rank_of(constraints));

        auto iface_gen = hana::fuse(hana::partial(type_template <Interface>, meta(constraints)));
        auto iface = fuse_types(hana::transform(arguments, iface_gen));

        auto implementation = hana::fuse(hana::partial(type_template <Implementation>, ref));
        // result = args -> (crtp -> impl)
        auto args_to_impl_gen = hana::curry<2>(hana::demux(implementation)(hana::prepend));
        // result = tuple(crtp -> impl)
        auto impl_gens = hana::append(hana::transform(arguments, args_to_impl_gen), enable_shared);
        // result = crtp -> combined impl
        auto impl = hana::unpack(impl_gens, hana::demux(mix_types));
        return hana::prepend(hana::prepend(signatures, impl), iface);
    }

};

/******************************************************************************************/

}
