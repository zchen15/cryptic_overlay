#pragma once
#include "Basics.h"
#include <nupack/algorithms/Functional.h>

namespace nupack {

/******************************************************************************************/

template <class T> constexpr auto make_mask(T const &t) {
    return hana::scan_left(t, usize{1}, hana::mult);
}

constexpr auto begin_position(usize s) {return s;}
constexpr auto begin_position(All) {return 0;}
constexpr auto begin_position(Span s) {return s.a;}

/******************************************************************************************/

template <class ...Ts> class Rectangular_Shape {
protected:
    hana::tuple<Ts...> dimensions;
    decltype(make_mask(dimensions)) mask;

    struct Extent {
        constexpr auto operator()(usize d, All) const {return d;}
        constexpr auto operator()(usize, Span s) const {return s.b - s.a;}
        constexpr auto operator()(usize, usize) const {return hana::nothing;}
    };

public:
    NUPACK_REFLECT(Rectangular_Shape, dimensions, mask);

    template <class ...Es> constexpr auto extents(Es &&...es) const {
        return hana::remove(hana::zip_with(Extent(), dimensions, hana::make_tuple(fw<Es>(es)...)), hana::nothing);
    }

    static constexpr auto rank = hana::size_c<sizeof...(Ts)>;

    auto shape() const {return dimensions;}

    auto n_elem() const {return hana::back(mask);}

    auto offset(Ts ...ts) const {
        return hana::sum<usize>(hana::zip_with(hana::mult, hana::make_tuple(ts...), mask));
    }

    Rectangular_Shape(hana::tuple<Ts...> a) : dimensions{std::move(a)}, mask(make_mask(dimensions)) {}

    Rectangular_Shape() = default;

    template <bool B=true, NUPACK_IF(B && sizeof...(Ts))>
    Rectangular_Shape(Ts ...ts) : dimensions{ts...}, mask(make_mask(dimensions)) {}
};

/******************************************************************************************/

//static constexpr auto rectangular = hana::compose(hana::fuse(type_template <Rectangular_Shape>), replicate(size_type));

NUPACK_LAMBDA(rectangular, [](auto n) {
    return hana::unpack(replicate(size_type, n), hana::template_<Rectangular_Shape>);
});

/******************************************************************************************/

}
