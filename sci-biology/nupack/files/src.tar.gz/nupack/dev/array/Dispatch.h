#pragma once
#include "Shape.h"
#include "Access.h"

namespace nupack {

// I think maybe Dispatch should map Constraints -> Implementation
// so construction with constraints should give an impl, functionality yields compatible impls, etc.
//



/******************************************************************************************/

template <class Option_Tuple> class Array_Options {
protected:

    static constexpr auto Type = 0_c; // double_c
    static constexpr auto Rank = 1_c; // 1_c, 2_c ...
    static constexpr auto Shape = 2_c; // rectangular
    static constexpr auto Ownership = 3_c; // owns_data, references_data, shares_data
    static constexpr auto Contiguity = 4_c; // 1_c, 2_c ...
    template <class ...Ts> static auto make(hana::tuple<Ts...> ops) {return Array_Options<hana::tuple<Ts...>>{ops};}

public:
    using options_type = Option_Tuple;
    options_type options;

    template <class T> auto with_type(T t) {return make(set_at(options, Type, t));}
    template <class T> auto with_rank(T t) {return make(set_at(options, Rank, t));}
    template <class T> auto with_shape(T t) {return make(set_at(options, Shape, t));}
    template <class T> auto with_ownership(T t) {return make(set_at(options, Ownership, t));}
    template <class T> auto with_contiguity(T t) {return make(set_at(options, Contiguity, t));}
};

/******************************************************************************************/

template <template <class> class Array_N, class Option_Tuple>
class Dispatch : public Array_Options<Option_Tuple> {
    using base_type = Array_Options<Option_Tuple>;
    static constexpr auto CRTP = type_c<Array_N<Option_Tuple>>;

    // Returns the compatible array type
    static auto dispatch(typename Base::options_type const &ops) {
        auto type = ops[Base::Type];
        auto rank = ops[Base::Rank];
        auto shape = ops[Base::Shape](ops[Base::Rank]);
        auto contiguity = ops[Base::Contiguity];
        auto ownership = ops[Base::Ownership](type, shape, contiguity);
        auto data = hana::make_tuple(contiguous_data(ownership));

        auto Indexable = all_access(hana::partial(contiguous_ref, CRTP), contiguity); // --> gives tuple of mixins
        auto spannable = span_access(hana::partial(contiguous_ref, CRTP), contiguity); // --> gives tuple of mixins

        return hana::unpack(hana::flatten(hana::make_tuple(data, Indexable, spannable)), hana::template_<Array_Mixer>);
    }

public:

    using mixin_type = decltype(*dispatch(declval<typename Base::options_type>()));

    template <class New_Array_Options>
    constexpr auto derived_type_c(New_Array_Options ops) const {
        return hana::template_<Array_N>(type_of(ops.options));
    }
};

/******************************************************************************************/

//template <class T, class N, class Override>
//using Pack_Array_Options = std::conditional_t<is_same<Override, void>,
//    decltype(hana::make_tuple(type_c<T>, int_c<N>, rectangular, owns_data, int_c<N>)), Override
//>;

/******************************************************************************************/

template <class Type, int N, class Options=decltype(hana::make_tuple(rectangular, owns_data, int_c<N>))>
class Array;

template <class T> using void_to_empty_tuple = std::conditional_t<is_same<T, void>, hana::tuple<>, T>;
template <class T> using empty_tuple_to_void = std::conditional_t<is_same<T, hana::tuple<>>, void, T>;

template <class Type, int N, class Options>
using Pack_Options = decltype(hana::concat(hana::make_tuple(type_c<Type>, int_c<N>),
                                           declval<void_to_empty_tuple<Options>>()));

template <class Options>
using Array_N = Array<typename decltype(+declval<Options>()[0_c])::type,
                      decltype(+declval<Options>()[1_c])::value,
                      empty_tuple_to_void<decltype(hana::remove_range_c<0, 2>(declval<Options>()))>>;

/******************************************************************************************/

// Takes concepts and returns a compatible array type
template <class Type, int N, class Options>
class Array : public Dispatch<Array_N, Pack_Options<Type, N, Options>>::mixin_type,
              public Dispatch<Array_N, Pack_Options<Type, N, Options>> {

    using Disp = Dispatch<Array_N, Pack_Options<Type, N, Options>>;
    using base_type = typename Disp::mixin_type;

public:

    using Disp::options;

    template <class ...Ts> Array(Ts &&...ts) : Base{fw<Ts>(ts)...} {}
    template <class ...Ts> Array(decltype(Disp::options) ops, Ts &&...ts) : Base{fw<Ts>(ts)...}, Disp{ops} {}

    template <class T> Array & operator=(T &&t) {Base::operator=(fw<T>(t)); return *this;}
    Array & operator=(Array const &t) = default;
    Array & operator=(Array &&t) = default;
};

/******************************************************************************************/

}
