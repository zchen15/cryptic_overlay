#pragma once
#include "Basics.h"

namespace nupack {

/******************************************************************************************/

struct Rank_Tag {};
struct Type_Tag {};
struct Contiguity_Tag {};

static constexpr auto const rank_tag = Rank_Tag();
static constexpr auto const type_tag = Type_Tag();
static constexpr auto const contiguity_tag = Contiguity_Tag();

/******************************************************************************************/

struct Compare_ID {
    template <class T1, class T2>
    constexpr auto operator()(T1 const &t1, T2 const &t2) const {return t1.id() > t2.id();}
};

/******************************************************************************************/

template <class Type> struct Type_Constraint {
    using value_type = Type;
    constexpr auto id() const {return "type"_s;}
    constexpr auto value_type_c() const {return type_c<Type>;}
};

static constexpr auto type_constraint = type_template <Type_Constraint>;
NUPACK_LAMBDA3(value_type_of) = [](auto t) {return type_c<typename decltype(*t)::value_type>;};

/******************************************************************************************/

template <bool C> struct Storage_Order_Constraint {
    static constexpr bool column_major = C;
    constexpr auto id() const {return "storage"_s;}
    constexpr auto storage_order_c() const {return bool_c<C>;}
};

/******************************************************************************************/

template <int N> class Rank_Constraint {
    maybe_uint8<N> value;
public:
    static constexpr auto rank_value = N;
    constexpr Rank_Constraint(maybe_uint8<N> v={}) : value(v) {}
    constexpr auto id() const {return "rank"_s;}
    constexpr auto rank() const {return value;}
};

static constexpr auto rank_constraint = int_template <Rank_Constraint>;
NUPACK_LAMBDA3(rank_of) = [](auto t) {return int_c<decltype(*t)::rank_value>;};

/******************************************************************************************/

template <int N> class Contiguity_Constraint {
    maybe_uint8<N> value;
public:
    static constexpr auto contiguity_c = N;
    constexpr Contiguity_Constraint(maybe_uint8<N> v={}) : value(v) {}
    constexpr auto id() const {return "contiguity"_s;}
    constexpr auto contiguity() const {return value;}
};

static constexpr auto contiguity_constraint = int_template <Contiguity_Constraint>;

/******************************************************************************************/

template <bool B> struct Disjoint_Constraint {
    static constexpr auto disjoint = B;
    constexpr auto id() const {return "disjoint"_s;}
    constexpr auto disjoint_c() const {return bool_c<B>;}
};

/******************************************************************************************/

struct Shareable_Constraint {
    constexpr auto id() const {return "shareable"_s;}
};

struct Source_Constraint {
    constexpr auto id() const {return "source"_s;}
};

/******************************************************************************************/

template <class ...Constraints>
class Sorted_Array_Constraints;

template <class Cs> auto sorted_array_constraints(Cs cs) {
    auto c = hana::sort(cs, Compare_ID());
    return hana::unpack(c, [](auto ...cs) {return Sorted_Array_Constraints<decltype(cs)...>(cs...);});
}

template <class ...Constraints>
class Sorted_Array_Constraints : public Constraints... {
    constexpr void id() {}

public:
    static_assert(is_same<decltype(hana::sort(declval<hana::tuple<Constraints...>>(),
        Compare_ID())), hana::tuple<Constraints...>>, "Constraints not in order");

    Sorted_Array_Constraints() = default;
    Sorted_Array_Constraints(Constraints ...cs) : Constraints(std::move(cs))... {}

    template <bool B=true, NUPACK_IF(B && sizeof...(Constraints) <= 2)>
    void reduced_type() const {}

    template <bool B=true, NUPACK_IF(B && sizeof...(Constraints) >= 3)>
    auto reduced_type() const {
        auto cs = hana::make_tuple(Constraints(*this)...);
        auto rs = hana::remove_if(cs, [](auto r){return r.id() == "type"_s || r.id() == "rank"_s;});
        return sorted_array_constraints(rs);
    }

    auto as_tuple() const {return hana::make_tuple(Constraints(*this)...);}

    template <class T> static auto with_c(T t) {
        return type_of(declval<Sorted_Array_Constraints>().with(declval(t)));
    }
};

NUPACK_LAMBDA3(replace_constraint) = [](auto c, auto to) {
    auto rs = hana::replace_if(c.as_tuple(), [=](auto c1){return c1.id() == to.id();}, to);
    return sorted_array_constraints(rs);
};

/******************************************************************************************/

namespace detail {
template <class T, int N>
Sorted_Array_Constraints<Type_Constraint<T>, Rank_Constraint<N>> expand_constraints(void *);

template <class T, int N, class ...Cs>
Sorted_Array_Constraints<Type_Constraint<T>, Rank_Constraint<N>, Cs...> expand_constraints(Sorted_Array_Constraints<Cs...> *cs);
}

/******************************************************************************************/


template <class ...Cs> using Array_Constraints = decltype(sorted_array_constraints(hana::make_tuple(declval<Cs>()...)));
template <class T, int N, class C> using Expanded_Constraints = decltype(detail::expand_constraints<T, N>((C *) nullptr));

static constexpr auto array_constraints = hana::template_<Array_Constraints>;

}
