#pragma once
#include "Data.h"
#include "Basics.h"

namespace nupack {

/******************************************************************************************/

template <class CRTP, class ...Ts> struct Contiguous_Ref {
    auto operator()(Ts ...ts) {
        auto &self = crtp_cast<CRTP>(this);
        auto n = result_rank(type_of(ts)...);
        auto it = self.contiguous_at(begin_position(ts)...);

        using R = decltype(*self.derived_type_c(self
            .with_rank(n)
            .with_contiguity(n)
            .with_ownership(references_data(type_of(it)))
        ));

        return R(it, self.extents(ts...));
    }
};

static constexpr auto contiguous_ref = type_template <Contiguous_Ref>;

/******************************************************************************************/

NUPACK_LAMBDA3(all_access_i) = [](auto meta, auto n_all, auto n_int) {
    return hana::unpack(hana::concat(replicate(all_type, n_all), replicate(size_type, n_int)), meta);
};

NUPACK_LAMBDA3(all_access) = [](auto meta, auto n_slot) {
    return hana::unpack(hana::make_range(0_c, n_slot + 1_c), [=](auto ...is) {
        return hana::make_tuple(all_access_i(meta, is, n_slot-is)...);
    });
};

NUPACK_LAMBDA3(span_access_i) = [](auto meta, auto n_all, auto n_int) {
    return hana::unpack(hana::concat(hana::append(
        replicate(all_type, n_all), span_type), replicate(size_type, n_int)), meta);
};

NUPACK_LAMBDA3(span_access) = [](auto meta, auto n_slot) {
    return hana::unpack(hana::make_range(0_c, n_slot), [=](auto ...is) {
        return hana::make_tuple(span_access_i(meta, is, n_slot-is-1_c)...);
    });
};

/******************************************************************************************/

}
