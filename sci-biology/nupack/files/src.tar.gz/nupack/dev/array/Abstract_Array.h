#pragma once
#include "Constraints.h"

namespace nupack {

/******************************************************************************************/

static constexpr auto Static_Concepts = hana::make_tuple(Streamable(), Rectangular(), Typed(), Ranked(), Fillable(), Share_Accessible(), Allocated());

/******************************************************************************************/

template <class C, class ...Bases>
struct Abstract_Interface : public Bases... {
    C constraints;
    template <class ...Ts> Abstract_Interface(Ts &&...ts) : constraints(fw<Ts>(ts)...) {}
};

static constexpr auto abstract_interface = hana::fuse(hana::template_<Abstract_Interface>);

/******************************************************************************************/

template <class M, class C> auto abstract_dispatch(M meta, C constraints) {
    auto concepts = fmap(Static_Concepts, meta, constraints);
    auto signatures = hana::chain(concepts, all_after(2_c));
    auto concept = hana::partial(calculate_abstract, signatures);
    auto impls = filter_out_nothing(hana::transform(concepts, optional_at(1_c)));
    auto virtual_impl = hana::partial(calculate_impl, signatures);
    auto model = [=](auto crtp, auto base) {return fuse_types(hana::prepend(fmap(impls, crtp), virtual_impl(crtp, base)));};
    auto iface = abstract_interface(hana::prepend(hana::transform(concepts, hana::front), constraints));
    return hana::make_tuple(iface, model, concept);
}

NUPACK_DETECT(is_holder, typename T::basic_type);

/******************************************************************************************/

template <template <class> class Meta, class Type, int N, class Extras>
class Abstract_Dispatch {
    static constexpr auto constraints = type_c<Expanded_Constraints<Type, N, Extras>>;
    using T = decltype(abstract_dispatch(hana::template_<Meta>, constraints));

public:

    using array_base = decltype(*declval<T>()[0_c]);

    template <class Concept, class Model>
    using model_base = decltype(*declval<T>()[1_c](type_c<Concept>, type_c<Model>));

    template <class Concept>
    using concept_base = decltype(*declval<T>()[2_c](type_c<Concept>));
};

/******************************************************************************************/

template <class Type, int N, class Extras=void>
class Abstract_Array;

template <class Constraints> using Abstract_Array_N = Abstract_Array<
    typename Constraints::value_type, Constraints::rank_value,
    decltype(declval<Constraints>().reduced_type())
>;

/******************************************************************************************/

template <class Type, int N, class Extras>
class Abstract_Array : public Abstract_Dispatch<Abstract_Array_N, Type, N, Extras>::array_base {
    using Dispatch = Abstract_Dispatch<Abstract_Array_N, Type, N, Extras>;

    struct Concept : public Dispatch::template concept_base<Concept> {virtual ~Concept() = default;};

    template <class T>
    struct Model final : public T, public Dispatch::template model_base<Model<T>, Concept> {
        template <class ...Ts> Model(Ts &&...ts) : T{fw<Ts>(ts)...} {}
    };

public:

    /**************************************************************************************/

    std::shared_ptr<Concept> ptr;

    Concept const & self() const {return *ptr;}
    std::shared_ptr<Concept const> pointer() const {return ptr;}

    template <class ...Ts>
    decltype(auto) vcall(Ts &&...ts) const {return ptr->vcall(*ptr, fw<Ts>(ts)...);}

    template <class ...Ts> decltype(auto) vcall(Ts &&...ts) {
        auto valid = hana::is_valid([](auto&& p) -> decltype((void) p->vcall(*p, fw<Ts>(ts)...)) {});
        using Test = Test_OK<decltype(valid(ptr))::value, hana::tuple<Ts...>>;
        static_assert(Test::is_ok, "Invalid arguments to vcall");
        return ptr->vcall(*ptr, fw<Ts>(ts)...);
    }

    /**************************************************************************************/

    explicit Abstract_Array() = default;

    template <class T, class M=Model<Value_Holder<std::decay_t<T>>>, NUPACK_IF(!is_holder<std::decay_t<T>>)>
    explicit Abstract_Array(T &&t) : ptr(M::shared(fw<T>(t))) {}

    template <class T, class M=Model<std::decay_t<T>>, NUPACK_IF(is_holder<std::decay_t<T>>)>
    explicit Abstract_Array(T &&t) : ptr(M::shared(fw<T>(t))) {}

    template <class T, class ...Ts, NUPACK_IF(sizeof...(Ts))>
    explicit Abstract_Array(hana::type<T>, Ts &&...ts) : ptr(Model<Value_Holder<T>>::shared(fw<Ts>(ts)...)) {}

    /**************************************************************************************/

    Abstract_Array(Abstract_Array &&) = default;
    Abstract_Array(Abstract_Array const &) = default;

    Abstract_Array & operator=(Abstract_Array  &) = default;
    Abstract_Array & operator=(Abstract_Array &&) = default;
    Abstract_Array & operator=(Abstract_Array const &) = default;

    template <class T> decltype(auto) operator=(T &&t)  & {return this->assign(fw<T>(t));}
    template <class T> decltype(auto) operator=(T &&t) && {return std::move(*this).assign(fw<T>(t));}

    decltype(auto) model_info() const {return typeid(*ptr);}
    decltype(auto) model_name() const {return demangle(typeid(*ptr).name());}

    /**************************************************************************************/
};

/******************************************************************************************/

}
