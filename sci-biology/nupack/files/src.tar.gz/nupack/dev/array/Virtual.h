#pragma once
#include <boost/preprocessor/repetition/repeat.hpp>
#include <boost/preprocessor/seq/for_each.hpp>
#include "Basics.h"

#define PACK_LENGTHS (0)(1)(2)(3)(4)(5)(6)(7)

/******************************************************************************************/

#define PACK_VIRTUAL_TEMPLATE_N(z, N, data) , class Q##N, class R##N, class ...T##N##s
#define PACK_VIRTUAL_TEMPLATE(N) template <class Base BOOST_PP_REPEAT(N, PACK_VIRTUAL_TEMPLATE_N,)>

#define PACK_VIRTUAL_STRUCT_N(z, N, data) , Signature<Q##N, R##N, T##N##s...>
#define PACK_VIRTUAL_STRUCT(N) struct Virtual_Pack<Base BOOST_PP_REPEAT(N, PACK_VIRTUAL_STRUCT_N,)>

#define PACK_VIRTUAL_BODY_N(z, N, data) /*
*/ virtual R##N vcall(Qualify<Base, Q##N>, T##N##s...) const = 0;
#define PACK_VIRTUAL(r, data, N) PACK_VIRTUAL_TEMPLATE(N) PACK_VIRTUAL_STRUCT(N) {BOOST_PP_REPEAT(N, PACK_VIRTUAL_BODY_N,);};

/******************************************************************************************/

#define PACK_IMPL_TEMPLATE_N(z, N, data) , class Q##N, class R##N, class ...T##N##s
#define PACK_IMPL_TEMPLATE(N) template <class CRTP, class Base BOOST_PP_REPEAT(N, PACK_IMPL_TEMPLATE_N,)>

#define PACK_IMPL_STRUCT_N(z, N, data) , Signature<Q##N, R##N, T##N##s...>
#define PACK_IMPL_STRUCT(N) struct Impl_Pack<CRTP, Base BOOST_PP_REPEAT(N, PACK_IMPL_STRUCT_N,)> : public Base

#define PACK_IMPL_BODY_N(z, N, data) \
R##N vcall(Qualify<Base, Q##N> self, T##N##s...ts) const override final { /*
*/    return static_cast<R##N>(static_cast<Qualify<CRTP, Q##N>>(self)(fw<decltype(ts)>(ts)...));}

#define PACK_IMPL(r, data, N) PACK_IMPL_TEMPLATE(N) PACK_IMPL_STRUCT(N) {BOOST_PP_REPEAT(N, PACK_IMPL_BODY_N,)};

/******************************************************************************************/

#define PACK_INDEX(r, data, N) BOOST_PP_COMMA_IF(N) hana::size_c<N>

namespace nupack {

/******************************************************************************************/

static_assert(is_same<Qualify<int, lvalue_t>, int &>, "");
static_assert(is_same<Qualify<int, rvalue_t>, int &&>, "");
static_assert(is_same<Qualify<int, decay_value_t>, int>, "");
static_assert(is_same<Qualify<int, const_lvalue_t>, int const &>, "");
static_assert(is_same<Qualify<int, const_rvalue_t>, int const &&>, "");

/******************************************************************************************/

template <class Qualifier, class ...Ts>
struct Signature {using type = Signature;};

template <class Qualifier, class ...Ts>
static constexpr auto signature_c = Signature<Qualifier, Ts...>();

template <class Qualifier, class ...Ts>
constexpr auto signature(Qualifier q, Ts ...ts) {return signature_c<Qualifier, typename Ts::type...>;}

template <class ...Ts> struct Virtual_Pack;
BOOST_PP_SEQ_FOR_EACH(PACK_VIRTUAL, , PACK_LENGTHS);

template <class ...Ts> struct Impl_Pack;
BOOST_PP_SEQ_FOR_EACH(PACK_IMPL, , PACK_LENGTHS);

static constexpr auto Indices = hana::make_tuple(BOOST_PP_SEQ_FOR_EACH(PACK_INDEX, , PACK_LENGTHS));

/******************************************************************************************/

struct calculate_abstract_t {
    template <class S, class C> auto operator()(S signatures, C crtp) const {
        constexpr auto c = hana::contains(Indices, hana::size(signatures));
        using Test = Test_OK<c(), decltype(hana::size(signatures))>;
        static_assert(Test::is_ok, "Undefined virtual base template");
        return hana::unpack(hana::prepend(signatures, crtp), hana::template_<Virtual_Pack>);
    }
};

static constexpr auto calculate_abstract = calculate_abstract_t();


struct calculate_impl_t {
    template <class S, class C, class B> auto operator()(S signatures, C crtp, B base) const {
        constexpr auto c = hana::contains(Indices, hana::size(signatures));
        using Test = Test_OK<c(), decltype(hana::size(signatures))>;
        static_assert(Test::is_ok, "Undefined implementation template");
        auto args = hana::prepend(hana::prepend(signatures, base), crtp);
        return hana::unpack(args, hana::template_<Impl_Pack>);
    }
};

static constexpr auto calculate_impl = calculate_impl_t();

/******************************************************************************************/

}
