#pragma once
#define BOOST_HANA_CONFIG_ENABLE_STRING_UDL
#include <boost/hana.hpp>
#define BOOST_PP_VARIADICS 1
#include <boost/preprocessor/repetition/repeat.hpp>
#include <boost/preprocessor/variadic/to_seq.hpp>
#include <boost/preprocessor/seq/for_each.hpp>
#include <nupack/algorithms/TypeSupport.h>

/******************************************************************************************/

namespace nupack {

namespace hana = boost::hana;
using namespace hana::literals;

template <int N> static constexpr auto int_c = hana::int_c<N>;
template <bool B> static constexpr auto bool_c = hana::bool_c<B>;
template <class T> static constexpr auto type_c = hana::type_c<T>;
static constexpr auto void_type = type_c<void>;
static constexpr auto bool_type = type_c<bool>;

template <class T> T operator*(hana::basic_type<T> t);
static constexpr auto const type_of = hana::decltype_;

struct value_of_t {
    template <class T> constexpr auto operator()(T const &) const {return T::value;}
};

static constexpr auto value_of = value_of_t();

namespace traits {
    constexpr auto is_type(void const *) {return hana::false_c;}
    template <class T> constexpr auto is_type(hana::basic_type<T> const *) {return hana::true_c;}
}
template <class T>
static constexpr auto is_type = decltype(traits::is_type((std::decay_t<T> const *) nullptr))();

template <template <bool, class ...> class Temp> struct bool_template_t {
    template <class T, class ...Ts>
    constexpr auto operator()(T, Ts ...) const {return type_c<Temp<T::value, type_in<Ts>...>>;}
    template <bool B, class ...Ts> struct apply {using type = Temp<B, Ts...>;};
};

template <template <std::size_t, class ...> class Temp> struct size_template_t {
    template <class T, class ...Ts>
    constexpr auto operator()(T, Ts ...) const {return type_c<Temp<T::value, type_in<Ts>...>>;}
    template <std::size_t N, class ...Ts> struct apply {using type = Temp<N, Ts...>;};
};

template <template <int, class ...> class Temp> struct int_template_t {
    template <class T, class ...Ts>
    constexpr auto operator()(T, Ts ...) const {return type_c<Temp<T::value, type_in<Ts>...>>;}
    template <int N, class ...Ts> struct apply {using type = Temp<N, Ts...>;};
};

template <template <class ...Ts> class Temp>
static constexpr auto type_template = hana::template_<Temp>;

template <template <bool B, class ...Ts> class Temp>
static constexpr auto bool_template = bool_template_t<Temp>();

template <template <int N, class ...Ts> class Temp>
static constexpr auto int_template = int_template_t<Temp>();

template <template <std::size_t N, class ...Ts> class Temp>
static constexpr auto size_template = size_template_t<Temp>();

/******************************************************************************************/

NUPACK_DEFINE_VARIADIC(is_hana_tuple, hana::tuple, class);

/******************************************************************************************/

template <class T> struct Printer<T, void_if<is_hana_tuple<T> && !is_empty<T>>> {
    void operator()(std::ostream &os, T const &t, Indent id) const {
        hana::unpack(t, [&](auto const &...ts){Printer<decltype(std::tie(ts...))>()(os, std::tie(ts...), id);});
    }
};

/******************************************************************************************/

template <class T>
class Storage {
    std::vector<T> v;
public:

    Storage() = default;
    Storage(std::size_t n) : v(n) {}
    decltype(auto) operator[](std::size_t i) {return v[i];}
    decltype(auto) operator[](std::size_t i) const {return v[i];}
};

/******************************************************************************************/

struct All {};
static constexpr auto all = All();

static constexpr auto all_type = type_c<All>;
static constexpr auto size_type = type_c<std::size_t>;
static constexpr auto span_type = type_c<Span>;
static constexpr auto double_type = type_c<double>;

/******************************************************************************************/

static constexpr auto replicate = hana::curry<2>(hana::replicate<hana::tuple_tag>);

/******************************************************************************************/

template <class C, class I, class T>
constexpr auto set_at(C c, I i, T t) {return hana::insert(hana::remove_at(c, i), i, t);}

/******************************************************************************************/

struct lvalue_t {
    using type = lvalue_t;
    template <class T> constexpr auto operator()(T) const {return type_c<decay<type_in<T>> &>;}
};

struct const_lvalue_t {
    using type = const_lvalue_t;
    template <class T> constexpr auto operator()(T) const {return type_c<decay<type_in<T>> const &>;}
};

struct rvalue_t {
    using type = rvalue_t;
    template <class T> constexpr auto operator()(T) const {return type_c<decay<type_in<T>> &&>;}
};

struct const_rvalue_t {
    using type = const_rvalue_t;
    template <class T> constexpr auto operator()(T) const {return type_c<decay<type_in<T>> const &&>;}
};

struct decay_value_t {
    using type = decay_value_t;
    template <class T> constexpr auto operator()(T) const {return type_c<decay<type_in<T>>>;}
};

static constexpr auto lvalue = lvalue_t();
static constexpr auto rvalue = rvalue_t();
static constexpr auto const_lvalue = const_lvalue_t();
static constexpr auto const_rvalue = const_rvalue_t();
static constexpr auto decay_value = decay_value_t();

template <class T, class Qualifier>
using Qualify = typename decltype(declval<Qualifier>()(type_c<T>))::type;

/******************************************************************************************/

static constexpr auto mix_types = hana::template_<Mixer>;
static constexpr auto fuse_types = hana::fuse(mix_types);

/******************************************************************************************/

template <class Fs, class ...Ts> auto fmap(Fs &&f, Ts &&...ts) {
    return hana::unpack(fw<Fs>(f), hana::demux(hana::make_tuple))(fw<Ts>(ts)...);
}

/******************************************************************************************/

struct optional_at_t {
    template <class N, class T>
    constexpr auto operator()(N n, T const &t) const {
        auto n_ = hana::size_c<N::value>;
        auto m = hana::if_(n_ < hana::size(t), hana::just(n_), hana::nothing);
        return hana::maybe(hana::nothing, hana::compose(hana::just, hana::partial(hana::at, t)), m);
    }
};

static constexpr auto optional_at = hana::curry<2>(optional_at_t());

/******************************************************************************************/

template <class N> constexpr auto all_after(N n) {
    auto min = hana::compose(hana::partial(hana::min, hana::size_c<N::value>), hana::size);
    return hana::demux(hana::remove_range)(hana::id, hana::always(hana::size_c<0>), min);
}

/******************************************************************************************/

struct OK {static constexpr bool is_ok = true;};

template <bool B, class T>
using Test_OK = if_t<B, OK, T>;

/******************************************************************************************/

template <class T>
auto filter_out_nothing(T const &t) {return hana::transform(hana::remove(t, hana::nothing), *hana::_);}

/******************************************************************************************/

struct Unspecified {
    static constexpr int value = -1;
    constexpr operator int() const {return value;}
};

struct Specified {
    static constexpr int value = 0;
    constexpr operator int() const {return value;}
};

static constexpr auto unspecified = Unspecified();
static constexpr auto specified = Specified();

template <int N> using maybe_uint8 = std::conditional_t<N == unspecified, uint8_t, hana::int_<N>>;
template <int N> using maybe_bool = std::conditional_t<N == unspecified, bool, hana::bool_<bool(N)>>;
template <class T> using maybe_type = std::conditional_t<is_same<T, Unspecified>, Unspecified, hana::type<T>>;


/******************************************************************************************/

namespace traits {
template <class T, class=void> struct is_constant : False {using type = False;};

template <class T> struct is_constant<T, enable_same<decay<decltype(T{} == T{})>, hana::true_>> : True {using type = True;};
}

template <class T> static constexpr auto is_constant_v = hana::bool_c<traits::is_constant<T>::value>;

class is_constant_t {
    template <class T>
    static auto test(T t) {return hana::all_of(t, [](auto const &t) {return bool_c<is_constant_v<decltype(t)>>;});}

public:
    template <class ...Ts> constexpr auto operator()(Ts const &...ts) const {
        return decltype(test(declval<hana::tuple<Ts const &...>>()))();
    }
};

static constexpr auto is_constant = is_constant_t();

static_assert(is_constant(1_c), "");
static_assert(!is_constant(1), "");
static_assert(is_constant(type_c<int>), "");
static_assert(is_constant(hana::true_c), "");
static_assert(is_constant(hana::make_tuple(1_c)), "");
static_assert(!is_constant(hana::make_tuple(1)), "");

template <class T, class O, NUPACK_IF(is_constant_v<O>)> constexpr auto maybe_c(T t, O) {return t;}
template <class T, class O, NUPACK_IF(!is_constant_v<O>)> constexpr auto maybe_c(T, O or_) {return or_;}

/******************************************************************************************/

NUPACK_LAMBDA3(result_rank) = [](auto ...ts) {
    return int_c<(hana::size_c<sizeof...(ts)> - hana::count_if(hana::make_tuple(ts...), hana::trait<std::is_integral>))()>;
};

template <class CRTP, class T>
constexpr decltype(auto) crtp_move(T *t) {return static_cast<CRTP &&>(*t);}

template <class CRTP, class T>
constexpr decltype(auto) crtp_cast(T *t) {return static_cast<CRTP &>(*t);}

template <class CRTP, class T>
constexpr decltype(auto) crtp_cast(T const *t) {return static_cast<CRTP const &>(*t);}

/******************************************************************************************/

//template <class T, class U, NUPACK_IF(is_constant_v<decltype(declref<T const>() == declref<U const>)>)>
//constexpr maybe_equals

/******************************************************************************************/

template <template <class...> class T, std::size_t N=0>
class simple_constructor {
    template <class ...Ts, std::size_t ...Is>
    constexpr auto call(indices_t<Is...>, Ts &&...ts) const {
        return T<std::decay_t<Ts>...>{hana::arg<Is+1>(fw<Ts>(ts)...)...};
    }
public:
    template <class ...Ts> constexpr auto operator()(Ts &&...ts) const {
        return call(std::make_index_sequence<N>(), fw<Ts>(ts)...);
    }
};

template <class F, class ...Is> struct reorder_t {
    F f;
    template <class ...Ts> constexpr auto operator()(Ts &&...ts) const {
        return f(hana::arg<Is::value+1>(fw<Ts>(ts)...)...);
    }
};

static constexpr auto reorder_ = simple_constructor<reorder_t, 1>();

/******************************************************************************************/

}
