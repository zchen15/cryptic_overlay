#pragma once
#include <boost/iterator/iterator_facade.hpp>

namespace nupack {

/******************************************************************************************/

template <class T, class N=std::size_t>
class Constant_Iterator : public boost::iterator_facade<Constant_Iterator<T>, T, boost::random_access_traversal_tag, T const &, std::ptrdiff_t> {
    friend class boost::iterator_core_access;

    bool equal(Constant_Iterator<T> const & o) const {return count == o.count;}
    void increment() {++count;}
    void decrement() {--count;}
    void advance(std::ptrdiff_t d) {count += d;}
    auto distance_to(Constant_Iterator const &o) const {return o.count - count;}
    T const & dereference() const {return value;}

    T value;
    N count;

public:

    explicit Constant_Iterator(T t, std::size_t c=0) : value(std::move(t)), count(c) {}
};

/******************************************************************************************/

template <class T>
class Contiguous_Iterator : public boost::iterator_facade<Contiguous_Iterator<T>, T, boost::random_access_traversal_tag, T &, std::ptrdiff_t> {
    friend class boost::iterator_core_access;

    bool equal(Contiguous_Iterator<T> const & o) const {return ptr == o.ptr;}
    void increment() {++ptr;}
    void decrement() {--ptr;}
    void advance(std::ptrdiff_t d) {ptr += d;}
    auto distance_to(Contiguous_Iterator const &o) const {return o.ptr - ptr;}
    T & dereference() const {return *ptr;}

    T *ptr;

public:

    explicit Contiguous_Iterator(T *p) : ptr(p) {}
};

/******************************************************************************************/

template <class T, class N=std::size_t>
class Strided_Iterator : public boost::iterator_facade<Strided_Iterator<T>, T, boost::random_access_traversal_tag, T &, std::ptrdiff_t> {
    friend class boost::iterator_core_access;

    T *ptr;
    N skip;

    bool equal(Strided_Iterator<T> const & o) const {return ptr == o.ptr;}
    void increment() {ptr += skip;}
    void decrement() {ptr -= skip;}
    void advance(std::ptrdiff_t d) const {ptr += d * skip;}
    auto distance_to(Strided_Iterator const &o) {return (o.ptr - ptr) / skip;}
    T & dereference() const {return *ptr;}

public:

    explicit Strided_Iterator(T *p, N n) : ptr(p), skip(n) {}
};

/******************************************************************************************/

// template <class T, class ...Ts, NUPACK_IF(hana::size(declval<T>())() == sizeof...(Ts))>
// constexpr T increment_nd(T const &indices, T const &mask, Ts &&...ts) {return T(fw<Ts>(ts)...);}
//
// template <class T, class ...Ts, NUPACK_IF(hana::size(declval<T>())() != sizeof...(Ts))>
// constexpr T increment_nd(T const &indices, T const &mask, Ts &&...ts) {
//     constexpr N = hana::size_c<sizeof...(Ts)>;
//     if (indices[N] + hana::size_c<1> == mask[N]) return increment_nd(indices, mask, fw<Ts>(ts)..., hana::size_c<0>);
//     else return T(fw<Ts>(ts), indices[N] + hana::size_c<1>, hana::slice_c<sizeof...(Ts)+1, hana::size(indices)()>(indices));
// }
//
// template <class T, class ...Is>
// class Rectangular_Iterator : public boost::iterator_facade<Rectangular_Iterator<T, Is...>, T, boost::random_access_tag, T &, std::ptrdiff_t> {
//     friend class boost::iterator_core_access;
//
//     hana::tuple<Is...> indices, mask;
//     T *ptr;
//
//     constexpr bool equal(Rectangular_Iterator<T, Is...> const &o) const {return ptr = o.ptr && indices == o.indices;}
//     void increment() {}
//
//
//
//
//     T & dereference() const {return ptr[hana::product(indices)];}
// };
//
/******************************************************************************************/

//template <class T, class N1=std::size_t, class N2=std::size_t>
//class Chunked_Iterator : public boost::iterator_facade<Chunked_Iterator<T>, T, boost::random_access_tag, T &, std::ptrdiff_t> {
//    friend class boost::iterator_core_access;
//
//    bool equal(Chunked_Iterator<T> const & o) const {return ptr == o.ptr;}
//    void increment() {ptr += skip;}
//    void decrement() {ptr -= skip;}
//    void advance(std::ptrdiff_t d) const {ptr += d * skip;}
//    auto distance_to(Chunked_Iterator const &o) {return (o.ptr - ptr) / skip;}
//    T & dereference() const {return *ptr;}
//
//    T *ptr;
//    N1 skip;
//    N2 run;
//
//public:
//
//    explicit Chunked_Iterator(T *p, N1 s, N2 r) : ptr(p), skip(s), run(r) {}
//};


/******************************************************************************************/

//Contiguous
//*************
//
//Contiguous_Chunked(N)
//****___****___****
//
//Strided
//*__*__*__*__
//
//Strided_Chunked(N)
//*_*____*_*____*_*____



}
