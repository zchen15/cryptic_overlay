#pragma once

#include "../standard/Set.h"
#include "../common/Runtime.h"
#include <H5Cpp.h>

namespace nupack {

/******************************************************************************************/

struct H5_Node {
    std::unique_ptr<H5::CommonFG> ptr;

    H5_Node() = default;

    H5_Node(File_Path p) {
        if (std::ifstream(p).good()) ptr = std::make_unique<H5::H5File>(p, H5F_ACC_RDWR);
        else ptr = std::make_unique<H5::H5File>(p, H5F_ACC_TRUNC);

    }

    Set<string> keys() const {
        Set<string> ret;
        H5G_iterate_t f = [](hid_t, const char *s, void *p) {
            static_cast<decltype(ret) *>(p)->emplace(s); return 0;
        };
        ptr->iterateElems(".", nullptr, f, &ret);
        return ret;
    }

    H5_Node(H5_Node const &p, string const &s) {
        if (p.keys().count(s)) ptr = std::make_unique<H5::Group>(p.ptr->openGroup(s));
        else ptr = std::make_unique<H5::Group>(p.ptr->createGroup(s));
    }
};

/******************************************************************************************/

struct H5_Object {
    H5::DataSet data;

    template <class T>
    H5_Object(H5::CommonFG &g, string const &name, T const &t) {
        std::stringstream ss;
        Default_OArchive{ss}(t);
        auto s = std::move(ss).str();
        hsize_t dims[] = {len(s)};
        data = g.createDataSet(name, H5::PredType::NATIVE_CHAR, H5::DataSpace(1, dims));
        data.write(&s[0], H5::PredType::NATIVE_CHAR);
    }

    template <class T>
    H5_Object(H5_Node const &n, string const &name, T const &t) : H5_Object(*n.ptr, name, t) {}

    H5_Object(H5::CommonFG &g, string const &name) : data(g.openDataSet(name)) {}
    H5_Object(H5_Node const &n, string const &name) : H5_Object(*n.ptr, name) {}

    template <class T>
    void load(T &t) {
        hsize_t dims[1];
        int ndims = data.getSpace().getSimpleExtentDims(dims, nullptr);
        string s(dims[0], char());
        data.read(&s[0], H5::PredType::NATIVE_CHAR);
        std::stringstream ss(std::move(s));
        Default_IArchive{ss}(t);
    }

    void set_attribute(string const &key, vec<char> const &value) {
        hsize_t dims[] = {size(value)};
        auto dspace = H5::DataSpace(1, dims);
        auto attr = data.createAttribute(key, H5::PredType::NATIVE_CHAR, dspace);
        if (!value.empty()) attr.write(H5::PredType::NATIVE_CHAR, value.data());
    }

    vec<char> get_attribute(string const &key) {
        auto attr = data.openAttribute(key);
        vec<char> ret(attr.getStorageSize(), char());
        if (!ret.empty()) attr.read(H5::PredType::NATIVE_CHAR, ret.data());
        return ret;
    }
};

/******************************************************************************************/

}
