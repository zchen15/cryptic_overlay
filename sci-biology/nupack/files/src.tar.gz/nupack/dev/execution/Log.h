#pragma once

#include "H5.h"
#include "../algorithms/Utility.h"
#include "../kmc/Stopwatch.h"

namespace nupack {

/******************************************************************************************/

struct H5Log {
    using Clock = std::chrono::system_clock;
    using Time = std::chrono::time_point<Clock>;
    H5_Node node;
    int counter;

    H5Log() : counter(0) {}

    H5Log(H5_Node const &n) : node(n, timestamp<Clock>() + "_" + random_string(5)), counter(0) {}
    H5Log(H5_Node const &n, string s) : node(n, s), counter(0) {}

    template <class ...Ts>
    void write(Ts &&...ts) {
        std::stringstream ss;
        print_os<'\n'>(ss, fw<Ts>(ts)...);
        H5_Object(node, std::to_string(counter++), std::move(ss).str());
    }

    H5Log inside(string s) {return {node, std::to_string(counter++) + " " + s};}
};

/******************************************************************************************/

}
