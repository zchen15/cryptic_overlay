#pragma once
#ifdef NUPACK_HDF5
#include "Log.h"
#include "Memo.h"

/******************************************************************************************/

namespace nupack {

template <class Exec>
struct Downstream_Executor {
    Exec ex;
    H5_Node node;
    H5Cache cache;
    H5Log log;

    template <class F>
    auto call(string const &s, F &&f) {
        cache.call(s, fw<F>(f));
    }
};

template <class Exec>
Downstream_Executor<Exec> make_downstream(H5Cache c, Exec x, string s) {
    return {c, x, s};
}

/******************************************************************************************/

template <class Exec, class Cache, class Log>
struct Basic_Cached_Executor {
    Exec ex;
    Cache cache;
    Log log;

    using Inside_Type = Basic_Cached_Executor<decltype(ex.inside(string())),
        decltype(cache.inside(string())), decltype(log.inside(string()))>;

    template <class ...Ts>
    auto collect(string s, Ts &&...ts) {
        return cache.call("collect-" + s,
            [&]{return ex.map(fw<Ts>(ts)...);});
    }

    template <class ...Ts>
    auto call(Ts &&...ts) {return cache.call(fw<Ts>(ts)...);}

    template <class ...Ts>
    auto check_call(Ts &&...ts) {return cache.check_call(fw<Ts>(ts)...);}

    template <class ...Ts>
    void write(Ts &&...ts) {log.write(fw<Ts>(ts)...);}

    Inside_Type inside(string s) {return {ex.inside(s), cache.inside(s), log.inside(s)};}
};

/******************************************************************************************/

template <class Exec>
struct Cached_Executor : public Basic_Cached_Executor<Exec, H5Cache, H5Log> {
    H5_Node node;
    using base_type = typename Cached_Executor::Basic_Cached_Executor;

    //template <class N, class ...Ts>
    //Cached_Executor(N n, Ts &&...ts) : node(std::move(n)), ex(Exec(fw<Ts>(ts)...)),
    //    cache(H5Cache(node, "cache")), log(H5Log(H5_Node(node, "logs"))) {}
};

/******************************************************************************************/

}

#endif
