
import nupack, numpy as np, json

name = 'rna95'
mod = nupack.Model(parameters=name)
p = mod.parameters

import itertools

d5 = np.array(p.dangle5.cast(object))
d3 = np.array(p.dangle3.cast(object))

out = {}
for i,j,k,l in itertools.product(*(4 * [range(4)])):
    s = ''.join('ACGT'[x] for x in (i,j,k,l))
    t = np.round(d3[i,j,k] + d5[j,k,l], 5)
    if t != 0:
        out[s] = t

print(json.dumps(out, indent=4))

m1 = nupack.Model(parameters=name, T=310)
m2 = nupack.Model(parameters=name, T=320)
p1 = m1.parameters
p2 = m2.parameters

import itertools

d5 = np.array(p1.dangle5.cast(object)) + (np.array(p2.dangle5.cast(object)) - np.array(p1.dangle5.cast(object))) * -310 / 10
d3 = np.array(p1.dangle3.cast(object)) + (np.array(p2.dangle3.cast(object)) - np.array(p1.dangle3.cast(object))) * -310 / 10

out = {}
for i,j,k,l in itertools.product(*(4 * [range(4)])):
    s = ''.join('ACGT'[x] for x in (i,j,k,l))
    t = np.round(d3[i,j,k] + d5[j,k,l], 5)
    if t != 0:
        out[s] = t

print(json.dumps(out, indent=4))
