# transpose interior loop parameters

import json


for key in 'rna95 rna06 dna04'.split():
    file = '/Users/Mark/Projects/nupack/parameters/%s.json' % key
    with open(file) as f:
        ps = json.load(f)

    for kind in ('dG', 'dH'):
        if kind not in ps:
            continue
        P = ps[kind]
        P['interior_1_1'] = {''.join(k[i] for i in [0,4,2,3,5,1]): v for k, v in P['interior_1_1'].items()}
        P['interior_1_2'] = {''.join(k[i] for i in [0,2,3,4,5,6,1]): v for k, v in P['interior_1_2'].items()}
        P['interior_2_2'] = {''.join(k[i] for i in [0,2,3,4,5,6,7,1]): v for k, v in P['interior_2_2'].items()}

    with open(file, 'w') as f:
        json.dump(ps, f, indent=4)
