*Full documentation for users is currently available [here](https://mfornace.github.io/nupack-documentation). The documentation below is unstable and primarily for NUPACK developers. You may also look at the `release` branch for release versions of NUPACK.*

# Installation

## Requirements

NUPACK 4 is a C++ library distributed as a Python package for portability and ease of use. Before installing NUPACK, you must have Python 3 and a few common packages installed on your computer. Note that Python 2 is not currently supported. The specific Python package requirements for NUPACK 4 are:

- Python 3.6+
- numpy
- scipy

For full visualization capabilities, the following packages are recommended:

- matplotlib
- bokeh
- notebook

## Installing NUPACK from source

### Dependencies for C++ libraries

- C++17 compliant compiler (works with Clang 3.6+, AppleClang; questionable with GCC 5+)
- [Boost](https://www.boost.org) (1.58+, optionally including Boost Context)
- [Intel TBB](https://github.com/wjakob/tbb)
- [Armadillo matrix library](https://arma.sourceforge.net/) (9.5+)

All are available on [Homebrew](https://brew.sh) for Mac. For example, after Homebrew is installed, run `brew install tbb armadillo boost`. They are also commonly available in Linux package managers (e.g. `apt-get`, `pacman`).

### Directions

Make sure `python` points to your desired version of Python (>= 3.5). You can check this via the output of `python --version`. On a Unix-like system, clone the repository and install in Terminal via the following commands.

Clone the git repository for NUPACK.
```bash
git clone --recurse-submodules git@github.com:mfornace/nupack.git
```

Make a build folder and navigate into it.
```bash
cd nupack
mkdir build
cd build
```

Run the CMake configuration. You may add any custom compilation options as flags to the `cmake` command if desired. For instance, you could add `-DCMAKE_INSTALL_PREFIX=/usr/local -DCMAKE_CXX_COMPILER=clang++` to use a specified install directory and C++ compiler (for example). Or, you can add `-DREBIND_PYTHON=/usr/local/bin/python3` (for example) to change the Python interpreter to use, if it is not the same as the `python` in your executable path.

```
cmake .. -DBUILD_TESTING=OFF -DCMAKE_BUILD_TYPE=Release
```

Build and install the NUPACK Python module.
```bash
cmake --build . --target python
pip install ../external/rebind
pip install .
```

### Running the C++ unit tests

You may also build the C++ unit test suite. You may skip this section if desired (recommended for non-developers).
```
cmake --build . --target utest
pip install ../external/lilwil
```

To run the C++ unit tests, enter the build directory and run:

- `./test -fer "test/*" --time=10` to run unit tests, only showing errors and exceptions, with each test taking up to approximately 10 seconds.
- `./test -fser "test/*"` to run all unit tests, showing all successes and errors
- `./test -h` for help on more options

# Bundled and optional packages

## Included C++ packages

- [JSON for Modern C++](https://github.com/nlohmann/json>)
- [Boost.SIMD](https://github.com/nickporubsky/boost-simd-clone>)
- [concurrentqueue.h and blockingconcurrentqueue.h](https://github.com/cameron314/concurrentqueue>)
- [tclap](https://github.com/eile/tclap>)

## Included CMake packages

- [cotire.cmake](https://github.com/sakra/cotire>)
- [CMake common modules (for FindNumpy)](https://github.com/Eyescale/CMake>)
- [CMake modules (for git revision)](https://github.com/rpavlik/cmake-modules>)
- [Mathematica CMake folder](https://github.com/sakra/FindMathematica>)

## Optional libraries (unincluded)

- ccache, include-what-you-use, Ninja
- Mathematica, MATLAB, mlpack
- OpenMP, MPI, HDF5
- Doxygen
- BISON, FLEX
