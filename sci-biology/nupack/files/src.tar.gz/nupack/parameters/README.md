## Parameter set values

`dna04`:

- Parameters are the same from v3 to v4.

`rna95`:

- Literature terminal mismatches are used in v4; sum of dangles is used in v3

`rna99`:

- Literature terminal mismatches are used in v4; sum of dangles is used in v3.
- Minor adjustments within 0.1 kcal/mol are made elsewhere.
- Hairpin mismatch, triloop, interior asymmetry, and multiloop parameters are revised to follow NNDB.

`rna06`:
- All parameters are revised for NNDB's 04 RNA parameters.
