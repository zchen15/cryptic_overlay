import numpy as np
from . import constants
from .rebind import forward

################################################################################

@forward
class Output:
    '''
    The output of the equilibrium concentration solving algorithm
    '''
    solution: np.ndarray
    dual_solution: np.ndarray
    objective: float
    max_rel_grad: float
    iters: int
    converged: bool

################################################################################

@forward
class Options:
    '''
    The options for the equilibrium concentration solving algorithm
    The tolerance is specified in terms of the maximum relative error in
    strand concentration. If the current strand concentrations are a vector s,
    and the initial concentrations are a vector s0, this equates to:

    ```python
    converged = (abs(s - s0) / s0).max() < tol
    ```
    '''
    max_iters: int
    tolerance: float
    delta_min: float
    delta_max: float
    orthogonalize: bool
    init: int

    def __init__(self, delta_max=1000.0, delta_min=1e-12, max_iters=10000, tolerance=1e-08, init=1, orthogonalize=True, _fun_=None):
        '''
        Initialize solving options from specified keywords:
        - max_iters: maximum number of iterations
        - tolerance: tolerance for convergence
        - delta_min: minimum trust region radius
        - delta_max: maximum trust region radius
        - orthogonalize: whether or not to orthogonalize the input coefficient matrix
        - init: initialization
            0. uniform initialization
            1. initialization from given concentrations
            2. initialization from non-negative least squares solution
            3. initialization from absolute value of least squares solution
        '''
        _fun_(self)
        self.max_iters = max_iters
        self.tolerance = tolerance
        self.delta_min = delta_min
        self.delta_max = delta_max
        self.orthogonalize = orthogonalize
        self.set_init(int(init))

################################################################################

@forward
def solve(A, x0, logq, options=None, _fun_=None):
    '''
    Solve equilibrium concentrations in any system

    - `A` (ndarray): reaction coefficient matrix (n_strands, n_complexes)
    - `x0` (ndarray): initial concentrations (n_complexes)
    - `logq` (ndarray): logarithms of partition functions (n_complexes)
    - `options`: (Options) solving options
    '''
    A, x0, logq = [np.asarray(o, dtype=np.float64) for o in (A, x0, logq)]
    options = Options() if options is None else options
    return _fun_(A, x0, logq, options)

################################################################################

@forward
def solve_complexes(indices, logq, x0, options, rotational_correction=True) -> Output:
    '''
    Solve equilibrium concentrations (non-dimensionalized)
    Users should generally use `complex_concentrations`.
    '''

################################################################################

@forward
def complex_concentrations(indices, logq, x0, T,  _fun_=None, **kws):
    '''
    Solve equilibrium concentrations for a set of specified complexes

    - `indices` (List[List[int]]):
        for each complex, indices of each strand
    - `logq` (ndarray):
        the log partition function of each complex
    - `x0` (ndarray):
        initial concentrations for each complex
    - `T` (float): temperature in Kelvin
    '''
    logq = np.asarray(logq, dtype=np.float64)
    x0 = np.asarray(x0, dtype=np.float64) / constants.water_molarity(T)
    out = solve_complexes(indices, logq, x0, Options(**kws))
    return out.solution * constants.water_molarity(T)

################################################################################

def coefficient_matrix(complexes, strands, dtype=None):
    A = np.zeros((len(complexes), len(strands)), dtype=dtype)
    for i, c in enumerate(complexes):
        for strand in c:
            A[i, strands.index(strand)] += 1
    return A
