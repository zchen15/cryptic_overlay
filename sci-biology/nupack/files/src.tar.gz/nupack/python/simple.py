import numpy as np

from .constants import as_sequences, string_exp
from .analysis import Analysis, ConcentrationSolver
from .model import Model

################################################################################

def pfunc(strands, model=None):
    strands = as_sequences(strands)

    analysis = Analysis(model=model)
    analysis.partition_function(strands)
    result = analysis.compute()[strands]

    logq = result.log_partition_function
    return string_exp(logq)

################################################################################

def mfe(strands, model=None):
    strands = as_sequences(strands)

    analysis = Analysis(model=model)
    analysis.min_free_energy(strands)
    return analysis.compute()[strands].mfe_structures

################################################################################

def prob(strands, structure, model=None):
    strands = as_sequences(strands)

    analysis = Analysis(model=model)
    analysis.partition_function(strands)
    result = analysis.compute()
    return result.structure_probability(strands, structure)

################################################################################

def subopt(strands, gap: float, model=None):
    strands = as_sequences(strands)

    analysis = Analysis(model=model)
    analysis.suboptimal_structure(strands, gap)
    return analysis.compute()[strands].suboptimal_structures

################################################################################

def pairs(strands, model=None):
    strands = as_sequences(strands)

    analysis = Analysis(model=model)
    analysis.pair_probability(strands)
    return analysis.compute()[strands].pair_probability

################################################################################

def sample(strands, number: int, model=None):
    strands = as_sequences(strands)

    analysis = Analysis(model=model)
    analysis.boltzmann_sample(strands, number)
    return analysis.compute()[strands].sampled_structures

################################################################################

def count(strands, model=None):
    analysis = Analysis(model=model)
    strands = as_sequences(strands)

    analysis.structure_count(strands)
    log_count = analysis.compute()[strands].log_structure_count

    count = string_exp(log_count)
    return count if isinstance(count, str) else int(np.rint(count))

################################################################################

def distributions(strands, concentrations, model=None):
    raise NotImplementedError

################################################################################

def tube_analysis(strands, concentrations, max_size: int, model=None):
    analysis = Analysis(model=model)
    analysis.partition_function(strands, max_size=max_size)
    result = analysis.compute()
    solver = ConcentrationSolver.from_analysis_result(strands, result)
    return solver.compute(concentrations).complex_concentrations()
