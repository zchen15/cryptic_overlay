import numpy as np
from .kmc import State
from .std import Vector
from .rebind import forward

################################################################################

@forward
class BasePairPath:
    '''Path containing the list of base pairing steps that occurred during a simulation'''
    steps: Vector
    time: float

################################################################################

@forward
class Path(BasePairPath):
    '''Augments BasePairPath to also include initial and final states'''
    # start: State
    # stop: State

    def base_pair_time(self, power=0, relative=False) -> np.ndarray:
        '''
        Returns the integrated pair probability over the path as a full (power+1, N, N) array
        relative: bool
            whether to divide the result by the path time
        '''

    def structure_time(self, structures, power=0, relative=False) -> np.ndarray:
        '''
        Returns the amount of time the path spent in a set of given different secondary structures
        structures: List[PairList]
            list of structures to measure the occupancy time for
        relative: bool
            whether to divide the result by the path time
        '''

@forward
def sample_path(state, time) -> Path:
    '''Return a sample path of a given length from a given start state'''

################################################################################
