from .core import SimpleType
from .rebind import forward
import numpy as np

################################################################################

@forward
class Options(SimpleType):
    minimum: float
    maximum: float
    tolerance: float
    iters: int
    refresh: bool

    def __init__(self, minimum, maximum=1e10, tolerance=1e-6, iters=10000, refresh=True, _fun_=None):
        _fun_(self, minimum, maximum, tolerance, iters, refresh)

################################################################################

@forward
class ConstraintOptions(SimpleType):
    minimum: float
    maximum: float
    tolerance: float
    iters: int
    norm: int

    def __init__(self, minimum, maximum=1e10, tolerance=1e-10, norm=1, iters=4, _fun_=None):
        _fun_(self, minimum, maximum, tolerance, norm, iters)

################################################################################

@forward
class Output(SimpleType):
    solution: np.ndarray
    objective: float
    iters: int
    converged: bool

################################################################################

@forward
def trace_maximum(m, A, B, init=2, options=None, _fun_=None):
    if options is None:
        options = Options()
    return _fun_(int(m), A, B, init, options)

################################################################################

@forward
def stationary_maximum(m, A, B, pi, init=2, options=None, constraints=None, _fun_=None):
    if options is None:
        options = Options()
    if constraints is None:
        constraints = ConstraintOptions()
    return _fun_(int(m), A, B, pi, init, constraints, options)
