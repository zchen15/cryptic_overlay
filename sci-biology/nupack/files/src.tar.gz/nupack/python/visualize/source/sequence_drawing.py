import numpy as np
from skimage.io import imshow
from io import BytesIO
import base64
from PIL import Image
import colorsys as cs

# see: https://groups.google.com/a/continuum.io/forum/#!msg/bokeh/y79yuSPqcw4/bqVWiZSEBQAJ
# and: https://github.com/jni/blob-explorer/blob/master/picker.py

COLORS = [
    np.array([255] * 3),
    np.array([48, 142, 39]),
    np.array([60, 48, 252]),
    np.array([0, 0, 0]),
    np.array([157, 0, 12]),
]

HSV_COLS = [tuple(cs.rgb_to_hsv(*[i/255 for i in x])) for x in COLORS]

bases = dict(A=1, C=2, G=3, T=4, U=4)

def sequence_to_img(seq):
    N = len(seq)
    c = int(np.ceil(np.sqrt(N)))
    r = int(np.ceil(N/c))

    # print(c, r, c*r, N)

    data = np.zeros((c*r, 1, 3)).astype('uint8')
    data.fill(255)
    for i, base in enumerate(seq):
        data[(i, 0)] = COLORS[bases.get(base, 0)]

    data = data.reshape((c, r, 3))
    return Image.fromarray(data, mode='RGB')

def run_length_encode(seq):
    ret = list()
    cur = seq[0]
    count = 1
    for s in seq[1:]:
        if s == cur:
            count += 1
        else:
            ret.append((cur, count))
            cur = s
            count = 1

    ret.append((cur, count))
    return ret

def sequence_to_variant_img(seq):
    seq = run_length_encode(seq)
    N = len(seq)
    c = int(np.ceil(np.sqrt(N)))
    r = int(np.ceil(N/c))

    scale = 1/max(seq, key=lambda x: x[1])[1]

    data = np.zeros((c*r, 1, 3)).astype('uint8')
    for (i, (base, num)) in enumerate(seq):
        hsv = list(HSV_COLS[bases.get(base, 0)])
        # print(hsv)
        sc = scale * num
        hsv[1] *= sc
        hsv = [int(i*255) for i in hsv]
        data[(i, 0)] = np.asarray(hsv)

    data = data.reshape((c,r,3))
    return Image.fromarray(data, mode='HSV').convert('RGB')


def image_to_encoded_html(image):
    out = BytesIO()
    image.save(out, format='png')
    return "data:image/png;base64," + base64.b64encode(out.getvalue()).decode('utf-8')

def one_shot(x):
    return image_to_encoded_html(sequence_to_img(x))

def variant_one_shot(x):
    return image_to_encoded_html(sequence_to_variant_img(x))
