from source.everything import *
from bokeh.plotting import curdoc

make_server_doc(curdoc())
