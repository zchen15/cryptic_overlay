from typing import Tuple
import numpy as np
from scipy.sparse import csc_matrix
from .utility import str_repr, DUp_to_dpp
from .rebind import forward

##########################################################################

@forward
class JSON:
    '''C++ JSON class'''

    def load(self, string):
        '''Load from JSON string'''

    def save(self, indent=0) -> str:
        '''Return JSON string with given indent'''

##########################################################################

class SimpleType:
    def __str__(self):
        return '{}({})'.format(type(self).__name__, ', '.join(k + '=' + repr(getattr(self, k)) for k in self.__annotations__))

    def annotated(self):
        return {k: getattr(self, k) for k in self.__annotations__}

##########################################################################

@forward
class PairList:
    def __init__(self, pairs, _fun_=None):
        if isinstance(pairs, str):
            if 'D' in pairs or 'U' in pairs:
                pairs = DUp_to_dpp(pairs)
            _fun_(self, pairs)
        else:
            _fun_(self, list(pairs)) #  np.asarray(pairs, dtype=np.uint32)

    def dp(self, nicks=()) -> str:
        '''Return equivalent dot-parens-plus string'''

    def array(self):
        '''Return numpy array of pair list indices'''
        self.view().copy()

    def view(self):
        return self.contents.cast(np.ndarray)

    def __iter__(self):
        return iter(self.view())

    def __getitem__(self, i):
        return self.view()[i]

##########################################################################

@forward
class Structure:
    def __init__(self, pairs, nicks):
        self.pairs = pairs
        self.nicks = tuple(map(int, nicks))

    def dp(self):
        return self.pairs.dp(self.nicks)

    def __str__(self):
        return self.dp()

    def __repr__(self):
        return "Structure('%s')" % str(self)

##########################################################################

@forward
class NickSequence:
    def sequences(self) -> Tuple[str, ...]:
        pass

##########################################################################

@forward
class Local:
    def __init__(self, threads=1):
        '''Initialize with given number of threads'''

    # @classmethod
    # def from_object(cls, env=None):
    #     if env is None:
    #         return cls(1)
    #     if isinstance(env, int):
    #         return cls(env)
    #     return env

##########################################################################

@forward
class Sequence:
    def __str__(self):
        return self.cast(str)

##########################################################################

@forward
class Base:
    def __str__(self):
        return self.cast(str)

##########################################################################

@forward
class Fenwick:
    def __len__(self):
        pass

##########################################################################

@forward
class MemoryLimit:
    length: int
    capacity: int

##########################################################################

@forward
class LRU:
    pass

################################################################################

@forward
def sparse_pair_matrix(A, n=0) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    '''Return matrix diagonal and off-diagonal elements'''

@forward
class SparsePairMatrix:
    def __init__(self, A, n=0):
        self.diagonal, self.values, self.rows, self.cols = sparse_pair_matrix(A, n)

    def to_array(self):
        out = np.diag(self.diagonal)
        out[self.rows, self.cols] = self.values
        out[self.cols, self.rows] = self.values
        return out

    def to_sparse(self, cls=csc_matrix):
        '''Return equivalent sparse matrix'''
        n = len(self.diagonal)
        rows = np.concatenate([np.arange(n), self.rows, self.cols])
        cols = np.concatenate([np.arange(n), self.cols, self.rows])
        vals = np.concatenate([self.diagonal, self.values, self.values])
        return cls((vals, (rows, cols)), shape=(n, n))

    def save(self):
        return dict(rows=self.rows.tolist(), cols=self.cols.tolist(),
                    values=self.values.tolist(), diagonal=self.diagonal.tolist())