from bokeh.plotting import curdoc
from source.page import Page

page = Page()
lay = page.make_layout()

doc = curdoc()
doc.title = "residuals"
doc.add_root(lay)
