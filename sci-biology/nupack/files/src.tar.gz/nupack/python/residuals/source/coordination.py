from .page import Page
from bokeh.io import show, output_notebook
from tempfile import NamedTemporaryFile

def notebook_file_results(fn=""):

    def make_doc(doc):
        import warnings
        warnings.simplefilter('ignore')

        nonlocal fn
        page = Page()
        if fn:
            page.get_filename.value = fn
        page.width_box.value = str(900)

        lay = page.make_layout(True)

        doc.title = "residuals"
        doc.add_root(lay)

    return make_doc

def notebook_results(des_res, url=None, outfile=None):
    if outfile:
        outfile = open(outfile, 'w')
    else:
        outfile = NamedTemporaryFile(mode='w', delete=False)

    if url is None:
        url = input('Input your notebook URL (default: \'localhost:8888\'):').strip()
    url = url or 'localhost:8888'

    outfile.write(des_res.to_json())

    show(notebook_file_results(outfile.name), notebook_url=url)
