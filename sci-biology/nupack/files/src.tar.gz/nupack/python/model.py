import enum

from .utility import nbits, match
from .constants import as_sequences
from .core import PairList
from .rebind import forward

################################################################################

@forward
class Conditions:
    '''
    Specification of environmental conditions for the simulated system
    '''
    temperature: float
    na_molarity: float
    mg_molarity: float

    def __init__(self, T=310.15, na=1.0, mg=0.0, _fun_=None):
        '''
        `T`: temperature in Kelvin
        `Na`: molarity of sodium in moles per liter
        `Mg`: molarity of magnesium in moles per liter
        '''
        _fun_(self)
        self.temperature = T
        self.na_molarity = na
        self.mg_molarity = mg

    def save(self):
        return dict(temperature=self.temperature, sodium=self.na_molarity, magnesium=self.mg_molarity)

################################################################################

@forward
class ParameterFile:
    '''
    Descriptor of the chosen parameter file
    '''
    path: str

    def __init__(self, name_or_file='RNA'):
        pass

################################################################################

@forward
class ParameterData:
    '''
    Raw free energy or enthalpy parameters loaded from parameter files
    '''
    hairpin_mismatch: object
    hairpin_size: object
    hairpin_tetra: object
    hairpin_tri: object
    interior_1_1: object
    interior_1_2: object
    interior_2_2: object
    interior_mismatch: object
    interior_size: object
    join_penalty: float
    log_loop_penalty: float
    multi_base: float
    multi_init: float
    multi_pair: float
    ninio: object
    stack: object
    terminal_mismatch: object
    terminal_penalty: float

@forward
class ParameterMetadata:
    '''
    Unique descriptor of a parameter set
    '''
    file: ParameterFile
    kind: str
    loop_bias: float
    temperature: float

################################################################################

@forward
class ParameterSet(ParameterData):
    '''
    Free energy parameters loaded from parameter files
    '''
    metadata: ParameterMetadata
    default_wobble_pairing: bool

################################################################################

@forward
class Ensemble(enum.IntEnum):
    '''
    Set of recursions to use in dynamic programs
    '''
    nostacking = 0
    stacking = 1
    min = 2
    all = 3
    none = 4

    @classmethod
    def get(cls, key):
        '''Construct Ensemble from either a string or an integer'''
        return cls.__members__[key] if isinstance(key, str) else cls(key)

################################################################################

@forward
class Model:
    ensemble: Ensemble
    beta: float
    parameters: ParameterSet
    conditions: Conditions

    def __init__(self, ensemble=Ensemble.stacking, wobble=None, parameters="RNA", T=310.15, na=1.0, mg=0.0, rates=None, bits=64, _fun_=None):
        '''
        Construct a Model

        - `ensemble`: Ensemble, one of ('min', 'all', 'none', 'nostacking', 'stacking')
        - `wobble`: enable wobble pairs or not
        - `parameters`: ParameterFile or equivalent object
        - `T`: temperature in Kelvin
        - `Na`: molarity of sodium in moles per liter
        - `Mg`: molarity of magnesium in moles per liter
        - `bits`: number of bits in the floating type used (probably 32 or 64)
        '''
        if isinstance(parameters, str):
            parameters = ParameterFile(parameters)
        conditions = Conditions(T, na, mg)
        if rates is None:
            rates = Kawasaki()

        bits = nbits(bits)
        cls = match(k for k, v in self._metadata_.items() if v.cast(int) == bits)
        gu = 2 if wobble is None else int(bool(wobble))

        _fun_(self, Ensemble.get(ensemble), parameters, conditions, rates, gu, return_type=cls)

    def save(self):
        out = dict(pseudoknots=False, ensemble=int(self.ensemble))
        out.update(self.conditions.save())
        out.update(self.parameters.save())
        return out

    @property
    def bits(self):
        return self._metadata_[self.type()].cast(int)

    @property
    def temperature(self):
        return self.conditions.temperature

    def boltz(self, energy) -> float:
        '''Return the Boltzmann factor corresponding to a given free energy (kcal/mol)'''

    def dangle5(self, b, c, d) -> float:
        '''Return dangle energy on 5' side'''

    def dangle3(self, b, c, d) -> float:
        '''Return dangle energy on 5' side'''

    def loop_energy(self, sequences, nick=None, _fun_=None):
        '''Return energy of loop'''
        return _fun_(self, as_sequences(sequences), -2 if nick is None else nick).cast(float)

    def structure_energy(self, strands, structure):
        '''Free energy of a given secondary structure (kcal/mol)'''
        return structure_energy(as_sequences(strands), PairList.from_object(structure), self)

################################################################################

@forward
def structure_energy(sequences, structure, model) -> float:
    '''Free energy of a given secondary structure in (kcal/mol)'''

################################################################################

@forward
class RateFunction:
    '''Rate function base class'''
    molarity: float
    bimolecular_scaling: float
    unimolecular_scaling: float
    beta: float

    __new__ = NotImplemented

    def __init__(self, molarity=1e-6, bimolecular_scaling=5e5, unimolecular_scaling=1.6e6):
        '''Initialize using the given rate constant scalings'''

    def nondimensional_rate(self, dE) -> float:
        pass

    def unimolecular_rate(self, dE) -> float:
        pass

    def bimolecular_rate(self, dE) -> float:
        pass

@forward
class Kawasaki(RateFunction):
    '''Kawasaki rate function'''

@forward
class Metropolis(RateFunction):
    '''Metropolis rate function'''

################################################################################
