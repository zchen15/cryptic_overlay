#!/usr/bin/env python3
import sys
from argparse import ArgumentParser
from nupack import Analysis
from .common import parse, output_header, read_sequences

################################################################################

def main(files, model, samples):
    eng = Analysis(model=model)

    if files[0]:
        seqs = read_sequences(files[0])
    else:
        seqs = input("Enter Sequence: ").split("+")
    out = files[1] or sys.stdout

    result = eng.boltzmann_sample(seqs, samples).value()

    addendum = '% Free energy: {} kcal/mol\n% Number of Samples: {}\n'.format(result.free_energy, samples)
    print(output_header(prog="subopt", seqs=seqs, model=model, addendum=addendum), file=out)

    for struc in result.sampled_structures:
        print(struc.dp(), file=out)

################################################################################

if __name__ == '__main__':
    parser = ArgumentParser(description='''
Randomly sample unpseudoknotted structures from the equilibrium distribution

Example: sample -multi -T 25 -material dna -samples 100 example
''')
    parser.add_argument('-samples', type=int, default=10, help='number of sampled structures returned')
    main(**parse(parser, [('.in', 'r'), ('.sample', 'w')]))

















# #!/usr/bin/env python3
# import sys
# from argparse import ArgumentParser
# from nupack import Analysis
# from nupack.constants import ZeroCinK, DefaultTemperature
# from math import log
# from .common import *



