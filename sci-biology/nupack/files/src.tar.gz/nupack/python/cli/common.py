import os, sys
from .. import __version__
from ..model import ParameterFile, Model, Conditions
from ..constants import ZeroCinK, water_molarity, BoltzmannConstant, DefaultTemperature
from ..concentration import solve_complexes
from time import localtime, strftime
import numpy as np

def parse(parser, files=[]):
    parser.add_argument('-material', type=str, default='rna', help='material type ("rna1995", "dna1998", or "rna1999")')
    parser.add_argument('-sodium', type=float, default=1.0, help='concentration of sodium')
    parser.add_argument('-magnesium', type=float, default=0.0, help='concentration of magnesium')
    parser.add_argument('-temperature', type=float, default=(DefaultTemperature - ZeroCinK), help='temperature in Celsius')
    parser.add_argument('-dangles', type=str, default='none', help='dangle energy treatment (none, min, all, or coax)')
    parser.add_argument('-multi', action='store_true', help='specify calculation involving complexes of multiple strands')
    parser.add_argument('prefix', type=str, nargs="?")
    ops = vars(parser.parse_args())
    ops['temperature'] += ZeroCinK
    parameters = ParameterFile(ops.pop('material'))
    ops.pop('multi')
    ops['model'] = Model(parameters=parameters, T=ops.pop('temperature'), dangles=ops.pop('dangles'), na=ops.pop('sodium'), mg=ops.pop('magnesium'))

    prefix = ops.pop('prefix')

    ops['files'] = []
    for (suffix, mode) in files:
        if prefix:
            filename = prefix + suffix
            try:
                ops['files'].append(open(filename, mode))
            except IOError:
                raise IOError("No file \"{}\"".format(filename))
        else:
            ops['files'].append(None)

    return ops


def read_sequences(input_file, lines=None):
    if lines == None:
        lines = [line.strip() for line in input_file]
    try: # if first line is a number, then correct format for multi;
        int(lines[0])
        multi = True
    except:
        multi = False


    if not multi:
        return [lines[0]]
    else:
        num_seqs = 0
        seqs = list()
        indices = list()
        for line in lines:
            line = line.strip()
            elems = line.split()
            if len(elems) == 1:
                try:
                    num = int(line)
                    if num_seqs == 0:
                        num_seqs = num
                    else:
                        indices = [num]
                except:
                    seqs.append(line)
            else:
                indices = [int(i) - 1 for i in elems]

        assert(num_seqs == len(seqs))
        try:
            return [seqs[i] for i in indices]
        except IndexError:
            raise IndexError("Permutation specification includes invalid index.")

def get_seqs_structure(input_file):
    lines = [line.strip() for line in input_file]
    structure = lines[-1]

    seqs = read_sequences(None, lines[:-1])

    return seqs, structure

def get_nicks(seqs):
    lens = [len(s) for s in seqs]
    return tuple(map(int, np.cumsum(lens)))

def output_header(prog, model, seqs=None, addendum="", outfile=sys.stdout):
    time = strftime("%a %b %-d %Y %X", localtime())

    header = \
"""% NUPACK {version}
% Program: {prog}
% Start time: {time}
% Command: {command}
% Sequence: {seq}
% v(pi): {v_pi}
% Parameters: {params}
% Dangles setting: {dangles}
% Temperature (C): {c_temp}
% Sodium concentration: 1.0000 M
% Magnesium concentration: 0.0000 M
"""
    pfile = model.parameters.metadata.file
    dG = os.path.basename(pfile.dG)
    dH = os.path.basename(pfile.dH)
    header = header.format(version=__version__, prog=prog, time=time, command=" ".join(sys.argv),
        v_pi=1, params=', '.join([pfile.material, dG] + ([dH] if dH else [])), ensemble=model.ensemble,
        c_temp=model.temperature, seq="+".join(seqs))

    return header + addendum

def print_concentrations(init_concs, compositions, dGs, temperature, comp_ids, sub_ids, outfile):
    print("%\n% Initial monomer concentrations", file=outfile)
    for i, ic in enumerate(init_concs):
        print("%\t{}:\t{:.6e} Molar".format(i+1, ic), file=outfile)

    x = solve_complexes(init_concs, compositions, g=dGs, T=(temperature + ZeroCinK))
    # print(x); exit()
    for comp_id, sub_id, comp, dG, conc in zip(comp_ids, sub_ids, compositions, dGs, x):
        conc_string = "{}\t{}\t".format(comp_id, sub_id) + "\t".join(str(c) for c in comp) + "\t{:.6e}\t{:.6e}".format(dG, conc)
        print(conc_string, file=outfile)

