#!/usr/bin/env python3
import sys
from argparse import ArgumentParser
from nupack import Analysis
from .common import parse, output_header, read_sequences

################################################################################

def main(files, model):
    eng = Analysis(model=model)

    if files[0]:
        seqs = read_sequences(files[0])
    else:
        seqs = input("Enter Sequence: ").split("+")
    out = files[1] or sys.stdout

    print(output_header(prog="mfe", seqs=seqs, model=model, addendum=''), file=out)

    result = eng.min_free_energy(seqs).value()
    for struc, energy in result.suboptimal_structures:
        divider = "% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %"
        print(divider, file=out)
        print(len("".join(seqs)), file=out)
        print("{:.4}".format(energy), file=out)
        print(struc.dp(), file=out)
        for i, n in enumerate(struc.pairs):
            if i < n:
                print("{}\t{}".format(i+1, n+1), file=out)
        print(divider + "\n", file=out)

################################################################################

if __name__ == '__main__':
    parser = ArgumentParser(description='''
Computes the MFE and returns all MFE structures

Example: mfe -multi -temperature 25 -material dna example
''')
    main(**parse(parser, [('.in', 'r'), ('.out', 'w')]))
