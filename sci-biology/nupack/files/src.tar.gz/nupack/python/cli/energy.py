#!/usr/bin/env python3
import sys
from argparse import ArgumentParser
from nupack import Analysis
from .common import parse, output_header, get_seqs_structure

################################################################################

def main(files, model, out=sys.stdout):
    if files[0]:
        seqs, structure = get_seqs_structure(files[0])
    else:
            seqs = input("Enter Sequence: ").split("+")
            print("Enter structure: ", file=out)
            print("+".join(seqs), file=out)
            structure = input()

    print(output_header(prog="energy", seqs=seqs, model=model, addendum=''), file=out)

    print(model.structure_energy(seqs, structure), file=out)

################################################################################

if __name__ == '__main__':
    parser = ArgumentParser(description='''
Compute the free energy of a given structure

Example: energy -multi -temperature 25 -material dna example
''')
    main(**parse(parser, [('.in', 'r')]))

################################################################################

