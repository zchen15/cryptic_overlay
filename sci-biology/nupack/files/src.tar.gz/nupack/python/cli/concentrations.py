#!/usr/bin/env python3
import sys
import numpy as np
from argparse import ArgumentParser
from nupack.constants import ZeroCinK, DefaultTemperature, water_molarity, BoltzmannConstant
from .common import *

parser = ArgumentParser(description='''
Calculate the partition function of the input sequence.

Example: concentrations prefix
''')

parser.add_argument('prefix', type=str)

args = parser.parse_args()

conc_fn = args.prefix + ".con"
try:
    concs_file = open(conc_fn, 'r')
    init_concs = [float(line.strip()) for line in concs_file.readlines()]
except IOError:
    raise IOError("Concentrations requested, but no concentration file " + conc_fn)

dG_fn = args.prefix + ".ocx"
dGs = []
comp_ids = []
sub_ids = []
compositions = []
header = ""
try:
    dG_file = open(dG_fn, 'r')
    for line in dG_file:
        toks = line.strip().split()

        if line[0] == '%':
            header += line

            if len(toks) > 2 and toks[1] == "T" and toks[2] == '=':
                temperature = float(toks[-1])


        if toks[0] != "%":
            ints = [int(t) for t in toks[:-1]]
            comp_ids.append(ints[0])
            sub_ids.append(ints[1])
            compositions.append(ints[2:])
            dGs.append(float(toks[-1]))

except IOError:
    raise IOError("No file {}. Must have run complexes.py prior to calling concentrations.py".format(conc_fn))

if len(compositions[0]) != len(init_concs):
    raise ValueError("number of sequences, {}, does not match number of initial concentrations, {}".format(len(seqs), len(init_concs)))

out_fn = args.prefix + ".eq"
try:
    outfile = open(out_fn, 'w')
except IOError:
    raise IOError("Can't open {}".format(out_fn))

print(header.strip(), file=outfile)
print_concentrations(init_concs, compositions, dGs, temperature, comp_ids, sub_ids, outfile)
