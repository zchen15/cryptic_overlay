#!/usr/bin/env python3
import sys
from argparse import ArgumentParser

from nupack import Analysis
from .common import parse, output_header, get_seqs_structure
from nupack.constants import dp_to_pairs, string_exp


################################################################################

def main(files, model, mfe, out=sys.stdout):
    eng = Analysis(model=model)

    if files[0]:
        seqs, structure = get_seqs_structure(files[0])
    else:
        seqs = input("Enter Sequence: ").split("+")
        print("Enter structure: ")
        print("+".join(seqs))
        structure = input()

    addendum = "% Structure: {}\n% Ensemble defect n(s, ϕ) and normalized ensemble defect n(s, ϕ)/N:"
    if mfe:
        addendum = "% Structure: {}\n% MFE defect μ(s, ϕ) and normalized MFE defect μ(s, ϕ)/N:"
    addendum = addendum.format(structure)

    print(output_header(prog="complexdefect", seqs=seqs, model=model, addendum=addendum), file=out)

    s = dp_to_pairs(structure)
    N = sum(len(s) for s in seqs)
    if not mfe:
        result = eng.pair_probability(seqs).value()
        ppairs, logq = result.pair_probability, result.log_partition_function
        defect = N - sum(ppairs[i, s[i]] for i in range(N))
        print(defect, file=out)
        print(defect/N, file=out)
    else:
        # return minimum defect of all MFE structures
        mfes = eng.min_free_energy(seqs).value().mfe_structures
        ms = [x[0] for x in mfes]

        def same(m):
            accum = 0
            for i in range(N):
                accum += s[i] == m[i]
            return accum

        defect = N - max(same(m.pairs.view()) for m in ms)
        print(defect, file=out)
        print(defect/N, file=out)


################################################################################

if __name__ == '__main__':
    parser = ArgumentParser(description='''
Calculate the complex ensemble defect of the input sequence relative to the input structure.

Example: pairs -multi -T 25 -material dna example
''')
    parser.add_argument('-mfe', action='store_true', help='compute MFE defect')
    main(**parse(parser, [('.in', 'r')]))
