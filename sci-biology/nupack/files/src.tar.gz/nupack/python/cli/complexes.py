#!/usr/bin/env python3
from typing import Tuple
import sys
import numpy
from argparse import ArgumentParser
from nupack import Analysis
from nupack.constants import ZeroCinK, DefaultTemperature, water_molarity, BoltzmannConstant
from math import log
from time import localtime, strftime
from .common import parse, get_nicks, print_concentrations
from nupack.constants import compute_necklaces

parser = ArgumentParser(description='''
Compute thermodynamic information for all complexes up to a maximum size.

Example: complexes -material DNA -sodium 1.0 -magnesium 0.0 -temperature 25 -dangles some -cutoff 0.0001 -pairs -mfe -concentrations
''')

parser.add_argument('-cutoff', type=float, default=0.001, help='minimum pair probability reported')
parser.add_argument('-pairs', action='store_true', help='compute pair probabilities for each complex')
parser.add_argument('-mfe', action='store_true', help='compute mfe structures for each complex')
parser.add_argument('-quiet', action='store_true', help='suppress output to the screen')
parser.add_argument('-concentrations', action='store_true', help='compute equilibrium concentrations of each complex based on strand concentrations in prefix.con')

options = parse(parser)
eng = Analysis(model=options['model'])
divider = "% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %"

def read_sequences(infile):
    lines = [line.strip() for line in infile.readlines()]
    num = int(lines[0])
    max_size = int(lines[-1])
    seqs = list()

    # pull out what should be sequence lines
    for line in lines[1:-1]:
        seqs.append(line)

    assert num == len(seqs)
    return seqs, max_size


def get_input_info(prefix):
    filename = prefix + ".in"
    try:
        infile = open(filename, 'r')
    except IOError:
        raise IOError("No input file \"{}\"".format(filename))

    seqs, max_size = read_sequences(infile)
    other_perms = list()

    list_fn = args.prefix + ".list"
    try:
        listfile = open(list_fn, 'r')
        lines = [line.strip() for line in listfile.readlines()]
        for line in lines:
            toks = line.split()
            if len(toks) > max_size:
                other_perms.append([int(n) - 1 for n in toks])
    except IOError:
        if not args.quiet: print("There is no input list " + list_fn)


    init_concs = []
    if args.concentrations:
        conc_fn = args.prefix + ".con"
        try:
            concs_file = open(conc_fn, 'r')
            init_concs = [float(line.strip()) for line in concs_file.readlines()]
        except IOError:
            raise IOError("Concentrations requested, but no concentration file " + conc_fn)

        if len(seqs) != len(init_concs):
            raise ValueError("number of sequences, {}, does not match number of initial concentrations, {}".
                    format(len(seqs), len(init_concs)))

    return seqs, max_size, other_perms, init_concs


def get_output_files(prefix):
    outfiles = {}
    try:
        outfiles["key"] = open(prefix + ".ocx-key", 'w')
        outfiles["ocx"] = open(prefix + ".ocx", 'w')
    except IOError:
        raise IOError("Can't open main output files.")

    if args.mfe:
        try:
            outfiles["mfe"] = open(prefix + ".ocx-mfe", 'w')
        except IOError:
            raise IOError("Can't open mfe output file.")

    if args.pairs:
        try:
            outfiles["pairs"] = open(prefix + ".ocx-ppairs", 'w')
        except IOError:
            raise IOError("Can't open pairs output file.")


    if args.concentrations:
        try:
            outfiles["conc"] = open(prefix + ".eq", 'w')
        except IOError:
            raise IOError("Can't open concentrations output file.")

    return outfiles


def print_header(prog="", seqs=None, params=None, dangles=None, temperature=None, addendum="", outfile=sys.stdout,
        max_size=None, cutoff=None, enum_complexes=None, explicit_complexes=None):
    time = strftime("%a %b %-d %Y %X", localtime())
    dangles = "none" # thermo algorithm can't turn dangles on
    all_complexes = enum_complexes + explicit_complexes
    params = "{}, {}, {}".format(params.material, params.dG, params.dH)
    command = " ".join(sys.argv)
    cutoff_str = ""
    if "ocx-ppairs" in outfile.name:
        cutoff_str = "% Minimum output pair probability: {}\n".format(cutoff)

    header = \
f"""% NUPACK v4
% Program: {prog}
% Start time: {time}
%
% Command: {command}
% Maximum complex size to enumerate: {max_size}
{cutoff_str}% Number of complexes from enumeration: {enum_complexes}
% Additional complexes from .list file: {explicit_complexes}
% Total number of complexes: {all_complexes}
% Parameters: {params}
% Dangles setting: {dangles}
% Temperature (C): {temperature}
% Sodium concentration: 1.0000 M
% Magnesium concentration: 0.0000 M
%
% Do not change the comments below this line, as they may be read by other programs!
%
"""

    print(header+addendum, file=outfile)


def make_addendum(seqs, temp):
    num = len(seqs)
    addendum = "% Number of strands: {}\n".format(num)
    addendum += "% id sequence\n"
    for i, s in enumerate(seqs):
        addendum += "% {:2} {}\n".format(i+1, s)
    addendum += "% T = {:.1f}".format(temp)

    return addendum


def get_compositions(perms):
    comps = list()
    for perm in perms:
        comp = [0] * len(seqs)
        for p in perm:
            comp[p] +=1
        comps.append(comp)

    comp_set = {}
    i = 0
    ids = []
    sub_ids = []
    for c in comps:
        tup = tuple(c)
        if tup not in comp_set:
            i += 1
            comp_set[tup] = i
        ind = comp_set[tup]
        ids.append(ind)
        sub_ids.append(ids.count(ind))

    return comps, ids, sub_ids


def rotate(l, n):
    n = n % len(l)
    return l[n:] + l[:n]


def free_energy(log_pfunc):
    return -log_pfunc/model.beta


perms = list()
def extract_perms(perm):
    perms.append(tuple(perm))


def pairs(seqs, to_file=print):
    ppairs, partition_function = eng.pair_probability(seqs, cache=True)

    size = ppairs.shape[0]
    unpaired = {}
    line = "{}\t{}\t{:.3e}"
    for i in range(size):
        for j in range(i, size):
            if i == j:
                unpaired[i+1] = ppairs[i,j]
            elif ppairs[i,j] > args.cutoff:
                to_file(line.format(i+1, j+1, ppairs[i,j]))

    # to_file unpaired probability as probability of pairing to fictitious N+1th base (backwards compatibility)
    for index, value in unpaired.items():
        to_file(line.format(index, size+1, value))


def mfe(seqs, to_file=print):
    nicks = get_nicks(seqs)
    result = MFE_Engine.subopt(seqs)
    for r in result:
        to_file("{:.8e}".format(r[1]))
        to_file(r[0].dp(nicks))
        for i, n in enumerate(r[0]):
            if i < n:
                to_file("{}\t{}".format(i+1, n+1))
        if r != result[-1]:
            to_file("")


def inc_output(comp_id, sub_id, comp, perm, energy):
    ocx = "{}\t{}\t".format(comp_id, sub_id) + "\t".join(str(c) for c in comp) + "\t{:.8e}".format(energy)
    print(ocx, file=outfiles["ocx"])

    key = "{}\t{}\t".format(comp_id, sub_id) + "\t".join(str(p + 1) for p in perm)
    print(key, file=outfiles["key"])

    seq = tuple(seqs[i] for i in perm)

    if args.pairs:
        def pairs_out(string):
            print(string, file=outfiles['pairs'])

        pairs_out("\n" + divider)
        pairs_out("% composition{}-ordering{}".format(comp_id, sub_id))
        pairs_out(sum(len(s) for s in seq))
        pairs(seq, pairs_out)
        pairs_out(divider)

    if args.mfe:
        def mfe_out(string):
            print(string, file=outfiles['mfe'])

        mfe_out("\n" + divider)
        mfe_out("% composition{}-ordering{}".format(comp_id, sub_id))
        mfe_out(sum(len(s) for s in seq))
        mfe(seq, mfe_out)
        mfe_out(divider)





outfiles = get_output_files(args.prefix)

seqs, max_size, other_perms, init_concs = get_input_info(args.prefix)

for size in range(1, max_size+1):
    compute_necklaces(extract_perms, n_elements=len(seqs), size=size)

num_perms = len(perms) + len(other_perms)

if not args.quiet: print("Starting partition function calculations.")

seq_inv = {s.replace('U', 'T'): i+1 for i, s in enumerate(seqs)}
unique_perms = set()
def print_seqs(message):
    width = len(str(num_perms))
    global unique_perms
    global inc_out_str
    if message.calculation_type != 'C':
        perm = [seq_inv[s] for s in message.sequences]
        should_append = True
        for i in range(len(perm)):
            if tuple(rotate(perm, i)) in unique_perms:
                should_append = False
        if should_append:
            unique_perms.add(tuple(perm))
            print("Computing partition function {:{width}} / {:{width}} : {perm}".format(len(unique_perms), num_perms, width=width, perm=perm))

results = eng.permutations(seqs, max_size, obs=(print_seqs if not args.quiet else None))
results = {k.sequences(): v for k, v in results}

for o in outfiles.values():
    print_header(prog="complexes",
            seqs=seqs,
            params=params,
            ensemble=args.ensemble,
            temperature=args.temperature,
            addendum=make_addendum(seqs, args.temperature),
            explicit_complexes=len(other_perms),
            enum_complexes=len(results),
            max_size=max_size,
            cutoff=args.cutoff,
            outfile=o
            )

for o in other_perms:
    cur = tuple(seqs[i].replace('U', 'T') for i in o)
    if not args.quiet:
        results[cur] = eng(cur, obs=(print_seqs if not args.quiet else None))

if not args.quiet: print("Partition function calculations finished.")

seqs = [seq.replace('U', 'T') for seq in seqs]


perms += other_perms
compositions, comp_ids, sub_ids = get_compositions(perms)

comp_ids, sub_ids, compositions, perms = zip(*sorted(zip(comp_ids, sub_ids, compositions, perms)))
dGs = list()

num = 0
for comp_id, sub_id, comp, perm in zip(comp_ids, sub_ids, compositions, perms):
    num += 1
    for i in range(len(perm)):
        rot = tuple(rotate(perm, i))
        seq = tuple(seqs[r] for r in rot)
        if seq in results.keys():
            dGs.append(free_energy(results[seq]))
            if args.mfe or args.pairs:
                if not args.quiet: print("Status: Set {} / {}: nPerms ({})  {} / {}".format(comp_id, max(comp_ids), sub_id, num, len(comp_ids)))
            inc_output(comp_id, sub_id, comp, perm, dGs[-1])
            break

if args.concentrations:
    print_concentrations(init_concs, compositions, dGs, args.temperature, comp_ids, sub_ids, outfiles['conc'])


if not args.quiet: print("Total number of terms calculated: {0}".format(len(perms)))
