#!/usr/bin/env python3
import sys
from argparse import ArgumentParser

from nupack import Analysis
from .common import parse, output_header, read_sequences
from nupack.constants import string_exp

################################################################################

def main(files, model, out=sys.stdout):
    eng = Analysis(model=model)

    if files[0]:
        seqs = read_sequences(files[0])
    else:
        seqs = input("Enter Sequence: ").split("+")

    addendum = '%\n% Free energy (kcal/mol) and partition function:'
    print(output_header(prog="pfunc", seqs=seqs, model=model, addendum=addendum), file=out)

    result = eng.partition_function(seqs).value().log_partition_function
    print(-result/model.beta, file=out)
    print(string_exp(result), file=out)

def go():
    parser = ArgumentParser(description='Calculate the partition function of the input sequence.\n\nExample: pfunc -multi -T 25 -material dna prefix')
    main(**parse(parser, [('.in', 'r')]))

################################################################################

if __name__ == '__main__':
    go()
