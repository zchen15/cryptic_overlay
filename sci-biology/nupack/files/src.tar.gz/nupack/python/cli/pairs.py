#!/usr/bin/env python3
import sys
from argparse import ArgumentParser

from nupack import Analysis
from .common import parse, output_header, read_sequences
from nupack.constants import string_exp

################################################################################

def main(files, model, cutoff):
    eng = Analysis(model=model)

    if files[0]:
        seqs = read_sequences(files[0])
    else:
        seqs = input("Enter Sequence: ").split("+")
    out = files[1] or sys.stdout

    addendum = "% Minimum printed pair probability: {}".format(cutoff)
    print(output_header(prog="pairs", seqs=seqs, model=model, addendum=addendum), file=out)

    result = eng.pair_probability(seqs).value()
    print("% Free energy: {} kcal/mol\n".format(result.free_energy), file=out)
    print(len("".join(seqs)), file=out)

    P = result.pair_probability
    size = P.shape[0]
    unpaired = [0] * (size + 1)

    pair_lines = ""
    for i in range(size):
        for j in range(i, size):
            if P[i,j] > cutoff:
                if i == j:
                    unpaired[i+1] = P[i,j]
                else:
                    pair_lines += "{}\t{}\t{:.4e}\n".format(i+1, j+1, P[i,j])
    if len(pair_lines) > 0: print(pair_lines.rstrip(), file=out)

    # print unpaired probability as probability of pairing to fictitious N+1th base (backwards compatibility)
    for i in range(1,size+1):
        print("{}\t{}\t{:.4e}".format(i, size+1, unpaired[i]), file=out)

################################################################################

if __name__ == '__main__':
    parser = ArgumentParser(description='''
Calculate the pair probabilities of the input sequence.

Example: pairs -multi -T 25 -material dna example
''')
    parser.add_argument('-cutoff', type=float, default=0.001, help='minimum pair probability reported')
    main(**parse(parser, [('.in', 'r'), ('.ppairs', 'w')]))
