#!/usr/bin/env python3
import sys
from argparse import ArgumentParser
from nupack import Analysis
from .common import parse, output_header, read_sequences

################################################################################

def main(files, model, gap, dotparensonly):
    eng = Analysis(model=model)

    if files[0]:
        seqs = read_sequences(files[0])
    else:
        seqs = input("Enter Sequence: ").split("+")
    out = files[1] or sys.stdout

    addendum = '% Energy gap: {}\n'.format(gap)
    print(output_header(prog="subopt", seqs=seqs, model=model, addendum=addendum), file=out)

    result = eng.suboptimal_structure(seqs, gap=gap).value()

    for struc, energy in result.suboptimal_structures:
        divider = "% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %"
        print(divider, file=out)
        print(len("".join(seqs)), file=out)
        print("{:.4}".format(energy), file=out)
        print(struc.dp(), file=out)
        if not dotparensonly:
            for i, n in enumerate(struc.pairs):
                if i < n:
                    print("{}\t{}".format(i+1, n+1), file=out)
        print(divider + "\n", file=out)

################################################################################

if __name__ == '__main__':
    parser = ArgumentParser(description='''
Return all structures within gap above MFE

Example: subopt -multi -temperature 25 -material dna -gap 1.0 example
''')
    parser.add_argument('-gap', type=float, default=0.0, help='the energy gap in kcal/mol above the mfe for which structure are included')
    parser.add_argument('-dotparensonly', action="store_true", help="print the dot parens structure only, skipping a list of pairs")
    main(**parse(parser, [('.in', 'r'), ('.subopt', 'w')]))



