from .generic import Runner
import sys
sys.path.insert(0, '/Users/nporubsk/Code/Ji_coax/build/')

import scd

class Unvectorized_Coaxial:
    def __init__(self, count):
        self.count = count

    def __call__(self, strands):
        seq = '+'.join(s.lower().replace("u", "t") for s in strands)
        runner = scd.pfunc(seq)
        if self.count: runner.setcount()
        ret = float(runner.getans())
        print(sum(len(s) for s in strands), ret)
        return ret


pfunc, count = [Runner('Ji\'s unvectorized code', Unvectorized_Coaxial(c)) for c in (0,1)]

