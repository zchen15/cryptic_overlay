from tempfile import TemporaryDirectory
from subprocess import check_call
import os

def complexes_and_concentrations(sequences, strand_concentrations, maxsize=1, material='rna1995', dangles='none', prefix='', timeout=None):
    '''
    sequences: tuple of sequence strings, e.g. ('AAA', 'TTT')
    concentrations: list of concentrations for the same sequences
    Returns:
        - list of strand indices for each complex
        - free energies for each complex in the same order
        - concentrations of each complex in the same order
    '''
    with TemporaryDirectory() as directory:
        path = os.path.join(directory, 'nupack_input')
        with open(path + '.in', 'w') as in_file:
            print(len(sequences), file=in_file)
            for s in sequences:
                print(s, file=in_file)
            print(maxsize, file=in_file)

        check_call([prefix + 'complexes', '-quiet', '-dangles', dangles, '-material', material, path], timeout=timeout)

        indices, concentrations, delta_G = [], [], []

        with open(path + '.con', 'w') as in_file:
            for i in strand_concentrations:
                print(i, file=in_file)

        check_call(['concentrations', '-sort', '0', '-quiet', path], timeout=timeout)

        with open(path + '.eq') as out_file:
            for line in out_file:
                toks = line.split()
                if toks[0] != '%':
                    indices.append([int(i) for i in toks[2:-2]])
                    concentrations.append(float(toks[-1]))
                    delta_G.append(float(toks[-2]))

        return indices, delta_G, concentrations
