from nupack import random_sequence
from nupack.constants import evaluation_cost, ANALYSIS_CPU_PREFACTOR
import json, sys, numpy as np

def split():
    jobs = json.load(open('sampling-natural.json'))

    x = np.arange(len(jobs))
    np.random.shuffle(x)

    chunks = np.array_split(x, 6)

    for i, c in enumerate(chunks):
        with open('sampling-natural-%d.json' % i, 'w') as f:
            json.dump([jobs[j] for j in c], f)


def cpu(n3):
    return n3 * ANALYSIS_CPU_PREFACTOR / 3600

def mem(s):
    return 17 * 8 * s**2 / 1e9

'''
These functions are supposed to each write a JSON file(s).
An example JSON file is like
[{
    "type": "versions",
    "parameters": ["AAA", "TTT"]
}]
'''

def versions(reps):
    '''
    Figure 9A. 9B is just reformatted data.
    A single complex of size 3, strand lengths given below
    Calculate with dangles = 'none' and 'coax', and NUPACK 3 'none'
    '''
    # sizes = [3, 10, 30, 100, 300, 1000, 3000, 10000]
    sizes = np.round(10 ** np.arange(0.5, 4.25, 0.25)).astype(int)
    print({
        'Number': reps,
        'Memory': mem(3 * sizes[-1]),
        'Time': cpu(sum((3 * x)**3 for x in sizes))
    })

    for r in range(reps):
        yield [[random_sequence(size) for _ in range(3)] for size in sizes]

def blocking(reps):
    '''
    Figure 10B/C plots
    Calculate all complex PFs with NUPACK 4 with dangles = 'coax'
    Blocking on and off
    Number of strands [1:8]
    Lmax = [2:6]
    Strand length = 30
    '''
    lengths = [50]
    strands = range(1, 9)
    lmaxes = range(2, 7)

    print({
        'Number': 1,
        'Memory': float('inf'),
        'Time': reps * cpu(sum(float(evaluation_cost([l] * n, lmax)) for n in strands for lmax in lmaxes for l in lengths))
    })

    yield [[[random_sequence(l) for _ in range(n)], lmax] for r in range(reps) for n in strands for lmax in lmaxes for l in lengths]


def parallel(reps):
    lengths = [50]
    strands = range(1, 128)
    lmaxes = range(1, 3)

    print({
        'Number': 1,
        'Memory': float('inf'),
        'Time': reps * cpu(sum(float(evaluation_cost([l] * n, lmax)) for n in strands for lmax in lmaxes for l in lengths))
    })

    yield [[[random_sequence(l) for _ in range(n)], lmax] for n in strands for r in range(reps) for lmax in lmaxes for l in lengths]

def sampling(reps):
    '''
    Figure 13
    For number of compare_sampling 10^2 10^4 10^6 (superset done here)
    3 strands of the strand lengths below
    Calculate single complex Boltzmann compare_sampling with dangles = 'coax'
    Also calculate single sampling time (just multiply?)
    '''
    # sizes = [10, 30, 100, 300, 1000, 3000]
    sizes = np.round(10 ** np.arange(0.5, 3.75, 0.25)).astype(int)
    print({
        'Number': 1,
        'Memory': 3 * sizes[-1] * 1e6 * 4 / 1e9 + mem(3 * sizes[-1]),
        'Time': reps * cpu(sum((3 * x)**3 for x in sizes))
    })
    yield [([random_sequence(size) for _ in range(3)], [int(10 ** m) for m in [0, 1, 2, 3, 4, 5, 6]]) for r in range(reps) for size in sizes]

def subopt(reps):
    '''
    Figure 13
    For number of compare_sampling 10^2 10^4 10^6 (superset done here)
    3 strands of the strand lengths below
    Calculate single complex Boltzmann compare_sampling with dangles = 'coax'
    Also calculate single sampling time (just multiply?)
    '''
    # sizes = [10, 30, 100, 300, 1000, 3000]
    sizes = np.round(10 ** np.arange(0.5, 3.75, 0.25)).astype(int)
    print({
        'Number': 1,
        'Time': reps * cpu(sum((3 * x)**3 for x in sizes))
    })
    yield [[random_sequence(size) for _ in range(3)] for r in range(reps) for size in sizes]


def quantities(reps):
    '''
    Figure 14
    Partition function, P matrix, MFE, MFE structure, subopt(k T), Sample(m=30 and 1000)
    Coaxial stacking
    Single complexes
    '''
    # sizes = [10, 30, 100, 300, 1000, 3000]
    sizes = np.round(10 ** np.arange(0.5, 3.75, 0.25)).astype(int)
    print({
        'Number': 1,
        'Memory': mem(3 * sizes[-1]),
        'Time': reps * 3 * cpu(sum((3 * x)**3 for x in sizes))
    })
    yield [[random_sequence(size) for _ in range(3)] for r in range(reps) for size in sizes]


def contours(batches, reps, time):
    '''
    Lmax [1:10]
    Max time either 1 or 60 minutes
    Partition function and concentrations
    Coaxial stacking
    '''
    sizes = [30, 100, 300]
    strands = list(range(1, 11)) + [15, 20, 25, 30, 40, 50, 60, 70, 80, 90, 100]
    print({
        'Number': batches * len(sizes),
        'Memory': float('inf'),
        'Time': reps * len(strands) * 10 * time / 3600
    })
    for _ in range(batches):
        # go through the following series until the time taken is too high
        yield [([random_sequence(size) for _ in range(n)], time) for r in range(reps) for size in sizes for n in strands]

def dump(name, items):
    if input('Run {}? (y/n)'.format(name)) != 'y':
        return
    print('\n' + name)
    for i, jobs in enumerate(items):
        if len(sys.argv) > 1:
            with open('%s/%s-%d.json' % (sys.argv[1], name, i), 'w') as f:
                json.dump([dict(type=name.split('-')[0], parameters=j) for j in jobs], f)

dump('blocking',   blocking(10))
dump('quantities', quantities(10))
dump('sampling',   sampling(100))
dump('subopt',     subopt(100))
dump('contours-h', contours(5, 1, 3600))
dump('contours-m', contours(1, 5, 60))
dump('parallel',   parallel(5))
dump('versions',   versions(5))
