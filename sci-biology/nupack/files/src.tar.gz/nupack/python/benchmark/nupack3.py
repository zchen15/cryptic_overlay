from subprocess import call, check_call
from tempfile import TemporaryDirectory
import os, re, time, numpy as np
from .generic import Runner
from functools import partial
from random import uniform
from ..constants import BoltzmannConstant, DefaultTemperature, as_sequences

################################################################################

def scalar_exe(seqs, commands, material='rna1995', dangles='none', prefix='', timeout=None, **kwargs):
    seqs = as_sequences(seqs)
    commands = list(commands)
    commands[0] = prefix + commands[0]
    with TemporaryDirectory() as dir:
        path = os.path.join(dir, 'random_rna')
        with open(path + '.in', 'w') as in_file:
            print('+'.join(seqs), file=in_file)

        commands += ['-material', material, '-dangles', dangles]
        if len(kwargs) > 0:
            for k, v in kwargs.items():
                commands += ["-" + k, str(v)]
        commands += [path]

        s = -time.time()
        with open(path + '.out', 'w') as out_file:
            call(commands, stdout=out_file, timeout=timeout)
        s += time.time()

        with open(path + '.out') as out_file:
            lines = out_file.readlines()
            result = lines[-1]
            print(''.join(lines))

        ret = dict(result=result, material=material, time=s)
        ret.update(kwargs)
        return ret

################################################################################

def mfe(seqs, material='rna1995', dangles='none', **kwargs):
    seqs = as_sequences(seqs)
    with TemporaryDirectory() as dir:
        path = os.path.join(dir, 'random_rna')
        with open(path + '.in', 'w') as in_file:
            print('+'.join(seqs), file=in_file)

        commands = ['mfe', '-dangles', dangles, '-material', material]
        if len(kwargs) > 0:
            for k, v in kwargs.items():
                commands += ["-" + k, str(v)]
        commands += [path]
        check_call(commands)

        with open(path + '.mfe') as out_file:
            lns = out_file.readlines()
            try:
                lns = lns[lns.index(next(ln for ln in lns if '%'*10 in ln)):]
            except StopIteration:
                raise ValueError('No connected structures')
            ret = dict(structure=lns[3].strip(), energy=float(lns[2].strip()))

        if len(kwargs) == 0:
            return ret
        else:
            ret.update(kwargs)
            ret["material"] = material
            return ret

################################################################################

def subopt(seqs, gap, material='rna1995', dangles='none'):
    seqs = as_sequences(seqs)
    match = re.compile("^[()+.]+$").match
    with TemporaryDirectory() as dir:
        path = os.path.join(dir, 'random_rna')
        with open(path + '.in', 'w') as in_file:
            print('+'.join(seqs), file=in_file)
            print(0.000001 + gap, file=in_file)
        check_call(['subopt', '-dangles', dangles, '-material', material, path])
        with open(path + '.subopt') as out_file:
            strucs = [ln.strip() for ln in filter(match, out_file.readlines())]
            if not strucs: raise ValueError("No connected structure")
            return strucs

################################################################################

def run_sample(seqs, n, material='RNA'):
    seqs = as_sequences(seqs)
    """
    Sample structures for a set of sequences
        sequences: ordered sequences
        n: number of samples to draw
    """
    mat = {'rna': 'rna1995', 'dna': 'dna1998'}[material.lower()]
    with tempfile.TemporaryDirectory() as tmp:
        with open(os.path.join(tmp, 'x.in'), 'w') as f:
            f.write('\n'.join(seqs))
        cmd = ['sample', '-material', mat, '-samples', str(n)]
        try:
            subprocess.check_call(cmd + [os.path.join(tmp, 'x')], stdout=subprocess.DEVNULL, env=env)
        except subprocess.CalledProcessError:
            return set([None])
        with open(os.path.join(tmp, 'x.sample')) as f:
            return set(ln for ln in f.read().split('\n') if ln and not ln.startswith('%'))

################################################################################

def concentrations(seqs, maxsize=1, material='rna1995', dangles='none', prefix='', timeout=None):
    seqs = as_sequences(seqs)
    kT = 0.00198717 * 310.15
    with TemporaryDirectory() as dir:
        path = os.path.join(dir, 'random_rna')
        with open(path + '.in', 'w') as in_file:
            print(len(seqs), file=in_file)
            for s in seqs: print(s, file=in_file)
            print(maxsize, file=in_file)

        s1 = -time.time()
        check_call([prefix + 'complexes', '-quiet', '-dangles', dangles, '-material', material, path], timeout=timeout)
        s1 += time.time()

        factor = 10 ** uniform(-12, -3)
        x0 = [uniform(0.1,100) * factor for s in seqs]
        A = []
        x = []
        g = []

        with open(path + '.con', 'w') as in_file:
            for i in x0: print(i, file=in_file)

        s2 = -time.time()
        check_call(['concentrations', '-sort', '0', '-quiet', path], timeout=timeout)
        s2 += time.time()

        with open(path + '.eq') as out_file:
            for line in out_file:
                toks = line.split()
                if toks[0] != '%':
                    A.append([int(i) for i in toks[2:-2]])
                    x.append(float(toks[-1]))
                    g.append(float(toks[-2])/kT)
        x0 += [0 for i in range(len(x) - len(x0))]
        return dict(x0=x0, A=A, g=g, x=x, complexes_time=s1, concentrations_time=s2)

################################################################################

def pairs(seqs, material='rna1995', dangles='none'):
    seqs = as_sequences(seqs)
    length = len("".join(seqs))
    multi = len(seqs) > 1
    with TemporaryDirectory() as dir:
        path = os.path.join(dir, 'random')
        with open(path + ".in", 'w') as in_file:
            if not multi:
                print("".join(seqs), file=in_file)
            else:
                print(len(seqs), file=in_file)
                for seq in seqs:
                    print(seq, file=in_file)
                print(" ".join(str(1 + r) for r in range(len(seqs))), file=in_file)

        if not multi:
            check_call(["pairs", "-dangles", dangles, "-material", material, path])
        else:
            check_call(["pairs", "-dangles", dangles, "-multi", "-material", material, path])

        left, right, prob = [], [], []
        with open(path + ".ppairs") as out_file:
            match = re.compile("^[0-9]+\t[0-9]+\t[0-9][.][0-9]{4}e-[0-9]{2}$").match
            lines = [line.strip() for line in filter(match, out_file.readlines())]
            for line in lines:
                toks = line.split()
                i = int(toks[0]) - 1
                j = int(toks[1]) - 1
                left.append(i)
                if j == length:
                    j = i
                right.append(j)
                prob.append(float(toks[2]))

        return dict(i=left, j=right, prob=prob)

################################################################################

pfunc = partial(scalar_exe, commands=['pfunc'])
count = partial(scalar_exe, commands=['count'])
energy = partial(scalar_exe, commands=['energy'])

################################################################################

run_subopt = Runner('NUPACK 3.2.0', subopt)
run_mfe =    Runner('NUPACK 3.2.0', mfe)
run_pairs =  Runner('NUPACK 3.2.0', pairs)
run_count =  Runner('NUPACK 3.2.0', count)
run_pfunc =  Runner('NUPACK 3.2.0', pfunc)
run_energy = Runner('NUPACK 3.2.0', energy)
run_concentrations = Runner('NUPACK 3.2.0', concentrations)

"""
EXAMPLE SCRIPT

from nupack.benchmark import default_gen, param_gen, nupack3

ms_gen = lambda: (default_gen(2, 8, 200) for _ in range(16))
ss_gen = lambda: (default_gen(1, 1, 400) for _ in range(16))
ss_param_gen = lambda: (param_gen(1, 1, 400) for _ in range(16))

for i in range(200):
    print(i)
    nupack3.run_subopt('subopt-dna98-basic-0.0-ss', gen=ss_gen(), gap=0.0, material='dna1998')
    nupack3.run_subopt('subopt-dna98-basic-0.0-ms', gen=ms_gen(), gap=0.0, material='dna1998')
    nupack3.run_subopt('subopt-rna95-basic-0.0-gu-ss', gen=ss_gen(), gap=0.0, material='rna1995')
    nupack3.run_subopt('subopt-rna95-basic-0.0-gu-ms', gen=ms_gen(), gap=0.0, material='rna1995')

    nupack3.run_subopt('subopt-dna98-basic-0.4-ss', gen=ss_gen(), gap=0.4, material='dna1998')
    nupack3.run_subopt('subopt-dna98-basic-0.4-ms', gen=ms_gen(), gap=0.4, material='dna1998')
    nupack3.run_subopt('subopt-rna95-basic-0.4-gu-ss', gen=ss_gen(), gap=0.4, material='rna1995')
    nupack3.run_subopt('subopt-rna95-basic-0.4-gu-ms', gen=ms_gen(), gap=0.4, material='rna1995')

    nupack3.run_pfunc('pf-dna98-basic-ss', gen=ss_gen(), material='dna1998')
    nupack3.run_pfunc('pf-dna98-basic-ms', gen=ms_gen(), material='dna1998')
    nupack3.run_count('count-dna98-basic-ss', gen=ss_gen(), material='dna1998')
    nupack3.run_count('count-dna98-basic-ms', gen=ms_gen(), material='dna1998')
    nupack3.run_mfe('mfe-dna98-basic-ss', gen=ss_gen(), material='dna1998')
    nupack3.run_mfe('mfe-dna98-basic-ms', gen=ms_gen(), material='dna1998')

    nupack3.run_pairs('pairs-rna95-basic-ms', gen=ms_gen(), material='rna1995')
    nupack3.run_pairs('pairs-dna98-basic-ms', gen=ms_gen(), material='dna1998')
    nupack3.run_pairs('pairs-rna95-basic-ss', gen=ss_gen(), material='rna1995')
    nupack3.run_pairs('pairs-dna98-basic-ss', gen=ss_gen(), material='dna1998')


FOR CONCENTRATIONS

from nupack.benchmark import default_gen, nupack3

ms_gen = lambda: (default_gen(2, 8, 50) for _ in range(8))

for i in range(50):
    print(i)
    nupack3.run_concentrations('concentrations-rna95-basic', gen=ms_gen(), maxsize=3, material='rna1995')
    nupack3.run_concentrations('concentrations-dna98-basic', gen=ms_gen(), maxsize=3, material='dna1998')
"""
