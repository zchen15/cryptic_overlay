"""This module contains the class ParameterSet

"""
import numpy as np
from functools import partial
from itertools import product
import json, datetime

################################################################################

BASEPAIRS = ["A{UT}", "CG", "GC", "{UT}A", "G{UT}", "{UT}G"]
BASES = ["A", "C", "G", "{UT}"]

# ideal gas constant in kcal/mol/K
R = 1.972036e-3
# Temperature in K
T = 273.15 + 37

KT = R * T

MISSING = 9999 # float('nan')

def dict_to_array(d):
    out = [0.0] * (max(d.keys()) + 1 if d else 0)
    for k, v in d.items():
        out[int(k)] = v
    return out

def concatenate_keys(d):
    return {''.join(k): v for k, v in d.items()}


def nupack4_mismatch(d):
    return {k[1][1] + k[0][1] + k[0][0] + k[1][0]: v for k, v in d.items()}


################################################################################

class Parameters:
    """Energy values for sequence and size dependent quantities

    This class is essentially a convenient collection of dictionaries and
    values so that ParameterSet can have a unified interface for Gibbs
    free energy and enthalpy values. This allows output methods to reuse
    logic for both types of data.

    All values are stored in kcal/mol (as most are reported this way)
    """
    def __init__(self):
        """Construct a the set of underlying dictionaries

        For loops, keys are a tuple of sequences with the same backbone
        and it is implied that last base of sequence i is paired to the
        first base of sequence i+1

        Attributes:
            stacks (dict): nearest-neighbor energies
            triloops (dict): energies for measured triloops
            tetraloops (dict): energies for measured tetraloops
            terminal_mismatch (dict): energies for the mismatch of two unpaired
                bases in an exterior loop adjacent to a base pair
            hairpin_mismatch (dict): energies for first mismatch inside of
                a hairpin
            interior_mismatch (dict): energies for first mismatch adjacent
                to one pair in an interior loop
            interior_1x1 (dict): mismatch interior loop energies
            interior_1x2 (dict): size 3, asymmetry 1 interior loop energies
            interior_2x2 (dict): size 4, asymmetry 0 interior loop energies
            dangles (dict): dangle energy for single base extensions
            hairpin_size (dict): size-based energies for hairpins
            bulge_size (dict): size-based energies for bulge loops
            interior_size (dict): size-based energies for interior loops
            multiloop_terms (dict): alpha terms for multiloop energy
            asymmetry_terms (dict): terms corresponding to energy for
                asymmetry in interior loops
            poly_C (dict):
            AT_penalty (float): penalty applied when pair defining a
                multiloop or exterior loop is not a GC pair ("AT penalty"
                is the historical name)
            bimolecular (float): an energy penalty for translational entropy
                loss incurred when a free strand joins a complex.
        """
        self.log_loop_penalty = None
        # key format: ("AB", "CD") C is 3' of A, D is 5' of B
        self.stacks = {}
        # key format: ("AB", "CD") C is 3' of A, D is 5' of B, strand break between C and D
        self.flush_coaxial_stacks = {}
        # key format: ("ABCDE")
        self.triloops = {}
        # key format: ("ABCDEF")
        self.tetraloops = {}
        # key format: ("AB", "CD") AB -> basepair, C is 3' of A, D is 5' of B
        self.terminal_mismatch = {}
        # key format: ("AB", "CD") AB -> basepair, C is 3' of A, D is 5' of B
        self.hairpin_mismatch = {}
        # key format: ("AB", "CD") AB -> basepair, C is 3' of A, D is 5' of B
        self.interior_mismatch = {}
        # key format: ("ABC", "DEF")
        self.interior_1x1 = {}
        # key format: ("ABC", "DEFG")
        self.interior_1x2 = {}
        # key format: ("ABCD", "EFGH")
        self.interior_2x2 = {}
        # key format:
        #   ("AB", "C"): C is 3' of A
        #   ("A", "BC"): A is 5' of B
        self.dangles = {}
        # key format: int
        self.hairpin_size = {}
        # key format: int
        self.bulge_size = {}
        # key format: int
        self.interior_size = {}
        # keys: α1, α2, α3,
        self.multiloop_terms = {}
        # keys: m1, m2, m3, m4, max
        self.asymmetry_terms = {}
        # keys: poly_C_triloop, slope, intercept
        self.poly_C = {}
        # keys: β1, β1m, β1p, β2, β3
        self.pseudoknot_terms = {}
        self.AT_penalty = None
        self.bimolecular = None

    def to_dict(self, *, make_strings=True):
        if make_strings:
            def make_keys_strings(d):
                return {str(k): v for k, v in d.items()}
        else:
            def make_keys_strings(d):
                return d

        return {
                "stacks": make_keys_strings(self.stacks),
                "flush_coaxial_stacks": make_keys_strings(self.flush_coaxial_stacks),
                "triloops": make_keys_strings(self.triloops),
                "tetraloops": make_keys_strings(self.tetraloops),
                "terminal_mismatch": make_keys_strings(self.terminal_mismatch),
                "hairpin_mismatch": make_keys_strings(self.hairpin_mismatch),
                "interior_mismatch": make_keys_strings(self.interior_mismatch),
                "interior_1x1": make_keys_strings(self.interior_1x1),
                "interior_1x2": make_keys_strings(self.interior_1x2),
                "interior_2x2": make_keys_strings(self.interior_2x2),
                "dangles": make_keys_strings(self.dangles),
                "hairpin_size": make_keys_strings(self.hairpin_size),
                "bulge_size": make_keys_strings(self.bulge_size),
                "interior_size": make_keys_strings(self.interior_size),
                "multiloop_terms": make_keys_strings(self.multiloop_terms),
                "asymmetry_terms": make_keys_strings(self.asymmetry_terms),
                "poly_C": make_keys_strings(self.poly_C),
                "pseudoknot_terms": make_keys_strings(self.pseudoknot_terms),
                "AT_penalty": self.AT_penalty,
                "bimolecular": self.bimolecular,
        }

    def to_nupack4(self):
        return {
            'log_loop_penalty': self.log_loop_penalty,
            'hairpin_size': dict_to_array(self.hairpin_size)[1:],
            'bulge_size': dict_to_array(self.bulge_size)[1:],
            'multiloop_closing': self.multiloop_terms.get('α1', 0),
            'multiloop_interior': self.multiloop_terms.get('α2', 0),
            'multiloop_base': self.multiloop_terms.get('α3', 0),
            'join_penalty': self.bimolecular or 0.0,
            'interior_size': dict_to_array(self.interior_size)[1:],
            'asymmetry_ninio': [self.asymmetry_terms.get(k, 0) for k in ["m1", "m2", "m3", "m4", "max"]],
            'stack': concatenate_keys(self.stacks),
            'coaxial_stack': concatenate_keys(self.flush_coaxial_stacks),
            'hairpin_triloop': self.triloops,
            'hairpin_tetraloop': self.tetraloops,
            'hairpin_mismatch': nupack4_mismatch(self.hairpin_mismatch),
            'interior_mismatch': nupack4_mismatch(self.interior_mismatch),
            'terminal_mismatch': nupack4_mismatch(self.terminal_mismatch),
            'dangle_5': {k[0][1] + k[0][0] + k[1]: v for k, v in self.dangles.items() if len(k[1]) == 1},
            'dangle_3': {''.join(k): v for k, v in self.dangles.items() if len(k[0]) == 1},
            'interior_1_1': concatenate_keys(self.interior_1x1),
            'interior_1_2': concatenate_keys(self.interior_1x2),
            'interior_2_2': concatenate_keys(self.interior_2x2),
            'terminal_penalty': {'AT': self.AT_penalty} if self.AT_penalty else {},
        }

################################################################################

class Lookup:
    '''
    Class which enables tracking each individual nearest-neighbor parameter
    '''

    def __init__(self):
        self.contents = {}

    def __getitem__(self, name_value):
        name, value = name_value
        assert isinstance(name, str)
        value = float(value)
        if self.contents.get(name, value) != value:
            raise ValueError('Parameter is set to different values', name, value)
        return value

    def key(self, key):
        return str(key) if isinstance(key, (str, int)) else '-'.join(map(self.key, key))

    def tabulate(self, prefix, items):
        if hasattr(items, 'items'):
            return {k: self['%s-%s' % (prefix, self.key(k)), v] for k, v in items.items()}
        else:
            return [(*v[:-1], self['%s-%s' % (prefix, self.key(v[:-1])), v[-1]]) for v in items]

################################################################################

class ParameterSet(Lookup):
    """A representation of the nucleic acid secondary structure model parameters


    Classes:
        Parameters: collection of dictionaries for individual parameter
        types

    Instance Methods:
        to_nupack3: output current object state in the format used up to
            NUPACK 3
        to_json: output JSON representation of the parameters
        to_binary: output some as yet undetermined binary format for faster
            read-in to NUPACK 4.0
    """

    def __init__(self, name, *, material, temperature, default_wobble_pairing):
        """Create a blank ParameterSet

        Args:
            name (str): a short name for the parameter set.
            material (str): either rna or dna
            temperature (float): the temperature in degrees Celsius at which
                the data was measured and regressed.

        Attributes:
            name (str): a short name for the parameter set.
            material (str): either rna or dna
            temperature (float): the temperature in degrees Celsius at which
                the data was measured and regressed.
            dG (Parameters): the Gibbs free energy parameters relative to
                reference
            dH (Parameters): the enthalpy parameters relative to reference
        """
        super().__init__()
        self.name = name
        self.material = material
        self.temperature = temperature
        self.default_wobble_pairing = default_wobble_pairing
        self.dG = Parameters()
        self.dH = Parameters()

    # export functions
    def to_dict(self, **kwargs):
        return {"ΔG": self.dG.to_dict(**kwargs), "ΔH": self.dH.to_dict(**kwargs)}

    def to_nupack4(self):
        return {
            'name': self.name,
            'material': self.material,
            'default_wobble_pairing': self.default_wobble_pairing,
            'time_generated': datetime.datetime.now().isoformat(),
            'dG': self.dG.to_nupack4(),
            'dH': self.dH.to_nupack4()
        }

    def to_json(self, prefix, *, prettyprint=True):
        indent = 4 if prettyprint else None
        with open(prefix + ".json", 'w') as jfile:
            json.dump(self.to_dict(), jfile, ensure_ascii=False, indent=indent)


    def to_nupack3(self, prefix):
        """create old-style parameter files

        Args:
            prefix: the filename path to be augmented with .dG and .dH
        """
        decimals = {"rna": -1, "dna": 0}[self.material]
        UT = {"rna": "U", "dna": "T"}[self.material]
        bps = [x.format(UT=UT) for x in BASEPAIRS]
        bases = [x.format(UT=UT) for x in BASES]

        def scale_energy(num):
            """convert kcal/mol to deka cal/mol and round"""
            return int(np.around(num * 100, decimals=decimals))

        def energies_line(values):
            """print a line of energies appropriately scaled and formatted"""
            return "".join("{:4} ".format(scale_energy(v)) for v in values)

        def write_old_format(params, f):
            """output either a .dG or .dH file

            Args:
                params: either the dG or dH Parameters object
                f: the file to write parameters to
            """
            def stack_type_output(s):
                for pair1 in bps:
                    energies = list()
                    for pair2 in bps:
                        key = (pair1[0] + pair2[0], pair2[1] + pair1[1])
                        energies.append(s.get(key, MISSING))
                    out(energies_line(energies))


            out = partial(print, file=f)
            # stacking section
            out(f""">All values represent ΔG in units of deka cal/mol (kcal/mol*100)
>Stacking 5' X1 Y1 3'
>         3' X2 Y2 5'
>X1X2 = A{UT} CG GC {UT}A G{UT} {UT}G (row headings)
>Y1Y2 = A{UT} CG GC {UT}A G{UT} {UT}G (column headings)""")
            stack_type_output(params.stacks)

            # coaxial stack section
            out(f""">Coaxial Stacking 5' X1 - Y1 3'
>                 3' X2 / Y2 5'
>X1X2 = A{UT} CG GC {UT}A G{UT} {UT}G (row headings)
>Y1Y2 = A{UT} CG GC {UT}A G{UT} {UT}G (column headings)""")
            stack_type_output(params.flush_coaxial_stacks)

            # hairpin size section
            out(">Hairpin Loop Energies: size = 1,2,3,..,30")
            out(energies_line(params.hairpin_size.get(x, MISSING) for x in range(1,31)))

            # bulge loop size section
            out(">Bulge loop Energies: size = 1,2,3,..,30")
            out(energies_line(params.bulge_size.get(x, MISSING) for x in range(1,31)))

            # interior loop size section
            out(">Interior Loop Energies: size = 1,2,3,..,30")
            out(energies_line(params.interior_size.get(x, MISSING) for x in range(1,31)))

            # asymmetry terms section
            out(""">NINIO asymmetry Terms: m1, m2, m3, m4, max
>Energy = MAX[ max, asymmetry*m#] where # = MIN(4,L1,L2)
>and L1, L2 are lengths of each side of loop,
>and asymmetry = |L1-L2|""")
            names = ["m1", "m2", "m3", "m4", "max"]
            out(energies_line(params.asymmetry_terms.get(n, MISSING) for n in names))

            def print_sequence_energies(d):
                """print formatted pairs of sequences and their corresponding energies for hairpins"""
                keys = sorted(d.keys())
                for key in keys:
                    out("{}{:5}".format(key, scale_energy(d[key])))

            # triloop section
            out(">Triloops  5' .. 3' (Not listed equals 0 bonus)")
            empty = f"AAAA{UT}"
            # old loading protocol expects at least one explicit value in the file
            if not params.triloops:
                params.triloops[empty] = 0
            print_sequence_energies(params.triloops)

            # tetraloop section
            out(">Tetraloops  5' .. 3' (Not listed equals 0 bonus)")
            empty = f"AAAAA{UT}"
            # old loading protocol expects at least one explicit value in the file
            if not params.tetraloops:
                params.tetraloops[empty] = 0
            print_sequence_energies(params.tetraloops)

            def print_mismatches(p):
                for mismatch in product(bases, bases):
                    mismatch = "".join(mismatch)
                    energies = [p.get((x, mismatch), MISSING) for x in bps]
                    out(energies_line(energies))

            # hairpin mismatch section
            out(f""">Mismatch HP:
>Columns 5'-A{UT},CG,GC,{UT}A,G{UT},{UT}G-3'
>rows 5'-AA,AC,AG,A{UT},CA,..,{UT}{UT}-3'""")
            print_mismatches(params.hairpin_mismatch)

            # interior loop mismatch section
            out(f""">Mismatch Interior:
>Columns 5'-A{UT},CG,GC,{UT}A,G{UT},{UT}G-3'
>rows 5'-AA,AC,AG,A{UT},CA,..,{UT}{UT}-3'""")
            print_mismatches(params.interior_mismatch)

            # 3' dangle section
            out(f""">Dangle Energies: 5' X1 Y 3'
>                 3' X2 . 5'
>Columns: Y = A, C, G, {UT}
>Rows = X1X2 = A{UT},CG,GC,{UT}A,G{UT},{UT}G""")

            for pair in bps:
                energies = [params.dangles.get((pair,base), MISSING) for base in bases]
                out(energies_line(energies))

            # 5' dangle section
            out(f""">Dangle Energies: 5' X1 . 3'
>                 3' X2 Y 5'
>Columns: Y = A, C, G, {UT}
>Rows = X1X2 = A{UT},CG,GC,{UT}A,G{UT},{UT}G""")

            for pair in bps:
                energies = [params.dangles.get((base,pair[::-1]), MISSING) for base in bases]
                out(energies_line(energies))

            # multiloop terms section
            out(f""">Multiloop terms: ALPHA_1, ALPHA_2, ALPHA_3
>ML penalty = ALPHA_1 + s * ALPHA_2 + u *ALPHA_3
>s = # stems adjacent to ML, u = unpaired bases in ML""")
            names = ["α1", "α2", "α3"]
            out(energies_line(params.multiloop_terms.get(n, MISSING) for n in names))

            # AT penalty section
            out(""">AT_PENALTY:
>Penalty for non GC pairs that terminate a helix""")
            value = params.AT_penalty
            if not value:
                value = 0.0
            out(energies_line([value]))

            # 1x1 (single mismatch) interior loops section
            out(f""">Interior Loops 1x1
>CG..A{UT} = 5'- C X A 3'
>         3'- G Y {UT} 5'
>Rows: X = A C G {UT} (X constant for a row)
>Columns: Y = A C G {UT} (Y constant in column)""")
            for bp1, bp2 in product(bps, bps):
                out(f"{bp1}..{bp2}")
                for x in bases:
                    energies = [params.interior_1x1.get((bp1[0] + x + bp2[0], bp2[1] + y + bp1[1]), MISSING) for y in bases]
                    out(energies_line(energies))

            # 2x2 (tandem mismatch) interior loops section
            out(f""">Interior Loops 2x2
>CG.AG..A{UT} = 5'- C A G A -3'
>            3'- G Y X {UT} -5'
>Rows: X = A C G {UT} (X constant for a row)
>Columns: Y = A C G {UT} (Y constant in column)""")
            binary = list("".join(x) for x in product(bases, bases))
            for bp1, bp2, top in product(bps, bps, binary):
                out(f"{bp1}.{top}..{bp2}")
                for x in bases:
                    energies = [params.interior_2x2.get((bp1[0] + top + bp2[0], bp2[1] + f"{x}{y}" + bp1[1]), MISSING) for y in bases]
                    out(energies_line(energies))

            # 2x1 interior loops section
            out(f""">Interior Loops 1x2
>CG.A..A{UT} = 5'- C A   A -3'
>           3'- G Y X {UT} -5'
>Rows: X = A C G {UT} (X constant for a row)
>Columns: Y = A C G {UT} (Y constant in column)""")
            for bp1, bp2, top in product(bps, bps, bases):
                out(f"{bp1}.{top}..{bp2}")
                for x in bases:
                    energies = [params.interior_1x2.get((bp1[0] + top + bp2[0], bp2[1] + f"{x}{y}" + bp1[1]), MISSING) for y in bases]
                    out(energies_line(energies))

            # poly-C hairpin section
            out(""">POLYC - Penalty for poly C hairpins.
>First number is penalty for polyC triloop
>Second number is "slope", i.e. penalty per C in a non triloop
>Third number is "intercept", i.e. constant penalty for non triloops""")
            names = ["poly_C_triloop", "slope", "intercept"]
            out(energies_line(params.poly_C.get(name, MISSING) for name in names))

            # pseudoknot section
            out(""">BETA - Pseudoknot energy parameters.  B1 B2 B3 B1M B1P
>B1 = Constant penalty for "open" pseudoknot
>B2 = penalty per pair in pseudoknot
>B3 = penalty per base in pseudoknot
>B1M = constant penalty for pseudoknot in a "closed" loop
>B1P = constant penalty for pseudoknot in a pseudoknot.""")
            names = ["β1", "β2", "β3", "β1m", "β1p"]
            out(energies_line(params.pseudoknot_terms.get(n, MISSING) for n in names))

            # bimolecular section
            out(">BIMOLECULAR //TINOCO, 277")
            out(energies_line([params.bimolecular]))

        with open(prefix + ".dG", 'w') as dg_file:
            write_old_format(self.dG, dg_file)
        with open(prefix + ".dH", 'w') as dh_file:
            write_old_format(self.dH, dh_file)

    def to_binary(self, prefix):
        raise NotImplementedError

################################################################################

def fill_pseudoknot_terms(params):
    """Add in pseudoknot parameters from Dirks and Pierce (2003)

    Args:
        params: the ParameterSet to augment

    Citation: Dirks and Pierce (2003)

    These terms have never been changed and are the same for all material in
    NUPACK. As active development has moved away from pseudoknot modeling
    because of complexity constraints, these parameters are included primarily
    for historical documentation purposes (as they appear in the parameter
    files for NUPACK version <4.0).
    """
    # "After a search of the nearby parameter space we selected the values
    #       β_1 = 9.6, β_1^m = β_1^p = 15, β_2 = 0.1, β_3 = 0.1
    # Dirks and Pierce (2003)
    betas = {
            "β1": 9.6,
            "β1m": 15,
            "β1p": 15,
            "β2": 0.1,
            "β3": 0.1,
            }

    params.dG.pseudoknot_terms.update(betas)

    # no mention of temperature dependence, leave ΔH values blank
