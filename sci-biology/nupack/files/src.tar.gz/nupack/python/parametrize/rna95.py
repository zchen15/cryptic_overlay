"""Citations and logic to convert the parameter set presented in Serra and
    Turner (1995) into a Python object for output

Functions:
    make_rna_1995_parameters: produce ParameterSet based on
        Serra and Turner (1995) for RNA
    fill_stacks: fill in stack parameters
    fill_flush_coaxial_stacks: fill in flush coaxial stack parameters
    fill_triloops: fill in triloop bonuses
    fill_tetraloops: fill in tetraloop bonuses
    fill_terminal_mismatch: fill in terminal mismatch parameters
    fill_hairpin_mismatch: fill in hairpin mismatch parameters
    fill_interior_mismatch: fill in interior mismatch parameters
    fill_interior_1x1: fill in 1x1 interior loop parameters
    fill_interior_1x2: fill in 1x1 interior loop parameters
    fill_interior_2x2: fill in 1x1 interior loop parameters
    fill_dangle: fill in dangle parameters
    fill_hairpin_size: fill in hairpin loop size parameters
    fill_bulge_size: fill in bulge loop size parameters
    fill_interior_size: fill in interior loop size parameters
    fill_multiloop_terms: fill in linear multiloop function parameters
    fill_asymmetry_terms: fill in interior loop asymmetry parameters
    fill_poly_C: fill in poly-C hairpin parameters
    fill_AT_penalty: fill in penalty for non-GC loops
    fill_bimolecular: fill in bimolecular (join) parameter
"""
from .constants import ParameterSet, BASEPAIRS, BASES, KT, fill_pseudoknot_terms
from copy import deepcopy as copy
from itertools import product
import numpy as np

bases = [b.format(UT="U") for b in BASES]
base_pairs = [b.format(UT="U") for b in BASEPAIRS]

################################################################################

def generate():
    """Translate data from citations into an RNA ParmeterSet

    Returns:
        ParameterSet: full RNA parameters based on Serra and Turner (1995)


    Citations:
        Serra, M. J., & Turner, D. H. (1995). Predicting Thermodynamic Properties of RNA.
            Methods in Enzymology, 259(1977), 242-261.

        Jaeger, J. A., Turner, D. H., & Zuker, M. (1989). Improved predictions
            of secondary structures for RNA. Biochemistry, 86(October),
            7706-7710. http://doi.org/10.1073/pnas.86.20.7706

        Walter, a E., Turner, D. H., Kim, J., Lyttle, M. H., Müller, P.,
            Mathews, D. H., & Zuker, M. (1994). Coaxial stacking of helixes
            enhances binding of oligoribonucleotides and improves predictions
            of RNA folding. Proceedings of the National Academy of Sciences of
            the United States of America, 91(20), 9218-9222.
            http://doi.org/10.1073/pnas.91.20.9218

        Mathews, D. H., Sabina, J., Zuker, M., & Turner, D. H. (1999).
            Expanded sequence dependence of thermodynamic parameters improves
            prediction of RNA secondary structure. Journal of Molecular
            Biology, 288(5), 911-940. http://doi.org/10.1006/jmbi.1999.2700
    """

    ps = ParameterSet('rna95', material='RNA', temperature=37.0, default_wobble_pairing=True)
    fill_stacks(ps)
    fill_flush_coaxial_stacks(ps)
    fill_triloops(ps)
    fill_tetraloops(ps)
    fill_dangle(ps)
    fill_terminal_mismatch(ps)
    fill_hairpin_mismatch(ps)
    fill_interior_mismatch(ps)
    fill_hairpin_size(ps)
    fill_bulge_size(ps)
    fill_interior_size(ps)
    fill_multiloop_terms(ps)
    fill_asymmetry_terms(ps)
    fill_interior_1x1(ps)
    fill_interior_1x2(ps)
    fill_interior_2x2(ps)
    fill_poly_C(ps)
    fill_AT_penalty(ps)
    fill_bimolecular(ps)
    fill_pseudoknot_terms(ps)

    return ps

################################################################################

def fill_stacks(ps):
    """add in stacking energy terms

    Args:
        ps: the ParameterSet to augment

    Citation: Table 1 of Serra and Turner (1995), pp. 244-245
    """
    flip = lambda s: s[::-1]

    # tuples are initially (bp1, bp2, energy)
    # p. 245
    dG = ps.tabulate('dG-stack', [
        ("AU", "AU", -0.9),
        ("AU", "UA", -0.9),
        ("AU", "GC", -1.7),
        ("AU", "CG", -2.1),
        ("AU", "GU", -0.5),
        ("AU", "UG", -1.0),
        ("CG", "AU", -1.8),
        ("CG", "UA", -1.7),
        ("CG", "GC", -2.0),
        ("CG", "CG", -2.9),
        ("CG", "GU", -1.2),
        ("CG", "UG", -1.9),
        ("GC", "AU", -2.3),
        ("GC", "UA", -2.1),
        ("GC", "GC", -2.9),
        ("GC", "CG", -3.4),
        ("GC", "GU", -1.4),
        ("GC", "UG", -2.1),
        ("UA", "AU", -1.1),
        ("UA", "UA", -0.9),
        ("UA", "GC", -1.8),
        ("UA", "CG", -2.3),
        ("UA", "GU", -0.8),
        ("UA", "UG", -1.1),
        # dual wobble pair energies present in footnote a, below table, p. 245
        ("UG", "GU", -0.2),
        ("UG", "UG", -0.4),
        ("GU", "UG", +1.5),
    ])

    # p. 244
    dH = ps.tabulate('dH-stack', [
        ("AU", "AU", -6.6),
        ("AU", "UA", -5.7),
        ("AU", "GC", -7.6),
        ("AU", "CG", -10.2),
        ("AU", "GU", -2.7),
        ("AU", "UG", -4.0),
        ("CG", "AU", -10.5),
        ("CG", "UA", -7.6),
        ("CG", "GC", -8.0),
        ("CG", "CG", -12.2),
        ("CG", "GU", -3.1),
        ("CG", "UG", -11.2),
        ("GC", "AU", -13.3),
        ("GC", "UA", -10.2),
        ("GC", "GC", -12.2),
        ("GC", "CG", -14.2),
        ("GC", "GU", -6.3),
        ("GC", "UG", -9.5),
        ("UA", "AU", -8.1),
        ("UA", "UA", -6.6),
        ("UA", "GC", -10.5),
        ("UA", "CG", -13.3),
        ("UA", "GU", -8.5),
        ("UA", "UG", -13.6),
        # dual wobble pair energies present in footnote a, below table, p. 245
        ("UG", "GU", -11.0),
        ("UG", "UG", -20.0),
        ("GU", "UG", -9.3),
    ])

    def fill(input, output):
        """add in rotated GU stacks and store in Parameters"""

        for x in copy(input):
            if x[1] in ["GU", "UG"]:
                input.append((flip(x[1]), flip(x[0]), x[2]))

        # remove exact duplicates from copying dual wobbles
        input = list(set(input))

        output.stacks.update(((x[0][0]+x[1][0], x[1][1]+x[0][1]), x[2]) for x in input)


    fill(dG, ps.dG)
    fill(dH, ps.dH)


def fill_flush_coaxial_stacks(ps):
    """copy stack parameters

    Args:
        ps: the ParameterSet to augment

    Citation: Serra and Turner (1995)
    """
    # "For directly adjacent helices, ΔG_37 (coaxial stacking of helices) has
    # been approximated as the ΔG_37 for the equivalent nearest-neighbor base
    # pair combination in an intact helix as listed in Table I."
    # Serra and Turner (1995) p. 257
    #
    # Just copy the stack parameters which have already been filled out
    ps.dG.flush_coaxial_stacks.update(ps.dG.stacks)
    ps.dH.flush_coaxial_stacks.update(ps.dH.stacks)


def fill_triloops(ps):
    """Do nothing as there are no triloop bonuses in this parameter set

    Args:
        ps: the ParameterSet to augment

    Citation: Serra and Turner (1995)

    There is no mention of a special case for handling triloops in Serra and
    Turner (1995)
    """
    return


def fill_tetraloops(ps):
    """Add in tetraloops present in historical parameter set based on earlier citations

    Args:
        ps: the ParameterSet to augment

    Citation:
        Jaeger, Turner, and Zuker (1989)
        Antao and Tinoco (1992)
        Walter et al. (1994)
        Serra and Turner (1995)

    regex to grab all hairpin sequences in historical  ^[ACGU](G[ACGU][AG]A|U[ACGU]CG|UCCG|GUAA|CUUG|AUUU|UUUA)[ACGU]
    or: ^[ACGU](UUCG|GAAA|GCAA|GAGA|GUGA|GGAA|UACG|GCGA|UCCG|GUAA|CUUG|AUUU|UUUA)[ACGU]
    """
    # "Recently, Tuerk et al. (28) reported that UUCG forms an unusually
    # stable hairpin loop. J. Haney and 0. C. Uhlenbeck (personal
    # communication) find that GAAA behaves similarly. They have also noticed
    # that these and six other sequences (GCAA, GAGA, GUGA, GGAA, UACG, and
    # GCGA) account for >60% of tetraloops in a set of 16S and 23S rRNAs (29).
    # Appropriate ΔG_37 values for these sequences are not known. Nevertheless,
    # they are clearly more stable than other tetraloops. To test the effect
    # of such enhanced stability on structure prediction, hairpins of 4 nt
    # containing the eight most prevalent tetraloop sequences were each made
    # more stable by 2 kcal/mol; this increment corresponds to a single strong
    # hydrogen bond or stacking interaction "
    # Jaeger, Turner, and Zuker (1989) p. 7707
    #
    # "Thermodynamic parameters were those listed by Jaeger et al. (14) with
    # the following exceptions...UCCG, GUAA, CUUG, AUUU, and UUUA were added
    # to the list of extra-stable tetraloops."
    # Walter et al. (1989) p. 9218-9219
    #
    # These two taken together indicate that the preceeding interior sequences
    # with each possible hairpin closing base pair should be given the same
    # bonus of 2 kcal/mol
    loop_unpaired = ["UUCG", "GAAA", "GCAA", "GAGA", "GUGA", "GGAA", "UACG",
            "GCGA", "UCCG", "GUAA", "CUUG", "AUUU", "UUUA"]

    val = ps['dG-tetraloop-bonus', -2]
    ps.dG.tetraloops.update((bp[0] + lu + bp[1], val) for bp, lu in product(base_pairs, loop_unpaired))

    # it is unclear where the parameters for the ΔH come from in the
    # historical rna1995 parameter set. They are all set equal to -4.0
    # kcal/mol, but so far left blank here without a reference.


def fill_terminal_mismatch(ps):
    """Description

    Args:
        ps: the ParameterSet to augment

    Citation:
        Serra and Turner (1995), Table 1 on p. 245
        Mathews, Sabina, Zuker et al. (1999), p. 922
    """
    # "Parameters in parentheses are estimated by (1) summing parameters for
    # the constituent 5' and 3' dangling ends for AC and pyrimidine-pyrimidine
    # mismatches, or (2) averaging measured AA and AG mismatches with the same
    # adjacent base pair for purine purine mismatches. Parameters for non-
    # hydrogen-bonded Watson-Crick and GU pairs may be estimated similarly."
    # Serra and Turner (1995), p. 245
    # the estimated elements in original table are noted below

    dG = ps.tabulate('dG-terminal-mismatch', [
        (("AU", "AA"), -0.8),
        (("AU", "AC"), -1.0), # estimated
        (("AU", "AG"), -0.8), # estimated
        (("AU", "CA"), -0.6),
        (("AU", "CC"), -0.7), # estimated
        (("AU", "CU"), -0.7), # estimated
        (("AU", "GA"), -0.8),
        (("AU", "GG"), -0.8), # estimated
        (("AU", "UC"), -0.8), # estimated
        (("AU", "UU"), -0.8), # estimated
        (("CG", "AA"), -1.5),
        (("CG", "AC"), -1.5),
        (("CG", "AG"), -1.4),
        (("CG", "CA"), -1.0), # estimated
        (("CG", "CC"), -1.1), # estimated
        (("CG", "CU"), -0.8),
        (("CG", "GA"), -1.4),
        (("CG", "GG"), -1.6),
        (("CG", "UC"), -1.4),
        (("CG", "UU"), -1.2),
        (("GC", "AA"), -1.1),
        (("GC", "AC"), -1.5), # estimated
        (("GC", "AG"), -1.3),
        (("GC", "CA"), -1.1),
        (("GC", "CC"), -0.7), # estimated
        (("GC", "CU"), -0.5), # estimated
        (("GC", "GA"), -1.6),
        (("GC", "GG"), -1.4),
        (("GC", "UC"), -2.1), # estimated
        (("GC", "UU"), -0.7), # estimated
        (("UA", "AA"), -1.0),
        (("UA", "AC"), -0.8),
        (("UA", "AG"), -1.1),
        (("UA", "CA"), -0.7),
        (("UA", "CC"), -0.6),
        (("UA", "CU"), -0.5),
        (("UA", "GA"), -1.1),
        (("UA", "GG"), -1.2),
        (("UA", "UC"), -0.6),
        (("UA", "UU"), -0.5),
    ])

    dH = ps.tabulate('dH-terminal-mismatch', [
        (("AU", "AA"), -3.9),
        (("AU", "AC"), +2.0), # estimated
        (("AU", "AG"), -3.5), # estimated
        (("AU", "CA"), -2.3),
        (("AU", "CC"), +6.0), # estimated
        (("AU", "CU"), -0.3), # estimated
        (("AU", "GA"), -3.1),
        (("AU", "GG"), -3.5), # estimated
        (("AU", "UC"), +4.6), # estimated
        (("AU", "UU"), -1.7), # estimated
        (("CG", "AA"), -9.1),
        (("CG", "AC"), -5.6),
        (("CG", "AG"), -5.6),
        (("CG", "CA"), -5.7), # estimated
        (("CG", "CC"), -3.4), # estimated
        (("CG", "CU"), -2.7),
        (("CG", "GA"), -8.2),
        (("CG", "GG"), -9.2),
        (("CG", "UC"), -5.3),
        (("CG", "UU"), -8.6),
        (("GC", "AA"), -5.2),
        (("GC", "AC"), -4.0),
        (("GC", "AG"), -5.6),
        (("GC", "CA"), -7.2),
        (("GC", "CC"), +0.5), # estimated
        (("GC", "CU"), -4.2), # estimated
        (("GC", "GA"), -7.1),
        (("GC", "GG"), -6.2),
        (("GC", "UC"), -0.3), # estimated
        (("GC", "UU"), -5.0), # estimated
        (("UA", "AA"), -4.0),
        (("UA", "AC"), -6.3),
        (("UA", "AG"), -8.9),
        (("UA", "CA"), -4.3),
        (("UA", "CC"), -5.1),
        (("UA", "CU"), -1.8),
        (("UA", "GA"), -3.8),
        (("UA", "GG"), -8.9),
        (("UA", "UC"), -1.4),
        (("UA", "UU"), +1.4),
    ])

    ps.dG.terminal_mismatch.update(dG)
    ps.dH.terminal_mismatch.update(dH)

    # "For those terminal mismatches adjacent to G⋅U pairs that were not
    # measured, the stability is approximated as that of the mismatch adjacent
    # to an A⋅U pair such that the A replaces the G."
    # Mathews, Sabina, Zuker et al. (1999), p. 922
    #
    # Since no GU mismatches were measured yet, we can wholesale duplicate
    # AU/UA information into GU
    def wobble_mismatches(energies):
        keys = [k for k in energies.keys() if k[0] in ('AU', 'UA')]
        energies.update(((bp.replace("A", "G"), mm), energies[(bp,mm)]) for bp, mm in keys)

    wobble_mismatches(ps.dG.terminal_mismatch)
    wobble_mismatches(ps.dH.terminal_mismatch)

    # Based on the quote before the table, it appears that when treating base
    # pairs as a mismatch one should use the some of the dangles for that pair
    def dangle_pairs(p):
        for key in product(base_pairs, base_pairs):
            bp, mm = key
            dangle3 = p.dangles.get((bp, mm[0]), 0)
            dangle5 = p.dangles.get((mm[1], bp[::-1]), 0)
            assert key not in p.terminal_mismatch, key
            p.terminal_mismatch[key] = dangle5 + dangle3

    dangle_pairs(ps.dG)
    dangle_pairs(ps.dH)


def fill_hairpin_mismatch(ps):
    """add in hairpin mismatch energies as modified terminal mismatch energies

    Args:
        ps: the ParameterSet to augment

    Citation:
        Serra and Turner (1995), p. 254
    """
    # "The interaction of the first mismatch with the closing base pair is
    # assumed to be the same for the hairpin as for a terminal mismatch on a
    # duplex and contributes both an enthalpy and entropy term to the
    # stability of the hairpin."
    # copy terminal mismatch parameters
    ps.dG.hairpin_mismatch.update(ps.dG.terminal_mismatch)
    ps.dH.hairpin_mismatch.update(ps.dH.terminal_mismatch)

    # "The additional stability of the GA and UU (-0.7 kcal/mol) first
    # mismatches is approximated as entirely due to a favorable enthalpy term.
    # In a similar fashion, the penalty for closure of the hairpin loop by an
    # AU or UA base pair is approximated as an unfavorable enthalpy (+0.4
    # kcal/mol)." Serra and Turner (1995), p. 254
    #
    # These terms must be added to both ΔG and ΔH. This assumption is borne
    # out in the examples in Figure 3, pp. 254-255
    #
    # "A bonus is applied to loops with UU and GA (G on the 5' side and A on
    # 3' side of loop) first mismatches."
    # Mathews, Sabina, Zuker et al. (1999), p. 923
    #
    # So, there is an asymmetry between GA and AG mismatches in hairpins
    #
    # Furthermore, we can probably assume that GU/UG pairs should be treated
    # the same as AU/UA pairs
    def modulate(energies):
        keys = energies.keys()
        stable_mismatch = list(filter(lambda x: x[1] in ["GA", "UU"], keys))
        unstable_pair = list(filter(lambda x: x[0] in ["AU", "UA", "GU", "UG"], keys))
        mod1 = ps['hairpin-modulate-1', -0.7]
        mod2 = ps['hairpin-modulate-2', +0.4]
        energies.update((key, energies[key] + mod1) for key in stable_mismatch)
        energies.update((key, energies[key] + mod2) for key in unstable_pair)

    modulate(ps.dG.hairpin_mismatch)
    modulate(ps.dH.hairpin_mismatch)


def fill_interior_mismatch(ps):
    """Description

    Args:
        ps: the ParameterSet to augment

    Citation: Serra and Turner (1995), p. 256-257
    """
    # "For larger internal loops, terminal GA, UU, and other mismatches
    # adjacent to CG pairs are assumed to make the loop more stable by -2.7,
    # -2.5, and 1.5 kcal/mol, respectively. These mismatches adjacent to
    # AU pairs are assumed to make the loop more stable by -2.2, -2.0, and
    # -1.0 kcal/mol, respectively."
    #
    # So there are only 6 free parameters here. We assume as elsewhere that GU
    # pairs get the same parameters as AU pairs
    mismatches = list(set("".join(x) for x in product(bases, bases)) - set(base_pairs))
    GC = ps.tabulate('dG-interior-mismatch-GC', {
        "AG": -2.7,
        "GA": -2.7,
        "UU": -2.5,
        "other": -1.5
    })
    AU = ps.tabulate('dG-interior-mismatch-AU', {
        "AG": -2.2,
        "GA": -2.2,
        "UU": -2.0,
        "other": -1.0,
    })
    map = {"AU": AU, "UA": AU, "GU": AU, "UG": AU, "GC": GC, "CG": GC}
    ps.dG.interior_mismatch.update(((bp, mm), map[bp].get(mm, map[bp]["other"]))
            for bp, mm in product(base_pairs, mismatches))

    # Discussion in paper in "Internal Loops" does not seem to consider the
    # possibility of unpaired Watson-Crick or wobble complements as valid
    # "mismatches." We will assume here that the sum of dangles (as in
    # terminal mismatch) is used.
    ps.dG.interior_mismatch.update(((bp, mm), ps.dG.terminal_mismatch.get((bp, mm), 0))
            for bp, mm in product(base_pairs, base_pairs))

    # "Prediction of ΔH° and ΔS° cannot be made with the currently available
    # data." Serra and Turner (1995), p. 257
    # leave dH empty


def fill_interior_1x1(ps):
    """Description

    Args:
        ps: the ParameterSet to augment

    Citation: Serra and Turner (1995), p. 256
    """
    # "Single mismatches are given ΔG_37 = 0.8 kcal/mol regardless of
    # sequence, owing to lack of experimental data." Serra and Turner (1995),
    # p. 256
    fill = ps['dG-single-mismatch', 0.8]
    for bp1, bp2, up, down in product(base_pairs, base_pairs, bases, bases):
        key = (bp1[0] + up + bp2[1], bp2[0] + down + bp1[1]) # top sequence, bottom sequence
        ps.dG.interior_1x1[key] = fill

    # "Prediction of ΔH° and ΔS° cannot be made with the currently available
    # data." Serra and Turner (1995), p. 257
    # leave dH empty

def fill_interior_1x2(ps):
    """Combine interior loop mismatch, asymmetry, and size information to
        generate explicit loops

    Args:
        ps: the ParameterSet to augment

    Citation: Serra and Turner (1995), p. 256-257
    """
    # "The limited data available can be fit reasonably well with a model that
    # includes the loop size, closing base pairs, first mis- matches, and loop
    # asymmetry...For larger internal loops, terminal GA, UU, and other mis-
    # matches adjacent to CG pairs are assumed to make the loop more stable by
    # -2.7, -2.5, and 1.5 kcal/mol, respectively."
    # Serra and Turner (1995), p. 256
    #
    # So, there is no special handling of 1x2 mismatches and thus we use the
    # fully generic formula. Thus, the nucleotide on the length 1 side of the
    # interior loop is treated as simultaneously participating in two separate
    # mismatches
    size_energy = ps.dG.interior_size[3]
    asymmetry_energy = min(ps.dG.asymmetry_terms["m1"] * 1, ps.dG.asymmetry_terms["max"])
    for bp1, bp2, x, y, z in product(base_pairs, base_pairs, bases, bases, bases):
        mm1 = x + y
        mm2 = z + x
        key = (bp1[0]+x+bp2[1], bp2[0]+z+y+bp1[1])
        mm_energy1 = ps.dG.interior_mismatch.get((bp1,mm1), 0)
        mm_energy2 = ps.dG.interior_mismatch.get((bp2,mm2), 0)
        ps.dG.interior_1x2[key] = size_energy + asymmetry_energy + mm_energy1 + mm_energy2


def fill_interior_2x2(ps):
    """Combine interior loop mismatch and size information to generate explicit loops

    Args:
        ps: the ParameterSet to augment

    Citation: Serra and Turner (1995), p. 256-257
    """
    # "The limited data available can be fit reasonably well with a model that
    # includes the loop size, closing base pairs, first mis- matches, and loop
    # asymmetry...For larger internal loops, terminal GA, UU, and other mis-
    # matches adjacent to CG pairs are assumed to make the loop more stable by
    # -2.7, -2.5, and 1.5 kcal/mol, respectively."
    # Serra and Turner (1995), p. 256
    #
    # So, there is no special handling of 2x2 mismatches and as they have no
    # size asymmetry, the free energy reduces to the size component and the
    # two mismatch free energies.

    size_energy = ps.dG.interior_size[4]
    binary = list("".join(x) for x in product(bases, bases))
    for bp1, bp2, mm1, mm2 in product(base_pairs, base_pairs, binary, binary):
        key = (bp1[0]+mm1[0]+mm2[1]+bp2[1], bp2[0]+mm2[0]+mm1[1]+bp1[1])
        mm_energy1 = ps.dG.interior_mismatch.get((bp1,mm1), 0)
        mm_energy2 = ps.dG.interior_mismatch.get((bp2,mm2), 0)
        ps.dG.interior_2x2[key] = size_energy + mm_energy1 + mm_energy2

    # "Prediction of ΔH° and ΔS° cannot be made with the currently available
    # data." Serra and Turner (1995), p. 257
    # leave dH empty


def fill_dangle(ps):
    """add in dangle energies (5' and 3')

    Args:
        ps: the ParameterSet to augment

    Citations:
        Table 2 of Serra and Turner (1995), p. 251
        Mathews, Sabina, Zuker et al. (1999), p. 921
    """
    dG = ps.tabulate('dG-dangle', [
        (("AU", "A"), -0.8),
        (("AU", "C"), -0.5),
        (("AU", "G"), -0.8),
        (("AU", "U"), -0.6),
        (("CG", "A"), -1.7),
        (("CG", "C"), -0.8),
        (("CG", "G"), -1.7),
        (("CG", "U"), -1.2),
        (("GC", "A"), -1.1),
        (("GC", "C"), -0.4),
        (("GC", "G"), -1.3),
        (("GC", "U"), -0.6),
        (("UA", "A"), -0.7),
        (("UA", "C"), -0.1),
        (("UA", "G"), -0.7),
        (("UA", "U"), -0.1),
        (("A", "AU"), -0.3),
        (("C", "AU"), -0.3),
        (("G", "AU"), -0.4),
        (("U", "AU"), -0.2),
        (("A", "CG"), -0.5),
        (("C", "CG"), -0.3),
        (("G", "CG"), -0.2),
        (("U", "CG"), -0.1),
        (("A", "GC"), -0.2),
        (("C", "GC"), -0.3),
        (("G", "GC"), 0),
        (("U", "GC"), 0),
        (("A", "UA"), -0.3),
        (("C", "UA"), -0.1),
        (("G", "UA"), -0.2),
        (("U", "UA"), -0.2),
    ])

    dH = ps.tabulate('dH-dangle', [
        (("AU", "A"), -4.9),
        (("AU", "C"), -0.9),
        (("AU", "G"), -5.5),
        (("AU", "U"), -2.3),
        (("CG", "A"), -9.0),
        (("CG", "C"), -4.1),
        (("CG", "G"), -8.6),
        (("CG", "U"), -7.5),
        (("GC", "A"), -7.4),
        (("GC", "C"), -2.8),
        (("GC", "G"), -6.4),
        (("GC", "U"), -3.6),
        (("UA", "A"), -5.7),
        (("UA", "C"), -0.7),
        (("UA", "G"), -5.8),
        (("UA", "U"), -2.2),
        (("A", "AU"), 1.6),
        (("C", "AU"), 2.2),
        (("G", "AU"), 0.7),
        (("U", "AU"), 3.1),
        (("A", "CG"), -2.4),
        (("C", "CG"), 3.3),
        (("G", "CG"), 0.8),
        (("U", "CG"), -1.4),
        (("A", "GC"), -1.6),
        (("C", "GC"), 0.7),
        (("G", "GC"), -4.6),
        (("U", "GC"), -0.4),
        (("A", "UA"), -0.5),
        (("C", "UA"), 6.9),
        (("G", "UA"), 0.6),
        (("U", "UA"), 0.6),
    ])

    ps.dG.dangles.update(dG)
    ps.dH.dangles.update(dH)

    # "Dangling ends on terminal G⋅U pairs are treated like dangling ends on
    # terminal A⋅U pairs with the A replacing the G."
    # Mathews, Sabina, Zuker et al. (1999), p.921
    #
    # This heuristic seems odd. It seems that it would make more sense to
    # approximate the U "side" of a GU pair with an AU pair and the G side
    # with a GC pair. However, this heuristic is used in later data sets
    # (quote comes from 1999 paper, this issue doesn't seem to have been
    # considered in 1995), and so it will be used here as well.
    def add_wobbles(energies):
        for bp, base in product(["GU", "UG"], bases):
            mock = bp.replace("G", "A")
            energies[(bp, base)] = energies.get((mock, base), 0)
            energies[(base, bp)] = energies.get((base, mock), 0)

    add_wobbles(ps.dG.dangles)
    add_wobbles(ps.dH.dangles)


def fill_hairpin_size(ps):
    """Add in size-based free energies for hairpins

    Add in corresponding size-based free energies for hairpins, both tabulated
    values and computed logarithmic extrapolation up to 30 unpaired nt.

    Args:
        ps: the ParameterSet to augment

    Citation: Table 3 of Serra and Turner (1995), p. 253
    """
    # "Not much is known about the factors determining the ΔH° and ΔS° of
    # initiation for hairpin loops. Therefore it is usually assumed that
    # ΔH_i = 0" Serra and Turner (1995), p. 252
    # leave dH empty

    # From Table 3
    tabulated_size_energies = ps.tabulate('dG-hairpin-size', [
            # it is assumed that size 3 is the smallest possible hairpin to form
        (3, 4.1),
        (4, 4.9),
        (5, 4.4),
        (6, 5.0),
        (7, 5.0),
        (8, 5.1), # interpolated in table
        (9, 5.2),
    ])

    ps.dG.hairpin_size.update(tabulated_size_energies)

    # logarithmic formula for sizes 10-30
    n_max = 9
    dG_0 = ps.dG.hairpin_size[n_max]
    ps.dG.log_loop_penalty = scale = ps['log-loop-penalty', 1.75 * KT]
    ps.dG.hairpin_size.update((n, dG_0 + scale * np.log(n/n_max)) for n in range(10,31))


def fill_bulge_size(ps):
    """Add in size-based free energies for hairpins

    Add in corresponding size-based free energies for bulge loops, both
    tabulated values and computed logarithmic extrapolation up to 30
    unpaired nt.

    Args:
        ps: the ParameterSet to augment

    Citation: Table 3 of Serra and Turner (1995), p. 253
    """
    # "Current data sets are not complete enough to allow partitioning of the
    # bulge loop stability into enthalpic and entropic energy terms. Therefore
    # ΔH°, ΔS°, and melting temperatures cannot be predicted reliably." Serra
    # and Turner (1995), p. 256
    # leave dH empty

    # From Table 3
    tabulated_size_energies = ps.tabulate('dG-bulge-size', [
        (1, 3.9),
        (2, 3.1),
        (3, 3.5),
        (4, 4.2), # interpolated in table
        (5, 4.8),
    ]) # data for 6-9 nt present in table according to below extrapolation formula

    ps.dG.bulge_size.update(tabulated_size_energies)

    # logarithmic formula for sizes 6-30
    n_max = 5
    dG_0 = ps.dG.bulge_size[n_max]
    scale = ps['log-loop-penalty', 1.75 * KT]
    ps.dG.bulge_size.update((n, dG_0 + scale *np.log(n/n_max)) for n in range(6,31))


def fill_interior_size(ps):
    """Add in size-based free energies for hairpins

    Add in corresponding size-based free energies for bulge loops, both
    tabulated values and computed logarithmic extrapolation up to 30
    unpaired nt.

    Args:
        ps: the ParameterSet to augment

    Citation: Table 3 of Serra and Turner (1995), p. 253
    """
    # "Prediction of ΔH° and ΔS° cannot be made with the currently available
    # data." Serra and Turner (1995), p. 257
    # leave dH empty

    # From Table 3
    tabulated_size_energies = ps.tabulate('dG-interior-size', [
        (2, 0.8),
        (3, 5.1),
        (4, 4.9),
        (5, 5.3),
        (6, 5.7),
    ]) # data for 7-9 nt present in table according to below extrapolation formula

    ps.dG.interior_size.update(tabulated_size_energies)

    # logarithmic formula for sizes 6-30
    n_max = 6
    dG_0 = ps.dG.interior_size[n_max]
    scale = ps['log-loop-penalty', 1.75 * KT]
    ps.dG.interior_size.update((n, dG_0 + scale *np.log(n/n_max)) for n in range(7,31))


def fill_multiloop_terms(ps):
    """Add in the penalty terms for multiloop initiation, number of branches,
    and number of unpaired bases

    Args:
        ps: the ParameterSet to augment

    Citation: Serra and Turner (1995), p. 257
    """
    # Equation 5 on p. 257 gives the relevant parameters
    ps.dG.multiloop_terms.update([
        ("α1", ps['dG-multiloop-a1', 4.6]),
        ("α2", ps['dG-multiloop-a2', 0.1]),
        ("α3", ps['dG-multiloop-a3', 0.4]),
    ])

    # No ΔH information is given; leave empty


def fill_asymmetry_terms(ps):
    """add in asymmetry penalty terms

    Args:
        ps: the ParameterSet to augment

    Citation: Serra and Turner (1995), p. 256
    """
    # "This penalty is the minimum of 3.0 or 0.3|N1 - N2| kcal/mol for a loop
    # with branches of NI and N2 nucleotides" Serra and Turner (1995), p. 256
    names = ["m1", "m2", "m3", "m4"]
    min = ps['asymmetry-min', 0.3]
    max = ps['asymmetry-max', 3.0]
    ps.dG.asymmetry_terms.update((n, min) for n in names)
    ps.dG.asymmetry_terms["max"] = max

    # no ΔH for asymmetry terms


def fill_poly_C(ps):
    """Do nothing as there is no poly_c correction mentioned

    Args:
        ps: the ParameterSet to augment

    Citation: Serra and Turner (1995)

    There is no mention of this correction in the Serra and Turner (1995)
    model for hairpins.
    """
    return


def fill_AT_penalty(ps):
    """Do nothing as AT penalty is not present

    Args:
        ps: the ParameterSet to augment

    Citation: Serra and Turner (1995)

    The non-GC penalty is handled differently in this paper than in later
    papers. It is incorporated into mismatches in a context dependent way
    such that this global parameter doesn't exit. The idea of a global AT penalty
    for helix initiation as such came after Serra and Turner (1995).
    """
    return

def fill_bimolecular(ps):
    """add in bimolecular values

    Args:
        ps: the ParameterSet to augment

    Citation: Serra and Turner (1995), Table 1 p. 245
    """
    # "For initiation of a duplex from two strands, ΔH = 0 kcal/mol, ΔS = 10.8
    # eu, ΔG_37 = 3.4 kcal/mol." Serra and Turner (1995), Table 1 p. 245
    #
    # This paper refers to the bimolecular term as the "duplex initiation" parameter

    ps.dG.bimolecular = ps['dG-bimolecular', 3.4]
    ps.dH.bimolecular = ps['dH-bimolecular', 0.0]
