"""Citations and logic to convert the parameter set presented in SantaLucia
    and Hicks (2004) into a Python object for output

Functions:
    make_dna_2004_parameters: produce ParameterSet based on
        SantaLucia and Hicks (2004) for DNA
    fill_stacks: fill in stack parameters
    fill_flush_coaxial_stacks: fill in flush coaxial stack parameters
    fill_triloops: fill in triloop bonuses
    fill_tetraloops: fill in tetraloop bonuses
    fill_terminal_mismatch: fill in terminal mismatch parameters
    fill_hairpin_mismatch: fill in hairpin mismatch parameters
    fill_interior_mismatch: fill in interior mismatch parameters
    fill_interior_1x1: fill in 1x1 interior loop parameters
    fill_interior_1x2: fill in 1x1 interior loop parameters
    fill_interior_2x2: fill in 1x1 interior loop parameters
    fill_dangle: fill in dangle parameters
    fill_hairpin_size: fill in hairpin loop size parameters
    fill_bulge_size: fill in bulge loop size parameters
    fill_interior_size: fill in interior loop size parameters
    fill_multiloop_terms: fill in linear multiloop function parameters
    fill_asymmetry_terms: fill in interior loop asymmetry parameters
    fill_poly_C: fill in poly-C hairpin parameters
    fill_AT_penalty: fill in penalty for non-GC loops
    fill_bimolecular: fill in bimolecular (join) parameter
"""
from .constants import ParameterSet, BASEPAIRS, BASES, KT, fill_pseudoknot_terms
from copy import deepcopy as copy
from itertools import product
import numpy as np
import pandas as pd

bases = [b.format(UT="T") for b in BASES]
base_pairs = [b.format(UT="T") for b in BASEPAIRS]

def generate():
    """Translate data from citations into an DNA ParmeterSet

    Returns:
        ParameterSet: full DNA parameters based on SantaLucia (1998)


    Citations:
        SantaLucia, J., & Hicks, D. (2004). The thermodynamics of DNA
            structural motifs. Annual Review of Biophysics and Biomolecular
            Structure, 33, 415-440.
            http://doi.org/10.1146/annurev.biophys.32.110601.141800

        SantaLucia, J. (1998). A unified view of polymer, dumbbell, and
            oligonucleotide DNA nearest-neighbor thermodynamics. Proceedings
            of the National Academy of Sciences of the United States of
            America, 95(4), 1460-1465. http://doi.org/10.1073/pnas.95.4.1460

        # a
        Allawi, H. T., & SantaLucia, J. (1998). Nearest neighbor thermodynamic
            parameters for internal G⋅A mismatches in DNA. Biochemistry,
            37(8), 2170-2179. http://doi.org/10.1021/bi9724873

        # b
        Allawi, H. T., & SantaLucia, J. (1998). Nearest-neighbor
            thermodynamics of internal A·C mismatches in DNA: Sequence
            dependence and pH effects. Biochemistry, 37(26), 9435-9444.
            http://doi.org/10.1021/bi9803729

        # c
        Allawi, H. T., & SantaLucia, J. (1998). Thermodynamics of internal C·T
            mismatches in DNA. Nucleic Acids Research, 26(11), 2694-2701.
            http://doi.org/10.1093/nar/26.11.2694

        Allawi, H. T., & Santalucia, J. (1997). Thermodynamics and NMR of
            internal G·T mismatches in DNA. Biochemistry, 36(34), 10581-10594.
            http://doi.org/10.1021/bi962590c

        Peyret, N., Seneviratne, P. A., Allawi, H. T., & SantaLucia, J.
            (1999). Nearest-neighbor thermodynamics and NMR of DNA sequences
            with internal A·A, C·C, G·G, and T·T mismatches. Biochemistry,
            38(12), 3468-3477. http://doi.org/10.1021/bi9825091

        Peyret, N. (2000). Prediction of nucleic acid hybridization:
            parameters and algorithms. Wayne State University.
    """

    dna2004 = ParameterSet("dna04", material="DNA", temperature=37.0, default_wobble_pairing=False)
    fill_stacks(dna2004)
    fill_flush_coaxial_stacks(dna2004)
    fill_triloops(dna2004)
    fill_tetraloops(dna2004)
    fill_dangle(dna2004)
    fill_terminal_mismatch(dna2004)
    fill_hairpin_mismatch(dna2004)
    fill_interior_mismatch(dna2004)
    fill_hairpin_size(dna2004)
    fill_bulge_size(dna2004)
    fill_interior_size(dna2004)
    # fill_multiloop_terms(dna2004)
    fill_asymmetry_terms(dna2004)
    fill_interior_1x1(dna2004)
    fill_interior_1x2(dna2004)
    fill_interior_2x2(dna2004)
    fill_poly_C(dna2004)
    fill_AT_penalty(dna2004)
    fill_bimolecular(dna2004)
    fill_pseudoknot_terms(dna2004)

    return dna2004

def fill_stacks(ps):
    """Fill in nearest-neighbor stacking terms

    Args:
        ps: the ParameterSet to augment

    Citation:
        SantaLucia and Hicks (2004) Table 1 p. 420
        SantaLucia (1998)
    """
    # Tables are given almost in "native" format where sequences are listed
    # instead of successive base pairs; there is no need to condition them
    # afterwards
    dG = ps.tabulate('dG-stack', [
        (("AA", "TT"), -1.0),
        (("AT", "AT"), -0.88),
        (("TA", "TA"), -0.58),
        (("CA", "TG"), -1.45),
        (("GT", "AC"), -1.44),
        (("CT", "AG"), -1.28),
        (("GA", "TC"), -1.30),
        (("CG", "CG"), -2.17),
        (("GC", "GC"), -2.24),
        (("GG", "CC"), -1.84),
    ])

    dH = ps.tabulate('dG-stack', [
        (("AA", "TT"), -7.9), # typo in 2004 paper relative to 1998 paper
        (("AT", "AT"), -7.2),
        (("TA", "TA"), -7.2),
        (("CA", "TG"), -8.5),
        (("GT", "AC"), -8.4),
        (("CT", "AG"), -7.8),
        (("GA", "TC"), -8.2),
        (("CG", "CG"), -10.6),
        (("GC", "GC"), -9.8),
        (("GG", "CC"), -8.0),
    ])

    def add_rotated_sequences(p):
        """rotate the stack sequences, e.g. so both AA/TT and TT/AA are present"""
        keys = p.keys()
        r_keys = [(k[1], k[0]) for k in keys]
        p.update([(r, p[k]) for k, r in zip(keys, r_keys)])


    ps.dG.stacks.update(dG)
    add_rotated_sequences(ps.dG.stacks)
    ps.dH.stacks.update(dH)
    add_rotated_sequences(ps.dH.stacks)


def fill_AT_penalty(ps):
    """Add the non-GC duplex termination penalty

    Args:
        ps: the ParameterSet to augment

    Citation: SantaLucia and Hicks (2004) Table 1 p. 420
    """
    ps.dG.AT_penalty = ps['dG-AT-penalty', 0.05]
    ps.dH.AT_penalty = ps['dH-AT-penalty', 2.2]


def fill_bimolecular(ps):
    """Add the bimolecular/join penalty

    Args:
        ps: the ParameterSet to augment

    Citation: SantaLucia and Hicks (2004) Table 1 p. 420
    """
    # Given as "Initiation" parameter, but clear from Equation 1 on p. 419
    # that is is the regressed free energy associated with all bimolecular
    # duplex formation events.
    ps.dG.bimolecular = ps['dG-bimolecular', 1.96]
    ps.dH.bimolecular = ps['dH-bimolecular', 0.2]

def fill_interior_1x1(ps):
    """Add in 1x1 interior loops from mismatch values

    Args:
        ps: the ParameterSet to augment

    Citations:
        SantaLucia and Hicks (2004) p. 423 and Table 2, p. 424
        Peyret, Seneviratne, Allawi, and SantaLucia (1999) Table 2 p. 3471
        Allawi and SantaLucia (1997) Table 5 p. 10589
        Allawi and SantaLucia (1998a) Table 4 p. 2175
        Allawi and SantaLucia (1998b) Table 4 p. 9441
        Allawi and SantaLucia (1998c) Table 5 p. 2699
    """
    # The following are straight from Table 2, Watson-Crick basepairs do not
    # have a valid representation in this model and hence have no value in the
    # table.
    mismatch_dG = ps.tabulate('dG-interior-1x1-mismatch', {
            ("GC", "AA"): 0.17,
            ("GC", "AC"): 0.81,
            ("GC", "AG"): -0.25,
            ("GC", "CA"): 0.47,
            ("GC", "CC"): 0.79,
            ("GC", "CT"): 0.62,
            ("GC", "GA"): -0.52,
            ("GC", "GG"): -1.11,
            ("GC", "GT"): 0.08,
            ("GC", "TC"): 0.98,
            ("GC", "TG"): -0.59,
            ("GC", "TT"): 0.45,

            ("CG", "AA"): 0.43,
            ("CG", "AC"): 0.75,
            ("CG", "AG"): 0.03,
            ("CG", "CA"): 0.79,
            ("CG", "CC"): 0.70,
            ("CG", "CT"): 0.62,
            ("CG", "GA"): 0.11,
            ("CG", "GG"): -0.11,
            ("CG", "GT"): -0.47,
            ("CG", "TC"): 0.40,
            ("CG", "TG"): -0.32,
            ("CG", "TT"): -0.12,

            ("AT", "AA"): 0.61,
            ("AT", "AC"): 0.88,
            ("AT", "AG"): 0.14,
            ("AT", "CA"): 0.77,
            ("AT", "CC"): 1.33,
            ("AT", "CT"): 0.64,
            ("AT", "GA"): 0.02,
            ("AT", "GG"): -0.13,
            ("AT", "GT"): 0.71,
            ("AT", "TC"): 0.73,
            ("AT", "TG"): 0.07,
            ("AT", "TT"): 0.69,

            ("TA", "AA"): 0.69,
            ("TA", "AC"): 0.92,
            ("TA", "AG"): 0.42,
            ("TA", "CA"): 1.33,
            ("TA", "CC"): 1.05,
            ("TA", "CT"): 0.97,
            ("TA", "GA"): 0.74,
            ("TA", "GG"): 0.44,
            ("TA", "GT"): 0.43,
            ("TA", "TC"): 0.75,
            ("TA", "TG"): 0.34,
            ("TA", "TT"): 0.68,
    })

    # ΔH and ΔS are not reported in SantaLucia and Hicks (2004) instead "Error
    # bars and ΔH◦ and ΔS◦ parameters are provided in the original references."
    #
    # Each section of parameters will be accompanied by a reference to the
    # reporting paper.
    mismatch_dH = ps.tabulate('dH-interior-1x1-mismatch', {
            # Peyret, Seneviratne, Allawi, and SantaLucia (1999) Table 2 p. 3471
            ("AT", "AA"): 1.2,
            ("CG", "AA"): -0.9,
            ("GC", "AA"): -2.9,
            ("TA", "AA"): 4.7,
            ("AT", "CC"): 0.0,
            ("CG", "CC"): -1.5,
            ("GC", "CC"): 3.6,
            ("TA", "CC"): 6.1,
            ("AT", "GG"): -3.1,
            ("CG", "GG"): -4.9,
            ("GC", "GG"): -6.0,
            ("TA", "GG"): 1.6,
            ("AT", "TT"): -2.7,
            ("CG", "TT"): -5.0,
            ("GC", "TT"): -2.2,
            ("TA", "TT"): 0.2,
            # Allawi and SantaLucia (1998a) Table 4 p. 2175
            ("AT", "AG"): -0.6,
            ("AT", "GA"): -0.7,
            ("CG", "AG"): -0.7,
            ("CG", "GA"): -4.0,
            ("GC", "AG"): -0.6,
            ("GC", "GA"): 0.5,
            ("TA", "AG"): 0.7,
            ("TA", "GA"): 3.0,
            # Allawi and SantaLucia (1998b) Table 4 p. 9441
            ("AT", "AC"): 2.3,
            ("AT", "CA"): 5.3,
            ("CG", "AC"): 1.9,
            ("CG", "CA"): 0.6,
            ("GC", "AC"): 5.2,
            ("GC", "CA"): -0.7,
            ("TA", "AC"): 3.4,
            ("TA", "CA"): 7.6,
            # Allawi and SantaLucia (1998c) Table 5 p. 2699
            ("AT", "CT"): 0.7,
            ("AT", "TC"): -1.2,
            ("CG", "CT"): 0.8,
            ("CG", "TC"): -1.5,
            ("GC", "CT"): 2.3,
            ("GC", "TC"): 5.2,
            ("TA", "CT"): 1.2,
            ("TA", "TC"): 1.0,
            # Allawi and SantaLucia (1997) Table 5 p. 10589
            ("AT", "GT"): 1.0,
            ("AT", "TG"): -2.5,
            ("CG", "GT"): -4.1,
            ("CG", "TG"): -2.8,
            ("GC", "GT"): 3.3,
            ("GC", "TG"): -4.4,
            ("TA", "GT"): -0.1,
            ("TA", "TG"): -1.3,
    })

    def combine_mismatches(p, mms):
        combined = list()
        WC = ["AT", "CG", "GC", "TA"]
        mismatches = list(set("".join(x) for x in product(bases, bases)) - set(WC))
        for bp1, mm, bp2 in product(base_pairs, mismatches, base_pairs):
            key = (bp1[0] + mm[0] + bp2[0], bp2[1] + mm[1] + bp1[1])
            energy = mms.get((bp1, mm), 0) + mms.get((bp2[::-1], mm[::-1]), 0)
            combined.append((key, energy))

        p.update(combined)

    combine_mismatches(ps.dG.interior_1x1, mismatch_dG)
    combine_mismatches(ps.dH.interior_1x1, mismatch_dH)

def interpolate_size_energies(ps, data):
    """interpolate size energies for hairpins, bulge loops, and interior loops

    Citation: SantaLucia and Hicks (2004) p. 427
    """
    nmax = max(data.keys())
    dGmax = data[nmax]
    for n in range(min(data.keys()),nmax):
        if n not in data:
            data[n] = dGmax + ps['log-loop-entropy', 2.44 * KT] * np.log(n/nmax)

def fill_hairpin_size(ps):
    """Add in measured and extrapolated hairpin_size

    Args:
        ps: the ParameterSet to augment

    Citation: SantaLucia and Hicks (2004) Table 4, p. 427
    """
    tabulated_size_energies = ps.tabulate('dG-hairpin-size', [
            (3, 3.5),
            (4, 3.5),
            (5, 3.3),
            (6, 4.0),
            (7, 4.2),
            (8, 4.3),
            (9, 4.5),
            (10, 4.6),
            (12, 5.0),
            (14, 5.1),
            (16, 5.3),
            (18, 5.5),
            (20, 5.7),
            (25, 6.1),
            (30, 6.3)
    ])
    ps.dG.hairpin_size.update(tabulated_size_energies)
    interpolate_size_energies(ps, ps.dG.hairpin_size)

    # "All loop ΔH° parameters are assumed to equal 0."
    # SantaLucia and Hicks (2004) Table 4, p. 427
    #
    # so just don't add them to the parameter set at all

def fill_bulge_size(ps):
    """Add in measured and extrapolated bulge_size

    Args:
        ps: the ParameterSet to augment

    Citation: SantaLucia and Hicks (2004) Table 4, p. 427
    """
    tabulated_size_energies = ps.tabulate('dG-bulge-size', [
            (1, 4.0),
            (2, 2.9),
            (3, 3.1),
            (4, 3.2),
            (5, 3.3),
            (6, 3.5),
            (7, 3.7),
            (8, 3.9),
            (9, 4.1),
            (10, 4.3),
            (12, 4.5),
            (14, 4.8),
            (16, 5.0),
            (18, 5.2),
            (20, 5.3),
            (25, 5.6),
            (30, 5.9)
    ])

    ps.dG.bulge_size.update(tabulated_size_energies)
    interpolate_size_energies(ps, ps.dG.bulge_size)

    # "All loop ΔH° parameters are assumed to equal 0."
    # SantaLucia and Hicks (2004) Table 4, p. 427
    #
    # so just don't add them to the parameter set at all

def fill_interior_size(ps):
    """Add in measured and extrapolated interior_size

    Args:
        ps: the ParameterSet to augment

    Citation: SantaLucia and Hicks (2004) Table 4, p. 427
    """
    tabulated_size_energies = ps.tabulate('dG-interior-size', [
            (3, 3.2),
            (4, 3.6),
            (5, 4.0),
            (6, 4.4),
            (7, 4.6),
            (8, 4.8),
            (9, 4.9),
            (10, 4.9),
            (12, 5.2),
            (14, 5.4),
            (16, 5.6),
            (18, 5.8),
            (20, 5.9),
            (25, 6.3),
            (30, 6.6)
    ])
    ps.dG.interior_size.update(tabulated_size_energies)
    interpolate_size_energies(ps, ps.dG.interior_size)

    # "All loop ΔH° parameters are assumed to equal 0."
    # SantaLucia and Hicks (2004) Table 4, p. 427
    #
    # so just don't add them to the parameter set at all

def fill_triloops(ps):
    """Add in explicit triloop bonuses from table

    Args:
        ps: the ParameterSet to augment

    Citation:
        SantaLucia and Hicks (2004) Table S1, in supp info, p. 1 and p. 428 in
            paper
    """

    # SantaLucia and Hicks (2004) Table S1, in supp info, p. 1
    dG = ps.tabulate('dG-triloop', {
            "AGAAT": -1.5,
            "AGCAT": -1.5,
            "AGGAT": -1.5,
            "AGTAT": -1.5,
            "CGAAG": -2.0,
            "CGCAG": -2.0,
            "CGGAG": -2.0,
            "CGTAG": -2.0,
            "GGAAC": -2.0,
            "GGCAC": -2.0,
            "GGGAC": -2.0,
            "GGTAC": -2.0,
            "TGAAA": -1.5,
            "TGCAA": -1.5,
            "TGGAA": -1.5,
            "TGTAA": -1.5,
    })

    dH = ps.tabulate('dH-triloop',{
            "AGAAT": -1.5,
            "AGCAT": -1.5,
            "AGGAT": -1.5,
            "AGTAT": -1.5,
            "CGAAG": -2.0,
            "CGCAG": -2.0,
            "CGGAG": -2.0,
            "CGTAG": -2.0,
            "GGAAC": -2.0,
            "GGCAC": -2.0,
            "GGGAC": -2.0,
            "GGTAC": -2.0,
            "TGAAA": -1.5,
            "TGCAA": -1.5,
            "TGGAA": -1.5,
            "TGTAA": -1.5,
    })
    # "ΔG◦37(total) = ΔG◦37(Hairpin of 3) + ΔG◦37(triloop bonus) + closing AT penalty"
    # "the closing AT penalty is +0.5 kcal/mol"
    # Santa
    def add_AT_penalty(p):
        for k in p.keys():
            if k[0] == "A" or k[-1] == "A": # AT pair
                p[k] += ps['dG-triloop-AT-penalty', 0.5]

    ps.dG.triloops.update(dG)
    ps.dH.triloops.update(dH)
    add_AT_penalty(ps.dG.triloops)
    add_AT_penalty(ps.dH.triloops)


def fill_tetraloops(ps):
    """Add in explicit tetraloop bonuses from table

    Args:
        ps: the ParameterSet to augment

    Citation:
        SantaLucia and Hicks (2004) Table S1, in supp info, p. 1-5

    """
    # This data was taken from SantaLucia and Hicks (2004) Table S1, in supp info, p. 1-5
    seq, dG, dH = zip(*[
        ('AAAAAT',0.7,0.5),
        ('AAAACT',0.2,0.7),
        ('AAACAT',0.5,1),
        ('ACTTGT',-1.3,0),
        ('AGAAAT',-1.6,-1.1),
        ('AGAGAT',-1.6,-1.1),
        ('AGATAT',-2,-1.5),
        ('AGCAAT',-2.1,-1.6),
        ('AGCGAT',-1.6,-1.1),
        ('AGCTTT',-0.3,0.2),
        ('AGGAAT',-1.6,-1.1),
        ('AGGGAT',-1.6,-1.1),
        ('AGGGGT',0.3,0.5),
        ('AGTAAT',-2.1,-1.6),
        ('AGTGAT',-1.6,-1.1),
        ('AGTTCT',0.3,0.8),
        ('ATTCGT',-0.7,-0.2),
        ('ATTTGT',-0.5,0),
        ('ATTTTT',-1,-0.5),
        ('CAAAAG',0.9,0.5),
        ('CAAACG',0.7,0.7),
        ('CAACAG',1,1),
        ('CAACCG',0,0),
        ('CCTTGG',-0.8,0),
        ('CGAAAG',-1.1,-1.1),
        ('CGAGAG',-1.1,-1.1),
        ('CGATAG',-1.5,-1.5),
        ('CGCAAG',-1.6,-1.6),
        ('CGCGAG',-1.1,-1.1),
        ('CGCTTG',0.2,0.2),
        ('CGGAAG',-1.1,-1.1),
        ('CGGGAG',-1,-1),
        ('CGGGGG',0.8,0.5),
        ('CGTAAG',-1.6,-1.6),
        ('CGTGAG',-1.1,-1.1),
        ('CGTTCG',0.8,0.8),
        ('CTTCGG',-0.2,-0.2),
        ('CTTTGG',0,0),
        ('CTTTTG',-0.5,-0.5),
        ('GAAAAC',1.5,0.5),
        ('GAAACC',0.7,0.7),
        ('GAACAC',1,1),
        ('GCTTGC',-0.8,0),
        ('GGAAAC',-1.1,-1.1),
        ('GGAGAC',-1.1,-1.1),
        ('GGATAC',-1.6,-1.6),
        ('GGCAAC',-1.6,-1.6),
        ('GGCGAC',-1.1,-1.1),
        ('GGCTTC',0.2,0.2),
        ('GGGAAC',-1.1,-1.1),
        ('GGGGAC',-1.1,-1.1),
        ('GGGGGC',0.8,0.5),
        ('GGTAAC',-1.6,-1.6),
        ('GGTGAC',-1.1,-1.1),
        ('GGTTCC',0.8,0.8),
        ('GTTCGC',-0.2,-0.2),
        ('GTTTGC',0,0),
        ('GTTTTC',-0.5,-0.5),
        ('GAAAAT',1.5,0.5),
        ('GAAACT',1,1),
        ('GAACAT',1,1),
        ('GCTTGT',-0.5,0),
        ('GGAAAT',-1.1,-1.1),
        ('GGAGAT',-1.1,-1.1),
        ('GGATAT',-1.6,-1.6),
        ('GGCAAT',-1.6,-1.6),
        ('GGCGAT',-1.1,-1.1),
        ('GGCTTT',-0.1,-0.1),
        ('GGGAAT',-1.1,-1.1),
        ('GGGGAT',-1.1,-1.1),
        ('GGGGGT',0.8,0.5),
        ('GGTAAT',-1.6,-1.6),
        ('GGTGAT',-1.1,-1.1),
        ('GTATAT',-0.5,-0.5),
        ('GTTCGT',-0.4,-0.4),
        ('GTTTGT',-0.4,-0.4),
        ('GTTTTT',-0.5,-0.5),
        ('TAAAAA',0.4,0.5),
        ('TAAACA',0.2,0.7),
        ('TAACAA',0.5,1),
        ('TCTTGA',-1.3,0),
        ('TGAAAA',-1.6,-1.1),
        ('TGAGAA',-1.6,-1.1),
        ('TGATAA',-2.1,-1.6),
        ('TGCAAA',-2.1,-1.6),
        ('TGCGAA',-1.6,-1.1),
        ('TGCTTA',-0.3,0.2),
        ('TGGAAA',-1.6,-1.1),
        ('TGGGAA',-1.6,-1.1),
        ('TGGGGA',0.3,0.5),
        ('TGTAAA',-2.1,-1.6),
        ('TGTGAA',-1.6,-1.1),
        ('TGTTCA',0.3,0.8),
        ('TTTCGA',-0.7,-0.2),
        ('TTTTGA',-0.5,0),
        ('TTTTTA',-1,-0.5),
        ('TAAAAG',1,0.5),
        ('TAAACG',0.5,1),
        ('TAACAG',0.5,1),
        ('TCTTGG',-1,0),
        ('TGAAAG',-1.5,-1),
        ('TGAGAG',-1.5,-1),
        ('TGATAG',-2,-1.5),
        ('TGCAAG',-2,-1.5),
        ('TGCGAG',-1.5,-1),
        ('TGCTTG',-0.6,-0.1),
        ('TGGAAG',-1.5,-1),
        ('TGGGAG',-1.5,-1),
        ('TGGGGG',0.3,0.5),
        ('TGTAAG',-2,-1.5),
        ('TGTGAG',-1.5,-1),
        ('TTTCGG',-0.9,-0.4),
        ('TTTTAG',-1.5,-1),
        ('TTTTGG',-0.9,-0.4),
        ('TTTTTG',-1,-0.5),
    ])
    ps.dG.tetraloops.update(ps.tabulate('dG-tetraloop', list(zip(seq, dG))))
    ps.dH.tetraloops.update(ps.tabulate('dH-tetraloop', list(zip(seq, dH))))

def fill_dangle(ps):
    """Fill in dangle terms for WC pairs

    Args:
        ps: the ParameterSet to augment

    Citation:
        SantaLucia and Hicks (2004) Table 3 p. 426
    """
    # dangling end tables copied and modified directly from PDF, weird hyphen
    # instead of minus sign
    dG = ps.tabulate('dG-dangle', [
            (('A', 'AT'), -0.51),
            (('C', 'AT'), -0.42),
            (('G', 'AT'), -0.62),
            (('T', 'AT'), -0.71),
            (('A', 'CG'), -0.96),
            (('C', 'CG'), -0.52),
            (('G', 'CG'), -0.72),
            (('T', 'CG'), -0.58),
            (('A', 'GC'), -0.58),
            (('C', 'GC'), -0.34),
            (('G', 'GC'), -0.56),
            (('T', 'GC'), -0.61),
            (('A', 'TA'), -0.50),
            (('C', 'TA'), -0.02),
            (('G', 'TA'), 0.48),
            (('T', 'TA'), -0.10),

            (('AT', 'A'), -0.12),
            (('AT', 'C'), 0.28),
            (('AT', 'G'), -0.01),
            (('AT', 'T'), 0.13),
            (('CG', 'A'), -0.82),
            (('CG', 'C'), -0.31),
            (('CG', 'G'), -0.01),
            (('CG', 'T'), -0.52),
            (('GC', 'A'), -0.92),
            (('GC', 'C'), -0.23),
            (('GC', 'G'), -0.44),
            (('GC', 'T'), -0.35),
            (('TA', 'A'), -0.48),
            (('TA', 'C'), -0.19),
            (('TA', 'G'), -0.50),
            (('TA', 'T'), -0.29),
    ])

    dH = ps.tabulate('dH-dangle', [
            (('A', 'AT'), 0.2),
            (('C', 'AT'), 0.6),
            (('G', 'AT'), -1.1),
            (('T', 'AT'), -6.9),
            (('A', 'CG'), -6.3),
            (('C', 'CG'), -4.4),
            (('G', 'CG'), -5.1),
            (('T', 'CG'), -4.0),
            (('A', 'GC'), -3.7),
            (('C', 'GC'), -4.0),
            (('G', 'GC'), -3.9),
            (('T', 'GC'), -4.9),
            (('A', 'TA'), -2.9),
            (('C', 'TA'), -4.1),
            (('G', 'TA'), -4.2),
            (('T', 'TA'), -0.2),

            (('AT', 'A'), -0.5),
            (('AT', 'C'), 4.7),
            (('AT', 'G'), -4.1),
            (('AT', 'T'), -3.8),
            (('CG', 'A'), -5.9),
            (('CG', 'C'), -2.6),
            (('CG', 'G'), -3.2),
            (('CG', 'T'), -5.2),
            (('GC', 'A'), -2.1),
            (('GC', 'C'), -0.2),
            (('GC', 'G'), -3.9),
            (('GC', 'T'), -4.4),
            (('TA', 'A'), -0.7),
            (('TA', 'C'), 4.4),
            (('TA', 'G'), -1.6),
            (('TA', 'T'), 2.9),
    ])

    ps.dG.dangles.update(dG)
    ps.dH.dangles.update(dH)


def fill_poly_C(ps):
    """Do nothing as there is no poly_c correction mentioned

    Args:
        ps: the ParameterSet to augment

    Citation: SantaLucia and Hicks (2004)

    There is no mention of this correction in the SantaLucia and Hicks (2004)
    model for hairpins.
    """
    return


def fill_flush_coaxial_stacks(ps):
    """Add in coaxial stacking parameters from Peyret (2000)

    Args:
        ps: the ParameterSet to augment

    Citation: Peyret (2000) Table 8.4, pp. 228-229
    """

    # From Peyret (2000) Table 8.4, pp. 228-229
    # Taken from table in same format as natively stored in ParameterSet
    dG = ps.tabulate('dG-coaxial-stack', [
            (("AA", "TT"), -1.5),
            (("TT", "AA"), -2.7),
            (("TT", "AA"), -2.4),
            (("AT", "AT"), -2.2),
            (("TA", "TA"), -1.6),
            (("CA", "TG"), -1.7),
            (("TG", "CA"), -1.7),
            (("GT", "AC"), -3.0),
            (("AC", "GT"), -1.9),
            (("CT", "AG"), -2.4),
            (("AG", "CT"), -1.1),
            (("AG", "CT"), -1.2),
            (("GA", "TC"), -2.6),
            (("TC", "GA"), -2.9),
            (("CG", "CG"), -0.8),
            (("GC", "GC"), -3.3),
            (("CC", "GG"), -2.6),
            (("GG", "CC"), -1.6),
            ])

    dH = ps.tabulate('dH-coaxial-stack', [
            (("AA", "TT"), -15.3),
            (("TT", "AA"), -9.9),
            (("TT", "AA"), -26.5),
            (("AT", "AT"), -20.5),
            (("TA", "TA"), -9.7),
            (("CA", "TG"), -16.2),
            (("TG", "CA"), -12.0),
            (("GT", "AC"), -20.2),
            (("AC", "GT"), -10.5),
            (("CT", "AG"), -12.8),
            (("AG", "CT"), -9.0),
            (("AG", "CT"), -18.8),
            (("GA", "TC"), -17.7),
            (("TC", "GA"), -13.5),
            (("CG", "CG"), -9.0),
            (("GC", "GC"), -13.1),
            (("CC", "GG"), -18.7),
            (("GG", "CC"), -8.0),
            ])

    # some nearest neighbor stacks in Peyret (2000) are presented in the table
    # with different next-nearest neighbor contexts, and so are to be averaged
    # out since the model/algorithm does not differentiate these states.
    def average_redundant(p):
        """If keys are repeated, take the average of their energies."""
        intermediate = {}
        for el in p:
            seqs = el[0]
            energy = el[1]
            if seqs in intermediate:
                intermediate[seqs].append(energy)
            else:
                intermediate[seqs] = [energy]

        return [(k, float(np.mean(v))) for k, v in intermediate.items()]

    ps.dG.flush_coaxial_stacks.update(average_redundant(dG))
    ps.dH.flush_coaxial_stacks.update(average_redundant(dH))

def fill_terminal_mismatch(ps):
    """A placeholder as terminal mismatch parameters are not published

    Args:
        ps: the ParameterSet to augment

    Citation: "We have completed the database of measurements for terminal
    mismatches (S. Varma & J. SantaLucia, manuscript in preparation)"
    SantaLucia and Hicks (2004) p. 425
    """
    pass


def fill_hairpin_mismatch(ps):
    """Fill in hairpin mismatches from terminal mismatches

    Args:
        ps: the ParameterSet to augment

    Citation: SantaLucia and Hicks (2004) p. 428
    """
    # "For hairpin loops with lengths longer than 4, Equation 10 is applied:
    # ΔG◦_37(total) = ΔG◦_37(Hairpin of N) + ΔG◦_37(terminal mismatch), 10."
    # SantaLucia and Hicks (2004) p. 428
    #
    # So the hairpin mismatch is exactly the same as the terminal mismatch
    ps.dG.hairpin_mismatch.update(ps.dG.terminal_mismatch)
    ps.dH.hairpin_mismatch.update(ps.dH.terminal_mismatch)


def fill_interior_mismatch(ps):
    """Fill in interior loop mismatches from terminal mismatches

    Args:
        ps: the ParameterSet to augment

    Citation: SantaLucia and Hicks (2004) p. 429
    """
    # "Thus, internal loop stability is calculated according to Equation 12:
    # ΔG◦_37(Loop total) = ΔG◦_37(Internal Loop of N) + ΔG◦_37(asymmetry)
    #   + ΔG◦_37(left terminal mismatch)
    #   + ΔG◦_37(right terminal mismatch), 12."
    # SantaLucia and Hicks (2004) p. 429
    #
    # The equation for the energy term implies that the same terminal mismatch
    # parameters are used in interior loops that are used in external loop
    # contexts.
    ps.dG.interior_mismatch.update(ps.dG.terminal_mismatch)
    ps.dH.interior_mismatch.update(ps.dH.terminal_mismatch)


def fill_interior_2x2(ps):
    """Compute 2x2 interior loop energies from mismatches and size energy

    Args:
        ps: the ParameterSet to augment

    Citation: SantaLucia and Hicks (2004) p. 429
    """
    # "Thus, internal loop stability is calculated according to Equation 12:
    # ΔG◦_37(Loop total) = ΔG◦_37(Internal Loop of N) + ΔG◦_37(asymmetry)
    #   + ΔG◦_37(left terminal mismatch)
    #   + ΔG◦_37(right terminal mismatch), 12."
    # SantaLucia and Hicks (2004) p. 429
    #
    # "For RNA, a huge database of symmetric and mixed tandem mismatches has been
    # measured (91). In DNA, on the other hand, parameters for tandem mismatches
    # are available only for tandem GT (1), and other 2×2 internal loop sequences
    # remain to be determined and thus are approximated by Equation 12."
    # SantaLucia and Hicks (2004) p. 429
    #
    # So just directly apply the equation to all possible 2x2 loops,
    # neglecting the asymmetry penalty as all 2x2 loops are side length
    # symmetric.
    size_energy = ps.dG.interior_size[4]
    binary = list("".join(x) for x in product(bases, bases))
    for bp1, bp2, mm1, mm2 in product(base_pairs, base_pairs, binary, binary):
        key = (bp1[0]+mm1[0]+mm2[1]+bp2[1], bp2[0]+mm2[0]+mm1[1]+bp1[1])
        mm_energy1 = ps.dG.interior_mismatch.get((bp1,mm1), 0)
        mm_energy2 = ps.dG.interior_mismatch.get((bp2,mm2), 0)
        ps.dG.interior_2x2[key] = size_energy + mm_energy1 + mm_energy2

    # No information is given for ΔH values.


def fill_asymmetry_terms(ps):
    """Compute 1x2 interior loop energies from mismatches, size energy, and asymmetry

    Args:
        ps: the ParameterSet to augment

    Citation: SantaLucia and Hicks (2004) p. 429
    """
    # where ΔG◦_37(asymmetry) = |length A − length B| × 0.3 kcal mol^{−1} and A
    # and B are the lengths of both sides of the internal loop.
    # SantaLucia and Hicks (2004) p. 429
    #
    # This seems to indicate a flat value for all the "m" values. Further,
    # there is no indication of a max value for very asymmetric interior loops
    # so set max to 10000 * 0.3 as an upper limit (larger than any sequence
    # that we can reasonably compute)
    m_values = ["m1", "m2", "m3", "m4"]
    asymmetry_coefficient = ps['dG-asymmetry-constant', 0.3]
    ps.dG.asymmetry_terms.update((x, asymmetry_coefficient) for x in m_values)
    ps.dG.asymmetry_terms["max"] = 10000 * asymmetry_coefficient

    # There is no information on how ΔH terms should scale


def fill_interior_1x2(ps):
    """Compute 1x2 interior loop energies from mismatches, size energy, and asymmetry

    Args:
        ps: the ParameterSet to augment

    Citation: SantaLucia and Hicks (2004) p. 429
    """
    # In the discussion in the "Internal Loops" section, there is no special
    # mention made of 1x2 interior loops

    size_energy = ps.dG.interior_size[3]
    asymmetry_energy = min(ps.dG.asymmetry_terms["m1"] * (2-1), ps.dG.asymmetry_terms["max"])
    for bp1, bp2, x, y, z in product(base_pairs, base_pairs, bases, bases, bases):
        mm1 = x + y
        mm2 = z + x
        key = (bp1[0]+x+bp2[1], bp2[0]+z+y+bp1[1])
        mm_energy1 = ps.dG.interior_mismatch.get((bp1,mm1), 0)
        mm_energy2 = ps.dG.interior_mismatch.get((bp2,mm2), 0)
        ps.dG.interior_1x2[key] = size_energy + asymmetry_energy + mm_energy1 + mm_energy2

