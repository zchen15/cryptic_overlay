
from . import rna95
from . import rna99
from . import dna04

def generate(name):
    return {
        'rna95': rna95,
        'rna99': rna99,
        'dna04': dna04,
    }[name].generate()

# def make():
#     if __name__ == '__main__':
#         make_rna_1995_parameters().to_old_nupack("rna1995")
