#!/usr/bin/env python3
"""Citations and logic to convert the parameter set presented primarily in
    Mathews et al. (1999) into a Python object for output.

Functions:
    make_rna_1999_parameters: produce ParameterSet based on
        Serra and Turner (1995) for RNA
    fill_stacks: fill in stack parameters
    fill_flush_coaxial_stacks: fill in flush coaxial stack parameters
    fill_triloops: fill in triloop bonuses
    fill_tetraloops: fill in tetraloop bonuses
    fill_terminal_mismatch: fill in terminal mismatch parameters
    fill_hairpin_mismatch: fill in hairpin mismatch parameters
    fill_interior_mismatch: fill in interior mismatch parameters
    fill_interior_1x1: fill in 1x1 interior loop parameters
    fill_interior_1x2: fill in 1x1 interior loop parameters
    fill_interior_2x2: fill in 1x1 interior loop parameters
    fill_dangle: fill in dangle parameters
    fill_hairpin_size: fill in hairpin loop size parameters
    fill_bulge_size: fill in bulge loop size parameters
    fill_interior_size: fill in interior loop size parameters
    fill_multiloop_terms: fill in linear multiloop function parameters
    fill_asymmetry_terms: fill in interior loop asymmetry parameters
    fill_poly_C: fill in poly-C hairpin parameters
    fill_AT_penalty: fill in penalty for non-GC loops
    fill_bimolecular: fill in bimolecular (join) parameter
"""
from .constants import ParameterSet, BASEPAIRS, BASES, KT, fill_pseudoknot_terms
from . import rna95
from copy import deepcopy as copy
from itertools import product
import numpy as np

bases = [b.format(UT="U") for b in BASES]
base_pairs = [b.format(UT="U") for b in BASEPAIRS]
mismatches = ["".join(mm) for mm in product(bases, bases) if "".join(mm) not in base_pairs]

def generate():
    """Translate data from citations into an RNA ParmeterSet

    Returns:
        ParameterSet: full RNA parameters based on Mathews et al. (1999)

    Citations:
        Mathews, D. H., Sabina, J., Zuker, M., & Turner, D. H. (1999).
            Expanded sequence dependence of thermodynamic parameters improves
            prediction of RNA secondary structure. Journal of Molecular
            Biology, 288(5), 911–940. http://doi.org/10.1006/jmbi.1999.2700

        Xia, T., Santalucia, J., Burkard, M. E., Kierzek, R., Schroeder, S.
            J., Jiao, X., … Turner, D. H. (1998). Thermodynamic Parameters for
            an Expanded Nearest-Neighbor Model for Formation of RNA Duplexes
            with Watson-Crick Base Pairs. Biochemistry, 37, 14719–14735.

        Serra, M. J., Barnes, T. W., Betschart, K., Gutierrez, M. J., Sprouse,
            K. J., Riley, C. K., … Temel, R. E. (1997). Improved parameters
            for the prediction of RNA hairpin stability. Biochemistry,
            36(16), 4844–4851. http://doi.org/10.1021/bi962608j

        Dirks, R. M., & Pierce, N. a. (2003). Partition Function and Base-
            Pairing Probability Algorithms for Nucleic Acid Secondary
            Structure including Pseudoknots. J Comput Chem, 24, 1664–1677.
            http://doi.org/10.1002/jcc.10296
    """

    ps = ParameterSet('rna99', material="RNA", temperature=37.0, default_wobble_pairing=True)
    fill_stacks(ps)
    fill_flush_coaxial_stacks(ps)
    fill_triloops(ps)
    fill_tetraloops(ps)
    fill_dangle(ps)
    fill_terminal_mismatch(ps)
    fill_hairpin_mismatch(ps)
    fill_interior_mismatch(ps)
    fill_hairpin_size(ps)
    fill_bulge_size(ps)
    fill_interior_size(ps)
    fill_multiloop_terms(ps)
    fill_asymmetry_terms(ps)
    fill_interior_1x1(ps)
    fill_interior_1x2(ps)
    fill_interior_2x2(ps)
    fill_poly_C(ps)
    fill_AT_penalty(ps)
    fill_bimolecular(ps)
    fill_pseudoknot_terms(ps)

    return ps

def fill_stacks(ps):
    """add in stacking energy terms

    Args:
        ps: the ParameterSet to augment

    Citation:
        Table 4 of Xia et al. (1998), p. 14728
        Table 4 of Mathews et al. (1999), p. 921
    """


    # tuples are initially (bp1, bp2, energy)
    #
    # Table 4 of Xia et al. (1998) provides the Watson-Crick-only stacks, and
    # Table 4 of Mathews et al. (1999) provides stacks involving at least one
    # wobble pair.
    dG = ps.tabulate('dG-stack', [
            # Xia
            ("AU", "AU", -0.93),
            ("AU", "UA", -1.10),
            ("UA", "AU", -1.33),
            ("CG", "UA", -2.08),
            ("CG", "AU", -2.11),
            ("GC", "UA", -2.24),
            ("GC", "AU", -2.35),
            ("CG", "GC", -2.36),
            ("GC", "GC", -3.26),
            ("GC", "CG", -3.42),
            # Mathews
            ("AU", "GU", -0.55),
            ("AU", "UG", -1.36),
            ("CG", "GU", -1.41),
            ("CG", "UG", -2.11),
            ("GC", "GU", -1.53),
            ("GC", "UG", -2.51),
            ("GU", "AU", -1.27),

            # "The nearest neighbor, [GG/UU] is in only one measured duplex
            # and therefore has a large standard error from the fit. The
            # positive (unfavorable) ΔG_37 listed in Table 4 decreased the
            # accuracy of the structure prediction algorithm compared to a
            # favorable value. Therefore, for secondary structure prediction,
            # the value of [GG/UU] is set to a favorable -0.5 kcal/mol, a
            # reasonable estimate considering the size of the error."
            # Mathews et al. (1999) p. 920
            ("GU", "GU", -0.5),

            ("GU", "UG", 1.29),
            ("UA", "GU", -1.00),
            ("UG", "GU", 0.30),
    ])

    dH = ps.tabulate('dH-stack', [
            # Xia
            ("AU", "AU", -6.82),
            ("AU", "UA", -9.38),
            ("UA", "AU", -7.69),
            ("CG", "UA", -10.48),
            ("CG", "AU", -10.44),
            ("GC", "UA", -11.40),
            ("GC", "AU", -12.44),
            ("CG", "GC", -10.64),
            ("GC", "GC", -13.39),
            ("GC", "CG", -14.88),
            # Mathews
            ("AU", "GU", -3.21),
            ("AU", "UG", -8.81),
            ("CG", "GU", -5.61),
            ("CG", "UG", -12.11),
            ("GC", "GU", -8.33),
            ("GC", "UG", -12.59),
            ("GU", "AU", -12.83),
            ("GU", "GU", -13.47),
            ("GU", "UG", -14.59),
            ("UA", "GU", -6.99),
            ("UG", "GU", -9.26),
    ])

    def fill(input, output):
        """add in rotated stacks and store in Parameters"""
        def flip(s):
            """reverse a string"""
            return s[::-1]

        for x in copy(input):
            input.append((flip(x[1]), flip(x[0]), x[2]))

        # remove exact duplicates from copying dual wobbles
        input = list(set(input))

        output.stacks.update(((x[0][0]+x[1][0], x[1][1]+x[0][1]), x[2]) for x in input)


    fill(dG, ps.dG)
    fill(dH, ps.dH)


def fill_flush_coaxial_stacks(ps):
    """copy stack parameters

    Args:
        ps: the ParameterSet to augment

    Citation: Mathews et al. (1999) p. 934
    """
    # "For interfaces followed by strand extensions, the excess stability is
    # 0.0 (0.54) kcal/mol. It is assumed that the environment inside a larger
    # structure will be similar to the models with strand extensions and,
    # therefore, coaxial stacking of helices with no intervening nucleotides
    # is set to the nearest-neighbor parameter for those sequences within a
    # helix."
    # Mathews et al. (1999) p. 934
    #
    # Just copy the stack parameters which have already been filled out
    ps.dG.flush_coaxial_stacks.update(ps.dG.stacks)
    ps.dH.flush_coaxial_stacks.update(ps.dH.stacks)


def fill_triloops(ps):
    """Do nothing as there are no triloop bonuses in this parameter set

    Args:
        ps: the ParameterSet to augment

    Citation:
        Mathews et al. (1999), p. 923
        Serra et al. (1997), p. 4848
    """
    # "Hairpin loops of three are modeled as independent of loop sequence with
    # no interaction between the closing base pair and first mismatch (Serra &
    # Turner, 1995). Therefore, ∆G°37L is equal to ∆G°37iL for hairpin loops
    # of three, where ∆G°37iL is the free energy for initiating a hairpin
    # loop."
    # Serra et al. (1997), p. 4848
    #
    # "Stacking of the first mismatch and the free energy bonuses are not
    # included for loops smaller than four nucleotides because it is assumed
    # that these loops are too constrained to allow the same stacking
    # possible at the end of a duplex. The sequence independence of the
    # stability of loops of three supports this assumption (Serra et al.,
    # 1997)."
    # Mathews et al. (1999), p. 923
    #
    # So do nothing here.
    return


def fill_tetraloops(ps):
    """Add in tetraloops present in historical parameter set based on earlier citations

    Args:
        ps: the ParameterSet to augment

    Citation: Table 8 of Mathews et al. (1999), p. 926
    """
    dG = ps.tabulate('dG-tetraloop', [
            ("GGGGAC", -3.0),
            ("GGUGAC", -3.0),
            ("CGAAAG", -3.0),
            ("GGAGAC", -3.0),
            ("CGCAAG", -3.0),
            ("GGAAAC", -3.0),
            ("CGGAAG", -3.0),
            ("CUUCGG", -3.0),
            ("CGUGAG", -3.0),
            ("CGAAGG", -2.5),
            ("CUACGG", -2.5),
            ("GGCAAC", -2.5),
            ("CGCGAG", -2.5),
            ("UGAGAG", -2.5),
            ("CGAGAG", -2.0),
            ("AGAAAU", -2.0),
            ("CGUAAG", -2.0),
            ("CUAACG", -2.0),
            ("UGAAAG", -2.0),
            ("GGAAGC", -1.5),
            ("GGGAAC", -1.5),
            ("UGAAAA", -1.5),
            ("AGCAAU", -1.5),
            ("AGUAAU", -1.5),
            ("CGGGAG", -1.5),
            ("AGUGAU", -1.5),
            ("GGCGAC", -1.5),
            ("GGGAGC", -1.5),
            ("GUGAAC", -1.5),
            ("UGGAAA", -1.5),
    ])

    ps.dG.tetraloops.update(dG)


def fill_terminal_mismatch(ps):
    """Description

    Args:
        ps: the ParameterSet to augment

    Citation:
        Serra and Turner (1995), Table 1 on p. 245
        Mathews, Sabina, Zuker et al. (1999), p. 921
    """
    # "The parameters for dangling ends and mismatches are not affected by the
    # change in nearest-neighbor model. The free energy parameters for unpaired
    # nucleotides adjacent to Watson-Crick pairs are taken from a prior
    # compilation (Serra & Turner, 1995). Dangling ends on terminal G⋅U pairs
    # are treated like dangling ends on terminal A⋅U pairs with the A replacing
    # the G."
    # Mathews et al. (1999), p. 921
    #
    # Since we used the above-mentioned heuristic for handling G⋅U pairs in
    # the 1995 RNA parameter set, we will just directly use the same code here
    # as the parameters are expected to be the same.
    rna95.fill_terminal_mismatch(ps)


def fill_hairpin_mismatch(ps):
    """add in hairpin mismatch energies as modified terminal mismatch energies

    Args:
        ps: the ParameterSet to augment

    Citation:
        Mathews et al. (1999), p. 923
    """
    # "The interaction of the first mismatch with the closing base pair is
    # assumed to be the same for the hairpin as for a terminal mismatch on a
    # duplex and contributes both an enthalpy and entropy term to the
    # stability of the hairpin."
    # copy terminal mismatch parameters
    ps.dG.hairpin_mismatch.update(ps.dG.terminal_mismatch)
    ps.dH.hairpin_mismatch.update(ps.dH.terminal_mismatch)

    # "A bonus is applied to loops with UU and GA (G on the 5' side and A on
    # 3' side of loop) first mismatches."
    # Mathews et al. (1999), p. 923
    #
    # The value for this bonus is given in Table 6 of Mathews et al. (1999),
    # p. 923
    bonus = ps['hairpin-mismatch-bonus', -0.8]
    def modulate(energies):
        keys = energies.keys()
        stable_mismatch = list(filter(lambda x: x[1] in ["GA", "UU"], keys))
        energies.update((key, energies[key] + bonus) for key in stable_mismatch)

    modulate(ps.dG.hairpin_mismatch)
    modulate(ps.dH.hairpin_mismatch)


def fill_interior_mismatch(ps):
    """Expand the relatively short "mismatch" description to the whole parameter set

    Args:
        ps: the ParameterSet to augment

    Citation: Table 15 of Mathews et al. (1999), p. 931
    """
    # Table 15 gives three components to the mismatch
    # 1. A closure penalty for A⋅U or G⋅U pairs: 0.2 kcal per mol, however,
    #    this is the penalty over and above the 0.45 terminal AU penalty as
    #    explained here:
    #
    # "The 2×2 internal loops closed by A⋅U base-pairs are less favorable than
    # loops closed by G⋅C base-pairs by 0.65 kcal/mol per A U closure. This is
    # 0.2 kcal/mol less stable than the 0.45 kcal/mol term alone for terminal
    # A⋅U base-pairs (Xia et al., 1998). This 0.2 kcal/mol, called  ΔG_{AU/GU
    # closure penalty}, is added to the terminal A⋅U penalty of 0.45 kcal/mol
    # for each A⋅U or G⋅U closure of a large internal loop."
    # Mathews et al. (1999), p. 933
    #
    # So since the terminal AU penalty is not added via a separate mechanism
    # in the code, we use the following value here
    AUGU_penalty = ps['AUGU-penalty', 0.65]
    # 2. A bonus for AG/GA mismatches:
    AGGA_bonus = ps['AGGA-bonus', -1.1]
    # 3. A bonus for UU mismatches:
    UU_bonus = ps['UU-bonus', -0.7]

    for key in product(base_pairs, mismatches):
        bp, mm = key
        bonus = 0
        if mm in ["AG", "GA"]:
            bonus = AGGA_bonus
        elif mm == "UU":
            bonus = UU_bonus

        penalty = 0
        if bp in ["AU", "UA", "GU", "UG"]:
            penalty = AUGU_penalty

        ps.dG.interior_mismatch[key] = bonus + penalty

    # base pair "mismatches" in the table should probably be given some large
    # positive value to be consistent with the treatment of analogous states
    # in 2x2 and 1x2 interior loops. Here, we use 4 kcal/mol. This line of
    # reasoning was not followed in the historical parameter files.
    ps.dG.interior_mismatch.update((key, 4) for key in product(base_pairs, base_pairs))

def fill_interior_1x1(ps):
    """Add in available default information for single interior mismatches

    Args:
        ps: the ParameterSet to augment

    Citation: Mathews et al. (1999), p. 931
    """
    # "To take this sequence depen- dence into account, the new version of the
    # algorithm consults a table of all possible 1×1 loops and closing base-
    # pair combinations for the free energies of single mismatches.
    # The table of 1×1 loops contains experimentally determined values from
    # our lab (R.K. et al., unpublished results; Peritz et al., 1991)."
    #
    # This "table" does not appear in the paper. As it is at least partially
    # based on unpublised results, and the other cited reference does not
    # provide a deconvolution of the duplex measurements into individual loop
    # parameters.

    dG = {}
    # "The sequence,
    # 5' GUC 3'
    # 3' CUG 5'
    # was also excluded from the average because it is nearly 1 kcal/mol more
    # stable than other non-GG single mismatches."
    dG[("GUC","GUC")] = ps['dG-interior-GUC-GUC', -1 + 0.4]
    average = ps['dG-interior-average', 0.4]
    penalty = ps['dG-interior-AU-GU', 0.65]

    for bp1, bp2, mm in product(base_pairs, base_pairs, mismatches):
        key = (bp1[0]+mm[0]+bp2[0], bp2[1]+mm[1]+bp1[1])

        # If the mentioned table were available, the explicit values could be
        # entered beforehand into dG and the following if statement will
        # prevent clobbering them.
        if key not in dG:
            # "For all other mismatches except GG, the average of 0.4 kcal/mol
            # for all experimentally determined stabilities of single
            # mismatches with two adjacent GC pairs, excluding the GG
            # mismatches, are used."
            if mm != "GG":
                energy = average
            # "For GG mismatches, the average stability, -1.7 kcal/mol, is used."
            else:
                energy = ps['dG-interior-GG', -1.7]
            # "For each A×U or G×U closure, a 0.65 kcal/mol penalty
            # (determined from the 2×2 internal loops) is applied. This
            # penalty is consistent with experimental results (R.K.., M.E.B. &
            # D.H.T., unpublished results)."
            penalty = np.sum(x not in ["GC", "CG"] for x in [bp1, bp2]) * penalty

            dG[key] = energy + penalty

    # The historical parameter file treats "mismatches" which are actually
    # base pairs the same as all other unmeasured parameters.
    #
    # It seems like this value should be higher, however, to effectively
    # prevent a 1x1 loop when the bases can pair.
    for bp1, bp2, mm in product(base_pairs, base_pairs, base_pairs):
        key = (bp1[0]+mm[0]+bp2[0], bp2[1]+mm[1]+bp1[1])
        energy = average
        penalty = np.sum(x not in ["GC", "CG"] for x in [bp1, bp2]) * penalty
        dG[key] = energy + penalty

    ps.dG.interior_1x1.update(dG)


def fill_interior_1x2(ps):
    """Modulate tabulated values from reference to extrapolate to different
    base-pairing contexts

    Args:
        ps: the ParameterSet to augment

    Citation: Mathews et al. (1999), pp. 929, 931
    """
    # "Table 14 summarizes the stability of G C closed 2×1 internal loops.
    # Values based on experiment are derived from the measurements by
    # Schroeder et al. (1996) and the INN-HB parameters by Xia et al. (1998)"
    # Mathews et al. (1999), p. 929
    #
    # Table 14 is reproduced below as a list of tuples with have closing base
    # pair (either GC or CG or avg), top base, bottom bases (3' to 5' order),
    # and energy.
    tabulated_values = ps.tabulate('dG-interior-1x2', [
            ("CG", "A", "AA", 2.3),
            ("GC", "A", "AA", 2.5),
            ("GC", "A", "AC", 2.1),
            ("CG", "A", "AG", 0.8),
            ("GC", "A", "AG", 1.2),
            ("avg", "A", "CA", 2.2),
            ("CG", "A", "CC", 1.7),
            ("avg", "A", "CG", 0.6),
            ("CG", "A", "GA", 1.1),
            ("GC", "A", "GA", 2.1),
            ("avg", "A", "GC", 1.6),
            ("GC", "A", "GG", 1.6),
            ("CG", "C", "AA", 2.3),
            ("avg", "C", "AC", 2.2),
            ("CG", "C", "AU", 2.5),
            ("avg", "C", "CA", 2.2),
            ("CG", "C", "CC", 2.5),
            ("CG", "C", "CU", 1.9),
            ("avg", "C", "UA", 2.2),
            ("avg", "C", "UC", 2.2),
            ("avg", "C", "UU", 2.2),
            ("CG", "G", "AA", 1.7),
            ("CG", "G", "AG", 0.8),
            ("CG", "G", "GA", 0.8),
            ("avg", "G", "GG", 2.2),
            ("CG", "U", "CC", 2.2),
            ("CG", "U", "CU", 1.7),
            ("CG", "U", "UC", 1.5),
            ("CG", "U", "UU", 1.2),
    ])

    # create initial dictionary from above, loop through end sequences
    # (skipping if a base pair is possible with the sequence [handle
    # separately]), check initial dictionary if an explicit measurement is
    # available.

    # create dictionary from above
    loop_dict = {}
    for bp, top, bot, energy in tabulated_values:
        # reverse bot so that it is 5' to 3' in
        bot = bot[::-1]
        # add in average as both GC and CG closings
        if bp == "avg":
            loop_dict[("GC", top, bot, "GC")] = energy
            loop_dict[("CG", top, bot, "CG")] = energy
        else:
            loop_dict[(bp, top, bot, bp)] = energy

    # post-process to copy measured values to unmeasured values when
    # applicable
    for k, v in copy(loop_dict).items():
        bp, top, bot, _ = k

        # check for other base pair measurement
        bp = bp[::-1]
        newkey = (bp, top, bot, bp)
        # copy measured value to flipped base pair if this pair has not been measured
        if newkey not in loop_dict:
            loop_dict[newkey] = v

    # How A⋅U pairs are handled: "The penalty for A⋅U closure is extrapo-
    # lated from the data on symmetric 2×2 internal loops not including G⋅U
    # mismatches. On average, the A⋅U closed symmetric 2×2 loops are 1.3
    # (±0.4) kcal/mol less stable than the G⋅C closed loops of the same
    # sequence (Wu et al., 1995). Therefore, a 0.65 kcal/mol penalty is
    # applied per closing A⋅U in a 2×1 internal loop. This penalty is 0.2
    # kcal/mol larger than expected for simply a terminal A⋅U base-pair."
    # Mathews et al. (1999), p. 931
    AU_penalty = ps['dG-AT-penalty', 0.65]

    # Add in all of the other ones, skipping loops where base pairing is
    # possible. This exclusion of loops which present the possibility of base
    # pairing between the nucleotides is based on these states not occuring in
    # Table 14.
    for top, b1, b2, bp1, bp2 in product(bases, bases, bases, base_pairs, base_pairs):
        bot = b1+b2
        key = (bp1, top, bot, bp2)
        # skip if value was measured or computed above
        if key in loop_dict:
            continue

        if any(x in base_pairs for x in [top + b1, top + b2]):
            # The following line will add a finite positive value to all loops
            # where internal base-pairing is possible. This was done in the
            # historical parameter file, presumably as a way to effectively
            # disallow such states from occurring. However, how the precise
            # value was chosen is not clear.
            loop_dict[key] = ps['large-penalty', 4.0]
            continue

        energy = np.mean([loop_dict[("GC", top, bot, "GC")], loop_dict[("CG", top, bot, "CG")]])
        # penalty for each non-GC closing base pair
        penalty = np.sum(x not in ["GC", "CG"] for x in [bp1, bp2]) * AU_penalty
        loop_dict[key] = energy + penalty

    # standardize loop sequence key and store in parameter set
    for k, v in loop_dict.items():
        bp1, top, bot, bp2 = k
        newkey = (bp1[0] + top + bp2[0], bp2[1] + bot + bp1[1])
        ps.dG.interior_1x2[newkey] = v


def fill_interior_2x2(ps):
    """Combine interior loop mismatch and size information to generate explicit loops

    Args:
        ps: the ParameterSet to augment

    Citation: Mathews et al. (1999), pp. 927-930
    """
    # "Table 11 summarizes the stabilites of symmetric 2×2 internal loops"
    # Mathews et al.
    #
    # These number are listed in Table 11 verbatim and an equation, given
    # later, is used to construct the asymmetric tandem mismatches. Since the
    # only unique sequence information is the base pair and mismatch sequence,
    # the table will be reconstructed here as (BP, MM) values.
    symmetric_tandem_mms = ps.tabulate('dG-symmetric-tandem-mms', {
            ("GC", "UG"): -4.9, # average
            ("GC", "GU"): -4.1, # average
            ("GC", "GA"): -2.6, # average
            ("GC", "AG"): -1.3,
            ("GC", "UU"): -0.5,
            ("GC", "GG"): 0.8, # predicted
            ("GC", "CA"): 1.0, # predicted
            ("GC", "CU"): 1.1, # average
            ("GC", "UC"): 1.0, # predicted
            ("GC", "CC"): 1.0, # predicted
            ("GC", "AC"): 0.9,
            ("GC", "AA"): 1.5,
            ("CG", "UG"): -4.2, # average
            ("CG", "GU"): -1.1, # average
            ("CG", "GA"): -0.7,
            ("CG", "AG"): -0.7, # average
            ("CG", "UU"): -0.4,
            ("CG", "GG"): 0.8,
            ("CG", "CA"): 1.1,
            ("CG", "CU"): 1.4,
            ("CG", "UC"): 1.4,
            ("CG", "CC"): 1.7,
            ("CG", "AC"): 2.0,
            ("CG", "AA"): 1.3,
            ("UA", "UG"): -2.6, # average
            ("UA", "GU"): -0.3,
            ("UA", "GA"): 0.7,
            ("UA", "AG"): 0.7, # predicted
            ("UA", "UU"): 1.1,
            ("UA", "GG"): 1.5, # predicted
            ("UA", "CA"): 1.9,
            ("UA", "CU"): 2.2,
            ("UA", "UC"): 2.8,
            ("UA", "CC"): 2.8, # predicted
            ("UA", "AC"): 2.8, # predicted
            ("UA", "AA"): 2.8,
            ("AU", "UG"): -1.9, # average
            ("AU", "GU"): 0.2, # average
            ("AU", "GA"): 0.3, # average
            ("AU", "AG"): 0.3, # predicted
            ("AU", "UU"): 0.6,
            ("AU", "GG"): 1.4, # predicted
            ("AU", "CA"): 2.3,
            ("AU", "CU"): 2.2, # predicted
            ("AU", "UC"): 2.2, # predicted
            ("AU", "CC"): 2.2, # predicted
            ("AU", "AC"): 2.5,
            ("AU", "AA"): 2.8,
    })

    # "For predicting the free energy of 2×2 loops closed by G⋅U pairs, each
    # G⋅U pair is treated as an A-U pair."
    # Mathews et al. (1999), p. 927
    for key, val in copy(symmetric_tandem_mms).items():
        if key[0] in ["AU", "UA"]:
            symmetric_tandem_mms[(key[0].replace("A", "G"), key[1])] = val

    dG = []
    # "Stable mismatches are defined as GU, GA, and UU; all other mismatches
    # are destabilizing."
    # Mathews et al. (1999), p. 927
    stabilizing_mms = ["GU", "GA", "UU"]
    # assign 2 to pyrimidines and 3 to purines
    sizes = {"A": 3, "C": 2, "G": 3, "U": 2}

    # iterate through all combinations of symmetric
    for item1, item2 in product(symmetric_tandem_mms.items(), symmetric_tandem_mms.items()):
        # unpack sequence and energy information
        key1, energy1 = item1
        key2, energy2 = item2
        bp1, mm1 = key1
        bp2, mm2 = key2
        final_key = (bp1[0]+mm1[0]+mm2[1]+bp2[1], bp2[0]+mm2[0]+mm1[1]+bp1[1])
        energy = (energy1 + energy2) / 2

        if key1 == key2: # symmetric case
            dG.append((final_key, energy))
        else:
        # Table 12 of Mathews et al. (1999), p. 930 contains conditions for
        # modulating the average of symmetric tandem mismatches to produce the
        # value for an asymmetric tandem mismatch.
            size1 = sum(sizes[i] for i in mm1)
            size2 = sum(sizes[i] for i in mm2)
            delta = 0
            if size1 == size2 or (size1 != size2 and all(x not in stabilizing_mms for x in [mm1, mm2])):
                delta = 0
            elif any(x == "AC" for x in [mm1, mm2]):
                delta = 0
            elif all(x in stabilizing_mms for x in [mm1, mm2]) and size1 != size2:
                delta = ps['mms-1', 1.8]
            elif any(x not in stabilizing_mms for x in [mm1, mm2]) \
                    and any(x in stabilizing_mms for x in [mm1, mm2]) \
                    and size1 != size2:
                delta = ps['mms-1', 1.0]

            dG.append((final_key, energy + delta))

    # "Table 13 gives the stabilities for 2 2 internal loops with the sequence
    # 5' GXYG 3'
    # 3' CWZC 5'
    # with XW and YZ as mismatches."
    # Mathews et al. (1999), p. 927
    #
    # parameter set seems to use measured values where available. So, we will
    # overwrite the computed values from above when measured values are
    # available in Table 13.

    # These are the column headers of Table 13, matching the order they had there.
    second_mm = ["GU", "UG", "AG", "GA", "UU", "GG", "AC", "UC", "CU", "CC", "CA", "AA",]
    # These are the exp rows from Table 13, with their row headers. The values
    # in the lists correspond to the combination of the row header and the
    # second_nm column header with the same index as the value in the list.
    # Values surrounded by parentheses come from the table and indicate that
    # these values were not measured, but they should match the predicted
    # values from above and hence change nothing.
    table_rows = {
            "UG": [-4.4, -3.0, -0.9, -0.8, -1.0, (-0.2), (-1.9), (-0.8), (-0.8), -0.3, -0.7, 0.1],
            "GU": [(-4.2), -2.4, -1.3, (-0.8), 0.0, (-0.6), (-1.5), (-0.4), -0.1, (-0.2), -0.6, -0.5],
            "GA": [(-1.6), 0.3, -1.7, (-1.8), 0.5, (-0.9), (-0.8), (0.4), (0.4), 0.7, 0.1, -0.3],
            "AG": [-0.6, 0.6, -0.5, -0.7, 1.4, (-0.2), 0.7, (1.0), 0.5, 0.7, 0.5, 0.4],
            "UU": [-1.0, 0.6, 0.9, 0.9, -0.6, (1.2), -0.2, 0.2, (0.4), -0.1, 0.0, 1.5],
            "GG": [(-1.0), (0.6), (-0.3), (-0.4), (0.9), (0.5), (0.7), (1.4), (1.4), (1.5), (1.7), (0.8)],
            "CA": [(-1.6), (0.0), -0.4, -0.7, (1.3), (1.5), (1.0), (1.2), (1.2), (1.3), (1.5), (1.1)],
            "CU": [(-0.6), (1.0), (1.2), (1.1), (0.3), (1.6), (1.1), (1.2), (1.2), (1.4), (2.1), (1.8)],
            "UC": [(-0.6), (1.0), (1.1), (1.0), 0.1, (1.5), (1.1), 1.7, (1.2), (1.3), (2.1), (1.8)],
            "CC": [(-0.6), (1.0), (1.1), -0.6, (0.3), (1.5), (1.1), (1.2), (1.2), (1.3), (2.1), (1.8)],
            "AC": [(-1.6), (-0.1), 0.7, -1.0, 0.3, (1.5), (1.0), (1.7), (1.7), 1.9, 1.1, (1.7)],
            "AA": [-0.1, 0.9, -0.2, 0.0, 1.4, (1.2), (1.3), (2.0), (2.0), 2.2, 0.6, 0.5],
            }

    asymmetric_dG = []
    for mm1, val in table_rows.items():
        for mm2, energy in zip(second_mm, val):
            newkey = ("G" + mm1[0] + mm2[0] + "G", "C" + mm2[1] + mm1[1] + "C")
            asymmetric_dG.append((newkey, ps['mismatch-2x2-%s-%s' % newkey, energy]))


    ps.dG.interior_2x2.update(dG)
    ps.dG.interior_2x2.update(asymmetric_dG)

    # The following sets all "mismatches" where at least one is a Watson-Crick
    # pair to a positive finite value. This removes all of the zeros from the
    # tables in the old-style parameter file format. The value here was chosen
    # to match the historical parameter file. It was presumably added to
    # disallow states where base pairing was possible. However, how the
    # precise value was chosen is not clear.
    WC = ["AU", "UA", "GC", "CG"]
    watson_crick_dG = []
    for bp1, bp2, bp3, b1, b2 in product(base_pairs, base_pairs, WC, bases, bases):
        mm = b1 + b2
        key1 = (bp1[0]+bp3[0]+mm[1]+bp2[1], bp2[0]+mm[0]+bp3[1]+bp1[1])
        key2 = (bp1[0]+mm[0]+bp3[1]+bp2[1], bp2[0]+bp3[0]+mm[1]+bp1[1])
        watson_crick_dG.append((key1, 2))
        watson_crick_dG.append((key2, 2))
    ps.dG.interior_2x2.update(watson_crick_dG)


def fill_dangle(ps):
    """add in dangle energies (5' and 3')

    Args:
        ps: the ParameterSet to augment

    Citations:
        Table 2 of Serra and Turner (1995), p. 251
        Mathews, Sabina, Zuker et al. (1999), p. 921
    """
    # "The parameters for dangling ends and mismatches are not affected by the
    # change in nearest-neighbor model. The free energy parameters for unpaired
    # nucleotides adjacent to Watson-Crick pairs are taken from a prior
    # compilation (Serra & Turner, 1995). Dangling ends on terminal G⋅U pairs
    # are treated like dangling ends on terminal A⋅U pairs with the A replacing
    # the G."
    # Mathews et al. (1999), p. 921
    #
    # Since we used the above-mentioned heuristic for handling G⋅U pairs in
    # the 1995 RNA parameter set, we will just directly use the same code here
    # as the parameters are expected to be the same.
    rna95.fill_dangle(ps)


def fill_hairpin_size(ps):
    """Add in size-based free energies for hairpins

    Add in corresponding size-based free energies for hairpins, both tabulated
    values and computed logarithmic extrapolation up to 30 unpaired nt.

    Args:
        ps: the ParameterSet to augment

    Citation: Table 6 of Mathews et al. (1999), p. 923
    """

    # From Table 6
    tabulated_size_energies = ps.tabulate('hairpin-size', [
            # it is assumed that size 3 is the smallest possible hairpin to form
            (3, 5.7),
            (4, 5.6),
            (5, 5.6),
            (6, 5.4),
            (7, 5.9),
            (8, 5.6), # interpolated in table
            (9, 6.4),
    ])

    ps.dG.hairpin_size.update(tabulated_size_energies)

    # logarithmic formula for sizes 10-30
    n_max = 9
    dG_0 = ps.dG.hairpin_size[n_max]

    ps.dG.hairpin_size.update((n, dG_0 + ps['log_loop_penalty', 1.75 * KT] *np.log(n/n_max)) for n in range(10,31))


def fill_bulge_size(ps):
    """Add in size-based free energies for hairpins

    Add in corresponding size-based free energies for bulge loops, both
    tabulated values and computed logarithmic extrapolation up to 30
    unpaired nt.

    Args:
        ps: the ParameterSet to augment

    Citation: Table 9 of Mathews et al. (1999), p. 926
    """

    # From Table 9
    tabulated_size_energies = ps.tabulate('dG-bulge-size', [
            (1, 3.8),
            (2, 2.8),
            (3, 3.2),
            # for the following:
            # "For loops of length four, five, and six, the free energy
            # increments are increased by 0.4 kcal/ mol above the increment
            # for the next smaller bulge. This increase was chosen to be the
            # same as the increase in free energy between bulges of two and
            # three nucleotides because the logarithmic increase in equation
            # (11) is expected only for longer loops"
            # Mathews et al. (1999), p. 927
            (4, 3.6),
            (5, 4.0),
            (6, 4.4),
    ]) # data for 6-9 nt present in table according to below extrapolation formula

    ps.dG.bulge_size.update(tabulated_size_energies)

    # logarithmic formula for sizes 7-30
    n_max = 6
    dG_0 = ps.dG.bulge_size[n_max]

    ps.dG.bulge_size.update((n, dG_0 + ps['log_loop_penalty', 1.75 * KT] *np.log(n/n_max)) for n in range(6,31))


def fill_interior_size(ps):
    """Add in size-based free energies for hairpins

    Add in corresponding size-based free energies for bulge loops, both
    tabulated values and computed logarithmic extrapolation up to 30
    unpaired nt.

    Args:
        ps: the ParameterSet to augment

    Citation: Table 17 of Mathews et al. (1999), p. 933
    """

    # From Table 17
    tabulated_size_energies = ps.tabulate('dG-interior-size', [
            (4, 1.7),
            (5, 1.8),
            (6, 2.0),
    ])

    ps.dG.interior_size.update(tabulated_size_energies)

    # logarithmic formula for sizes 7-30
    n_max = 6
    dG_0 = ps.dG.interior_size[n_max]

    ps.dG.interior_size.update((n, dG_0 + ps['log_loop_penalty', 1.75 * KT] *np.log(n/n_max)) for n in range(7,31))


def fill_multiloop_terms(ps):
    """Add in the penalty terms for multiloop initiation, number of branches,
    and number of unpaired bases

    Args:
        ps: the ParameterSet to augment

    Citation: Table 18 of Mathews et al. (1999), p. 933
    """
    # α1, α2, α3 are respectively a1, c1, and b1 as in Equation 20 on p. 933
    ps.dG.multiloop_terms.update([
        ("α1", ps['multiloop-closing', 3.4]),
        ("α2", ps['multiloop-interior', 0.4]),
        ("α3", ps['multiloop-base', 0.0]),
    ])

    # No ΔH information is given; leave empty


def fill_asymmetry_terms(ps):
    """add in asymmetry penalty terms

    Args:
        ps: the ParameterSet to augment

    Citation: Mathews et al. (1999), p. 932
    """
    # "Table 16 gives the ΔΔG° for each asymmetric loop and Figure 3 shows a
    # plot of ΔΔG°  as a function of |n1 - n2|. This effect is sequence
    # dependent, but it increases roughly linearly with |n1 - n2|. The data,
    # excluding 2×1 internal loops, are fit to a line with intercept at the
    # origin as shown in Figure 3. The slope of the line, 0.48 (±0.04)
    # kcal/mol, is used as ΔG°_asymm."
    # Mathews et al. (1999), p. 932
    names = ["m1", "m2", "m3", "m4"]
    ps.dG.asymmetry_terms.update((n, ps['asymmetry-constant', 0.48]) for n in names)
    # no mention of a maximum, so same value kept from Serra and Turner (1995)
    ps.dG.asymmetry_terms["max"] = ps['asymmetry-max', 3.0]

    # no ΔH for asymmetry terms


def fill_poly_C(ps):
    """Do nothing as there is no poly_c correction mentioned

    Args:
        ps: the ParameterSet to augment

    Citation: Table 6 of Mathews et al. (1999), p. 923
    """
    # ""
    ps.dG.poly_C["poly_C_triloop"] = ps['dG-poly-C-triloop', 1.4]
    ps.dG.poly_C["slope"] = ps['dG-poly-C-slope', 0.3]
    ps.dG.poly_C["intercept"] = ps['dG-poly-C-intercept', 1.6]

def fill_AT_penalty(ps):
    """Add in AU penalty parameter

    Args:
        ps: the ParameterSet to augment

    Citation:
        Table 4 of Xia et al. (1998), p. 14728
        Mathews et al. (1999) p. 920
    """
    # Values pulled directly from Table 4 of Xia et al. (1998)
    #
    # "Terminal G⋅U pairs are treated like terminal A⋅U pairs in the INN-HB
    # model, i.e. they are penalized 0.45 kcal/mol because they have two
    # hydrogen bonds."
    # Mathews et al. (1999) p. 920
    ps.dG.AT_penalty = ps['dG-AT-penalty', 0.45]
    ps.dH.AT_penalty = ps['dH-AT-penalty', 3.72]

def fill_bimolecular(ps):
    """add in bimolecular values

    Args:
        ps: the ParameterSet to augment

    Citation: Table 4 of Xia et al. (1998), p. 14728
    """
    # This paper refers to the bimolecular term as the "duplex initiation" parameter
    #
    # "Among other factors, initiation includes translational and rotational
    # entropy loss for converting two particles into one."
    # Xia et al. (1998) p. 14722

    ps.dG.bimolecular = ps['dG-bimolecular', 4.09]
    ps.dH.bimolecular = ps['dH-bimolecular', 3.61]
