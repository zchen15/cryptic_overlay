
class Weight:
    """docstring"""


class ReversedComplex:
    """docstring"""

    def strands(self):
        pass

    def domains(self):
        pass


class Weights:
    """docstring"""
    def add(self, weight):
        pass

    def add_objective_weight(self, weight):
        pass
