import json, jsonschema, sys, os, copy, traceback
from tornado.web import RequestHandler, Application
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from nupack.analysis import ConcentrationSolver, AnalysisResult, ComplexResult
from nupack import Model, Analysis, ParameterFile
from nupack.numeric import SparsePairMatrix

DEFAULT_PORT = 8765

################################################################################

def merge(*dicts):
    out = {}
    for d in dicts:
        out.update(d)
    return out

def load_model(x):
    params = ParameterFile(x['parameters'])
    return Model(bits=64, ensemble=x['ensemble'], parameters=params,
                 T=x['temperature'], na=x['sodium'], mg=x['magnesium'])

def save_complex_result(res, limit):
    out = {k: v for k, v in zip(res._fields, res) if v is not None}
    if res.pair_probability is not None:
        out['pair_probability'] = SparsePairMatrix(res.pair_probability, limit).save()
    if res.suboptimal_structures is not None:
        out['mfe_structures'] = [(s.dp(), e) for s, e in out.pop('suboptimal_structures')]
    return out

def save_analysis_result(res, limit):
    return [merge({'sequences': k}, save_complex_result(v, limit)) for k, v in res.contents.items()]

################################################################################

def complex_analysis(inputs):
    out = copy.deepcopy(inputs)
    model = load_model(out['model'])
    analysis = Analysis(model)

    for c in out['complexes']:
        analysis.min_free_energy(c['sequences'], max_size=c['max_complex_size'])
        analysis.pair_probability(c['sequences'], max_size=c['max_complex_size'])

    results = analysis.compute()
    out['complexes'] = save_analysis_result(results, out['pair_probability_limit'])

    concs = out.get('concentrations')

    if concs is not None:
        strands = [s['sequence'] for s in concs]
        concentrations = [s['concentration'] for s in concs]

        solver = ConcentrationSolver.from_analysis_result(strands, results)
        results = solver.compute(concentrations)

        out['concentrations'] = [{'indices': x, 'concentration': c}
            for x, c in zip(results.complexes, results.concentrations)]

    return out

################################################################################

def tube_analysis(inputs):
    out = copy.deepcopy(inputs)
    strands = [s['sequence'] for s in out['strands']]
    concentrations = [s['concentration'] for s in out['strands']]

    log_pfs = {tuple(r['sequences']): r['log_partition_function'] for r in out['complexes']}

    solver = ConcentrationSolver(strands, log_pfs, temperature=out['temperature'])
    results = solver.compute(concentrations)

    out['concentrations'] = [{'indices': x, 'concentration': c}
        for x, c in zip(results.complexes, results.concentrations)]

    return out

################################################################################

ComputeFunctions = {
    'complex-analysis': complex_analysis,
    'tube-analysis': tube_analysis
}

################################################################################

class ComputeHandler(RequestHandler):
    input_schema = None
    output_schema = None

    def post_json(self, status, response):
        self.set_status(status)

        # if self.output_schema is not None:
        #     try:
        #         None and self.output_schema.validate(response)
        #     except jsonschema.ValidationError as e:
        #         self.set_status(500)
        #         response = dict(type=job_type, message=str(e), scope=(['output-validation'] + list(e.absolute_path)))

        self.write(json.dumps(response))

    def post(self):
        try:
            body = json.loads(self.request.body)
        except json.JSONDecodeError as e:
            exc = traceback.format_exc()
            return self.post_json(400, dict(error=str(e), traceback=exc, scope=['input']))

        try:
            body = dict(body)
            jobs = body.pop('jobs')
        except Exception as e:
            exc = traceback.format_exc()
            return self.post_json(500, dict(error=str(e), traceback=exc, scope=['runtime']))
        # if self.input_schema is not None:
        #     try:
        #         self.input_schema.validate(job)
        #     except jsonschema.ValidationError as e:
        #         return self.post_json(400, None, scope=['validation'] + list(e.absolute_path), error=str(e))
        try:
            for job in jobs:
                compute = ComputeFunctions[job['type']]
                job['data'] = compute(job['data'])
            body['jobs'] = jobs
        except Exception as e:
            exc = traceback.format_exc()
            print(exc)
            body.update(dict(error=str(e), traceback=exc, scope=['runtime']))
            return self.post_json(500, body)

        return self.post_json(200, body)

# with open('../docs/server/analysis_input_schema.json') as f:
#     ComputeHandler.input_schema = jsonschema.Draft4Validator(json.load(f))

# with open('../docs/server/analysis_output_schema.json') as f:
#     ComputeHandler.output_schema = and jsonschema.Draft4Validator(json.load(f))

################################################################################

def make_app():
    return Application([
        (r"/", ComputeHandler),
    ])

################################################################################

def test(path, port=DEFAULT_PORT):
    '''kind = complex or tube'''
    import requests

    with open(path) as f:
        input_data = json.load(f)

    r = requests.post("http://127.0.0.1:%d/" % port, data=json.dumps(input_data))
    if r.status_code != 200:
        print(r.status_code, r.reason)

    return json.loads(r.text)


################################################################################

if __name__ == "__main__":
    from argparse import ArgumentParser

    parser = ArgumentParser(description='Run NUPACK analysis server')
    parser.add_argument('--port', type=int, default=DEFAULT_PORT)
    parser.add_argument('--post', type=str, default='')
    args = parser.parse_args()

    if args.post:
        if args.post == 'complex':
            fn = '../docs/server/complex_input.json'
        elif args.post == 'tube':
            fn = '../docs/server/tube_input.json'
        else:
            fn = args.post
        print(json.dumps(test(fn), indent=2))
    else:
        import tornado.ioloop
        app = make_app()
        app.listen(args.port)
        tornado.ioloop.IOLoop.current().start()

################################################################################
