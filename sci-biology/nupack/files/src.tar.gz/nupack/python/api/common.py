
def finite_float(flt):
    if flt == float('inf'):
        return 'inf'
    elif flt == float('-inf'):
        return '-inf'
    else:
        return flt


def dict_to_tuple(x):
    if hasattr(x, 'items'):
        return tuple((dict_to_tuple(i), dict_to_tuple(j)) for i, j in x.items())
    else:
        return x
