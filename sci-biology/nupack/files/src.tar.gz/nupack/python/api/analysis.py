from typing import Dict, List
import numpy as np

from ..analysis import Analysis
from .core import sparse_pair_matrix
from .concentration import solve_complexes, coefficient_matrix
from .model import Model, ParameterFile, Conditions
from .constants import complexes_from_maxsize

################################################################################

def load(cls, *args, **kws):
    out = cls.__new__(cls)
    out.load(*args, **kws)
    return otu

class Tube:
    # name: str
    strands: Dict[str, float]
    max_complex_size: int
    model: Model

    def __init__(self, name, strands):
        self.name = str(name)
        self.strands = dict(strands)

    def load(self, x):
        self.name = x['name']
        self.strands = {d['name']: d['concentration'] for d in x['strands']}
        self.max_complex_size = x['max_complex_size']
        self.models = [load(Model, m) for m in x['models']]

    def save(self):
        return dict(name=self.name,
            strands=[dict(name=k, concentration=v) for k, v in self.strands.items()],
            max_complex_size=self.max_complex_size, models=[m.save() for m in self.models])

################################################################################

class TubeResult:
    '''Concentration for each non-negligible complex in the Tube'''
    Dict[int, float]


# model_index
# free_energy
# mfe_structures
# mfe_energy
# pair_probabilities
class ComplexResult:
    '''Pair probability etc'''
    results: Dict[Model, Stuff]

    def pair_matrix(self, P, limit):
        diag, values, rows, cols = sparse_pair_matrix(P, limit)
        return dict(diagonal=diag.tolist(), rows=rows.tolist(), cols=cols.tolist(), values=values.tolist())


class Result:
    tube: List[TubeResult]
    complexes: List[ComplexResult]
    inputs: 'Analysis'
    # models: List[dict]

################################################################################

class Analysis:
    '''
    An Analysis object contains a list of Tubes to analyze and a shared set of
    named strands.
    Each Tube has an associated physical model, a set of strands, the concentration
    for each strand, and definition of the ensemble of complexes to consider.
    '''

    strands: Set[str]         # all unique strands
    tubes: List[Tube]         # each tube
    complexes: Set[List[str]] # each unique complex
    pair_probability_limit: int

    def __init__(self, tubes=(), strands=(), pair_probability_limit=10):
        self.pair_probability_limit = pair_probability_limit
        self.tubes = list(tubes)
        self.strands = list(strands)

    def load(self, x):
        self.models = {}
        self.tubes = [load(Tube, t, self.models) for t in x['tubes']]
        self.strands = {d['name']: d['concentration'] for d in x['strands']}
        self.pair_probability_limit = x['pair_probability_limit']

    def save(self):
        return dict(tubes=[t.save() for t in self.tubes],
            strands=[dict(name=n, concentration=c) for n, c in self.strands.values()],
            pair_probability_limit=self.pair_probability_limit)

    def __call__(self):
        # model_keys, models = make_models_map(spec['tubes'])
        # strands = {x['name']: x['sequence'] for x in spec['strands']}

        complexes = {} # name tuple -> model indices
        tubes = [] # model indices for that tube
        tube_complexes = []
        for tube in self.tubes:
            model_indices = [model_keys.index(dict_to_tuple(x)) for x in tube.models]
            tubes.append(model_indices)

            temp = sorted(complexes_from_maxsize(tube.strands.keys(), tube['max_complex_size']))
            tube_complexes.append(temp)

            for c in temp:
                if c not in complexes:
                    complexes[c] = set()
                complexes[c].update(model_indices)

        tube_results = [[dict(model_index=i) for i in t] for t in tubes]
        complex_results = [dict(strands=list(s), results=[dict(model_index=j) for j in sorted(i)]) for s, i in complexes.items()]
        complexes = tuple(complexes.keys())

        for i, model in enumerate(self.models.values()):
            pf_eng = Analysis(kind='pf', model=model)
            mfe_eng = Analysis(kind='mfe', model=model)

            for c in complex_results:
                try:
                    ind = c['results'].index(dict(model_index=i))
                except ValueError:
                    continue

                cstrands = [strands[s] for s in c['strands']]
                nicks = list(map(int, np.cumsum([len(s) for s in cstrands])))

                try:
                    pp, log_pf = pf_eng.pair_probability(cstrands)
                except Exception as e:
                    print(cstrands)
                    raise
                pp = pair_matrix(pp, spec['pair_probability_limit'])

                temp = mfe_eng.subopt(cstrands)
                mfe_energy = finite_float(temp[0][1]) if temp else 'inf'
                mfe_strucs = [i[0].dp(nicks) for i in temp]

                c['results'][ind].update(dict(
                    free_energy=-log_pf/model.beta,
                    mfe_structures=mfe_strucs,
                    mfe_energy=mfe_energy,
                    pair_probabilities=pp
                ))

            for tube, comps, res in zip(self.tubes, tube_complexes, tube_results):
                try:
                    ind = res.index(dict(model_index=i))
                except ValueError:
                    continue

                indices = [complexes.index(c) for c in comps]
                g = [j['free_energy'] for t in [complex_results[x]['results'] for x in indices] for j in t if j['model_index'] == i]
                strand_concs = tuple(tube.strands.values())
                stoich = coefficient_matrix(comps, tuple(tube.strands.keys()))

                concs = solve_complexes(strand_concs, stoich, g=g, T=model.temperature)
                concs = [dict(index=i, concentration=c) for i, c in zip(indices, concs)]
                res[ind].update(dict(complexes=concs))

        for c in complex_results:
            for r in c['results']:
                r['free_energy'] = finite_float(r['free_energy'])

        return dict(tubes=tube_results, complexes=complex_results, models=models)

################################################################################


def make_model_engine(m):
    pfile = ParameterFile(m['material'], m['parameter_dG'], m['parameter_dH'])
    model = Model(ensemble=m['ensemble'], parameters=pfile, T=m['temperature'], na=m['sodium'], mg=m['magnesium'])
    pf_eng = Analysis(kind='pf', model=model)
    mfe_eng = Analysis(kind='mfe', model=model)
    return model, pf_eng, mfe_eng


def make_models_map(tubes):
    temp = {dict_to_tuple(x): x for tube in tubes for x in tube['models']}
    return list(temp.keys()), list(temp.values())



