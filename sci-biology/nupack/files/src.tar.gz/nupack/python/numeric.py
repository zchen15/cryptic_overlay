import numpy as np
from scipy.sparse import csc_matrix
from typing import Tuple
import itertools, collections
from .core import SimpleType
from .rebind import forward

try:
    from sklearn.decomposition import NMF
except ImportError:
    NMF = None

################################################################################

@forward
class GatedPoisson:
    def __init__(self, gate, poisson):
        '''Initialize self from probability of gate and Poisson mean'''

    def __call__(self, value) -> float:
        pass

@forward
class Poisson:
    pass

@forward
class Normal:
    pass

@forward
class Gamma:
    def __init__(self, alpha, beta):
        pass

    def __call__(self, value) -> float:
        pass

@forward
class Radial:
    pass

@forward
class SddSolver:
    pass

################################################################################

@forward
class AlternatingResult(SimpleType):
    unconverged: int
    iters: int
    objective: float

################################################################################

@forward
class AlternatingOptions(SimpleType):
    tolerance: float
    iters: int
    warm_start: bool

    __new__ = NotImplemented

    def __init__(self, *, iters=5000, tolerance=1e-8, warm_start=False):
        pass

@forward
class GaussianOptions(SimpleType):
    regularize: float
    truncate: float

    def __init__(self, options=None, regularize=0, truncate=8, _fun_=None):
        _fun_(self, AlternatingOptions() if options is None else options, regularize, truncate)

################################################################################

@forward
class ScalarBound(SimpleType):
    minimum: float
    maximum: float
    regularization: float

    def __init__(self, minimum=0, maximum=np.inf, regularization=0):
        pass

@forward
class VectorBound(SimpleType):
    bounds: np.ndarray

    def __init__(self, bounds):
        pass

################################################################################

@forward
class FastDIIS:
    def __init__(self, max_history):
        pass

    def __call__(self, x, error) -> np.ndarray:
        pass

@forward
class ReferenceDIIS:
    def __init__(self, max_history):
        pass

    def __call__(self, x, error) -> np.ndarray:
        pass

@forward
class NonnegativeDIIS:
    def __init__(self, max_history, iters=5000, tol=1e-10):
        pass

    def __call__(self, x, error) -> np.ndarray:
        pass

def array_flags(x):
    return x.flags if hasattr(x, 'flags') else x.data.flags

################################################################################

@forward
def sparse_pair_matrix(A, n=0) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    '''Return matrix diagonal and off-diagonal elements'''

@forward
class SparsePairMatrix:
    def __init__(self, A, n=0):
        self.diagonal, self.values, self.rows, self.cols = sparse_pair_matrix(A, n)

    def to_array(self):
        out = np.diag(self.diagonal)
        out[self.rows, self.cols] = self.values
        out[self.cols, self.rows] = self.values
        return out

    def to_csc(self, cls=csc_matrix):
        '''Return equivalent sparse matrix'''
        n = len(self.diagonal)
        rows = np.concatenate([np.arange(n), self.rows, self.cols])
        cols = np.concatenate([np.arange(n), self.cols, self.rows])
        vals = np.concatenate([self.diagonal, self.values, self.values])
        return cls((vals, (rows, cols)), shape=(n, n))

    def save(self):
        return dict(rows=self.rows.tolist(), cols=self.cols.tolist(),
                    values=self.values.tolist(), diagonal=self.diagonal.tolist())

################################################################################

@forward
def mask_to_zero(x, mask, _fun_=None):
    '''Set elements of x to 0 where mask is True'''
    out, x = x, getattr(x, 'values', x)
    mask = mask.astype(bool)
    assert array_flags(x).c_contiguous
    assert array_flags(mask).c_contiguous
    assert x.shape[-mask.ndim:] == mask.shape
    reps = np.prod(x.shape) // np.prod(mask.shape)
    for part in x.reshape(reps, -1):
        _fun_(part, mask.reshape(-1), gil=False)
    return out

################################################################################

def fixed_point(x, function, history, trust=0.9, method='diis', order=2, iters=100000, tol=1e-6, disp=False, **kws):
    run = dict(diis=FastDIIS, ref=ReferenceDIIS, nndiis=NonnegativeDIIS)[method](history, **kws)
    for i in range(iters):
        y = function(x)
        err = y - x

        xnorm, rnorm = (np.linalg.norm(y, ord=order) for y in (x, err))
        ratio = rnorm / xnorm

        if disp:
            print('%4d: |relative|=%9.7f, |residual|=%.4e, |x|=%.4e' % (i, ratio, rnorm, xnorm))
        if ratio < tol:
            return x, i

        if i == 0 and trust == 1:
            run(x, err)
            x = y
        else:
            x = (1 - trust) * y + trust * run(x, err)

    return x, iters

################################################################################

@forward
def gmm_squared_loss(I, M, grid, pairs, *, gradient=False, gaussian=None, bounds=None, _fun_=None):
    # I = np.asfortranarray(I)
    # M = np.asfortranarray(M, dtype=M.dtype)
    pairs = np.asfortranarray(pairs, dtype=np.ulonglong)
    bounds = ScalarBound() if bounds is None else bounds
    gaussian = GaussianOptions() if gaussian is None else gaussian
    # grid = tuple(np.asfortranarray(g, dtype=I.dtype) for g in grid)
    value = _fun_(I, M, grid, pairs, gradient, gaussian, bounds, gil=False)
    return value.cast(Tuple[float, np.ndarray, np.ndarray])

################################################################################

@forward
def bound_solve(A, B, bounds, *, options=None, X=None, _fun_=None):
    '''
    Non-negative solution of a fully determined linear system
    Any number of trailing dimensions of B is allowed
    Example:
        A = np.random.random(size=(11, 320))
        x = np.random.random(size=(11, 1))
        X, err = bound_solve(A @ A.T, A @ A.T @ x, bounds=ScalarBound(0, np.inf), options=AlternatingOptions(iters=5000))
    '''
    B = np.array(np.reshape(B, [B.shape[0], -1], 'A'), order='F')  # flatten trailing dimensions
    if X is None:
        X = np.zeros(B.shape, dtype=A.dtype, order='F')
    if np.ndim(X) == 1:
        X = X[:, None]
    bounds = ScalarBound.from_object(bounds)
    options = AlternatingOptions() if options is None else options
    result = _fun_(X, A, B, bounds, options, None, gil=False).cast(AlternatingResult)  # signature = 2
    X = np.reshape(X, B.shape, order='F')
    return X, result

################################################################################

def bound_least_squares(A, B, iters=5000, tol=1e-8, bounds=None, options=None):
    '''
    Solve A X = B using non-negative least squares
    Similar to running bound_solve with arguments (A.T @ A, A.T @ B)
    Any number of trailing dimensions of B is allowed
    If strip is True, columns of A that are all zero will be ignored
    X will then be set explicitly to 0 in those locations
    '''
    out = bound_solve(A.T @ A, np.tensordot(A.T, B, 1), bounds=bounds, options=options)
    out.objective += (B * B).sum()
    return out

################################################################################

def stable_rank(M, n=1):
    """The ratio between squared Frobenius norm and the squared spectral norm of a matrix."""
    return np.linalg.norm(M, ord='fro')**2 / (np.linalg.svd(M, compute_uv=False)[:n]**2).sum()

################################################################################

def nmf(X, n, init='nndsvd', random_state=0, **kws):
    '''Non-negative mean factorization using sklearn'''
    model = NMF(n_components=n, init=init, random_state=random_state, **kws)
    if n == 0:
        return np.empty((X.shape[0], 0)), np.empty((0, X.shape[1])), (X*X).sum()
    return model.fit_transform(X), model.components_, model.reconstruction_err_

################################################################################

def unit_nmf(X, n, **kws):
    '''
    X: np.ndarray
        - Matrix to approximate (can be rectangular)
    n: int
        - rank of the approximation to make
    kws
        - other keywords to pass to sklearn.decomposition.NMF
    Return U, w, V, err such that U diag(w) V.T approximates X with error err
    The results are ordered such that |w| is descending.
    If X is symmetric, U and V should be identical.
    '''
    if n == 0:
        return np.empty((X.shape[0], 0)), np.empty((0,)), np.empty((X.shape[1], 0)), (X*X).sum()
    W, H, err = nmf(X, n, **kws)
    H = H.T
    w, h = 1 / W.sum(0), 1 / H.sum(0)
    W *= w
    H *= h
    n = 1 / (w * h)
    order = np.argsort(np.abs(n))[::-1]
    return W[:, order], n[order], H[:, order], err

################################################################################

def marginal_nmf(X, m, n, **kws):
    '''Return something like the singular values'''
    out = [nmf(X, i, **kws)[2] for i in range(m, n)]
    return np.diff(out)

# def naive_fixed_point(function, x0, **kws):
#     x0, x1 = None, x0
#     while True:
#         x0, x1 = x1, function(x1)
#         yield x1, x1 - x0

# def diis_fixed_point(function, x0, *, block=256, mix=0.3, size=64):
#     '''
#     I believe this uses DIIS
#     yields (next estimate of x, current f(x) - x residual)
#     size: length of history
#     block: when to do reallocation
#     mix: ratio between 0 and 1. 0 means no DIIS, 1 means all DIIS
#     '''
#     I = np.eye(len(x0))
#     x1 = function(x0)
#     r1 = x1 - x0
#     for i in itertools.count():
#         X = np.ndarray([(i+1)*block, len(x0)])  # function after - function before
#         R = np.ndarray([(i+1)*block, len(x0)])  # error after - error before
#         for k in range(i*block, (i+1)*block):
#             with np.errstate(invalid='raise'):
#                 n = k+1
#                 m = 0 if size is None else max(0, n - size)
#                 X[k] = x1 - x0
#                 tmp = function(x1)
#                 r0, r1 = r1, tmp - x1
#                 R[k] = r1 - r0
#                 try:
#                     tmp = tmp - mix * r1 @ np.linalg.lstsq(R[m:n], X[m:n] + R[m:n], rcond=None)[0]
#                 except np.linalg.LinAlgError:
#                     pass
#                 x0, x1 = x1, tmp
#             yield x1, r1

# ###############################################################################


# FIXED_POINT_METHODS = dict(diis=diis_fixed_point, naive=naive_fixed_point)

# def fixed_point(function, x0, method='diis', order=2, iters=100000, tol=1e-6, disp=False, **kws):
#     method = FIXED_POINT_METHODS.get(method, method)
#     for i, (x, r) in zip(range(iters), method(function, x0, **kws)):
#         xnorm, rnorm = (np.linalg.norm(y, ord=order) for y in (x, r))
#         ratio = rnorm / xnorm
#         if disp:
#             print('%4d: |relative|=%9.7f, |residual|=%.4e, |x|=%.4e' % (i, ratio, rnorm, xnorm))
#         if ratio < tol:
#             return x, i
#     return x, iters

def test_nnls():
    a = np.ones([5, 5])
    b = np.ones([5])
    return bound_solve(None, np.asfortranarray(a), np.asfortranarray(b))
