from .analysis import Analysis
from .model import Model
from .constants import to_sequences
from random import choices
from queue import PriorityQueue
from numpy import cumsum

def null(*args, **kwargs):
    return

def dotparens(pairs, seqs):
    N = sum(len(i) for i in seqs)
    breaks = []
    if len(seqs) > 0:
        breaks = cumsum([len(i) for i in seqs])[:-1]

    struc = ['.' for i in range(N)]
    for i, j in pairs:
        if i > j:
            j, i = i, j
        struc[i] = "("
        struc[j] = ")"

    for br in reversed(breaks):
        struc.insert(br, "+")

    return "".join(struc)

class Segment:

    # i and j are indices, type is which matrix
    _priority = {"null": -1, "N": 0, "Q": 1, "M": 1, "MS": 2, "S": 2, "B": 3}

    def __init__(self, i, j, type, func):
        self.i = i
        self.j = j
        self.len = abs(j-i)
        self.type = type
        self.func = func
        self.priority = Segment._priority.get(type, 4)

    def __lt__(self, other):
        if self.len > other.len:
            return True
        elif self.len == other.len:
            return self.priority < other.priority
        else:
            return False

    def __eq__(self, other):
        return self.type == other.type and self.i == other.i and self.j == other.j

    def __ne__(self, other):
        return not (self == other)

    def __str__(self):
        return "Q^{}[{}, {}]".format(self.type, self.i, self.j)

    def __hash__(self):
        return str(self).__hash__()

    @classmethod
    def null(cls):
        return cls._null

Segment._null = Segment(1, float("inf"), "null", null)
Segment._null.len = -1

class Sample:

    def __init__(self, seqs, num_samples=1):
        self.seqs = tuple(to_sequences(seqs))
        self.len = sum(len(i) for i in self.seqs)
        self.breaks = []
        if len(seqs) > 0:
            self.breaks = cumsum([len(i) for i in self.seqs])[:-1]
        self.num_samples = num_samples
        self._engine = Analysis(count=True)
        self.pq = PriorityQueue()
        self._Q = {}
        self.set = set()


    def compute_matrices(self):
        self._markers = {}

        def extract(message):
            if len(message.sequences) == len(self.seqs):
                self._Q["Q"] = message.block.Q.copy()
                self._Q["B"] = message.block.B.copy()
                self._Q["S"] = message.block.S.copy()
                self._Q["M"] = message.block.M.copy()
                self._Q["N"] = message.block.N.copy()
                self._Q["MS"] = message.block.MS.copy()

        self._engine(self.seqs, obs=extract)
        self._markers.update({k: {} for k in self._Q})
        self._markers["null"] = {}


    def recurse_Q(self, i, j):
        breaks, markers = self.get_breaks_markers(i, j, "Q")
        Q = self._Q["Q"]
        S = self._Q["S"]

        # special cases
        population = [Segment.null(), Segment(i, j, "S", self.recurse_S)]
        weights = [1, S[i, j]]

        # normal, recursive cases
        for d in range(i, j):
            population.append((Segment(i, d, "Q", self.recurse_Q), Segment(d+1, j, "S", self.recurse_S)))
            weights.append(Q[i, d]*S[d+1, j])

        self.update_pq(population, weights, markers)

    # base pairs are added to sampled structures when the Q^B block is hit
    # (instead of when added to priority queue)
    def recurse_B(self, i, j):
        breaks, markers = self.get_breaks_markers(i, j, "B")
        B = self._Q["B"]
        M = self._Q["M"]
        MS = self._Q["MS"]
        N = self._Q["N"]

        for x in markers:
            self.samples[x].append((i, j))

        population = []
        weights = []

        # hairpin
        if B[i, j] > 0:
            population.append(Segment.null())
            weights.append(1)

        # interior
        for d in range(i+1, j):
            for e in range(d+1, j):
                population.append(Segment(d, e, "B", self.recurse_B))
                weights.append(B[d, e])

        # multi
        for d in range(i+1, j):
            population.append((Segment(i+1, d-1, "M", self.recurse_M), Segment(d, j-1, "MS", self.recurse_MS)))
            weights.append(M[i+1, d-1] * MS[d, j-1])

        # exterior
        population.append(Segment(i+1, j-1, "N", self.recurse_N))
        weights.append(N[i+1, j-1])

        self.update_pq(population, weights, markers)


    def recurse_S(self, i, j):
        breaks, markers = self.get_breaks_markers(i, j, "S")
        B = self._Q["B"]

        population = []
        weights = []

        for d in range(i, j+1):
            population.append(Segment(i, d, "B", self.recurse_B))
            weights.append(B[i, d])

        self.update_pq(population, weights, markers)


    def recurse_M(self, i, j):
        breaks, markers = self.get_breaks_markers(i, j, "M")
        MS = self._Q["MS"]
        M = self._Q["M"]

        population = []
        weights = []

        for d in range(i, j):
            population.append(Segment(d, j, "MS", self.recurse_MS))
            weights.append(MS[d, j])
            population.append((Segment(i, d-1, "M", self.recurse_M), Segment(d, j, "MS", self.recurse_MS)))
            weights.append(M[i, d-1]*MS[d, j])

        self.update_pq(population, weights, markers)


    def recurse_MS(self, i, j):
        breaks, markers = self.get_breaks_markers(i, j, "MS")
        B = self._Q["B"]

        population = []
        weights = []

        for d in range(i, j+1):
            population.append(Segment(i, d, "B", self.recurse_B))
            weights.append(B[i, d])

        self.update_pq(population, weights, markers)


    def recurse_N(self, i, j):
        breaks, markers = self.get_breaks_markers(i, j, "N")
        Q = self._Q["Q"]

        population = []
        weights = []

        for br in breaks:
            population.append((Segment(i, br-1, "Q", self.recurse_Q), Segment(br, j, "Q", self.recurse_Q)))
            weights.append(Q[i, br-1]*Q[br, j])

        self.update_pq(population, weights, markers)


    def get_breaks_markers(self, i, j, type):
        return ([br for br in self.breaks if (br >= i and br <= j)],
                self._markers[type][(i, j)])


    def update_pq(self, population, weights, markers):
        def put_mark(seg, mark):
            self._markers[seg.type].setdefault((seg.i, seg.j), []).append(mark)
            if seg not in self.set:
                self.set.add(seg)
                self.pq.put(seg)

        samples = choices(population, weights, k=len(markers))
        for s, m in zip(samples, markers):
            if isinstance(s, Segment):
                put_mark(s, m)
            else:
                for seg in s:
                    put_mark(seg, m)

        pass


    def init_samples(self):
        self.samples = [[] for n in range(self.num_samples)]
        self._markers.update({k: {} for k in self._Q})
        self.set = set()
        self.pq = PriorityQueue()
        self._markers["Q"][(0, self.len - 1)] = [x for x in range(self.num_samples)]
        self.pq.put(Segment(0, self.len - 1, "Q", self.recurse_Q))


    def sample(self, num_samples=None):
        if num_samples:
            self.num_samples = num_samples
        if len(self._Q) == 0:
            self.compute_matrices()
        self.init_samples()

        total = 0
        repeats = 0
        prev = Segment.null()
        while not self.pq.empty():
            cur = self.pq.get()
            if cur == Segment.null():
                continue
            total += 1
            print(str(cur))
            if prev == cur:
                repeats += 1
                continue
            cur.func(cur.i, cur.j)
            prev = cur

        print("total: {}, repeats: {}, fraction: {}".format(total, repeats, repeats / total))
        self.samples = [dotparens(s, self.seqs) for s in self.samples]
        return self.samples

