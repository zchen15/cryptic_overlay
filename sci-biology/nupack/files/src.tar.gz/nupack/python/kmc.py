from .core import PairList, Local
from .constants import as_sequences
from .model import Model
import numpy as np, scipy.sparse as sp
from .std import Vector
from .rebind import Tuple, List, Dict, forward
import collections

################################################################################

@forward
class FirstCollision:
    def __init__(self, pairs, threshold=0):
        '''Initialize from pair list and maximum Hamming distance threshold'''

@forward
class PairIntegrator:
    '''Integrates pair probability during a trajectory'''

    def mean(self) -> np.ndarray:
        '''Return average pair probability'''

################################################################################

@forward
class PairInterval:
    '''Keeps a record of the pair probability in an interval'''
    cum_pp: np.ndarray
    time: float

    def mean(self) -> np.ndarray:
        '''Return average pair probability'''

@forward
class FreeEnergyInterval:
    '''Keeps a record of the MFE structure that has been seen in an interval'''
    exps: Dict[PairList, float] # map from state to Boltzmann factor

@forward
class TimeInterval:
    '''Keeps a record of the start and end times of an interval'''
    begin_step: int
    end_step: int

    begin_time: float
    end_time: float

################################################################################

@forward
class HittingTimeObserver:
    '''Records hitting time to a given state'''

@forward
class TimeIntegrator:
    '''Time integrator'''

@forward
class ScaledIntegrator:
    '''Integrator class'''

@forward
class HammingObserver:
    '''Integrator class'''

@forward
class EnumeratedIntegrator:
    '''Integrator class'''

@forward
class EnumeratedObserver:
    '''Counts all states that have been encountered'''

@forward
class CovarianceIntegrator:
    '''Integrates the outer product of any set of functions'''

@forward
class HammingIntegrator:
    '''Integrates Hamming distance from a given set of states'''

@forward
class ComplexSet:
    '''Holds complex level information about the state'''

Macrostate = collections.namedtuple('Macrostate', ['time', 'pairs', 'mfe', 'free_energy'])
# Macrostate = collections.namedtuple('Macrostate', ['time', 'mfe', 'free_energy'])

@forward
def small_box(states, tau: float=2e-4, match: float=0.2, spread: int=50, pfunc: int=100, timeout: float=0.1, log=False, env=1, _fun_=None):
    '''
    Small box algorithm:
    states: List[State]
        Initial states to start macrostate exploration (# states == # trajectories)
    tau: float
        window length
    match:
        pair probabililty match threshold
    spread:
        number of trajectories to launch during exploration from each initial macrostate
    pfunc:
        number of trajectories to sample partition functions at the end
    log:
        whether to use the doubling scanner or the linear scanner


    return tuple of:
        list of found macrostates
        macrostate rate matrix
        approximate partition functions for each macrostate
    '''
    assert len(states) > 0
    env = Local.from_object(env)
    result = _fun_(env, states, tau, match, spread, pfunc, timeout, log)
    us, R, pfs = result.cast(Tuple[Vector, np.ndarray, np.ndarray])
    # , elapsed = , List[Tuple[float, float, int]]
    return [Macrostate(*x) for x in us], R.copy(), pfs.copy()

################################################################################

@forward
def original_small_box(states, tau: float=2e-4, match: float=0.2, spread: int=50, pfunc: int=100, timeout: float=0.1, log=False, env=1, _fun_=None):
    '''
    Remaking the Small box algorithm to match Jon/Brian's design:
    states: List[State]
        Initial states to start macrostate exploration (# states == # trajectories)
    tau: float
        window length
    match:
        pair probabililty match threshold
    spread:
        number of trajectories to launch during exploration from each initial macrostate
    pfunc:
        number of trajectories to sample partition functions at the end
    log:
        whether to use the doubling scanner or the linear scanner


    return tuple of:
        list of found macrostates
        macrostate rate matrix
        approximate partition functions for each macrostate
    '''
    assert len(states) > 0
    env = Local.from_object(env)
    result = _fun_(env, states, tau, match, spread, pfunc, timeout, log)
    us, R, pfs = result.cast(Tuple[Vector, np.ndarray, np.ndarray])
    # , elapsed = , List[Tuple[float, float, int]]
    return [Macrostate(*x) for x in us], R.copy(), pfs.copy()

################################################################################

@forward
class StopWatch:
    '''Trajectory observer based on measured wall clock time'''
    max_time: float

    def seconds() -> float:
        pass

    def __init__(self, time=None, skip=20, _fun_=None):
        if hasattr(time, 'total_seconds'):
            time = time.total_seconds()
        _fun_(self, skip, -1 if time is None else time)

################################################################################

@forward
class Timer:
    '''Trajectory observer based on simulation time'''

    time: float
    time_offset: float
    max_time: float

    step: int
    step_offset: int
    max_step: int

    def __init__(self, steps=None, time=None, _fun_=None):
        _fun_(self, -1 if steps is None else steps, -1 if time is None else time)

    def __call__(self, t, _fun_=None):
        return _fun_(self, True, float(t))

################################################################################

@forward
class System:
    '''Holds sequence information for a given secondary structure state'''

################################################################################

@forward
class StateBase:
    def sequence(self) -> str:
        '''
        Concatenated sequence of system
        Connected strands are delimited with '+'
        Disconnected strands are delimited with ' '
        '''

    def dp(self) -> str:
        '''Dot parens plus of State'''

@forward
class State(StateBase):
    '''Secondary structure state used for Kinetic Monte Carlo'''

    def __init__(self, strands, dp: str=None, kind: str='lazy', model=None, _fun_=None):
        '''
        strands: str or List[str]:
            strands in the state
        dp: dot-parens of the structure (if not given, unpaired)
        kind: move generation algorithm, one of ('lazy', 'full' 'static')
        model: Model
            energy model to use
        '''
        strands = tuple(as_sequences(strands))
        if dp is None:
            dp = '+'.join('.' * len(s) for s in strands)
        if isinstance(dp, str):
            dp = PairList(dp)
        if model is None:
            model = Model()

        mode = dict(lazy='jump', full='jump', static='static')[kind]

        match = next(k for k, v in self._metadata_.items() if v.cast(str) == mode)
        if mode == 'static':
            _fun_(self, strands, dp, return_type=match)
            self.energy = None
            self.model = None
        else:
            _fun_(self, strands, dp, kind, model, return_type=match)
        self.kind = str(kind)

    def energy(self) -> float:
        '''Return current free energy of the state'''

    def calculate_energy(self, model) -> float:
        '''Return state energy using a separate energy model'''

    def enumerated(self) -> Vector:
        '''
        Returns a list of each possible State in the associated system
        '''

    def with_structure(self, structure) -> 'State':
        '''
        Return the same state but with a different structure
        structure(PairList or State): structure to use
        If a State is given, this function will fix strands being misordered
        '''

    def rate_matrix(self, basis=None, _fun_=None):
        '''
        basis: None, or (M x N x N) ndarray of M pair probability matrices N x N

        Using an enumeration of states that can be created by forming base pairs, return a tuple of:
            - vector of every microstate states (length N)
            - stationary probability vector for those states (length N)
            - rate matrix between those states (N x N sparse matrix)
            ` pair probability distances from each matrix in the basis (M x N array)
        '''
        basis = None if basis is None else np.asfortranarray(np.asarray(basis).T)
        return _fun_(self, basis).cast(Tuple[Vector, np.ndarray, sp.csc_matrix, np.ndarray])

    def step(self) -> float:
        '''
        Mutate self by taking one step by performing a base pair deletion or addition.
        Return the length of the timestep that was taken
        '''

    def run(self, stop=None, mutate=False, steps=None, time=None, walltime=None, average=False, observers=None, _fun_=None):
        '''
        stop: (State, float) -> bool
            callback used to stop the trajectory
        observers: List[State, float -> None]:
            any other callbacks
        Run a trajectory until stop callback returns true.
        Stop condition and observers are mutated
        Return new state after running trajectory
        '''
        if self.kind == 'static':
            raise AttributeError('State must be not initialized with kind=\'static\' for run()')
        w = self if mutate else self.copy()

        if stop is None and (steps is not None or time is not None):
            stop = Timer(steps=steps, time=time)
        elif walltime is not None:
            stop = Stopwatch(time=walltime)
        elif stop is None:
            raise TypeError('Stop condition must be callable, or else specified by other keywords')

        _fun_(w, average, stop, () if observers is None else observers)
        return w, stop

    def __repr__(self):
        return str(self)

################################################################################

@forward
class MfeInterval:
    '''Keeps a record of the MFE structure(s) that has been seen in an interval'''
    states: List[State]
