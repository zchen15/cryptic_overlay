from scipy.optimize import minimize
from typing import Tuple, List
from collections import namedtuple
from concurrent.futures import ThreadPoolExecutor
import time, numpy as np
from . import constants
from .numeric import AlternatingOptions, AlternatingResult, ScalarBound
from .utility import match, dtype_index
from .rebind import forward

################################################################################

@forward
def optimize_leica(Ex, Em, *, sequences, iters, _fun_=None):
    out = _fun_(Ex, Em, sequences, iters, gil=False)
    return out.cast(Tuple[np.ndarray, np.ndarray, float])

################################################################################

@forward
def optimize_probes(A, n, order=2, alpha=1, keep=0, iters=1000) -> Tuple[np.ndarray, float]:
    pass

################################################################################

def ravel(I):
    return np.reshape(getattr(I, 'values', I), -1, 'A')

@forward
def discrete_histogram(I, n=0, _fun_=None):
    return _fun_(ravel(I), n).cast(np.ndarray)

################################################################################

@forward
class ImageAnalyzer:
    rgb_c_r_z: np.ndarray
    rgb_l_c: np.ndarray
    max_l_r: np.ndarray
    sum_l_r: np.ndarray
    mean_l_z: np.ndarray
    norm2_r_z: np.ndarray
    cov_l_l: np.ndarray
    norm2: float
    capacity: int

    __new__ = NotImplemented

    def __init__(self, n, l, r, z, colors=None, dtype=None, score=None, out_type=np.float32, _fun_=None):
        types = (dtype_index(dtype), dtype_index(out_type))
        colors = np.asfortranarray(np.empty([l, 0]) if colors is None else colors, dtype=out_type)
        score = np.asfortranarray(np.ones([l]) if score is None else score, dtype=out_type)
        for k, m in self._metadata_.items():
            i, o = m.cast(Tuple[constants.TypeIndex, constants.TypeIndex])
            if (i, o) == types:
                return _fun_(self, n, l, r, z, score, colors, return_type=k)
        raise TypeError('Cannot find matching compiled type', types)

    def add(self, z, I):
        pass

    def samples(self) -> Tuple[np.ndarray, np.ndarray]:
        '''Returns samples and sample scores, sorted so that sample scores is descending'''
        pass

################################################################################

@forward
class SpectrumOptimizer:
    G_f_e: np.ndarray
    X_f_r: np.ndarray
    X_c_r: np.ndarray
    residual_f_r: np.ndarray
    residual_c_r: np.ndarray

    def __init__(self, *, sigma, R, S, G, C, indices):
        '''
        sigma(l): noise coefficients per wavelength
        R(l, f): spectrum for each fluorophore on the concatenated wavelength space
        S(l, e): laser power on the concatenated wavelength space
        G(f, e): laser power on the concatenated wavelength space
        C(f, c): initial coefficient of fluorophore in each component
        '''

    def joint_gamma_update(self, iters, x_options, g_options, normalize=False) -> AlternatingResult:
        '''Update gamma and X jointly'''

    def joint_coefficient_update(self, iters, x_options, c_options, normalize=False) -> AlternatingResult:
        '''Update C and X jointly'''

    def spectrum(self, coefficients=False) -> np.ndarray:
        pass

    def set_coefficients(self, C):
        pass

    def coefficients(self) -> np.ndarray:
        pass

    def set_coefficients(self, array):
        pass

    def reset_scans(self):
        '''Reset accumulators and errors before new batch of images'''

    def scan_image(self, image, exponent=0) -> float:
        pass

    def unmix_gamma(self, options, increment=False) -> AlternatingResult:
        '''Return number of least squares errors that occurred'''

    def unmix_coefficients(self, options, increment=False) -> AlternatingResult:
        '''Return number of least squares errors that occurred'''

    def solve_gamma(self, options, normalize=False) -> AlternatingResult:
        '''Return error and squared residual norm'''

    def solve_coefficients(self, options, normalize=False) -> AlternatingResult:
        '''Return error and squared residual norm'''

################################################################################

SampleStatistics = namedtuple('SampleStatistics', ['mu', 'cov', 'fake', 'iso', 'coloc', 'edges', 'count', 'samplers'])

################################################################################

@forward
def test_dots() -> float:
    '''Run a test'''

################################################################################

@forward
class DotParameters:
    # sites
    sigma: np.ndarray
    threshold: np.ndarray
    # small_vec<A> af;
    detect: np.ndarray
    alpha: np.ndarray
    beta: np.ndarray

    def __init__(self, sites, sigma, thresholds, truncate=1e-12):
        pass

    def flatten(self) -> np.ndarray:
        pass

    def update(self, x) -> None:
        pass


################################################################################

@forward
class SyntheticDotData:
    positions: np.ndarray
    intensities: np.ndarray
    sites: np.ndarray
    labels: np.ndarray

    def __init__(self, n, parameters):
        '''Initialize synthetic dots from the given parameters'''
        assert False

    def processed(self):
        return ProcessedData(self.positions, self.intensities)

################################################################################

class ProcessedData:
    def __init__(self, positions, intensities):
        self.channels = []
        print(positions.shape, intensities.shape)
        for p, i in zip(positions, intensities):
            idx = np.where(i != 0)
            self.channels.append((p[idx], i[idx]))

################################################################################

@forward
class DotChannelModel:
    def __init__(self, intensities, positions, _fun_=None):
        _fun_(self, intensities, positions)

    def real_component(self, parameters, intensities, i) -> np.ndarray:
        pass

    def fake_component(self, parameters, intensities, i) -> np.ndarray:
        pass

################################################################################

@forward
class DotStatistics:
    pass

################################################################################

@forward
class DotResult:
    count: int
    edges: np.ndarray
    edge_counts: np.ndarray
    fake_counts: List[np.ndarray]
    iso_counts: List[np.ndarray]

################################################################################

@forward
class DotSampler:
    prior_s: np.ndarray
    # channels
    stats: DotStatistics
    eweights: np.ndarray

    def __init__(self, channels, box, _fun_=None):
        ''''''
        _fun_(self, channels, np.asarray(box, dtype=np.float64, order='F'))

    def result(self, average=False):
        '''Return array of estimated probabilities that each dot is a real dot'''

    def sample(self, iters, parameters, sd, beta=1, _fun_=None):
        '''
        Sample parameters for a number of iterations
        Does not modify self; returns a modified copy of self instead
        '''
        s = self.copy()
        return (s,) + _fun_(s, iters, beta, parameters, sd, gil=False).cast(Tuple[np.ndarray, np.ndarray, int])

    def logp(self, parameters, i, j) -> float:
        '''Return log probability of given parameters'''

    def edge_probabilities(self, parameters, channels, _fun_=None):
        i, j = channels
        return _fun_(self, parameters, i, j).cast(np.ndarray)

    def sample_statistics(self, *args, pool=4, **kws):
        if isinstance(pool, int):
            with ThreadPoolExecutor(pool) as ex:
                return self.sample_statistics(*args, pool=ex, **kws)

        elapsed = -time.time()
        tasks = [pool.submit(self.sample, *args, **kws) for _ in range(8)]
        tasks = [t.result() for t in tasks]
        elapsed += time.time()

        mu, cov, n = [np.sum([t[i] for t in tasks], axis=0) for i in range(1, 4)]
        mu /= n
        cov /= n
        cov -= np.outer(mu, mu)

        stats = [t[0].result() for t in tasks]
        fake = [np.sum(i, axis=0) / n for i in zip(*[s.fake_counts for s in stats])]
        iso = [np.sum(i, axis=0) / n for i in zip(*[s.iso_counts for s in stats])]
        coloc = sum(s.edge_counts for s in stats) / n
        edges = stats[0].edges
        return SampleStatistics(mu=mu, cov=cov, fake=fake, iso=iso, coloc=coloc,
            edges=edges, count=n, samplers=[t[0] for t in tasks])

    def optimize(self, parameters, iters=10000, method='powell'):
        ps = parameters.copy()
        def objective(x):
            if np.any(x <= 0):
                return np.inf
            ps.update(x)
            return -self.logp(ps)
        sol = minimize(objective, parameters.flatten(), method=method, options=dict(maxiter=iters))
        ps.update(sol.x)
        return ps

################################################################################

def align():
    init = sitk.CenteredTransformInitializer(fixed_image, moving_image, sitk.Euler3DTransform(), sitk.CenteredTransformInitializerFilter.GEOMETRY)

    resampled = sitk.Resample(moving_image, fixed_image, init, sitk.sitkLinear, 0.0, moving_image.GetPixelID())

    reg = sitk.ImageRegistrationMethod()

    # Similarity metric settings.
    reg.SetMetricAsMattesMutualInformation(numberOfHistogramBins=50)
    reg.SetMetricSamplingStrategy(reg.RANDOM)
    reg.SetMetricSamplingPercentage(0.01)

    reg.SetInterpolator(sitk.sitkLinear)

    # Optimizer settings.
    reg.SetOptimizerAsGradientDescent(learningRate=1.0, numberOfIterations=100, convergenceMinimumValue=1e-6, convergenceWindowSize=10)
    reg.SetOptimizerScalesFromPhysicalShift()

    # Setup for the multi-resolution framework.
    reg.SetShrinkFactorsPerLevel(shrinkFactors = [4,2,1])
    reg.SetSmoothingSigmasPerLevel(smoothingSigmas=[2,1,0])
    reg.SmoothingSigmasAreSpecifiedInPhysicalUnitsOn()

    # Don't optimize in-place, we would possibly like to run this cell multiple times.
    reg.SetInitialTransform(init, inPlace=False)

    final = reg.Execute(sitk.Cast(fixed_image, sitk.sitkFloat32), sitk.Cast(moving_image, sitk.sitkFloat32))
    print(final)
