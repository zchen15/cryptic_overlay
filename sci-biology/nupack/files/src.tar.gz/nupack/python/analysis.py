from .rebind import Tuple, List, Dict, Union, Callable, forward
import functools, itertools, collections, numpy as np
from .core import Structure, PairList, NickSequence, SparsePairMatrix
from .utility import match, str_repr
from .model import Model, Ensemble
from .rotation import lowest_rotation
from .constants import complexes_from_maxsize, rotational_symmetry, string_exp, as_sequences
from .core import LRU, Local
from .concentration import complex_concentrations
from typing import NamedTuple

################################################################################

class ConcentrationResult:
    strands: List[Tuple[str]]
    complexes: List[Tuple[int]]
    concentrations: np.ndarray

    def __init__(self, strands, complexes, concentrations):
        self.strands = strands
        self.complexes = list(complexes)
        self.concentrations = np.asarray(concentrations)
        assert len(self.complexes) == len(self.concentrations)

    def complex_concentrations(self):
        return {tuple(self.strands[i] for i in k): v for k, v in zip(self.complexes, self.concentrations)}

################################################################################

class ConcentrationSolver:
    def __init__(self, strands, complex_results, temperature=None):
        '''
        - `complex_results`: either of
            - instance of AnalysisResult (temperature does not need to be specified)
            - map from a tuple of strands to the log partition function
        - `temperature`: if not deducable, the temperature of the system in Kelvin
        '''
        if isinstance(complex_results, AnalysisResult):
            return self.__init__(strands,
                {k: v.log_partition_function for k, v in complex_results.contents.items()},
                complex_results.model.temperature)

        self.strands = as_sequences(strands)
        self.lookup = {}
        for i, s in enumerate(self.strands):
            self.lookup.setdefault(s, []).append(i)

        try:
            self.temperature = float(temperature)
        except TypeError:
            raise TypeError('temperature should be specified unless constructed via AnalysisResult')

        self.complexes = {i: v for k, v in complex_results.items()
            if v is not None and all(s in self.lookup for s in k)
            for i in itertools.product(*map(self.lookup.__getitem__, k))}

    def compute(self, concentrations, complexes=None, as_strands=True):
        '''
        concentrations: array
            list of molarity of each strand species
        complexes: None, int, or List[List[str]]
            None: calculate concentrations in an ensemble containing all prior calculated complexes
            int: calculate concentration in an ensemble containing complexes of only up to this size
            List[List[str]]: calculate concentrations in an ensemble of only these complexes
        as_strands: bool
            Whether initial concentrations are given for each strand or for each complex
        '''
        if complexes is None:
            indices = tuple(self.complexes.keys())
        else:
            if isinstance(complexes, int):
                complexes = complexes_from_maxsize(self.strands, complexes)
            indices = [tuple(self.lookup[s][0] for s in x) for x in complexes]

        if as_strands:
            if len(concentrations) != len(self.strands):
                raise ValueError('strand number %d != concentration number %d' % (len(x0), len(self.strands)))
            x0 = [concentrations[k[0]] if len(k) == 1 else 0 for k in indices]
        else:
            x0 = concentrations

        logq = [self.complexes[k] for k in indices]
        x = complex_concentrations(indices, logq, x0, T=self.temperature)
        return ConcentrationResult(self.strands, indices, x)

################################################################################

class AnalysisResult:
    def __init__(self, model, contents):
        self.model = model
        self.contents = contents

    def items(self):
        return self.contents.items()

    def __getitem__(self, sequences):
        sequences = as_sequences(sequences)
        key = lowest_rotation(sequences)
        return self.contents[key] # .rotation(shift) eventually do rotations

    def update(self, other):
        assert self.model == other.model
        for k, v in other.contents.items():
            self.contents.setdefault(k, {}).update(v)

    def value(self):
        '''If there is only one complex in the ensemble, return its ComplexResult'''
        if len(self.contents) != 1:
            raise ValueError('More than 1 value has been computed')
        return next(iter(self.contents.values()))


    def structure_probability(self, sequences, structure):
        '''
        Return the Boltzmann probability of a given structure.
        Currently distinguishability is assumed everywhere.
        '''
        s = as_sequences(sequences)
        return self.model.boltz(self.model.structure_energy(s, structure) - self[s].free_energy)


    def __str__(self):
        return str(self.contents)

################################################################################

class ComplexResult(NamedTuple):
    free_energy: float = None
    min_free_energy: float = None

    log_partition_function: float = None
    log_structure_count: float = None
    log_stack_count: float = None

    pair_probability: np.ndarray = None
    pair_energy_gap: np.ndarray = None

    mfe_structures: list = None
    suboptimal_structures: list = None
    sampled_structures: list = None

    pf_matrices: dict = None
    mfe_matrices: dict = None

    def __repr__(self):
        return str_repr(self)

    def __str__(self):
        return ', '.join('{}={}'.format(k, v) for k, v in zip(self._fields, self) if v is not None)

################################################################################

class Analysis:
    '''
    The main class for thermodynamic computation in the complex ensemble. Computations
    are scheduled via member functions like `partition_function`, while the
    computations are then performed with `compute()`. Most methods for scheduling
    computation also take a `max_size` parameter. If this is specified as `>0`,
    all complexes of the given strands up to that size will be computed. Otherwise,
    just the complex of the given strands in that order will be computed.
    '''
    default_bits = {'partition_function': [32, 64, -32],
                    'structure_count': [32, 64, -32],
                    'stack_count': [32, 64, -32],
                    'min_free_energy': [32]}

    def __init__(self, model=None):
        '''Initialize analysis for a given free energy model of type nupack.Model'''
        self.model = Model() if model is None else model
        self.tasks = {}

    def add(self, sequences, max_size=0):
        k = as_sequences(sequences)
        for s in complexes_from_maxsize(k, max_size) if max_size else (k,):
            r = lowest_rotation(s)
            yield r, self.tasks.setdefault(r, Task())

    def partition_function(self, sequences, max_size=0, matrices=False):
        '''Schedule computation of complex partition function and free energy'''
        for k, v in self.add(sequences, max_size):
            self.tasks[k] = v._replace(partition_function=True, pf_matrices=v.pf_matrices or matrices)
        return self

    def pair_probability(self, sequences, max_size=0, row_size=0):
        '''Schedule computation of complex equilibrium pair probability'''
        for k, v in self.add(sequences, max_size):
            self.tasks[k] = v._replace(pair_probability=row_size)
        return self

    def min_free_energy(self, sequences, max_size=0, structures=True, matrices=False):
        '''Schedule computation of minimum free energy and, optionally, matching structures'''
        if structures:
            self.suboptimal_structure(sequences, 0, max_size)
        for k, v in self.add(sequences, max_size):
            self.tasks[k] = v._replace(min_free_energy=True, mfe_matrices=v.mfe_matrices or matrices)
        return self

    def suboptimal_structure(self, sequences, gap, max_size=0, stream=None):
        '''Schedule computation of suboptimal structures'''
        for k, v in self.add(sequences, max_size):
            self.tasks[k] = v._replace(suboptimal_structure=(gap if
                v.suboptimal_structure is None else max(v.suboptimal_structure[0], gap), stream))
        return self

    def boltzmann_sample(self, sequences, number, max_size=0):
        '''Schedule computation of structures sampled from Boltzmann distribution'''
        for k, v in self.add(sequences, max_size):
            self.tasks[k] = v._replace(boltzmann_sample=v.boltzmann_sample + number)
        return self

    def structure_count(self, sequences, stacks=False, max_size=0):
        d = {('stack_count' if stacks else 'structure_count'): True}
        for k, v in self.add(sequences, max_size):
            self.tasks[k] = v._replace(**d)
        return self

    def value(self, threads=1, pairing=None, cache_bytes=4e9, dtypes=None):
        '''Short-hand for self.compute(*args, **kwargs).value()'''
        return self.compute(threads, pairing, cache_bytes, dtypes).value()

    def compute(self, threads=1, pairing=None, cache_bytes=4e9, gil=True, dtypes=None):
        '''Compute all scheduled tasks and return a AnalysisResult'''
        mem = int(cache_bytes)

        if dtypes is None:
            bits = self.default_bits
        else:
            bits = self.default_bits.copy()
            bits.update(dtypes)

        kw = dict(env=Local.from_object(threads), pairing=_obs(pairing), observe=None, gil=gil)
        out = {k: {} for k in self.tasks.keys()}

        _compute_pf(self.tasks, out, **kw, **_options('pf', mem, self.model, bits['partition_function']))
        _compute_mfe(self.tasks, out, **kw, **_options('mfe', mem, self.model, bits['min_free_energy']))
        _compute_count(self.tasks, out, **kw, **_options('pf', mem, self.model, bits['structure_count'], Ensemble.nostacking, count=True))
        _compute_stacks(self.tasks, out, **kw, **_options('pf', mem, self.model, bits['stack_count'], Ensemble.stacking, count=True))

        for o in out.values():
            if 'log_partition_function' in o:
                o['free_energy'] = -o['log_partition_function'] / self.model.beta

        return AnalysisResult(self.model, {k: ComplexResult(**v) for k, v in out.items()}) # maybe return caches too if requested

################################################################################

class Task(NamedTuple):
    '''Inputs for thermodynamic calculations for a given complex'''

    partition_function: bool = False
    min_free_energy: int = None
    structure_count: int = None
    stack_count: int = None

    pair_probability: int = None
    pair_energy_gap: int = None

    boltzmann_sample: int = 0
    uniform_sample: int = None
    suboptimal_structure: float = None

    pf_matrices: bool = False
    mfe_matrices: int = None

################################################################################

def _call(fun, strands, **kws):
    try:
        return fun(strands=strands, **kws)
    except RuntimeError:
        raise RuntimeError('Function {} failed for strands {} and options {}'.format(fun, strands, kws))

################################################################################

def _options(kind, mem, model, bits, ensemble=None, count=False):
    if ensemble is not None:
        model = model.copy()
        model.ensemble = ensemble
    models = [CachedModel(model=model, kind=kind, bits=abs(b)) for b in bits]
    if count:
        for m in models:
            m.set_beta(0)
    return dict(cache=Cache(mem, model.ensemble, 3, bits) if mem else False, models=models)

def _compute_pf(tasks, output, **kws):
    for k, v in tasks.items():
        o = output[k]
        if v.boltzmann_sample:
            nicks = np.cumsum(list(map(len, k)))
            strucs, pf, n = _call(sample, k, n=v.boltzmann_sample, workers=1, **kws)
            o['log_partition_function'], o['sampled_structures'] = pf, [Structure(s, nicks) for s in strucs]
        if v.pair_probability is not None:
            P, o['log_partition_function'] = _call(pair_probability, k, **kws)
            o['pair_probability'] = SparsePairMatrix(P, v.pair_probability) if v.pair_probability else P
        elif v.pf_matrices:
            o['log_partition_function'], o['pf_matrices'] = _call(block, k, **kws)
        elif v.partition_function:
            o['log_partition_function'] = _call(dynamic_program, k, **kws)

def _compute_mfe(tasks, output, **kws):
    for k, v in tasks.items():
        o = output[k]
        if v.suboptimal_structure is not None:
            if v.suboptimal_structure[1]:
                o['min_free_energy'] = _call(subopt_stream, k, gap=v.suboptimal_structure[0], callback=v.suboptimal_structure[1], **kws)
            else:
                strucs = _call(subopt, k, gap=v.suboptimal_structure[0], **kws)
                nicks = np.cumsum(list(map(len, k)))
                strucs = o['suboptimal_structures'] = sorted(((Structure(s, nicks), f) for s, f in strucs), key=lambda p: p[1])
                mfe = o['min_free_energy'] = strucs[0][1] if strucs else np.inf
                o['mfe_structures'] = [(s, f) for s, f in strucs if f < mfe + 1e-4]
        elif v.pair_energy_gap:
            o['pair_energy_gap'], o['min_free_energy'] = _call(pair_probability, k, **kws)
        elif v.mfe_matrices:
            o['min_free_energy'], o['mfe_matrices'] = _call(block, k, **kws)
        elif v.min_free_energy:
            o['min_free_energy'] = _call(dynamic_program, k, **kws)

def _compute_count(tasks, output, **kws):
    for k, v in tasks.items():
        o = output[k]
        if v.uniform_sample:
            nicks = np.cumsum(list(map(len, k)))
            o['uniform_sample'] = [Structure(s, nicks) for s in _call(sample, k, n=v.uniform_sample, workers=1, **kws)]
        if v.structure_count:
            o['log_structure_count'] = _call(dynamic_program, strands=k, **kws)

def _compute_stacks(tasks, output, **kws):
    for k, v in tasks.items():
        o = output[k]
        if v.stack_count:
            o['log_stack_count'] = _call(dynamic_program, k, **kws)

################################################################################

@forward
class ComplexSampler:
    def __init__(self, sequences, logq, scale):
        pass

    def __call__(self, engine, n, env=1, _fun_=None):
        '''Return n samples from different sets of complexes as PairLists'''
        return _fun_(self, Local.from_object(env), engine, int(n))

################################################################################

@forward
class CachedModel:
    energy_model: Model
    distinguishable: bool

    def __init__(self, model=None, distinguishable=False, kind='pf', bits=None, _fun_=None):
        pf = dict(pf=True, mfe=False, count=True)[kind]
        if bits is None:
            bits = (64 if pf else 32) if model is None else model.bits

        if model is None:
            model = Model(bits)

        _fun_(self, model, return_type=match(
            k for k, v in self._metadata_.items() if v.cast(Tuple[int, bool]) == (bits, pf)))

        self.distinguishable = bool(distinguishable)

        if kind == 'count':
            self.set_beta(0)

    def set_beta(self, beta) -> None:
        '''Set the inverse temperature'''

    def capacity(self) -> int:
        '''Return maximum length of sequence that can be calculated without cache refresh'''

################################################################################

@forward
class Cache(LRU):
    def __init__(self, nbytes, ensemble, complexity=3, types=(64,), _fun_=None):
        ensemble = Ensemble.get(ensemble)
        if ensemble == Ensemble.none: # uses same recursions as nostacking
            ensemble = Ensemble.nostacking
        key = (int(complexity), int(ensemble), *types)
        _fun_(self, int(nbytes), return_type=match(
            k for k, v in self._metadata_.items() if v.cast(object) == key))

################################################################################

@forward
class XTensor:
    slices: Tuple[Tuple[np.ndarray, ...], ...]

################################################################################

@forward
class PairingAction:
    def __init__(self, function=None, _fun_=None):
        _fun_(self) if function is None else _fun_(self, function)

################################################################################

@forward
class Message:
    result: float
    sequences: Tuple[str, ...]

################################################################################

def _obs(fun=None):
    return fun if isinstance(fun, PairingAction) else PairingAction(fun)

################################################################################

@forward
def dynamic_program(env, strands, models, cache, observe: Callable[[Message], None], pairing) -> float:
    '''Low-level dynamic program call expecting all arguments to be specified'''

@forward
def block(env, strands, models, cache, observe: Callable[[Message], None], pairing, _fun_):
    '''Low-level dynamic program call expecting all arguments to be specified'''
    out = _fun_(env, as_sequences(strands), models, cache, observe, pairing)
    result = out[0].cast(float)
    names = out[1].cast(List[str])
    values = [v if isinstance(v, XTensor) else v.cast(np.ndarray) for v in out[2:]]
    return result, dict(zip(names, values))

@forward
def subopt(env, gap, strands, models, cache, observe: Callable[[Message], None], pairing, print_segments=False) -> List[Tuple[PairList, float]]:
    '''Low-level dynamic program call expecting all arguments to be specified'''

@forward
def subopt_stream(env, gap, strands, models, cache, callback: Callable[[Tuple[PairList, float]], bool] , observe: Callable[[Message], None], pairing) -> float:
    '''Low-level dynamic program call expecting all arguments to be specified'''

@forward
def sample(env, n, workers, strands, models, cache, observe: Callable[[Message], None], pairing) -> Tuple[List[PairList], float, int]:
    '''Low-level dynamic program call expecting all arguments to be specified'''

@forward
def pair_probability(env, strands, models, cache, observe: Callable[[Message], None], pairing) -> Tuple[np.ndarray, float]:
    '''Low-level dynamic program call expecting all arguments to be specified'''

@forward
def permutations(env, max_size, strands, models, cache, observe: Callable[[Message], None], pairing) -> List[Tuple[NickSequence, float]]:
    '''Low-level dynamic program call expecting all arguments to be specified'''

################################################################################
