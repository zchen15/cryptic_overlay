from scipy.linalg import pinv, eigh, inv
from scipy.sparse.linalg import spsolve
from scipy.sparse import vstack as spvstack
import numpy as np, logging
from .rebind import forward, Tuple

log = logging.getLogger(__name__)

##########################################################################

@forward
class RandomWalker:
    def __init__(self, R):
        '''Initialize from rate matrix'''

    def path(self, start, max_time) -> Tuple[np.ndarray, np.ndarray]:
        '''Return path of timesteps and states'''

##########################################################################

def window_sums(x, n):
    '''Return sum of observable in windows of length n'''
    cum = np.cumsum(x, 0)
    return cum[n:] - cum[:-n]

def window_cross_sums(X, n):
    '''Return sum of observable in windows of length n'''
    S = window_sums(X, n)
    G = np.cumsum(X, 0)
    SG = window_sums(X[:, :, None] * G[:, None, :], n)
    return S[:, :, None] @ G[n:, None, :] - SG

def make_positive(A):
    '''Make a matrix have positive eigenvalues by changing negative ones to 0'''
    e, V = np.linalg.eigh(A)
    return (V * np.maximum(0, e)) @ V.T

##########################################################################

def truncated_gf_estimate(X, tau: int):
    '''
    X: the series of observed values (time, function)
    tau: the truncation window length as #timesteps
    returns:
        G: estimated gamma
        mu: stationary function probabilities
        G1: projected G1 term
        G2: projected G2 term
    multiply time terms by length of timestep to get proper units
    it's a tiny bit off (probably off by 1)
    '''
    X = np.asarray(X)
    assert tau == int(tau)
    assert 2 * tau <= len(X)
    log.info({'tau': tau, 'shape': X.shape})
    mu = np.mean(X, axis=0)
    X = X - mu

    S0 = window_cross_sums(X, tau)
    G1 = S0.sum(0) / len(S0)

    S = window_sums(X, tau)
    G2 = (S[:-tau].T @ S[tau:]) / len(S)

    proj = np.eye(len(mu), dtype=mu.dtype)
    # proj -= np.outer(mu, mu) / np.dot(mu, mu)

    G1 = proj @ (G1+G1.T) @ proj / 2
    G2 = proj @ (G2+G2.T) @ proj / 2

    G = G1 @ (np.linalg.pinv(G1 - G2)) @ G1
    dump = lambda x: np.sort(x / np.std(x))[::-1]
    log.info({'G1 eigvals': dump(np.linalg.eigh(G1)[0])})
    log.info({'G eigvals': dump(np.linalg.eigh(G)[0])})

    G = proj @ G @ proj
    return G, mu, G1, G2

##########################################################################

def pi_inverse(A, pi):
    scale = 1 / avg_trace(A)
    A = A * scale
    if not hasattr(A, 'todense'):
        return scale * (inv(A + pi) - pi)
    return A, pi
    return spvstack([A, pi]), np.eye(len(pi)+1, len(pi))
    return scale * spsolve(spvstack([A, pi]), np.eye(len(pi)+1, len(pi)))

##########################################################################

def symmetrized(A):
    return 0.5 * (A + A.T)

##########################################################################

def avg_trace(A):
    return np.mean(A.diagonal())

##########################################################################

def projected_G(G, mu):
    scale = abs(avg_trace(G))
    G = G / scale
    iG = pinv(G)
    pi = mu * (iG @ mu) # vector
    eta = pi.sum()   # scalar
    pi /= eta
    Proj = np.eye(len(G)) - iG @ np.outer(mu, mu) / eta
    pG = scale * Proj.T @ G @ Proj
    #gpi = iG @ mu / eta
    return pi, pG

##########################################################################

def S_from_G(G, mu):
    """S from Gamma"""
    scales = np.diag(1 / mu)
    return scales @ G @ scales

##########################################################################

def sample_hit(x, y):
    return x.run(FirstCollision(y.pairs), observers=[Timer()])[-1].time

def sample_hits(x, y, threads=None):
    Hs = np.zeros([len(bcs), len(bcs)])
    Hp = np.zeros([len(bcs), len(bcs)])

    for i in range(len(bcs)):
        for j in range(len(bcs)):
            if i != j:
                run = lambda _: sample_hit(bstates[bcs[i]], bstates[bcs[j]])
                data = np.asarray(thread_map(48, run, threads=threads))
                Hs[i, j] = data.mean()
                Hp[i, j] = data.std() * len(data)**-0.5
    return Hs, Hp

##########################################################################

def S_from_R(R, pi, decay=0):
    scale = abs(avg_trace(R))
    R = R / scale
    if decay == 0:
        S = inv(np.outer(pi, pi) - np.diag(pi) @ R) - 1
        # R = np.outer(1, pi) - np.diag(1/pi) inv(S+1)
    else:
        decay = decay / scale
        S = inv(decay * np.diag(pi) - np.diag(pi) @ R) - 1/decay
    return S / scale

##########################################################################

def H_from_S(S):
    return np.diagonal(S) - S

##########################################################################

def first_order_G(G, mu, Gradient, scale):
    """Correction of Gamma by gradient"""
    return G @ pinv(G + scale * Gradient) @ G

##########################################################################

def reduce_G(G, mu):
    scale = abs(avg_trace(G))
    G = G / scale
    iG = pinv(G)
    pi, pG = projected_G(G, mu)[:2]

    S = S_from_G(pG, mu)
    H = H_from_S(S)
    R = -pi_inverse(S @ np.diag(pi), pi)
    return pG*scale, H*scale, R/scale, S*scale, pi
