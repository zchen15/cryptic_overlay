#pragma once

#include "Observables.h"

#include "../algorithms/Operators.h"
#include "../iteration/Transform.h"
#include "../types/Heap.h"
#include "../types/IO.h"

namespace nupack { namespace kmc {

/******************************************************************************************/

struct MfeComparator {
    template <class State>
    bool operator() (State const &w1, State const &w2) const {
        return std::tie(w1.energy, w1.pairs) < std::tie(w2.energy, w2.pairs);
        // creates a tuple of two states energy & pairs and compares them
    };
};

/******************************************************************************************/

template <class W>
struct MfeInterval {
    using State = W;
    vec<State> states;

    NUPACK_REFLECT(MfeInterval, states);

    void merge(MfeInterval const &i) {
        if (MfeComparator()(i.states[0], states[0])) states[0] = i.states[0];
        // fix for n > 1
    }
    auto get(mfe_state) const {return *min_element(states, MfeComparator());}
};

template <class W>
void render(Document &doc, Type<MfeInterval<W>> t)  {
    doc.type(t, "kmc.MfeInterval");
    render_public(doc, t);
};

template <class W, class V>
MfeInterval<W> join_intervals(MfeInterval<W> *, V const &v) {
    // This keeps track of the lowest energystates that have been seen in an interval
    MfeInterval<W> r;
    r.states.reserve(sum(v, [](auto const &i) {return len(i.states);}));
    for (auto const &i : v) cat(r.states, i.states);
    r.states = take_lowest(std::move(r.states), len(front(v).states), MfeComparator());
    return r;
}

/******************************************************************************************/

template <class W>
struct MfeRecorder {
    using State = W;
    using Interval = MfeInterval<State>;
    MaxSizeHeap<State, vec, MfeComparator> states;

    NUPACK_REFLECT(MfeRecorder, states);

    MfeRecorder(usize m=1) : states(m) {};

    auto size() {return len(states);}
    void operator() (State const &w, real) {states.emplace_if(w);};

    Interval next() {return {states.sorted()};}
};

/******************************************************************************************/

}}
