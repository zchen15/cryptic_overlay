#pragma once
#include <fstream>
#include "../algorithms/Operators.h"
#include "../iteration/Transform.h"
#include "../standard/Deque.h"
#include "../types/PairList.h"
#include "../types/Sequence.h"

namespace nupack { namespace kmc {

/******************************************************************************************/

struct Logger {
    NUPACK_REFLECT(Logger, dps, seqs);

    deque<string> dps, seqs;

    template <class State>
    void operator() (State const &w, real) {
        dps.emplace_back(w.dp()); seqs.emplace_back(w.sequence());
    };

    friend Logger reduce(Logger const &t1, Logger const &t2) {
        Logger ret = t1;
        extend(ret.dps, t2.dps);
        extend(ret.seqs, t2.seqs);
        return ret;
    }
};

/******************************************************************************************/

struct MoveRecorder {
    struct Step {
        real time, energy;
        Base_Pair bp;
    };
    deque<Step> steps;

    template <class State>
    void operator()(State const &w, real t) {
        steps.emplace_back(t, w.energy, w.last_move.bp);
    }
};

/******************************************************************************************/

struct AverageEnergyIntegrator {
    NUPACK_REFLECT(AverageEnergyIntegrator, e_sum, t_sum);

    real e_sum, t_sum;

    AverageEnergyIntegrator() : e_sum(0), t_sum(0) {};

    template <class W>
    void operator() (W const &w, real t) {
        e_sum += t * w.energy;
        t_sum += t;
    };

    friend AverageEnergyIntegrator reduce(AverageEnergyIntegrator const &t1, AverageEnergyIntegrator const &t2) {
        AverageEnergyIntegrator ret = t2;
        ret.e_sum += t1.e_sum; ret.t_sum += t1.t_sum;
        return ret;
    }

    real result() const {return e_sum / t_sum;}
};

/******************************************************************************************/

struct MovieMaker {
    NUPACK_REFLECT(MovieMaker, time, step, freq, filename, ofs);

    real time;
    usize step, freq;
    string filename;
    std::ofstream ofs;

    MovieMaker(string const &fn, usize f=1) : time(0), ofs(fn), filename(fn), freq(f), step(0) {};

    MovieMaker(MovieMaker const &m) :
        time(m.time), step(m.step), filename(m.filename), ofs(filename) {};

    template <class W>
    void operator() (W const &w, real t) {
        time += t; if(!(++step % freq)) write(w);
    }

    template <class W>
    void write(W const &w) {
        ofs << w.sequence() << " " << w.dp() << " " << time << std::endl;
    }
};

/******************************************************************************************/

struct FirstCollision {
    PairList structure;
    usize threshold;
    NUPACK_REFLECT(FirstCollision, structure, threshold);

    FirstCollision(PairList p={}, usize t=0) : structure(std::move(p)), threshold(t) {}

    bool operator()(PairList const &p) const {
        return threshold ? (structure ^ p) <= threshold : structure == p;
    }

    template <class W> bool operator()(W const &w, real) const {return (*this)(w.pairs);}
};

void render(Document &doc, Type<FirstCollision>);

/******************************************************************************************/

}}
