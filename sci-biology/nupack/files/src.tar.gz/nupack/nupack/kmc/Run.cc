#include "LocalTime.h"
#include "Stopwatch.h"
#include "Timer.h"
#include "Basics.h"
#include "JoinPropensity.h"
#include "FreeEnergy.h"
#include "../jump/Path.h"

namespace nupack::kmc {

/******************************************************************************************/

void render(Document &doc, Type<BasePairPath> t) {
    doc.type(t, "path.BasePairPath");
    render_public(doc, t);
}

void render(Document &doc, Type<Path> t) {
    doc.type(t, "path.Path");
    render_public(doc, t);
    doc.method(t, "base_pair_time", &base_pair_time);
    doc.method(t, "structure_time", &structure_time);

    doc.function("path.sample_path", [](JumpState<> w, real time) {
        Path p;
        p.start = State(w.sys, w.pairs);
        augment_path(w, p, Timer::with_max_time(time));
        p.stop = State(w.sys, w.pairs);
        return p;
    });
}

/******************************************************************************************/

Mat<real> structure_time(Path const &path, vec<PairList> const &structures, uint power, bool relative) {
    auto p = path.start.pairs;
    for (auto const &s : structures)
        NUPACK_REQUIRE(len(p), ==, len(s), "Inconsistent structure length");
    Mat<real> A(power+1, len(structures), la::fill::zeros);

    real t0 = 0;
    for (auto const [dt, b, c] : path.steps) {
        izip(structures, [&,dt=dt](auto i, auto const &s) {
            if (p == s) {
                A(0, i) += dt;
                auto t1 = t0 + dt, p0 = t0, p1 = t1;
                for (auto p : range(power)) {
                    p0 *= t0;
                    p1 *= t1;
                    A(p+1, i) += p1 - p0;
                }
            }
        });
        p.toggle_pair(b, c);
        t0 += dt;
    }
    for (auto n : range(1, A.n_rows)) A.row(n) *= 1.0 / (n + 1);
    if (relative) A /= path.time;
    return A;
}

/******************************************************************************************/

template <class F>
real observe_base_pairs(Path const &p, F &&f) {
    // Running total time
    real time = 0;
    // Pair vector
    auto pairs = p.start.pairs.contents;
    // Map of null-base indices to no-null-base indices
    auto const map = make_pairs_map(p.start);
    // Last time a base index had its pairing modified
    vec<real> last(len(pairs), 0);

    for (auto const [t, b, c] : p.steps) {
        time += t;

        // Those indices without null bases
        auto const m1 = map[b], m2 = map[c];

        if (pairs[b] == b && pairs[c] == c) { // Base pair addition
            f(m1, m1, last[b], time);
            f(m2, m2, last[c], time);
            pairs[b] = c; pairs[c] = b;
        } else if (pairs[b] == c && pairs[c] == b) { // Base pair deletion
            f(m1, m2, last[b], time);
            f(m2, m1, last[c], time);
            pairs[b] = b; pairs[c] = c;
        } else NUPACK_BUG("Invalid base pair move", b, c, pairs[b], pairs[c]);

        // Set the last modified time
        last[b] = time; last[c] = time;
    }

    for (auto i : indices(pairs)) if (map[i] != -1) // For all non-null bases
        f(map[pairs[i]], map[i], last[pairs[i]], time);
    return time;
}

/******************************************************************************************/

Cube<real> base_pair_time(Path const &p, uint power, bool relative) {
    Cube<real> A(power + 1, p.start.n_bases(), p.start.n_bases(), la::fill::zeros);

    real time = observe_base_pairs(p, [&A, power](auto i, auto j, auto t0, auto t1) {
        A.at(0, i, j) += t1 - t0;
        auto p0 = t0, p1 = t1;
        for (auto p : range(power)) {
            p0 *= t0;
            p1 *= t1;
            A.at(p+1, i, j) += p1 - p0;
        }
    });

    for (auto n : range(1, A.n_rows)) A.row(n) *= 1.0 / (n + 1);

    if (relative && time) A *= 1/time;

    return A;
}

/******************************************************************************************/

void HammingObserver::update(Col<real> &distances) const {
    auto const n = len(structures);
    real const z = 2.0 / len(front(structures)); // to normalize so distances are between -1 and 1

    izip(structures, [&](auto i, auto const &s) {
        legendres(2, order, distances(i), [&](auto m, auto t) {distances((m - 1) * n + i) = t;});
    });

    izip(deltas, [&](auto i, auto j) {
        distances(order * n + i) = (distances(j) + 1 < z * (threshold + 1e-6));
    });
}

Col<real> HammingObserver::calculate(PairList const &pairs) const {
    real const z = 2.0 / len(pairs); // to normalize so distances are between -1 and 1

    Col<real> ret(order * len(structures) + len(deltas));
    izip(structures, [&](auto i, auto const &s) {ret(i) = z * (pairs ^ s) - 1;});
    update(ret);
    return ret;
}

void HammingObserver::operator()(PairList const &pairs, usize b, usize c) {
    if (distances.empty()) {distances = calculate(pairs); return;}

    real const a = real(pairs[b] == c ? 2 : -2) / len(pairs); // positive if base pair formed

    izip(structures, [&](auto i, auto const &s) {
        if (s[b] == c) distances(i) -= 2 * a; // structure has that pair
        else distances(i) += a * (s[c] == c) + a * (s[b] == b);
    });
    update(distances);
}

/******************************************************************************************/

void KilledIntegrator::integrate(Col<real> const &f, real dt, bool cross) {
    real const s = sample_time, t = time, a = scale, x=exp(-dt * scale);
    Col<real> lhs = dt * f;
    times += lhs;
    la::add_outer(overlap, lhs, f);

    if (x + 1.e-10 > 1) { // use Taylor expansion if dt is very small
        if (cross) {
            lhs = dt * scale_grad;
            la::add_outer(gradient, lhs, f);
            lhs = dt * scale_times - 0.5 * dt * dt * f;
            la::add_outer(gamma, lhs, f);
        }

        scale_grad += scale_times * -dt;
        scale_grad *= x;
        scale_times *= x;
        scale_times += dt * f;
    } else {
        auto const u = (1 - x) / a; // (time**1) area under exp(-a t) dt
        auto const du = (dt * x - u) / a; // (time**2) derivative of that area

        if (cross) {
            auto const h = (dt - u) / a; // (time**2)
            auto const dh = -(2 * du + u * dt) / a; // (time**3)
            lhs = u * scale_grad + du * scale_times + dh * f;
            la::add_outer(gradient, lhs, f); // (time**3)
            lhs = u * scale_times + h * f;
            la::add_outer(gamma, lhs, f); // (time**2): add in new step
        }

        scale_grad += scale_times * -dt;
        scale_grad *= x;
        scale_grad += du * f;
        scale_times *= x;
        scale_times += u * f;
    }
    auto const eat = exp(-a * t), east = exp(a * (s - t));
    /// Integrate[ Exp[-a (t1 - t0)], {t1, t - s, t}, {t0, 0, t1}]
    pi_time  = (eat - east + s * a) / sq(a);
    /// D[%, a]
    dpi_time = (east * (2 + a * (t - s)) - 2 * eat - a * (s + eat * t)) / cube(a);
}

void KilledIntegrator::operator()(Col<real> const &f, real dt) {
    if (unlikely(time == 0)) {
        auto const n = len(f);
        gamma = gradient = overlap = la::zeros<Mat<real>>(n, n);
        times = scale_times = scale_grad = current_times = la::zeros<Col<real>>(n);
    }

    bool const cross = time >= warmup;
    time += dt;
    if (cross) sample_time += dt;

    if (period == 0) {
        integrate(f, dt, cross);
    } else {
        current_time += dt;
        current_times += dt * f;

        if (time > next_time) {
            integrate(current_times / current_time, current_time, cross);
            next_time = time + period;
            current_time = 0;
            current_times.zeros();
        }
    }
}

// sym(Gamma) / sample_time - outer(times/time, times/time) /scale
Mat<real> KilledIntegrator::average_gamma() const {
    Mat<real> G = (gamma + gamma.t()) / (-2 * sample_time);
    Col<real> mu_s = times * (sqrt(pi_time/sample_time) / time); // sqrt will be squared by outer()
    la::add_outer(G, mu_s, mu_s);
    return -std::move(G);
}

/// Same as gamma except for minus sign and another factor of 1/scale on the mean subtraction
// -sym(Grad) / sample_time - outer(times/time, times/time) /scale**2
Mat<real> KilledIntegrator::average_gradient() const {
    Mat<real> G = (gradient + gradient.t()) / (2 * sample_time);
    Col<real> mu_s = times * (sqrt(-dpi_time/sample_time) / time); // sqrt will be squared by outer()
    la::add_outer(G, mu_s, mu_s);
    return -std::move(G);
}

/******************************************************************************************/

// \int_{s=0}^{T-\Delta} \int_{t=s}^{T} F^T(X_s) F(X_t)
void StoppedIntegrator::operator()(Col<real> const &values, real dt) {

}

/******************************************************************************************/

void HittingTimeObserver::operator()(PairList const &p, real dt) {
    auto it = binary_search(structures, p);
    if (it != end_of(structures) && *it == p) {
        auto j = it - begin_of(structures);
        samples.col(j) += last_numbers.col(j) * time - last_times.col(j); // H(i -> j)AnnotatedCallback
        numbers.col(j) += last_numbers.col(j);                     // #(i -> j)
        last_numbers.col(j).zeros();   // everybody reached j now so clear them
        last_times.col(j).zeros();
        last_numbers.row(j) += 1;  // somebody new wants to reach each state
        last_times.row(j) += time;
    }
    time += dt;
}

/******************************************************************************************/

void render(Document &doc, Type<Stopwatch> t) {
    doc.type(t, "kmc.Stopwatch");
    render_public(doc, t);
    doc.method(t, "new", rebind::construct<int, real>(t));
    doc.method(t, "seconds", &Stopwatch::seconds);
    doc.method(t, "()", &Stopwatch::operator());
}


void render(Document &doc, Type<Timer> t) {
    using T = Timer;
    doc.type(t, "kmc.Timer");
    render_public(doc, t);
    doc.method(t, "new", rebind::construct<int, real>(t));
    doc.method(t, "()", &T::operator());
}

/******************************************************************************************/

void render(Document &doc, Type<FirstCollision> t) {
    using T = FirstCollision;
    doc.type(t, "kmc.FirstCollision");
    render_public(doc, t);
    doc.method(t, "new", rebind::construct<PairList, usize>(t));
    doc.method(t, "()", call_operator<T const, PairList const &>());
}

/******************************************************************************************/

void render(Document &doc, Type<JoinPropensityIntegrator> t) {
    doc.type(t, "kmc.JoinPropensityIntegrator");
    render_public(doc, t);
};

/******************************************************************************************/

void render(Document &doc, Type<HittingTimeObserver> t) {
    using T = HittingTimeObserver;
    doc.type(t, "kmc.HittingTimeObserver");
    doc.method(t, "new", rebind::construct<vec<PairList>>(t));
    doc.method(t, "result", &T::result);
}

/******************************************************************************************/

void render(Document &doc, Type<TimeInterval> t) {
    doc.type(t, "kmc.TimeInterval");
    render_public(doc, t);
}

/******************************************************************************************/

void render(Document &doc, Type<FreeEnergyInterval> t) {
    doc.type(t, "kmc.FreeEnergyInterval");
    render_public(doc, t);
}

/******************************************************************************************/

void render(Document &doc, Type<KilledIntegrator> t) {
    using T = KilledIntegrator;
    doc.type(t, "kmc.KilledIntegrator");
    doc.method(t, "add", &T::add);
    doc.method(t, "average_gamma", &T::average_gamma);
    doc.method(t, "average_gradient", &T::average_gradient);
    doc.method(t, "average_occupation", &T::average_occupation);
    doc.method(t, "average_overlap", &T::average_overlap);
}


}
