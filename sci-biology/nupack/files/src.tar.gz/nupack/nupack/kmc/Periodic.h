#pragma once

namespace nupack { namespace kmc {

/******************************************************************************************/

template <class Timer, class F>
struct Periodic {
    F function;
    Timer timer;

    template <class ...Ts>
    Periodic(F f, Ts &&...ts) : timer(fw<Ts>(ts)...), function(f) {}

    template <class State>
    auto operator()(State const &w, real t) {
        if (timer(w, t)) {timer.reset(); return function(w, t);}
    }
};

/******************************************************************************************/

}}
