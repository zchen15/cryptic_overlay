#pragma once

#include "Pairing.h"
#include "../types/Sequence.h"
#include "../types/Matrix.h"
#include "../standard/Map.h"
#include "../types/PairList.h"

namespace nupack { namespace kmc {

/******************************************************************************************/

template <bool Ordered, class T>
struct StructureCounter : ConstIterable<StructureCounter<Ordered, T>> {
    using hash_type = RangeHash<PairList>;
    using map_type = if_t<Ordered, std::map<PairList, T>, std::unordered_map<PairList, T, hash_type>>;

    map_type structures;
    NUPACK_REFLECT(StructureCounter, structures);

    template <class W>
    auto & put(W const &w) {return structures.emplace(w.pairs, T{}).first->second;}

    void emplace(PairList pairs) {structures.emplace(std::move(pairs), T{});}

    auto const & iter() const {return structures;}
    auto keys() const {return vmap(structures, first_of);}
    auto values() const {return vmap(structures, second_of);}
};

NUPACK_DEFINE_TEMPLATE(is_structure_counter, StructureCounter, bool, class);

/******************************************************************************************/

struct EnumeratedObserver {
    vec<PairList> structures;
    Mat<real> basis; // (# functions, # states)

    EnumeratedObserver(vec<PairList> s={}, Mat<real> b={}) : structures(std::move(s)), basis(std::move(b)) {}

    NUPACK_REFLECT(EnumeratedObserver, structures, basis);

    template <class W> Col<real> operator()(W const &w, real) const {
        return basis.unsafe_col(binary_search_index(structures, w.pairs));
    }
};

NUPACK_DEFINE_TYPE(isEnumeratedObserver, EnumeratedObserver);

template <class T, NUPACK_IF(traits::isEnumeratedObserver<T>)>
void render(Document &doc, Type<T> t) {
    doc.type(t, "kmc.EnumeratedObserver");
    doc.method(t, "new", rebind::construct<vec<PairList>, Mat<real>>(t));
};

/******************************************************************************************/

struct HittingTimeObserver {
    Mat<real> samples, last_times, last_numbers, numbers;
    vec<PairList> structures;
    real time=0;

    NUPACK_REFLECT(HittingTimeObserver, samples, last_times, numbers, last_numbers, structures, time);

    HittingTimeObserver() = default;
    HittingTimeObserver(vec<PairList> s) : samples(la::zeros<Mat<real>>(len(s), len(s))), last_times(samples),
        numbers(samples), last_numbers(samples), structures(std::move(s)) {sort(structures);}

    void operator()(PairList const &, real dt);

    auto result() const {
        auto avg = samples;
        for (auto i : indices(structures)) for (auto j : indices(structures))
            avg(i, j) /= max(1, numbers(i, j));
        return avg;
    }

    template <class W>
    void operator()(W const &w, real dt) {(*this)(w.pairs, dt);}
};

void render(Document &doc, Type<HittingTimeObserver>);

/******************************************************************************************/

struct sequence_set_reference {
    struct hasher {
        template <class K> usize operator()(K const &k) const {
            usize seed = 0;
            for (auto const &s : k) {
                boost::hash_combine(seed, &(*s.begin()));
                boost::hash_combine(seed, &(*s.end()));
            };
            return seed;
        };
    };

    struct equals {
        template <class K> bool operator() (K const &d1, K const &d2) const {return is(d1, d2);};
    };
};

struct sequence_set_value {
    struct hasher {
        template <class K> usize operator()(K const &k) const {
            usize seed = 0;
            for (auto const &s : k) for (auto const &b : s) boost::hash_combine(seed, b);
            return seed;
        };
    };

    struct equals {
        template <class K> bool operator() (K const &d1, K const &d2) const {return d1 == d2;};
    };
};

/******************************************************************************************/

template <class LD, class C=sequence_set_reference>
struct sequence_set_counter : ConstIterable<sequence_set_counter<LD, C>> {
    std::unordered_map<LD, usize, typename C::hasher, typename C::equals> counts;
    usize sum=0;
    NUPACK_REFLECT(sequence_set_counter, counts, sum);

    auto & iter() {return counts;}

    template <class W> void operator() (W const &w, real) {
        sum += len(w.loops);
        for (auto const &o : w.loops) update(o.seqs);
    }

    void update(LD const &o, usize n=1) {counts.emplace(o, 0).first->second += n;}

    void update(sequence_set_counter const &other) {
        sum += other.sum;
        for (auto const &o : other.counts) update(o.first, o.second);
    }

    friend sequence_set_counter reduce(sequence_set_counter const &t1, sequence_set_counter const &t2) {
        sequence_set_counter ret = t1; ret.update(t2); return ret;
    }
};

/******************************************************************************************/

struct sequence_hasher {
    template <class V> std::size_t operator()(V const &v) const {
        std::size_t seed = 0;
        for (auto const &s : v) {
            boost::hash_combine(seed, &(*s.begin()));
            boost::hash_combine(seed, &(*s.end()));
        };
        return seed;
    };
};

/******************************************************************************************/

struct sequence_counter {
    std::unordered_map<SubsequenceList, usize, sequence_hasher> counts;
    usize sum=0;

    template <class W> void operator() (W const &w, real) {
        sum += len(w.loops);
        for (auto const &o : w.loops) update(o.seqs.vec());
    }

    void update(SubsequenceList const &s, usize n=1) {counts.emplace(s, 0).first->second += n;}

    void update(sequence_counter const &other) {
        sum += other.sum;
        for (auto const &s : other.counts) update(s.first, s.second);
    }

    auto size() const {return len(counts);}

    friend sequence_counter reduce(sequence_counter const &t1, sequence_counter const &t2) {
        sequence_counter ret = t1; ret.update(t2); return ret;
    }

    template <class A>
    void serialize(A &a, const unsigned int){a & counts; a & sum;}
};

/******************************************************************************************/

}}
