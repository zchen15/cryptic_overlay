#pragma once
#include "../state/ComplexSet.h"
#include "../iteration/Transform.h"
#include "../standard/Map.h"

namespace nupack::kmc {

/******************************************************************************************/

struct ComplexCounter {
    using Key = vec<ComplexSet::Indices>;
    using It = std::map<Key, real>::iterator;

    Map<std::pair<Key, Key>, usize> transitions;
    Map<Key, real> populations;
    It current;
    real time;

    NUPACK_REFLECT(ComplexCounter, time, transitions, populations, current);

    ComplexCounter() : time(0) {};

    template <class W>
    void operator() (W const &w, real t) {
        // Reorder complex indices to avoid redundancy
        Key k = w.complexes.complex_indices;
        for (auto & x : k) rotate_min(x); rotate_min(k);
        // Put the indices in the map and get out their iterator
        auto next = populations.emplace(std::move(k), 0).first;
        // Record a transition if necessary
        if (len(populations) > 1 && current != next) {
            transitions.emplace(std::make_pair(current->first, next->first), 0).first->second += 1;
        }
        // Add the sampled time to that population element
        current = next;
        current->second += t;
        time += t;
    };
};

inline ComplexCounter reduce(ComplexCounter const &c1, ComplexCounter const &c2) {
    ComplexCounter ret = c2;
    ret.time += c1.time;
    for (auto const &p : c1.populations)
        ret.populations.emplace(p.first, 0.0).first->second += p.second;
    for (auto const &t : c1.transitions)
        ret.transitions.emplace(t.first, 0).first->second += t.second;
    return ret;
}

/******************************************************************************************/

}
