#pragma once
#include "../common/Runtime.h"

namespace nupack { namespace kmc {

/******************************************************************************************/

/// class providing a Stopwatch like observer which may be used limit trajectories' walltime
struct Stopwatch {
    struct interval {
        using clock = std::chrono::high_resolution_clock;
        std::chrono::time_point<clock> begin_time, end_time;
    };

    using Duration = std::chrono::duration<real>;
    using clock = std::chrono::high_resolution_clock;

    std::chrono::time_point<clock> initial_time, current_time;
    real max_time;
    bool running = false;
    int skip, counter = 0;

    NUPACK_REFLECT(Stopwatch, initial_time, current_time, running, skip, counter);

    Stopwatch(int skip_=20, real t=-1) : skip(skip_), max_time(t) {};

    static auto now() {return clock::now();}

    bool operator() (Ignore, Ignore) {
        if (!running) {initial_time = current_time = now(); running = true; return false;}
        if (!counter--) {current_time = now(); counter = skip; return (max_time >= 0 && seconds() >= max_time);}
        return false;
    }

    void reset() {running = false; counter = 0;}

    friend std::ostream & operator<<(std::ostream &os, Stopwatch const &t) {
        os << "Stopwatch(" << t.seconds();
        if (t.max_time >= 0) os << '/' << t.max_time;
        return os << "s)";
    }

    real seconds() const {return Duration(current_time - initial_time).count();}

    // operator std::function<bool(int)>() {return [t=*this](auto const &...) mutable {return t({}, {});};}
};

void render(Document &doc, Type<Stopwatch>);

}

/******************************************************************************************/

template <class T> struct memory::is_simple<std::chrono::time_point<T>, void> : True {};

}
