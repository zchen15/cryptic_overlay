#pragma once
#include "../algorithms/Constants.h"

namespace nupack::kmc {

/******************************************************************************************/

struct pair_probability {};
struct pair_probability_data {};
struct partition_function {};
struct free_energy {};
struct sample_time {};
struct end_time {};
struct sampled_states {};
struct sampled_pairs {};
struct mfe_state {};

/******************************************************************************************/

namespace traits {
    template <class T, class K, class ...Ts>
    auto is_gettable(int) -> decltype(get(declval<T>(), declval<K>(), declval<Ts>()...), True{});

    template <class T, class K, class ...Ts>
    False is_gettable(...);
}

template <class T, class K, class ...Ts>
using is_gettable = decltype(traits::is_gettable<T, K, Ts...>(0));

template <class T, class K, class ...Ts>
auto get(T &&t, K const &k, Ts &&...ts) -> decltype(t.get(k, fw<Ts>(ts)...)) {
    return t.get(k, fw<Ts>(ts)...);
}

template <std::size_t I=0, class K, class ...Ts, class T>
auto get(T &&t, K const &k, Ts &&...ts) -> decltype(
    void_if<is_tuple<decay<T>>>(),
    get(std::get<I>(t), k, fw<Ts>(ts)...)) {
    return get(std::get<I>(t), k,  fw<Ts>(ts)...);
}

template <std::size_t I=0, class K, class T, class ...Ts,
    typename=void_if<is_tuple<decay<T>> &&
        !is_gettable<decltype(std::get<I>(declval<T>())), K, Ts...>::value>()>
auto get(T &&t, K const &k, Ts &&...ts) {return get<I + 1>(t, k, fw<Ts>(ts)...);}

}
