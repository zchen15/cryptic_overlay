#pragma once
#include "Observables.h"
#include "../algorithms/Operators.h"

namespace nupack { namespace kmc {

/******************************************************************************************/

struct TimeInterval : TotallyOrdered {
    int begin_step, end_step;
    real begin_time, end_time;

    TimeInterval(int b=0, int e=0, real t=0, real s=0) : begin_step(b), end_step(e), begin_time(t), end_time(s) {}

    NUPACK_REFLECT(TimeInterval, begin_step, end_step, begin_time, end_time);

    friend std::ostream & operator<<(std::ostream &os, TimeInterval const &t) {
        return os << "(" << t.begin_step << ':' << t.end_step
                 << ", " << t.begin_time << ':' << t.end_time << ')';
    };

    void merge(TimeInterval const &i) {
        end_step += i.end_step - i.begin_step - begin_step; begin_step = 0;
        end_time += i.end_time - i.begin_time - begin_time; begin_time = 0;
    }

    auto get(sample_time) const {return end_time - begin_time;}
    auto get(::nupack::kmc::end_time) const {return end_time;}
};

inline TimeInterval join_intervals(TimeInterval const &i1, TimeInterval const &i2) {
    return {i1.begin_step, i2.end_step, i1.begin_time, i2.end_time};
};

template <class V>
TimeInterval join_intervals(TimeInterval*, V const &v) {return join_intervals(front(v), back(v));}

void render(Document &doc, Type<TimeInterval>);

/******************************************************************************************/

struct Timer {
    int step_offset=0, step=-1, max_step;
    real time_offset=0, time=0, max_time;

    NUPACK_REFLECT(Timer, step_offset, step, max_step, time_offset, time, max_time);

    Timer(int n=-1, real t=-1) : max_step(n), max_time(t) {};

    bool done() const {
        return (max_step >= 0 && step >= max_step) || (max_time >= 0 && time >= max_time);
    }

    bool operator() (Ignore, real t) {++step; time += t; return done();}

    TimeInterval next() {
        TimeInterval ret{step_offset, step_offset + step, time_offset, time_offset + time};
        step_offset += step; time_offset += time;
        step = -1; time = 0;
        return ret;
    }

    friend std::ostream & operator<<(std::ostream &os, Timer const &t) {
        os << "Timer(" << t.step;
        if (t.max_step >= 0) os << '/' << t.max_step;
        os << ", " << t.time;
        if (t.max_time >= 0) os << '/' << t.max_time;
        return os << "s)";
    }

    void reset() {step = -1; time = 0;}

    auto get(end_time) const {return time;}

    static Timer with_max_step(int n) {return {n, -1};}
    static Timer with_max_time(real t) {return {-1, t};}
};

void render(Document &doc, Type<Timer>);

/******************************************************************************************/

}}
