#pragma once

#include "Observables.h"
#include "../types/PairList.h"
#include "../types/Sequence.h"
#include "../types/Matrix.h"
#include "../iteration/View.h"
#include "../state/StaticState.h"

namespace nupack::kmc {

/******************************************************************************************/

/*
 * Output of PairIntegrator, it's a cumulative matrix of the pair probability integrated over some amount time
 */
template <class M>
struct PairInterval {
    using matrix_type = M;

    NUPACK_REFLECT(PairInterval, cum_pp, time, is_first);

    matrix_type cum_pp;
    real time=0;
    bool is_first=true;

    void merge(PairInterval const &i) {
        cum_pp += i.cum_pp;
        time += i.time;
        is_first = true;
    }

    matrix_type stdev() const {
        auto const ppm = get(pair_probability());
        return ppm - ppm % ppm;
    }

    matrix_type mean() const {return cum_pp / time;}

    matrix_type get(pair_probability) const {return cum_pp / time;}

    friend std::ostream & operator<<(std::ostream &os, PairInterval const &i) {dump_os(os, i.get(pair_probability())); return os;}

    decltype(auto) get(pair_probability_data) const {return *this;}
};

template <class M, class V>
PairInterval<M> join_intervals(PairInterval<M> *, V const &v) {
    auto last = std::prev(end_of(v));
    if (begin_of(v)->is_first) return {last->cum_pp, last->time, true};
    auto first = std::prev(begin_of(v));
    return {last->cum_pp - first->cum_pp, last->time - first->time, false};
}


template <class M>
void render(Document &doc, Type<PairInterval<M>> t) {
    doc.type(t, "kmc.PairInterval");
    render_public(doc, t);
    doc.method(t, "mean", &PairInterval<M>::mean);
}

/******************************************************************************************/

// // Pair probability tracker class. It lazily tracks the pair probability matrix P during a
// // trajectory by summing P * t for each timestep. Once finalized, matrix() divides by the
// // total time to give the average P.

template <class M>
class PairIntegrator {

    real time=0;
    pair_data_type pairs, map; // Pair vector, map of null-base indices to no-null-base indices
    vec<real> times; // Last time a base index had its pairing modified
    M value; // Sum of pair probability * residence time
    bool done=true, is_first=true; // value is up to date

    template <class State>
    void init(State const &w) {
        value = la::zeros<Matrix>(w.n_bases(), w.n_bases());
        map = make_pairs_map(w);
        pairs = w.pairs;
        times.resize(len(pairs), 0);
    };

public:

    NUPACK_REFLECT(PairIntegrator, time, pairs, map, times, value, done, is_first);

    using Matrix = M;

    /// Update to newest timestep, doing the least work possible
    template <class State>
    void operator() (State const &w, real t) {
        // If a move has not occurred yet
        if (times.empty()) init(w);
        else {
            // Base indices that switched
            auto b1 = w.last_move.bp.first, b2 = w.last_move.bp.second;
            // Those indices without null bases
            auto m1 = map[b1], m2 = map[b2];
            if (pairs[b1] == b1 && pairs[b2] == b2) { // Base pair addition
                value(m1, m1) += time - times[b1];
                value(m2, m2) += time - times[b2];
                pairs[b1] = b2; pairs[b2] = b1;
            } else if (pairs[b1] == b2 && pairs[b2] == b1) { // Base pair deletion
                value(m1, m2) += time - times[b1];
                value(m2, m1) += time - times[b2];
                pairs[b1] = b1; pairs[b2] = b2;
            } else NUPACK_BUG("Invalid base pair move", b1, b2, pairs[b1], pairs[b2]);
            // Set the last modified time
            times[b1] = time; times[b2] = time;
        }
        done = false;
        time += t;
    }

    /// Update all pair probability sums to current time
    PairInterval<Matrix> next() {
        NUPACK_ASSERT(!times.empty(), "PairIntegrator has not been run yet");
        if (!done) {
            for (auto i : indices(pairs)) if (map[i] != -1) // For all non-null bases
                value(map[pairs[i]], map[i]) += time - times[pairs[i]];
            fill(times, time);
            done = true;
        }
        return {value, time, std::exchange(is_first, false)};
    }

    Matrix average() {
        NUPACK_ASSERT(!times.empty(), "PairIntegrator has not been run yet");
        if (!done) {
            for (auto i : indices(pairs)) if (map[i] != -1) // For all non-null bases
                value(map[pairs[i]], map[i]) += time - times[pairs[i]];
            fill(times, time);
            done = true;
        }
        return value / time;
    }
};

template <class M>
void render(Document &doc, Type<PairIntegrator<M>> t) {
    doc.type(t, "kmc.PairIntegrator");
    doc.method(t, "new", rebind::construct(t));
    doc.method(t, "mean", &PairIntegrator<M>::average);
}

/******************************************************************************************/

template <class Matrix=real_mat, class State> auto pp_from_state(State const &w) {
    auto map = make_pairs_map(w);
    auto ret = la::zeros<Matrix>(w.n_bases(), w.n_bases());
    izip(w.sys->total_sequence, [&](auto i, auto c) {
        if (c != Base('_')) ret(map[i], map[w.pairs[i]]) = 1;
    });
    return ret;
}

/******************************************************************************************/

template <class M>
class PairProbabilityBoltzmann {
    //Calculates the pair probability matrix by adding, with each new state within the macrostate, the structure matrix of that state * e^(-beta*energy(w))

    real beta;
    M structure_matrix_from_state;
    real exps_from_state;
    real time=0;
    vec<nupack::real> times; // Last time a base index had its pairing modified
    pair_data_type pairs, map; // Pair vector, map of null-base indices to no-null-base indices
    bool done=true, is_first=true; //, is_first=true; // value is up to date
    M PP; // cumulative sum of each sampled state's structure matrix * exps(w)

    // using pp_from_state

    template <class State>
    void init(State const &w) {
        structure_matrix_from_state = pp_from_state(w);
        exps_from_state = std::exp(-beta * w.energy);
        PP = pp_from_state(w) * std::exp(-beta * w.energy);
        map = make_pairs_map(w);
        pairs = w.pairs;
        times.resize(len(pairs), 0);
    };

public:

    NUPACK_REFLECT(PairProbabilityBoltzmann, beta, structure_matrix_from_state, exps_from_state, time, times, pairs, map, done, PP);


    using Matrix = M;

    // PUT CALCULATION OF EACH STATE * BOLTZMANN ENERGY WITHIN HERE (operator)? then choose to sum them if they are part
    // the same macrostate

    /// Update to newest timestep, doing the least work possible
    template <class State>
    void operator() (State const &w, real t) {
        // If a move has not occurred yet
        if (times.empty()) init(w);
        else {
            // Base indices that switched
            auto b1 = w.last_move.bp.first, b2 = w.last_move.bp.second;
            // Those indices without null bases
            auto m1 = map[b1], m2 = map[b2];
            if (pairs[b1] == b1 && pairs[b2] == b2) { // Base pair addition
                // value(m1, m1) += time - times[b1];
                // value(m2, m2) += time - times[b2];
                pairs[b1] = b2; pairs[b2] = b1;
            } else if (pairs[b1] == b2 && pairs[b2] == b1) { // Base pair deletion
                // value(m1, m2) += time - times[b1];
                // value(m2, m1) += time - times[b2];
                pairs[b1] = b1; pairs[b2] = b2;
            } else NUPACK_BUG("Invalid base pair move", b1, b2, pairs[b1], pairs[b2]);
            // Set the last modified time
            times[b1] = time; times[b2] = time;
        }
        done = false;
        time += t;
    }

    // template <class State>
    PairInterval<Matrix> next()  {
        NUPACK_ASSERT(!times.empty(), "PairProbabilityBoltzmann has not been run yet");
        if (!done) {
            auto x = [&] (auto const &w) {return PP += pp_from_state(w) * std::exp(-beta * w.energy);};
            fill(times, time);
            done = true;
        }
        return {PP, time, std::exchange(is_first, false)};
    }

    Matrix average() {
        NUPACK_ASSERT(!times.empty(), "PairProbabilityBoltzmann has not been run yet");
        return PP;
    }
};

template <class M>
void render(Document &doc, Type<PairProbabilityBoltzmann<M>> t) {
    doc.type(t, "kmc.PairProbabilityBoltzmann");
    doc.method(t, "new", rebind::construct(t));
    doc.method(t, "mean", &PairProbabilityBoltzmann<M>::average);
}

/******************************************************************************************/

/// Pair probability distance using L1 norm. The output is between 0 and 1
struct PairProbabilityL1 {
    /// Between two matrices
    template <class M1, class M2>
    auto operator() (M1 const &m1, M2 const &m2) const -> decltype(m1 - m2, value_type_of<M1>()) {
        auto const ret = la::esum(la::eabs(m1 - m2)) / 2.0 / la::n_rows(m1);
        NUPACK_REQUIRE(ret, >=, 0);
        NUPACK_REQUIRE(ret, <=, 1);
        return ret;
    };

    /// Between two macrostates
    template <class M1, class M2>
    auto operator() (M1 const &m1, M2 const &m2) const -> value_type_of<decltype(get(m1, pair_probability()))> {
        return (*this)(get(m1, pair_probability()), get(m2, pair_probability()));
    };

    /// For a range, take distance between first half and second half
    template <class V>
    auto operator() (V const &v) const {
        NUPACK_REQUIRE(1, <, len(v));
        // auto iv = indirect_view(v, [](auto const &t) {return get(t, pair_probability_data());}); // To avoid computation on other observables
        return (*this)(get(join_intervals(first_of(bisect(v))), pair_probability()),
                       get(join_intervals(second_of(bisect(v))), pair_probability()));
    }
};

/******************************************************************************************/

constexpr auto const pair_probability_l1 = PairProbabilityL1();

/******************************************************************************************/

struct HammingObserver {
    vec<PairList> structures;
    Col<real> distances;
    vec<usize> deltas;
    usize order, threshold;

    NUPACK_REFLECT(HammingObserver, structures, distances, deltas, order, threshold);

    HammingObserver(vec<PairList> s={}, vec<usize> d={}, usize o=4, usize t=0)
        : structures(std::move(s)), deltas(std::move(d)), threshold(t), order(o) {}

    /// complexity of # structures, constant with everything else
    void operator()(PairList const &pairs, usize b, usize c);

    void update(Col<real> &distances) const;

    Col<real> calculate(PairList const &pairs) const;

    template <class W>
    auto const & operator()(W const &w, real) {
        (*this)(w.pairs, w.last_move.bp.first, w.last_move.bp.second);
        return distances;
    }
};

NUPACK_DEFINE_TYPE(isHammingObserver, HammingObserver);

template <class T, NUPACK_IF(traits::isHammingObserver<T>)>
void render(Document &doc, Type<T> t) {
    doc.type(t, "kmc.HammingObserver");
    doc.method(t, "new", rebind::construct<vec<PairList>, vec<usize>, usize, usize>(t));
    doc.method(t, "()", &T::calculate);
};

/******************************************************************************************/

}
