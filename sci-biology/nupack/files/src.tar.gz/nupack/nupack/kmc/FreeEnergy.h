#pragma once
#include "Observables.h"

#include "../types/PairList.h"
#include "../types/IndirectMap.h"
#include "../standard/Map.h"

namespace nupack { namespace kmc {

/******************************************************************************************/

struct FreeEnergyInterval {
    real beta;
    // uint n_bases;
    // pair_data_type pairs_map;
    Map<PairList, real> exps; // map of structure to boltzmann factor
    NUPACK_REFLECT(FreeEnergyInterval, beta, exps);

    void merge(FreeEnergyInterval const &i) {exps.insert(begin_of(i.exps), end_of(i.exps));}

    auto get(partition_function) const {return sum(exps, [](auto const &p){return p.second;});}

    auto get(free_energy) const {return -1.0 / beta * std::log(get(partition_function()));}

    auto get(sampled_pairs) const {return map_keys(exps);}

    template <class State, class KM>
    auto get(sampled_states, State w, KM const &km) const {
        return indirect_view(exps, [&km, w](auto const &p){return State(w.sys, p.first, km);});
    }

    friend std::ostream & operator<<(std::ostream &os, FreeEnergyInterval const &t) {
        dump_os(os,std::make_tuple(t.get(partition_function()), t.get(free_energy()), len(t.exps)));
        return os;
    }

    // real_mat get(pair_probability) const {
    //     auto ret = la::zeros<real_mat>(n_bases, n_bases);
    //     for (auto const &p : exps) {
    //         auto const &pairs = p.first;

    //         double const boltz = p.second;
    //         izip(pairs_map, [&](auto i, auto j) {
    //             if (j != iseq(-1)) ret(j, pairs_map[pairs[i]]) += boltz;
    //         });
    //     }
    //     ret /= get(partition_function());
    //     return ret;
    // }
};

void render(Document &doc, Type<FreeEnergyInterval>);

template <class V> FreeEnergyInterval join_intervals(FreeEnergyInterval *, V const &v) {
    FreeEnergyInterval ret = front(v);
    for (auto const &i : v) ret.exps.insert(begin_of(i.exps), end_of(i.exps));
    return ret;
}

/******************************************************************************************/

struct FreeEnergyIntegrator {
    real beta;
    // uint n_bases;
    // pair_data_type pairs_map;
    Map<PairList, real> exps;

    FreeEnergyIntegrator(real b) : beta(b) {};
    // template <class State>
    // FreeEnergyIntegrator(State const &w, real b) : beta(b), pairs_map(make_pairs_map(w)), n_bases(w.n_bases()) {};

    template <class W>

    void operator() (W const &w, real) {
        exps.emplace(w.pairs, std::exp(-beta * w.energy));
    };

    FreeEnergyInterval next() {
        FreeEnergyInterval ret{beta, {}};
        // FreeEnergyInterval ret{beta, n_bases, pairs_map, {}};
        std::swap(ret.exps, exps);
        return ret;
    }
};

/******************************************************************************************/

}}
