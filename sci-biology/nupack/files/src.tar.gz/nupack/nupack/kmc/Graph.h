#pragma once
#include "Counters.h"
#include "../types/PairList.h"

#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/graphviz.hpp>

namespace nupack { namespace kmc {

/******************************************************************************************/

struct GraphMaker {

    struct Edge {
        Edge() = default;
        Edge(double w) : weight(w) {};
        double weight;
    };

    struct Node {
        Node() = default;
        Node(string s, double e) : dp(s), energy(e) {};
        string dp;
        double energy;
    };

    using Graph = boost::adjacency_list<boost::vecS, boost::vecS, boost::undirectedS, Node, Edge>;

    /**************************************************************************************/

    std::unordered_map<pair_data_type, int, RangeHash<pair_data_type>> nodes;
    Graph graph;
    int last_pos;

    NUPACK_REFLECT(GraphMaker, nodes, graph, last_pos);

    GraphMaker() : last_pos(-1) {};

    /**************************************************************************************/

    template <class W>
    void operator() (W const &w, real) {
        auto f = nodes.find(w.pairs);
        int pos;
        if (f == end_of(nodes)) {
            nodes[w.pairs] = pos = len(nodes);
            boost::add_vertex(Node(w.dp(), w.energy), graph);
        } else pos = f->second;

        auto weight = std::max(w.last_move.rate, 1.0 / w.last_move.rate);
        if (last_pos != -1 && !boost::edge(last_pos, pos, graph).second)
            boost::add_edge(last_pos, pos, Edge(weight), graph);

        last_pos = pos;
    };

    void write_graphviz(std::ostream & os) {
        boost::write_graphviz(os, graph, boost::make_label_writer(boost::get(&Node::dp, graph)));
    }

    friend GraphMaker reduce(GraphMaker const &t1, GraphMaker const &t2) {
        GraphMaker ret = t1;
        //ret.members.insert(begin(t2.members), end_of(t2.members));
        return ret;
    }

    template <class A>
    void serialize(A &a, const unsigned int){a & nodes; a & graph; a & last_pos;}

    auto size() const {return size_of(nodes);}
};

/******************************************************************************************/

template <class G, class W>
void add_vertices(G & g, W const &w, int op, int ok, int p, bool skip_stack) {
    if (!skip_stack || w[ok].exterior() || len(w[ok]) != 2
                       || w[op].exterior() || len(w[op]) != 2) {
        auto v = boost::add_vertex(g);
        if (w[ok].exterior()) g[v].color = "red";
        else if (len(w[ok]) == 1) g[v].color = "green";
        else if (len(w[ok]) == 2) g[v].color = "blue";
        else g[v].color = "orange";
        g[v].label = ""; g[v].shape = "circle";

        if (p != Ether) boost::add_edge(p, v, g);
        p = v;
    }
    for (auto const &e : w[ok].edges) if (e != Ether && e != w[ok].parent())
        add_vertices(g, w, ok, e, p, skip_stack);
}

struct LoopGraph {
    struct Vertex {string color; string label; string shape;};
    using Graph = boost::adjacency_list<boost::vecS, boost::vecS, boost::undirectedS, Vertex>;
    using Edge = std::pair<int, int>;

    Graph graph;

    template <class W> LoopGraph(W const &w, bool skip_stack=false) {
        for (auto x : w.complexes.complex_indices) {
            auto s_root = * std::find_if(begin_of(x), end_of(x),
                [&] (auto s) {return w[w.complexes.strand_map[s].loop].edges.is_root();});
            auto o_root = w.complexes.strand_map[s_root].loop;
            add_vertices(graph, w, Ether, o_root, Ether, skip_stack);
        };
    };

    void write(std::ostream & os) {
        boost::dynamic_properties dp;
        dp.property("color", get(& Vertex::color, graph));
        dp.property("node_id", get(boost::vertex_index, graph));
        dp.property("label", get(& Vertex::label, graph));
        dp.property("shape", get(& Vertex::shape, graph));
        boost::write_graphviz_dp(os, graph, dp);
    }
};

/******************************************************************************************/

struct LoopGraphMaker {
    vec<LoopGraph> graphs;

    LoopGraphMaker() = default;
    template <class W> LoopGraphMaker(W const &w) {graphs.emplace_back(w);};

    template <class W>
    void operator() (W const &w, real) {graphs.emplace_back(w);};

    void write(string prefix) {
        for (auto i : indices(graphs)) {
            std::ofstream of(prefix + std::to_string(i) + ".dot");
            graphs[i].write(of);
        }
    }
};

/******************************************************************************************/

}}
