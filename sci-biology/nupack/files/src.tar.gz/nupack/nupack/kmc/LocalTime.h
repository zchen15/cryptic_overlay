#pragma once

#include "Counters.h"

namespace nupack { namespace kmc {

/******************************************************************************************/

/*
 * Class that maintains a map of structures to values
 */
template <bool Ordered, class T>
struct StructureIntegrator : ConstIterable<StructureIntegrator<Ordered, T>> {
    using hash_type = RangeHash<PairList>;
    using map_type = if_t<Ordered, std::map<PairList, T>, std::unordered_map<PairList, T, hash_type>>;

    map_type structures;
    NUPACK_REFLECT(StructureIntegrator, structures);

    template <class W>
    auto & put(W const &w) {return structures.emplace(w.pairs, T{}).first->second;}

    void emplace(PairList pairs) {structures.emplace(std::move(pairs), T{});}

    auto const & iter() const {return structures;}
    auto keys() const {return vmap(structures, first_of);}
    auto values() const {return vmap(structures, second_of);}
};

NUPACK_DEFINE_TEMPLATE(isStructureIntegrator, StructureIntegrator, bool, class);

template <class T, NUPACK_IF(traits::isStructureIntegrator<T>)>
void render(Document &doc, Type<T> t) {
    doc.type(t, "kmc.StructureIntegrator");
    doc.method(t, "keys",    &T::keys);
    doc.method(t, "values",  &T::values);
    doc.method(t, "emplace", &T::emplace);
};

/******************************************************************************************/

/*
 * Class that keeps track of the time spent in each state
 */
template <bool Ordered>
struct TimeIntegrator : StructureIntegrator<Ordered, real> {
    using base_type = typename TimeIntegrator::StructureIntegrator;
    using base_type::structures;

    template <class W>
    void operator()(W const &w, real t) {base_type::put(w) += t;}

    friend TimeIntegrator reduce(TimeIntegrator t1, TimeIntegrator const &t2) {
        t1.structures.insert(begin_of(t2.structures), end_of(t2.structures));
        return t1;
    }
};

NUPACK_DEFINE_TEMPLATE(isTimeIntegrator, TimeIntegrator, bool);

template <class T, NUPACK_IF(traits::isTimeIntegrator<T>)>
void render(Document &doc, Type<T> t) {
    doc.type(t, "kmc.TimeIntegrator"); // base_type_of<T>
};

/******************************************************************************************/


/*
 * Class that keeps track of the time spent in each state, weighted by an exponential
 */
template <bool Ordered>
struct ScaledIntegrator : StructureIntegrator<Ordered, std::tuple<real, real, real>> {
    using base_type = typename ScaledIntegrator::StructureIntegrator;
    // x0 = scaled time per state
    // x1 = d(x0) / dscale
    // x2 = time per state
    real scale, current_time=0, scale_times=0;

    NUPACK_EXTEND_REFLECT(ScaledIntegrator, base_type, scale, current_time, scale_times);

    explicit ScaledIntegrator(real rate=0) : scale(rate) {}

    template <class W>
    void operator() (W const &w, real t) {
        auto &val = base_type::put(w);
        auto const s = t * scale;
        auto const exp_scale = exp(scale_times);
        if (abs(s) < 1.e-5) { // use first term in Taylor series
            first_of(val) += exp_scale * s;
            second_of(val) += exp_scale * scale_times * s;
        } else {
            auto const exp_s = exp(s);
            first_of(val) += exp_scale * (exp_s - 1);
            second_of(val) += exp_scale * (exp_s * (scale_times + s - 1) - scale_times + 1);
        }
        third_of(val) += t;
        current_time += t;
        scale_times += s;
    }
};

NUPACK_DEFINE_TEMPLATE(isScaledIntegrator, ScaledIntegrator, bool);

template <class T, NUPACK_IF(traits::isScaledIntegrator<T>)>
void render(Document &doc, Type<T> t) {
    doc.type(t, "kmc.ScaledIntegrator");
    doc.method(t, "new", rebind::construct<real>(t)); // base_type_of<T>
};

/******************************************************************************************/

/*
 * I think this tracks covariance in an exponential scaling way
 * At each timestep you call .update(values, dt) with values the basis function values at the given state
 */
struct KilledIntegrator {
    Mat<real> gamma, gradient, overlap;
    Col<real> times, scale_times, scale_grad, current_times;
    real time=0, sample_time=0, current_time=0, pi_time=0, dpi_time=0, period, next_time, warmup, scale;

    NUPACK_REFLECT(KilledIntegrator, gamma, gradient, overlap, times, scale_times, scale_grad, current_times,
                   time, sample_time, current_time, pi_time, dpi_time, period, next_time, warmup, scale);

    KilledIntegrator(real scale_=0, real period_=0, real warmup_=0)
        : scale(scale_), period(period_), next_time(period_), warmup(warmup_) {}

    void add(KilledIntegrator const &o) {
        if (time == 0) *this = o;
        else for_each_index<12>([&](auto i) {at_c(members_of(*this), i) += at_c(members_of(o), i);});
    }

    void integrate(Col<real> const &tf, real t, bool cross);
    void operator()(Col<real> const &values, real dt);

    // More or less \mathbb{E} \int e^{-\lambda t} F^T(X_0) F(X_t)
    Mat<real> average_gamma() const;
    // More or less \mathbb{E} \int t e^{-\lambda t} F^T(X_0) F(X_t)
    Mat<real> average_gradient() const;
    // Approximate F^T diag(\pi) F
    Mat<real> average_overlap() const {return overlap / time;}
    // Approximate pi^T F
    Col<real> average_occupation() const {return times / time;}
};

void render(Document &doc, Type<KilledIntegrator>);

/******************************************************************************************/

struct StoppedIntegrator {
    Mat<real> G;     // \int_{s=0}^{T-\Delta} \int_{t=s}^{T} F^T(X_s) F(X_t)
    Mat<real> GRG;     // \int_{s=0}^{T-\Delta} \int_{t=s}^{T} F^T(X_s) F(X_t)
    real period, time=0;

    NUPACK_REFLECT(StoppedIntegrator, G, GRG, period, time);

    explicit StoppedIntegrator(real p) : period(p) {}

    void operator()(Col<real> const &values, real dt);
};

/******************************************************************************************/

/*
 * Just like KilledIntegrator but you provide a function that will yield basis function values
 */
template <class Observer>
struct CovarianceIntegrator : KilledIntegrator {
    using observer_type = Observer;
    using base_type = KilledIntegrator;
    Observer observer;

    NUPACK_EXTEND_REFLECT(CovarianceIntegrator, base_type, observer);

    CovarianceIntegrator() = default;
    CovarianceIntegrator(Observer obs, real scale, real period=0, real warmup=0)
        : base_type(scale, period, warmup), observer(std::move(obs)) {}

    template <class W> void operator() (W const &w, real dt) {base_type::operator()(observer(w, dt), dt);}
};

NUPACK_DEFINE_TEMPLATE(isCovarianceIntegrator, CovarianceIntegrator, class);

template <class T, NUPACK_IF(traits::isCovarianceIntegrator<T>)>
void render(Document &doc, Type<T> t) {
    using Obs = typename T::observer_type;
    char const *name;
    if (is_t<Obs, HammingObserver>) name = "kmc.HammingIntegrator";
    else if (is_t<Obs, EnumeratedObserver>) name = "kmc.EnumeratedIntegrator";
    else name = "kmc.CovarianceIntegrator";

    doc.type(t, name); // <KilledIntegrator>
    doc.method(t, "new", rebind::construct<Obs, real, real, real>(t));// .template init<2, Obs, real, real, real>()
};

/******************************************************************************************/

}}
