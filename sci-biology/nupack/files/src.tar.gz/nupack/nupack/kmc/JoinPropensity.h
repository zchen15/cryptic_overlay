#pragma once
#include "../types/Matrix.h"

namespace nupack { namespace kmc {

/**************************************************************************************/

struct JoinPropensityIntegrator {
    BaseMat<real> propensity = la::zeros<BaseMat<real>>();
    real time = 0;
    bool is_first = true;

    NUPACK_REFLECT(JoinPropensityIntegrator, propensity, time, is_first);

    template <class State>
    void operator()(State const &w, real t) {
        //NUPACK_REQUIRE(len(w.complexes), ==, 1);
        propensity += t * w.complexes.complex_rates[0];
        time += t;
    };

    JoinPropensityIntegrator next() {return {propensity, 0, std::exchange(is_first, false)};}

    void merge(JoinPropensityIntegrator const &i) {
        propensity = weight_avg(propensity, i.propensity, time, i.time);
        time += i.time;
        is_first = true;
    };
};

void render(Document &doc, Type<JoinPropensityIntegrator>);

/**************************************************************************************/

template <class V>
JoinPropensityIntegrator join_intervals(JoinPropensityIntegrator *, V const &v) {
    auto last = end_of(v) - 1; // Due to limitations from boost::range (rather than back())
    if (begin_of(v)->is_first) return {last->propensity, last->time, true};
    else return {weight_avg(last->propensity, begin_of(v)->propensity, last->time, -begin_of(v)->time), last->time, false};
}

/******************************************************************************************/

}}
