#pragma once
#include "../iteration/Patterns.h"
#include "../common/Random.h"

namespace nupack {

namespace kmc {

/******************************************************************************************/

template <bool Avg=false, class W, class S, class O, class A=AlwaysTrue, class RNG=decltype(StaticRNG)>
auto run_until(W &&w, S &&stop, O &&observers, A &&accept={}, RNG &rng=StaticRNG) {
    real time = 0;
    while(true) {
        w.update_rates();
        for (auto i : range(1000)) {
            if (i % 16 == 0) throw_if_signal(); // Stop at a valid point if there is a system signal
            if constexpr(std::is_scalar_v<std::decay_t<S>>) {
                if (time >= stop) break;
            } else {
                if (stop(w, time)) break; // Check if we should stop
            }
            auto dt = w.timestep(if_c<Avg>(False(), rng));
            time += dt;
            for_each(observers, [&](auto &&o) {o(w, dt);}); // Inform observers
            w.step(accept, rng); // Take a step
        }
    }
    return time;
}

template <bool Avg=false, class ...Args>
auto runner(Args &&...args) {
    return [&](auto &&w, auto &&s, auto &&...ts) {
        return run_until<Avg>(fw<decltype(w)>(w), fw<decltype(s)>(s), std::forward_as_tuple(ts...), args...);
    };
}

template <bool Avg=false, class State, class ...Args>
auto pairs_runner(State w0, Args &&...args) {
    return [&, w0=std::move(w0)](auto pairs, auto &&s, auto &&...ts) {
        State w = w0.with_structure(std::move(pairs));
        run_until<Avg>(w, fw<decltype(s)>(s), std::forward_as_tuple(ts...), args...);
        return w.pairs;
    };
}

/******************************************************************************************/

template <class ...Obs> auto until_all(Obs && ...obs) {
    return [&] (auto const &w) {bool b = true; NUPACK_UNPACK(b = b && obs(w)); return b;};
}

/******************************************************************************************/

}}
