#pragma once
#include "../model/Move.h"
#include "../model/ModelVariants.h"
#include "../iteration/Search.h"
#include "../algorithms/Utility.h"

namespace nupack {

/******************************************************************************************/

struct ProductJoiner {
    using Active = True;

    NUPACK_REFLECT(ProductJoiner, half_rates);

    BaseMat<real> half_rates;
    ProductJoiner() : half_rates(zero) {}

    /**************************************************************************************/

    auto const &join_rates() const {return half_rates;};

    template <class EM>
    void update(SubsequenceList const &, int, EM const &);

    /// Iterate over all locations in the loop with their partial dG and partial rate constant
    template <class EM, class F>
    void for_locs(SubsequenceList const &, Base, Base, EM const &, F &&) const;

    template <class EM>
    auto choose_loc(SubsequenceList const &, double &, Base, Base, EM const &) const;

    /// Return all locations that can form the specified base pair
    template <class EM>
    auto all_locs(SubsequenceList const &, Base, Base, EM const &) const;
};

void render(Document &doc, Type<ProductJoiner>);

/******************************************************************************************/

// Remember that ProductJoiner updates are replicated in BOTH for_locs and update
template <class EM>
void ProductJoiner::update(SubsequenceList const &v, int n, EM const &em) {
    half_rates.fill(0);
    em.dangle_switch([&](auto const &dangle) {
        fork(em.rate_function, [&](auto const &rf) {
            for (auto s : iterators(v)) {
                auto const old5 = safe_dangle5(dangle, v, s); // at beginning
                auto const old3 = safe_dangle3(dangle, v, s); // at end

                for (auto b : iterators(*s).offset(1, -1)) {
                    for (auto const c : CanonicalBases) if (em.pairable.can_close(*b, c)) {
                        real new3 = (b > begin_of(*s) + 1) ? dangle.energy3(b[-1], b[0], c) : real(); // at beginning
                        real new5 = (b < end_of(*s) - 2) ? dangle.energy5(c, b[0], b[1]) : real();    // at end

                        // Beginning of sequence
                        real dE = 0.5 * em.join_penalty();
                        if (b == begin_of(*s) + 1) dE += new3 - old5;
                        else dE += dangle.reduce(new3, old5, b - begin_of(*s) + 1) - old5;

                        // End of sequence
                        if (b == end_of(*s) - 2) dE += new5 - old3;
                        else dE += dangle.reduce(new5, old3, end_of(*s) - b) - old3;

                        half_rates(*b, c) += rf.nondimensional_rate(dE);
                    }
                }
            }
        });
    });
}

/******************************************************************************************/

template <class EM>
auto ProductJoiner::choose_loc(SubsequenceList const &v, double &r, Base b1, Base b2, EM const &em) const {
    JoinLoc ret;
    for_locs(v, b1, b2, em, [&](auto i, auto b, auto dE, auto hrate){
        if (!minus_divide_if(r, hrate)) return false;
        else ret = JoinLoc(i, b, dE, hrate); return true;
    });
    NUPACK_REQUIRE(ret.hrate, >, 0, "Join choice failure");
    return ret;
}

/******************************************************************************************/

// Iterate over all locations in the loop that can form base pair b1 to b2
// Remember that ProductJoiner updates are replicated in BOTH for_locs and update
template <class EM, class F>
void ProductJoiner::for_locs(SubsequenceList const &v, Base b1, Base b2, EM const &em, F &&f) const {
    em.dangle_switch([&](auto const &dangle) { // switch on the specified type of dangle
        fork(em.rate_function, [&](auto const &rf) { // and rate function
            for (auto s : iterators(v)) { // iterate through the sequences
                auto const old5 = safe_dangle5(dangle, v, s); // old dangle contribution at beginning
                auto const old3 = safe_dangle3(dangle, v, s); // old dangle contribution at end

                for (auto b : iterators(*s).offset(1, -1)) if (*b == b1) { // for each matching base
                    // new dangle contributions after the base pair is made
                    real new3 = (b > begin_of(*s) + 1) ? dangle.energy3(b[-1], b[0], b2): real(); // at beginning
                    real new5 = (b < end_of(*s) - 2) ? dangle.energy5(b2, b[0], b[1]) : real();   // at end

                    // Split join penalty in 2 so it is properly counted
                    real dE = 0.5 * em.join_penalty();
                    // Beginning of sequence -- use dangle.reduce to delegate none, min, all dangles
                    if (b == begin_of(*s) + 1) dE += new3 - old5;
                    else dE += dangle.reduce(new3, old5, b - begin_of(*s) + 1) - old5;

                    // End of sequence -- use dangle.reduce to delegate none, min, all dangles
                    if (b == end_of(*s) - 2) dE += new5 - old3;
                    else dE += dangle.reduce(new5, old3, end_of(*s) - b) - old3;
                    NUPACK_ASSERT(contains_iter(*s, b));

                    // Call the callback with the base location information, free energy, and partial rate constant
                    // if the callback returns true, short-circuit and return early.
                    if (f(s - begin_of(v), b, dE, rf.nondimensional_rate(dE))) return;
                }
            }
        });
    });
}

/******************************************************************************************/

template <class EM>
auto ProductJoiner::all_locs(SubsequenceList const &v, Base b1, Base b2, EM const &em) const {
    vec<JoinLoc> ret;
    /// Iterate over all locations in the loop with their partial dG and partial rate constant
    for_locs(v, b1, b2, em, [&](auto i, auto b, auto dE, auto hrate){
        ret.emplace_back(i, b, dE, hrate);
        return false; // dont short circuit out of the iteration over locations
    });
    return ret;
}

/******************************************************************************************/

}
