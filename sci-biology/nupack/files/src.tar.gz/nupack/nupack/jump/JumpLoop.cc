#include "JumpLoop.h"

namespace nupack {

/******************************************************************************************/

void render(Document &doc, Type<JumpLoop<>> t) {render(doc, t, 0);}


void render(Document &doc, Type<JumpSequenceSet> t) {
    doc.type(t, "kmc.JumpSequenceSet"); // <SequenceSet>
}

void render(Document &doc, Type<ProductJoiner> t) {
    doc.type(t, "kmc.ProductJoiner");
};

void render(Document &doc, Type<BasePairAddition> t) {
    doc.type(t, "kmc.BasePairAddition");
};

void render(Document &doc, Type<LazySeqData> t) {
    doc.type(t, "kmc.LazySeqData");
};

void render(Document &doc, Type<LazyMoveGen> t) {
    doc.type(t, "kmc.LazyMoveGen");
};

void render(Document &doc, Type<FullMoveGen> t) {
    doc.type(t, "kmc.FullMoveGen");
};

/******************************************************************************************/

}
