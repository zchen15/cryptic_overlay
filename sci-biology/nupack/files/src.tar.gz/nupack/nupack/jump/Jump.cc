
#include "../smallbox/SmallBox.h"
#include "JumpLoop.h"
#include "Path.h"
#include "../kmc/Basics.h"
#include "../kmc/LocalTime.h"
#include "../kmc/Stopwatch.h"
#include "../kmc/Timer.h"
#include "../kmc/JoinPropensity.h"
#include "../kmc/FreeEnergy.h"
#include "../smallbox/SmallBox.h"
#include "../flow/Exact.h"

namespace nupack {

/******************************************************************************************/

void render(Document &doc, Type<JumpStateBase> t) {
    doc.type(t, "kmc.JumpStateBase");
    render_public(doc, t);
}
/******************************************************************************************/

void render(Document &doc, Type<JumpState<>> t) {render(doc, t, 0);}

/******************************************************************************************/

void render_kmc(Document &doc) {
    doc.render<StaticState<>>();
    doc.render<JumpState<>>();
    doc.function("kmc.partial_inverse", &enumerated_partial_inverse);
    doc.render<kmc::Path>();
    doc.render<System>();

    doc.function("kmc.small_box", &kmc::run_small_box<Local &, vec<JumpState<>>>);
    // doc.function("kmc.original_small_box", &kmc::original_small_box<Local &, vec<JumpState<>>>);
    // using R = decltype(first_of(kmc::original_small_box(declref<Local>(), vec<JumpState<>>())));
    using R = decltype(first_of(kmc::run_small_box(declref<Local>(), vec<JumpState<>>())));
    // doc.function("kmc.enumerate_small_box", &kmc::enumerate_small_box<JumpState<>, decay<R>>);
}

/******************************************************************************************/

/// Update pair vector for a change, update energy, update last_move
void JumpStateBase::register_move(BaseIter b1, BaseIter b2, real dE, real rate) {
    Base_Pair bp = {sys->index(b1), sys->index(b2)};
    NUPACK_ASSERT(*b1 != Base('_'));
    NUPACK_ASSERT(*b2 != Base('_'));
    pairs.toggle_pair(bp.first, bp.second);
    energy += dE;
    last_move = {bp, rate};
}

/******************************************************************************************/

std::optional<MoveMethod> request(Type<MoveMethod>, rebind::Variable const &r, rebind::Dispatch &msg) {
    if (auto p = r.request<std::string>()) {
        if (io::iequals(*p, "lazy")) return moves::lazy;
        if (io::iequals(*p, "full")) return moves::full;
        return msg.error("invalid MoveMethod: " + *p);
    }
    return msg.error("cannot convert to MoveMethod");
}

/******************************************************************************************/

}
