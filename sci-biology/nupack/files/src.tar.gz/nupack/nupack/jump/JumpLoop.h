#pragma once
#include "JumpSequenceSet.h"
#include "../loop/StaticLoop.h"
#include "../state/StateBase.h"

namespace nupack {

template <class SS>
struct JumpLoop : StaticLoop<SS> {
    using base_type = typename JumpLoop::StaticLoop;

    NUPACK_EXTEND_REFLECT(JumpLoop, base_type, del_move);

    using base_type::index;
    using base_type::edge_getter;
    using base_type::parent;
    using base_type::seqs;
    using base_type::edges;
    using base_type::base_type;

    BasePairDeletion del_move;

    JumpLoop() = default;

    /************************************************************************************/

    auto add_moves() const {return seqs.add_moves();}
    auto n_add_moves() const {return seqs.n_add_moves();}

    /************************************************************************************/

    void update_state(JumpStateBase &w);
    template <class W, class EM>
    void update_del_rate(W &, EM const &);
    template <class EM>
    void init_rates(JumpStateBase &w, EM const &em) {seqs.update(em); update_state(w);}

    /************************************************************************************/

    template <class W> void transfer(W &, Edge);
    template <class W> void flip(W &, Edge e=Ether);

    /************************************************************************************/

    template <class W, class EM>
    void merge(W &, JumpLoop &, EM const &);

    template <class W, class EM>
    void split(W &, JumpLoop &, BasePairAddition m, EM const &);

    template <class W, class EM>
    void dissociate(W &, JumpLoop &, EM const &);

    template <class W, class EM>
    static void associate(W &, JumpLoop &, JumpLoop &, JoinLoc, JoinLoc, EM const &);

    /******************************************************************************************/

    template <class W, class EM, class Accept>
    bool try_merge(W &, EM const &, Accept &&);

    template <class W, class EM, class Accept>
    bool try_split(W &, JumpLoop &, real r, EM const &, Accept &&);

    template <class W, class EM, class Accept>
    static bool try_associate(W &, JumpLoop &, JumpLoop &, JoinMove const &, EM const &, Accept &&acc);
};

/******************************************************************************************/

NUPACK_DEFINE_TEMPLATE(isJumpLoop, JumpLoop, class);

template <class T, NUPACK_IF(isJumpLoop<T>)>
void render(Document &doc, Type<T> t, int=0) {
    doc.type(t, "kmc.JumpLoop"); // base_type_of<T>
}

void render(Document &doc, Type<JumpLoop<>>);

/******************************************************************************************/

template <class SS> template <class W>
void JumpLoop<SS>::transfer(W & w, Edge i) {
    edges.transfer(i, edge_getter(w));
    if (seqs.exterior()) w.complexes.set_loop_index(w.sys->strand_of(seqs.strand_begin()), i);
}

/******************************************************************************************/

template <class SS>
void JumpLoop<SS>::update_state(JumpStateBase &w) {
    w.add_rates.update(index(), seqs.total_add_rate());
    if (seqs.can_join() && seqs.exterior()) {
        auto s = this->strand_index(w);
        w.complexes.set_loop_index(s, index());
        w.complexes.update_join_rates(s, seqs.join_rates());
    }
}

/******************************************************************************************/

template <class SS> template <class W, class EM>
void JumpLoop<SS>::update_del_rate(W &w, EM const &em) {
    if (edges.is_root()) del_move = decltype(del_move)();
    else {
        iseq pk, kp;
        std::tie(pk, kp) = EdgeSet::get_locs(w[parent()].edges, edges);
        del_move.dE = SS::get_deletion_energy(w[parent()].seqs, seqs, pk, kp, em);
        del_move.rate = fork(em.rate_function, [&](auto const &rf) {return rf.unimolecular_rate(del_move.dE);});
    }
    w.del_rates.update(index(), del_move.rate);
}

/******************************************************************************************/

template <class SS> template <class W, class EM>
void JumpLoop<SS>::merge(W & w, JumpLoop<SS> & k, EM const &em) {
    NUPACK_ASSERT(!k.seqs.exterior() || !seqs.exterior());
    auto pk_kp = edges.merge(k.edges, edge_getter(w));
    auto shift = seqs.merge(k.seqs, pk_kp.first, pk_kp.second, em);
    edges.rotate(shift);
    update_state(w); update_del_rate(w, em);
    for (auto const &e : edges) if (e != parent() && e != Ether) w[e].update_del_rate(w, em);
    NUPACK_ASSERT(edges.check());
    w.delete_at(k.index());
}

/******************************************************************************************/

template <class SS> template <class W, class EM>
void JumpLoop<SS>::dissociate(W & w, JumpLoop<SS> & k, EM const &em) {
    auto sp = this->strand_index(w), sk = k.strand_index(w);
    NUPACK_REQUIRE(w.complexes.strand_map[sp].loop, ==, static_cast<uint>(index()));
    NUPACK_REQUIRE(w.complexes.strand_map[sk].loop, ==, static_cast<uint>(k.index()));
    try {
        w.complexes.register_split(sp, sk);
    } catch (...) {
        print(w.loops);
        print(w);
        throw;
    }

    auto pk_kp = edges.dissociate(k.edges, seqs.nick(), k.seqs.nick(), edge_getter(w));

    auto shifts = seqs.dissociate(k.seqs, pk_kp.first, pk_kp.second, em);

    edges.rotate(shifts.first); k.edges.rotate(shifts.second);

    NUPACK_ASSERT(k.seqs.exterior() && seqs.exterior());
    update_state(w); update_del_rate(w, em);
    k.update_state(w); k.update_del_rate(w, em);

    for (auto const &e : edges) if (e != parent() && e != Ether)
        w[e].update_del_rate(w, em);
    for (auto const &e : k.edges) if (e != k.parent() && e != Ether)
        w[e].update_del_rate(w, em);

    NUPACK_ASSERT(edges.check());
    NUPACK_ASSERT(k.edges.check());
}

/******************************************************************************************/

template <class SS> template <class W, class EM, class Accept>
bool JumpLoop<SS>::try_split(W & w, JumpLoop<SS> & k, real r, EM const &em, Accept &&acc) {
    auto m = seqs.choose_split(r, em);
    if (!acc(m.b1, m.b2)) return false;
    else split(w, k, m, em); return true;
}

/******************************************************************************************/

template <class SS> template <class W, class EM>
void JumpLoop<SS>::split(W & w, JumpLoop<SS> & k, BasePairAddition m, EM const &em) {
    w.register_move(m.b1, m.b2, m.dE, m.rate);
    auto inverse_dE = -m.dE;

    k.edges = edges.split(len(w) - 1, m.s1 + 1, m.s2 + 1, edge_getter(w));
    auto shifts = seqs.split(m, k.seqs, em);
    edges.rotate(shifts.first); k.edges.rotate(shifts.second);

    // Update energies and addition rates
    update_state(w); k.update_state(w);

    if (k.parent() == index()) {
        update_del_rate(w, em);
        k.del_move.dE = std::move(inverse_dE);
        k.del_move.rate = fork(em.rate_function, [&](auto const &rf) {return rf.unimolecular_rate(k.del_move.dE);});
        w.del_rates.update(k.index(), k.del_move.rate);
    } else {
        k.update_del_rate(w, em);
        del_move.dE = std::move(inverse_dE);
        del_move.rate = fork(em.rate_function, [&](auto const &rf) {return rf.unimolecular_rate(del_move.dE);});
        w.del_rates.update(index(), del_move.rate);
    }

    // Other deletion moves
    for (auto e : edges) if (e != k.index() && e != parent() && e != Ether)
        w[e].update_del_rate(w, em);
    for (auto e : k.edges) if (e != index() &&  e != k.parent() && e != Ether)
        w[e].update_del_rate(w, em);

    NUPACK_ASSERT(edges.check());
    NUPACK_ASSERT(k.edges.check());
    for (auto const &o : w.loops) NUPACK_ASSERT(o.edges.check());
}

/******************************************************************************************/

template <class SS> template <class W, class EM>
void JumpLoop<SS>::associate(W &w, JumpLoop &p, JumpLoop &k, JoinLoc pj, JoinLoc kj, EM const &em) {
    auto rate = pj.hrate * kj.hrate * fork(em.rate_function,
        [](auto const &f) {return f.molarity * f.bimolecular_scaling;});
    w.register_move(pj.b, kj.b, pj.dE + kj.dE, rate);

    // Join edges. A little involved since one has to be root.
    if (k.is_root() && !p.is_root()) {
        k.edges.associate(p.edges, kj.s, pj.s, k.seqs.nick(), p.seqs.nick(), JumpLoop<SS>::edge_getter(w));
    } else {
        if (!p.is_root()) p.flip(w); NUPACK_ASSERT(p.is_root());
        p.edges.associate(k.edges, pj.s, kj.s, p.seqs.nick(), k.seqs.nick(), JumpLoop<SS>::edge_getter(w));
    }

    // Join loops and rotate edges
    auto shifts = p.seqs.associate(k.seqs, pj.s, kj.s, pj.b, kj.b, em);
    p.edges.rotate(shifts.first); k.edges.rotate(shifts.second);

    // Register complex join
    auto sp = p.strand_index(w), sk = k.strand_index(w);
    if (k.parent() == p.index()) w.complexes.register_join(sk, sp);
    else w.complexes.register_join(sp, sk);

    // Update energies and addition rates
    p.update_state(w); k.update_state(w);

    // Deletion moves
    p.update_del_rate(w, em);
    for (auto const &e : p.edges) if (e != k.index() && e != p.parent() && e != Ether)
        w[e].update_del_rate(w, em);
    k.update_del_rate(w, em);
    for (auto const &e : k.edges) if (e != p.index() && e != k.parent() && e != Ether)
        w[e].update_del_rate(w, em);
}

/******************************************************************************************/


template <class SS> template <class W, class EM, class Accept>
bool JumpLoop<SS>::try_associate(W &w, JumpLoop &p, JumpLoop &k, JoinMove const &m, EM const &em, Accept &&acc) {
    auto margin = m.margin / m.scale;
    auto c1 = p.seqs.choose_join(margin, m.b1, m.b2, em); NUPACK_REQUIRE(margin, <=, 1);
    margin *= m.scale;
    auto c2 = k.seqs.choose_join(margin, m.b2, m.b1, em); NUPACK_REQUIRE(margin, <=, 1);
    if (!acc(c1.b, c2.b)) return false;
    else associate(w, p, k, c1, c2, em); return true;
}

/******************************************************************************************/

template <class SS> template <class W, class EM, class Accept>
bool JumpLoop<SS>::try_merge(W & w, EM const &em, Accept &&acc) {
    NUPACK_ASSERT(w.complexes.check());
    NUPACK_ASSERT(!edges.is_root(), *this);
    auto bp = this->parent_base_pair();
    if (!acc(bp.first, bp.second)) return false;
    w.register_move(bp.first, bp.second, del_move.dE, del_move.rate);
    NUPACK_ASSERT(w.complexes.check());
    if (seqs.exterior() && w[parent()].seqs.exterior()) w[parent()].dissociate(w, *this, em);
    else w[parent()].merge(w, *this, em);
    NUPACK_ASSERT(w.complexes.check());
    return true;
}

/******************************************************************************************/

template <class SS> template <class W>
void JumpLoop<SS>::flip(W & w, Edge new_parent) {
    if (new_parent == Ether) del_move = decltype(del_move)();
    else del_move = std::move(w[new_parent].del_move);
    w.del_rates.update(index(), del_move.rate);
    NUPACK_REQUIRE(w.del_rates[index()], ==, del_move.rate, "Update failed");
    if (parent() != Ether) w[parent()].flip(w, index());
    edges.set_parent(new_parent);
}

/******************************************************************************************/

/// call a callback for every join location in the loop
template <class O, class KM, class F>
void for_join_locs_in_loop(O &&o, Base b, Base c, KM const &km, F &&f) {
    for (auto &&m : o.seqs.join_locs(b, c, km)) f(m);
}

/******************************************************************************************/

}
