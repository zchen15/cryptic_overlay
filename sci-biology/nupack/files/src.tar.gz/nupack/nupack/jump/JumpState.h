/** \file JumpState.h
 * @brief Contains JumpState, a State class capable of efficient base-pairing simulation
 */
#pragma once
#include "JumpSequenceSet.h"
#include "../reflect/Dump.h"
#include "../state/StaticState.h"
#include "../kmc/Run.h"
#include "../markov/Enumerate.h"
#include "../common/Random.h"
#include "../model/ModelVariants.h"

namespace nupack {

NUPACK_DETECT(is_enumerable, decltype(declref<T const>()[0].add_moves()));

/******************************************************************************************/

struct StepProposal {
    bool is_addition;
    Edge loop1, loop2;
    BaseIter base1, base2;
    NUPACK_REFLECT(StepProposal, is_addition, loop1, loop2, base1, base2);
};

/******************************************************************************************/

template <class O, class EM>
struct JumpState : StaticState<JumpStateBase, O> {
    using loop_type = O;
    using model_type = EM;
    using base_type = typename JumpState::StaticState;

    JumpState() = default;

    template <class Y=vec<string>, class M=EM>
    explicit JumpState(Y &&sys, PairList p, MoveMethod gen=moves::lazy, M &&em=EM{Ensemble::min})
        : base_type(fw<Y>(sys), std::move(p), gen), model(fw<M>(em)) {
        model.check(); base_type::check_structure(model.pairable); update_rates();
    }

    auto with_structure(PairList p={}) const {
        auto mvs = maybe_get<LazyMoveGen>(loops[0].seqs.gen) ? moves::lazy : moves::full;
        return JumpState(this->sys, std::move(p), mvs, model);
    }
    auto with_structure(StateBase const &w) const {return with_structure(this->aligned_pairs(w));}
    void check() const {base_type::check_structure(model.pairable); NUPACK_ASSERT(this->complexes.check());}

    /**************************************************************************************/

    using base_type::loops;
    using base_type::complexes;
    using base_type::sys;
    using base_type::pairs;
    using base_type::add_rates;
    using base_type::del_rates;
    using base_type::energy;
    using base_type::last_move;

    /// Access to energy model - model is pretty small now that ParameterSet is kept as ptr
    EM model;
    NUPACK_EXTEND_REFLECT(JumpState, base_type, model);

    void delete_at(iseq); /// Delete a loop
    void swap_at(iseq, iseq); /// Swap positions of two loops

    /// Add a loop
    template <class ...Ts> void emplace(Ts &&...ts) {
        add_rates.emplace_back(0);
        del_rates.emplace_back(0);
        base_type::emplace(fw<Ts>(ts)...);
    };

    void pop_back() {loops.pop_back(); add_rates.pop_back(); del_rates.pop_back();} /// Remove the last loop

    /**************************************************************************************/

    void update_rates(); /// Update all rates and energies in the state

    /// Total number of base pair addition moves possible
    template <class T=void>
    auto n_add_moves() const -> decltype(sink<T>(loops)[0].n_add_moves()) {
        return sum(sink<T>(loops), [](auto const &o){return o.n_add_moves();});
    }
    auto boltz() const {return model.boltz(energy);} /// Boltzmann factor

    /// Step forward in time using a random number generator
    template <class RNG=decltype(StaticRNG)> real timestep(RNG &gen=StaticRNG) const;
    /// Step forward in time using the a verage waiting time
    real timestep(False) const {auto r = total_rate(); return r == 0 ? *inf : real(1) / r;}

    /**************************************************************************************/

    /// Try a merge move and perform it if accepted
    template <class A> bool try_merge(real r, A &&accept);
    /// Try a split move and perform it if accepted
    template <class A> bool try_split(real r, A &&accept);
    /// Try a join move and perform it if accepted
    template <class A> bool try_join(real r, A &&accept);
    /// Step forward given a cumulative rate
    template <class A=AlwaysTrue, class RNG=decltype(StaticRNG)>
    void step(A &&accept={}, RNG &gen=StaticRNG);

    /// Manual associate
    void associate(ComplexJoinMove const &m) {
        loop_type::associate(*this, loops[m.loop1], loops[m.loop2], m.loc1, m.loc2, model);
    }

    static auto constexpr repr_names() {return make_names("base_class", "model");}
    auto save_repr() const {return make_members(static_cast<base_type const &>(*this), model);}

    void load_repr(base_type b, decltype(model) m) {
        static_cast<base_type &>(*this) = std::move(b);
        model = std::move(m);
        if (!pairs.empty()) update_rates();
    }

    /// Total rate of current state
    real total_rate() const {return add_rates.total() + del_rates.total() + complexes.join_rate(model);}

    friend std::ostream & operator<<(std::ostream &os, JumpState const &w) {
        dump_os(os, "State('", w.sequence(), "', '", w.dp(), "', ", w.energy, ")");
        return os;
    }
};

NUPACK_DEFINE_TEMPLATE(is_jump_state, JumpState, class, class);

template <class W, NUPACK_IF(is_jump_state<W>)>
void render(Document &doc, Type<W> t, int=0) {
    using stop = rebind::Pack<kmc::Stopwatch, kmc::Timer, kmc::FirstCollision, rebind::AnnotatedCallback<bool, W const &, double>>;
    using obs = std::variant<
        kmc::Stopwatch *,
        kmc::Timer *,
        kmc::HammingObserver *,
        kmc::PairIntegrator<Mat<real>> *,
        kmc::PairProbabilityBoltzmann<Mat<real>> *,
        kmc::TimeIntegrator<true> *,
        kmc::ScaledIntegrator<true> *,
        kmc::HittingTimeObserver *,
        rebind::AnnotatedCallback<void, W const &, double> const *
    >;
                            //  kmc::CovarianceIntegrator<kmc::EnumeratedObserver>,
                            //  kmc::CovarianceIntegrator<std::function<Col<real>(W const &, real)>>,
                            //  kmc::CovarianceIntegrator<kmc::HammingObserver>,
    using M = typename W::model_type;

    doc.render<typename W::base_type>();
    doc.render<kmc::PairIntegrator<Mat<real>>>();
    doc.type(t, "kmc.State", "jump"); // <base_type_of<W>>
    render_comparisons(doc, t);
    doc.method(t, "{}", dumpable(t));
    doc.method(t, "energy", &W::energy);
    doc.method(t, "boltz", &W::boltz);
    doc.method(t, "new", rebind::construct<string, PairList, MoveMethod, M const &>(t));
    doc.method(t, "new", rebind::construct<SequenceList, PairList, MoveMethod, M const &>(t));
    doc.method(t, "_update_rates", &W::update_rates);
    doc.method(t, "_check", &W::check);
    doc.method(t, "step", [](W &w) {auto t = w.timestep(); w.step(); return t;});

    stop::for_each([&](auto S) {
        doc.method(t, "run", [](W &w, bool avg, decltype(*S) &stop, small_vec<obs> v) {
            auto observe = std::make_tuple([&](W const &w, real const t) {
                for (auto &x : v) std::visit([&](auto &x) {if (x) (*x)(w, t);}, x);
            });
            if (avg) kmc::run_until<true>(w, stop, observe);
            else kmc::run_until<false>(w, stop, observe);
        });
    });

    rebind::Pack<PairList, StateBase>::for_each([&](auto T) {
        doc.method(t, "with_structure", [](W const &w, decltype(*T) const &t) {
            return w.with_structure(t);
        });
    });

    doc.method(t, "rate_matrix", [](W w, Cube<real> const *p) {
        w = w.with_structure();
        auto ws = enumerate_states(w);
        auto v = stationary_populations(ws);
        auto R = rates_from_states<real_csc>(ws);
        Mat<real> basis(len(ws), p ? p->n_slices : 0);
        if (p) {
            NUPACK_REQUIRE(p->n_rows, ==, len(w.pairs));
            NUPACK_REQUIRE(p->n_cols, ==, len(w.pairs));
            for (auto j : range(p->n_slices)) {
                auto const &P = p->slice(j);
                izip(ws, [&](auto i, auto const &w) {
                    real dot = 0;
                    izip(w.pairs, [&](auto b, auto c) {dot += P(b, c);});
                    basis(i, j) = len(w.pairs) - dot;
                });
            }
        }
        return move_as_tuple(ws, v, R, basis);
    });

    doc.method(t, "enumerated", enumerate_states<W>);
};

template <class Q, class W, NUPACK_IF(is_jump_state<no_qual<W>>)>
auto response(std::type_index t, W &&w, Q qual) {
    return (t == typeid(base_type_of<W>) || t == typeid(JumpStateBase)) ? &w : nullptr;
}

void render(Document &doc, Type<JumpState<>>);

/******************************************************************************************/

/// Update all rates, making any state valid according to input energy model
template <class O, class EM> void JumpState<O, EM>::update_rates() {
    add_rates.resize(len(loops)); del_rates.resize(len(loops));
    for (auto &o : loops) o.init_rates(*this, model);
    for (auto &o : loops) o.update_del_rate(*this, model);
    energy = (len(sys->strands) - len(complexes)) * model.join_penalty()
           + sum(loops, [](auto const &o){return o.energy();});
}

/******************************************************************************************/

/// Perform unordered deletion of loop at a given index
template <class O, class EM>
void JumpState<O, EM>::delete_at(iseq o) {
    add_rates.swap_erase(o);
    del_rates.swap_erase(o);
    if (o + 1 != len(loops)) loops.back().transfer(*this, o);
    swap_erase(loops, o);
}

/******************************************************************************************/

/// Swap the positions of two loops
template <class O, class EM>
void JumpState<O, EM>::swap_at(iseq i1, iseq i2) {
    if (i1 == i2) return;
    loops[i1].transfer(*this, len(loops));
    loops[i2].transfer(*this, i1);
    loops[i1].transfer(*this, i2);
    del_rates.swap_pos(i1, i2);
    add_rates.swap_pos(i1, i2);
    swap(loops[i1], loops[i2]);
}

/******************************************************************************************/

template <class O, class EM> template <class A, class RNG>
void JumpState<O, EM>::step(A &&accept, RNG &gen) {
    auto const rate = total_rate();
    if (Debug) check();
    if (rate == 0) {last_move = {{0, 0}, 0.0}; return;}
    while_false([&]{
        auto r = random_range(0, rate, gen);
        if (r < del_rates.total()) return try_merge(r, accept); else r -= del_rates.total();
        if (r < add_rates.total()) return try_split(r, accept); else r -= add_rates.total();
        if (likely(1 < len(complexes))) return try_join(r, accept);
        else NUPACK_BUG("Tried to join a single complex", r, add_rates.total(), del_rates.total());
    });
    if (Debug) check();
}

/******************************************************************************************/

/// Random residence time for kinetic Monte Carlo algorithm
template <class O, class EM> template <class RNG>
real JumpState<O, EM>::timestep(RNG &gen) const {
    auto const rate = total_rate();
    return rate == 0 ? *inf : std::exponential_distribution<real>(rate)(gen);
}

/******************************************************************************************/

template <class O, class EM> template <class A>
bool JumpState<O, EM>::try_split(real r, A &&accept) {
    auto p = add_rates.find(r);
    emplace();
    auto &o = loops[p.first];
    bool ret = o.try_split(*this, back(loops), p.second, model,
        [&](auto b1, auto b2){return accept(StepProposal{true, o.index(), o.index(), b1, b2});});
    if (!ret) pop_back();
    return ret;
}

/******************************************************************************************/

template <class O, class EM> template <class A>
bool JumpState<O, EM>::try_join(real r, A &&accept) {
    auto mv = complexes.get_join_move(r, model);
    auto &o1 = loops[mv.o1], &o2 = loops[mv.o2];
    return loop_type::try_associate(*this, o1, o2, mv, model,
        [&](auto b1, auto b2){return accept(StepProposal{true, o1.index(), o2.index(), b1, b2});});
}

/******************************************************************************************/

template <class O, class EM> template <class A>
bool JumpState<O, EM>::try_merge(real r, A && accept) {
    auto &o = loops[del_rates.find(r).first];
    return o.try_merge(*this, model,
        [&](auto b1, auto b2){return accept(StepProposal{false, o.index(), o.index(), b1, b2});});
}

/******************************************************************************************/

template <class State, class F>
void for_all_moves(State const &w, F &&f) {
    for_all_joins(w, [&](ComplexJoinMove const &m){f(m.loc1.b, m.loc2.b, m.dE());});

    for (auto const &o : w) if (!o.is_root()) {
        auto bp = o.parent_base_pair();
        f(bp.first, bp.second, o.del_move.dE);
    }

    for (auto const &o : w) for (auto const &m : o.add_moves()) f(m.b1, m.b2, m.dE);
}

/******************************************************************************************/

}
