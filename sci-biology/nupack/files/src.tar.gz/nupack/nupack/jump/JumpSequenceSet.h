#pragma once

#include "Joiner.h"
#include "../loop/SequenceSet.h"
#include "../model/Move.h"
#include "../model/LazyMoveGen.h"
#include "../model/FullMoveGen.h"
#include "../standard/Variant.h"

namespace nupack {

enum class moves : int {full, lazy};
using MoveMethod = VariantEnum<moves>;

inline void render(Document &doc, Type<MoveMethod> t) {doc.type(t, "kmc.MoveMethod");}

/****************************************************************************************/

struct JumpSequenceSet : SequenceSet {
    struct Report {iseq shift; real dE; real rate;};

    /************************************************************************************/

    NUPACK_EXTEND_REFLECT(JumpSequenceSet, SequenceSet, energy, gen, joiner);

    /// Pair addition move generator
    Variant<FullMoveGen, LazyMoveGen> gen;
    /// Complex join generator
    Variant<ProductJoiner, False> joiner;
    /// Energy of this loop
    real energy = 0;

    JumpSequenceSet() = default;
    JumpSequenceSet(SequenceSet s, MoveMethod g) : SequenceSet(std::move(s)), gen(g) {}
    JumpSequenceSet(BaseIter b, MoveMethod g) : SequenceSet(b), gen(g) {}

    auto const & get_joiner() const {return std::get<ProductJoiner>(joiner);}
    bool can_join() const {return maybe_get<ProductJoiner>(joiner);}

    /************************************************************************************/

    auto total_add_rate() const {return fork(gen, [](auto const &g) {return g.total_rate();});}

    auto add_moves() const {return fork(gen, [](auto const &g) {return g.moves();});}

    auto n_add_moves() const {return fork(gen, [](auto const &g) {return len(g.moves());});}

    auto join_rates() const {return get_joiner().join_rates();}

    template <class ...Ts>
    auto choose_join(Ts &&...ts) const {return get_joiner().choose_loc(seqs, fw<Ts>(ts)...);}

    /// Return all of the locations that can form a specified base pair
    template <class ...Ts>
    auto join_locs(Ts &&...ts) const {return get_joiner().all_locs(seqs, fw<Ts>(ts)...);}

    /************************************************************************************/

    template <class EM>
    void update(EM const &);

    template <class EM>
    BasePairAddition choose_split(real r, EM const &em) const {
        return fork(gen, [&](auto const &g) {return g.choose(r, seqs, n, em);});
    }

    /************************************************************************************/

    template <class EM>
    auto split(BasePairAddition const &, JumpSequenceSet &, EM const &);

    template <class EM>
    iseq merge(JumpSequenceSet const &, iseq, iseq, EM const &);

    template <class EM>
    auto dissociate(JumpSequenceSet &, iseq, iseq, EM const &);

    /************************************************************************************/

    template <class EM>
    auto associate(JumpSequenceSet &, iseq, iseq, BaseIter, BaseIter, EM const &);

    template <class EM>
    static real get_deletion_energy(JumpSequenceSet const &, JumpSequenceSet const &,
                                     iseq, iseq, EM const &);
};

/****************************************************************************************/

template <class EM>
void JumpSequenceSet::update(EM const &em) {
    energy = em.loop_energy(seqs, n);
    fork(gen, [&](auto &g) {g.update(energy, seqs, n, em);});
    auto ptr = maybe_get<ProductJoiner>(joiner);
    if (exterior() && ptr) ptr->update(seqs, n, em);
}

/****************************************************************************************/

template <class EM>
real JumpSequenceSet::get_deletion_energy(JumpSequenceSet const &p, JumpSequenceSet const &k,
                                             iseq pk, iseq kp, EM const &em) {
    if (p.exterior() && k.exterior()) {
        auto seqs = get_split_seqs(p.vec(), k.vec(),
            static_cast<iseq>(p.nick()), static_cast<iseq>(k.nick()), pk, kp);
        return em.loop_energy(seqs.first, find_nick(seqs.first))
            + em.loop_energy(seqs.second, find_nick(seqs.second))
            - p.energy - k.energy - em.join_penalty();
    } else {
        auto seqs = merged_seqs(p.vec(), k.vec(), pk, kp);
        return em.loop_energy(seqs, find_nick(seqs)) - p.energy - k.energy;
    }
}

/****************************************************************************************/

template <class EM>
auto JumpSequenceSet::split(BasePairAddition const &m, JumpSequenceSet & d, EM const &em) {
    auto ret = SequenceSet::split(m, d);
    update(em); d.update(em);
    return ret;
}

/****************************************************************************************/

template <class EM>
iseq JumpSequenceSet::merge(JumpSequenceSet const &k, iseq pk, iseq kp, EM const &em) {
    auto ret = SequenceSet::merge(k, pk, kp); update(em); return ret;
}

/****************************************************************************************/

template <class EM>
auto JumpSequenceSet::dissociate(JumpSequenceSet &k, iseq pk, iseq kp, EM const &em) {
    auto ret = SequenceSet::dissociate(k, pk, kp);
    update(em); k.update(em);
    return ret;
}

/****************************************************************************************/

template <class EM>
auto JumpSequenceSet::associate(JumpSequenceSet & k, iseq ps, iseq ks, BaseIter pb, BaseIter kb, EM const &em) {
    auto ret = SequenceSet::associate(k, ps, ks, pb, kb);
    update(em); k.update(em);
    return ret;
}

/****************************************************************************************/

}
