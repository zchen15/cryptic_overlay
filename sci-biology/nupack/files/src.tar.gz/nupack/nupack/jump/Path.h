#pragma once
#include "Jump.h"

namespace nupack::kmc {

/******************************************************************************************/

// Precision issues occurred with real32
using Step = std::tuple<real64, std::uint32_t, std::uint32_t>;

/******************************************************************************************/

struct BasePairPath {
    vec<Step> steps;
    real64 time = 0;

    NUPACK_REFLECT(BasePairPath, steps, time);
};

void render(Document &, Type<BasePairPath>);

/******************************************************************************************/

/*
 * Class extending BasePairPath to include start and stop states
 */
struct Path : BasePairPath {
    using base_type = BasePairPath;
    State start, stop;
    NUPACK_EXTEND_REFLECT(Path, BasePairPath, start, stop);

    /// Call a functor on each intermediate PairList with its occupancy time
    template <class F>
    void visit(F &&f) const {
        auto p = start.pairs;
        for (auto const &s : steps) {
            f(p, third_of(s));
            p.toggle_pair(first_of(s), second_of(s));
        }
        NUPACK_REQUIRE(p, ==, stop.pairs);
    }

    /// Call a functor on the PairList that existed at each time given; times should be ascending
    template <class V, class F>
    void sample(V const &times, F &&f) const {
        auto p = start.pairs;
        real time = 0;
        auto it = steps.begin();
        izip(times, [&](auto i, auto const t) {
            for (; it != steps.end() && time < t; ++it) {
                time += third_of(*it);
                p.toggle_pair(first_of(*it), second_of(*it));
            }
            f(i, t, p);
        });
    }
};

void render(Document &, Type<Path>);

/******************************************************************************************/

struct RunOptions {
    MoveMethod method=moves::lazy;
    bool average = false;
    NUPACK_REFLECT(RunOptions, method, average);
};

/******************************************************************************************/

template <class State, class S, class A=AlwaysTrue, class RNG=decltype(StaticRNG) &>
auto augment_path(State &w, BasePairPath &p, S &&stop, A &&accept={}, RNG &rng=StaticRNG, RunOptions const &ops={}) {
    while(true) {
        for (auto i : range(1024 - len(p.steps) % 1024)) { // go until next multiple of 1024
            if (!(i % 16u)) throw_if_signal(); // Stop at a valid point if there is a system signal
            auto const t = ops.average ? w.timestep(False()) : w.timestep(rng);
            p.time += t;
            w.step(accept, rng); // Take a step
            p.steps.emplace_back(t, w.last_move.bp.first, w.last_move.bp.second);
            if (auto b = stop(w, t)) return b; // Check if we should stop
        }
        w.update_rates();
    }
}

/******************************************************************************************/

template <class State, class S, class A=AlwaysTrue, class RNG=decltype(StaticRNG) &>
Path sample_path(State w, Model<> const &model, S &&stop, A &&accept={}, RNG &rng=StaticRNG, RunOptions const &ops={}) {
    JumpState<> j(w.sys, w.pairs, ops.method, model);
    Path p;
    p.start = std::move(w);
    augment_path(j, p, fw<S>(stop), fw<A>(accept), rng, ops);
    p.stop = State(j.sys, j.pairs);
    return p;
}

/******************************************************************************************/

Cube<real> base_pair_time(Path const &p, uint power=0, bool relative=false);

Mat<real> structure_time(Path const &p, vec<PairList> const &pairs, uint power=0, bool relative=false);

/******************************************************************************************/

// template <bool Avg, class ...Args>
// auto runner(Args &&...args) {
//     return [&](auto &&w, auto &&s, auto &&...ts) {
//         return run_until<Avg>(fw<decltype(w)>(w), fw<decltype(s)>(s), std::forward_as_tuple(ts...), args...);
//     };
// }

// template <bool Avg=false, class State, class ...Args>
// auto pairs_runner(State w0, Args &&...args) {
//     return [&, w0=std::move(w0)](auto pairs, auto &&s, auto &&...ts) {
//         State w = w0.with_structure(std::move(pairs));
//         run_until<Avg>(w, fw<decltype(s)>(s), std::forward_as_tuple(ts...), args...);
//         return w.pairs;
//     };
// }

/******************************************************************************************/

}
