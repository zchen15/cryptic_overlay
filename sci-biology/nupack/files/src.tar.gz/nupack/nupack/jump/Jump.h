#pragma once
#include "JumpState.h"
#include "JumpLoop.h"
#include "JumpSequenceSet.h"
#include "../state/State.h"

namespace nupack {

/******************************************************************************************/

template <class T=real, class Y=vec<string>, class ...Ts>
auto jump_state(Y &&sys, PairList p, Ts &&...ts) {
    return JumpState<JumpLoop<>, Model<T>>(fw<Y>(sys), std::move(p), fw<Ts>(ts)...);
}

/******************************************************************************************/

}
