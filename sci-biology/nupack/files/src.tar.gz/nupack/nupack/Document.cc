#include <rebind/Document.h>
#include <boost/exception/diagnostic_information.hpp>
#include <boost/core/demangle.hpp>

namespace nupack {

/// Perform functions declared elsewhere one time; the order should reflect dependencies
void render_submodules(rebind::Document &doc) {
#   define NUPACK_TMP(F) void F(rebind::Document &); F(doc)
    NUPACK_TMP(render_constants);
    NUPACK_TMP(render_math);
    NUPACK_TMP(render_image);
    NUPACK_TMP(render_model);
    NUPACK_TMP(render_kmc);
    NUPACK_TMP(render_markov);
    NUPACK_TMP(render_thermo);
    NUPACK_TMP(render_loop_sampler);
    NUPACK_TMP(render_concentration);
    NUPACK_TMP(render_design);
    NUPACK_TMP(render_unmix);
    NUPACK_TMP(render_trace);
#   undef NUPACK_TMP
}

/******************************************************************************************/

/// Top level module initializer running at library load time
void write_document(rebind::Document &doc) {
    rebind::set_demangler(&boost::core::demangle);
    try {
        render_submodules(doc);
    } catch (...) {
        std::cerr << "C++ import failed:\n" << boost::current_exception_diagnostic_information() << std::endl;
        throw;
    }
}

/******************************************************************************************/

}

namespace rebind {

void init(Document &doc) {
    nupack::write_document(doc);
}

}