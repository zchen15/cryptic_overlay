/** \file PairList.h
 * @brief Simple vector wrapper containing the indices of which base each base is paired to
 */
#pragma once
#include "../standard/Vec.h"
#include "../types/IO.h"
#include "../iteration/Range.h"
#include "../algorithms/Operators.h"
#include "../algorithms/Utility.h"
#include "../reflect/Hash.h"

namespace nupack {

/******************************************************************************************/

using pair_data_type = vec<iseq>;

struct PairList : Indexable<PairList>, TotallyOrdered {
    using data_type = pair_data_type;
    using size_type = iseq;
    using value_type = value_type_of<data_type>;
    using iterator = iterator_of<data_type>;

    /************************************************************************************/

    PairList() = default;
    explicit PairList(usize s) : contents(s) {reset();}

    PairList(std::string_view s) : contents(io::to_pairs<data_type>(s)) {}
    PairList(char const *s) : contents(io::to_pairs<data_type>(s)) {}
    PairList(std::string const &s) : contents(io::to_pairs<data_type>(s)) {}

    PairList(data_type t) : contents(std::move(t)) {}

    template <class Iter>
    PairList(Iter b, Iter e) : contents(b, e) {}

    /************************************************************************************/

    bool operator<(PairList const &p) const {return contents < p.contents;}
    bool operator==(PairList const &p) const {return contents == p.contents;}
    auto hash() const {return hash_of(contents);}

    /************************************************************************************/

    data_type contents;
    NUPACK_REFLECT(PairList, contents);

    auto & iter() {return contents;}

    /************************************************************************************/

    template <class N=data_type> string dp(N && nicks={}) const {
        return len(nicks) ? io::to_dp(contents, nicks) : io::to_dp(contents);
    }

    /// Print with dot-parens -- for multistranded this won't put '+' in though
    friend std::ostream & operator<<(std::ostream &os, PairList const &p) {return os << "PairList('" << p.dp() << "')";}

    /// Delete all base pairs
    void reset() {std::iota(begin_of(contents), end_of(contents), 0);}
    bool empty() const {return contents.empty();}

    template <class...Ts> void resize(Ts &&...ts) {contents.resize(fw<Ts>(ts)...);}

    /************************************************************************************/

    void add_pair(size_type i, size_type j) {at(contents, i) = j; at(contents, j) = i;}

    /// Add base pair from i to j if it doesn't exist, delete it if it does exist
    void toggle_pair(size_type i, size_type j) {
        if (at(contents, i) == i) {at(contents, i) = j; at(contents, j) = i;}
                         else {at(contents, i) = i; at(contents, j) = j;}
    }

    operator data_type const & () const {return contents;}
    operator data_type () && {return std::move(contents);}

    /// returns if two subsequences of the pairlist are equivalent once offsets are subtracted
    bool submatch(cspan I, cspan J) const {
        if (len(I) != len(J)) return false;
        for (auto k : indices(I))
            if (at(contents, I[k]) + J[k] != at(contents, J[k]) + I[k]) return false;
        return true;
    }

    size_type operator^(PairList const &p) const {return hamming_distance(contents, p.contents);}

    /// Expects a list of strand lengths where the lengths exclude null bases
    PairList with_null_bases(small_vec<iseq> const &strand_lengths) const;

    /************************************************************************************/

    /// Call a functor with the indices of each base pair
    template <class F> void for_each_pair(F &&f) const {
        izip(contents, [&](auto i, auto j) {if (i < j) f(i, j);});
    }

    /// Number of base pairs
    size_type n_pairs() const {
        size_type out = 0;
        for_each_pair([&](auto, auto) {++out;});
        return out;
    }

    /// Append an independent PairList() to the end of this one
    void append(PairList const &p) {
        auto const n = len(contents);
        contents.reserve(n + len(p));
        for (auto i : p) contents.emplace_back(n + i);
    }

    void check_for_mismatches() const {
        for (auto i : indices(contents)) if (at(contents, at(contents, i)) != i)
            NUPACK_ERROR("Mismatched pairs", i, contents[contents[i]], contents[i]);
    }
};

void render(Document &doc, Type<PairList>);
std::optional<PairList> request(Type<PairList>, rebind::Variable const &r, rebind::Dispatch &msg);

/******************************************************************************************/

/// Call a functor with the indices of each pseudoknot in a PairList()
template <class P, class F>
void for_pseudoknots(P const &pairs, F &&f) {
    izip(pairs, [&](auto i, auto j) {
        for (auto k = i; k < j; ++k) if (pairs[k] > j) f(i, j, k, pairs[k]);
    });
}

/******************************************************************************************/

template <class V>
V rotated_pairing(V p, int offset) {
    auto n = std::size(p);
    for (auto &d: p) d = (d + n - offset) % n;
    std::rotate(begin_of(p), begin_of(p) + (offset % n), end_of(p));
    return p;
}

template <class V, class P>
std::size_t pairing_symmetry(V const &v, P const &pairs) {
    std::size_t out = 1, z = len(pairs);
    NUPACK_REQUIRE(sum(v, len), ==, len(pairs));
    prime_factorization(rotational_symmetry(v), [&](auto const n) {
        auto const s = sum(view(v, 0, len(v) / (out * n)), len);
        auto const b = std::begin(pairs), e = std::end(pairs);
        if (std::equal(b, e - s, b + s, e, [=](auto i, auto j) {return (i + s) % z == j;}) // pairs[:-shift] + shift == pairs[shift:])
         && std::equal(b, b + s, e - s, e, [=](auto i, auto j) {return (i + z - s) % z == j;})) // pairs[:shift] + (size - shift) == pairs[-shift:]
            out *= n;
    });
    return out;
}

template <class ...Ts>
PairList join_pairs(PairList p, Ts const &...ts) {NUPACK_UNPACK(p.append(ts)); return p;}

/******************************************************************************************/

/**
 * @brief Call a functor for a sequence of PairList() each of which only differs by one base pair from the last
 * @param a Beginning PairList() --> functor is not called on this one
 * @param b Ending PairList() --> functor is not called on this one
 * @param f functor
 * @return iseq number of base pair moves to get from a to b
 */
template <class F>
iseq for_pairlists_between(PairList a, PairList const &b, F &&f) {
    iseq n = 0;
    for (auto i : indices(a)) if (a[i] != i && a[i] != b[i]) {
        if (n++) f(a);
        a.toggle_pair(i, a[i]); // cleave conflicting pairs
    }
    for (auto i : indices(a)) if (a[i] != b[i]) {
        if (n++) f(a);
        a.toggle_pair(i, b[i]); // add missing pairs
    }
    return n;
}

/******************************************************************************************/

}
