#pragma once

#include "constraint_handler.h"
#include "named_spec.h"
#include "algorithms.h"
#include "sequence_utils.h"

#ifdef JSONCPP_FOUND
#include <json/json.h>
#endif

#include "adapter.h"

#include <vector>
#include <map>
#include <string>
#include <iostream>

namespace nupack {
namespace design {

struct NupackInvariants;

class SingleSequenceSpec : public NamedSpec {
    vec<int> nuc_ids;
    vec<int> domain_ids;

public:
    SingleSequenceSpec(string name, const vec<int> & nuc_ids) :
        NamedSpec(name, "seqspec"), nuc_ids(nuc_ids) {}
    void serialize(const NupackInvariants & invars, std::ostream & out) const;
    const string & get_name() const { return this->name; }
    const vec<int> & get_nuc_ids() const { return this->nuc_ids; }
    int size() const { return this->nuc_ids.size(); }
    const vec<int> & get_domain_ids() const { return this->domain_ids; }
    void set_domain_ids(const vec<int> & ids) { this->domain_ids = ids; }
};

// Contains the complete specification linking to underlying set of
// nucleotide assignment variables
class SequenceSpec {
protected:
    vec<int> nucleotides;
    vec<int> variables;

    vec<SingleSequenceSpec> domains;
    vec<SingleSequenceSpec> strands;

    std::map<string, int> domain_name_to_ind_map;
    std::map<string, int> strand_name_to_ind_map;

public:
    SequenceSpec() {}

    vec<int> get_strand_ids(vec<string> names);
    int get_strand_id(string names);

    void add_domain_by_constraints(string name, string nuc_cons,
                                   const NupackInvariants & invars);
    void add_domain_by_constraints(string name, vec<int> nuc_cons,
                                   const NupackInvariants & invars);
    void add_domain_by_nuc_ids(string name, vec<int> nucs);

    void add_strand_by_nuc_ids(string name, vec<int> nucs, vec<int> domain_ids = {});

    void add_strand_by_domains(string name, vec<string> names);
    void add_strand_by_domain_ids(string name, vec<int> dom_ids);

    void set_variable(int id, int var);

    const vec<SingleSequenceSpec> & get_domains() const { return this->domains; }
    const vec<SingleSequenceSpec> & get_strands() const { return this->strands; }
    const vec<int> & get_nucleotides() const { return this->nucleotides; }
    const vec<int> & get_variables() const { return this->variables; }

    const SingleSequenceSpec & get_domain(string name) const;
    const SingleSequenceSpec & get_strand(string name) const;
    const SingleSequenceSpec & get_element(string name) const;

    int get_specified_id(string name, const std::map<string, int> & map) const;
    int get_domain_id(string name) const {return get_specified_id(name, domain_name_to_ind_map); }
    int get_strand_id(string name) const {return get_specified_id(name, strand_name_to_ind_map); }

    const std::map<string, int> & get_strand_map() const {
        return this->strand_name_to_ind_map;
    }
    const std::map<string, int> & get_domain_map() const {
        return this->domain_name_to_ind_map;
    }

    string partially_specified_domain() const;

#ifdef JSONCPP_FOUND
    Json::Value make_json_strands(
        const vec<int> & nucs, const NupackInvariants & invars) const;
    Json::Value make_json_domains(
        const vec<int> & nucs, const NupackInvariants & invars) const;
#endif
};

struct Match {
    Match(string name, vec<double> mins, vec<double> maxes) : name(name), mins(mins), maxes(maxes) {}

    MatchConstraint make_match_constraint(const SequenceSpec &seqs, const string &sequence);

    string name;
    vec<double> mins;
    vec<double> maxes;
};

class MatchSpec : public NamedSpec {
    string seq;
    vec<Match> matches;

  public:
    MatchSpec(const string &name, const string &seq) : NamedSpec(name, "match_spec"), seq(seq) {}

    void add_match(const string &dom_name, const vec<double> &mins,
                   const vec<double> &maxes);

    vec<MatchConstraint> make_match_constraints(const SequenceSpec &seqs);
};

inline int SequenceSpec::get_specified_id(string name,
        const std::map<string, int> & map) const {
    auto it = map.find(name);
    if (contains_it(it, map)) return it->second;

    return -1;
}

}
}
