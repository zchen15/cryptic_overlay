
#include "physical_result.h"
#include "sequence_spec.h"

#include "design_debug.h"
#include "algorithms.h"

#include "adapter.h"

#include <sys/time.h>
#include <cfloat>
#include <sstream>
#include <algorithm>
#include <numeric>

namespace nupack {
namespace design {

void PhysicalResult::print_res_files(const PhysicalSpec & spec,
        const NupackInvariants & invars, string file_prefix) const {
    auto const & strucspecs = spec.get_strucs();
    for (auto i = 0; i < this->strucs.size(); i++) {
        strucs[i].print_strucfiles(strucspecs[i], invars, file_prefix);
    }
}


void PhysicalResult::serialize(const PhysicalSpec & spec,
        const NupackInvariants & invars,
        std::ostream & out,
        int indent,
        string prefix) const {
    string ind_str(indent, ' ');
    ind_str = prefix + ind_str;

    real root_time = this->get_eval_time();
    int n_on_targets = 0;
    int n_off_targets = 0;
    int n_orders = 0;

    for (auto const & struc : spec.get_strucs()) {
        if (struc.get_structures().size() > 0) n_on_targets++;
    }
    n_orders += spec.get_orders().size();
    n_off_targets = n_orders - n_on_targets;

    out << ind_str << "design properties:" << std::endl;
    out << ind_str << "    evaluation time: " << flt_format << root_time << std::endl;
    out << ind_str << "    on-targets: " << n_on_targets << std::endl;
    out << ind_str << "    off-targets: " << n_off_targets << std::endl;
    out << ind_str << "physical results:" << std::endl;


    // previously separate function
    auto const & ss = spec.get_strucs();
    auto const & ts = spec.get_tubes();

    indent = indent + 4;
    ind_str = string(indent, ' ');
    ind_str = prefix + ind_str;
    string name_ind(indent, ' ');
    if (indent > 2) name_ind = prefix + string(indent - 2, ' ') + "- ";

    out << name_ind << "name: " << spec.get_name() << std::endl;

    if (this->strucs.size() > 0) {
        out << ind_str << "structures: " << std::endl;

        // Serialize structures
        auto struc_it = this->strucs.cbegin();
        auto ss_it = ss.cbegin();
        for (; struc_it != this->strucs.end() && ss_it != ss.end(); ++struc_it, ++ss_it)
            struc_it->serialize(*ss_it, invars, out, indent + 4, prefix);

    } else {
        out << ind_str << "structures: []" << std::endl;
    }

    if (this->tubes.size() > 0) {
        out << ind_str << "tubes: " << std::endl;

        // Serialize tubes
        auto tube_it = tubes.cbegin();
        auto ts_it = ts.cbegin();
        for (; tube_it != this->tubes.end() && ts_it != ts.end(); ++tube_it, ++ts_it) {
            tube_it->serialize(*ts_it, ss, spec.get_ord_struc_map(), invars,
                               out, indent + 4, prefix);
        }
    } else {
        out << ind_str << "tubes: []" << std::endl;
    }
}


void PhysicalResult::replace_node(const PhysicalResult & other, const PhysicalSpec & spec,
                                  int i, int k, const NupackInvariants & invars) {
    NUPACK_CHECK(this->strucs.size() == other.strucs.size(),
                 "Structure sizes don't match in replace node");
    NUPACK_CHECK(this->tubes.size() == other.tubes.size(),
                 "Tube sizes don't match in replace node");
    NUPACK_CHECK(i < this->strucs.size(), to_string(i)
                 + " is not a valid structure index " + "# strucs: "
                 + to_string(this->strucs.size()));

    this->strucs[i].replace_node(other.strucs[i], k, invars);

    auto const & order_to_struc = spec.get_ord_struc_map();
    auto const & tubes = spec.get_tubes();
    for (auto i_tube = 0; i_tube < this->tubes.size(); i_tube++) {
        NUPACK_DEBUG_PRINT("Evaluating tube: " << to_string(i_tube));
        this->tubes[i_tube].evaluate(this->strucs, this->orders, order_to_struc, tubes[i_tube], invars);
    }
}


real PhysicalResult::get_eval_time() const {
    real tot_time = accumulate(orders, (real)(0.0),
        [](const decltype(tot_time) & t, decltype(orders)::const_reference ord) {
            return ord.get_evaluated() ? t + ord.get_eval_time() : 0;
        }
    );
    tot_time = accumulate(strucs, tot_time,
        [](const decltype(tot_time) & t, decltype(strucs)::const_reference str) {
            return t + str.get_eval_time();
        }
    );

    return tot_time;
}


void PhysicalResult::evaluate(const SequenceState & seqs, const PhysicalSpec & spec,
                              const NupackInvariants & invars) {
    auto const & strucs = spec.get_strucs();
    auto const & tubes = spec.get_tubes();
    auto const & orders = spec.get_orders();
    auto const & order_to_struc = spec.get_ord_struc_map();

    int n_strucs = strucs.size();
    int n_orders = orders.size();
    int n_tubes = tubes.size();

    this->strucs.resize(n_strucs);
    this->orders.resize(n_orders);
    this->tubes.resize(n_tubes);

    Local().spread(range(n_strucs), 1, [&] (auto const &, auto const &, auto i) {
        this->strucs[i].evaluate(seqs, strucs[i], invars);
    });

    bool eval_off_targets = spec.eval_off_targets();
    Local().spread(range(n_orders), 1, [&] (auto const &, auto const &, auto i) {
        if (eval_off_targets && -1 == order_to_struc[i]) {
            this->orders[i].evaluate(seqs, orders[i], invars);
        } else {
            this->orders[i].clear_evaluated();
        }
    });

    Local().spread(range(n_tubes), 1, [&] (auto const &, auto const &, auto i) {
        this->tubes[i].evaluate(this->strucs, this->orders,
                                order_to_struc, tubes[i], invars);
    });
}


int PhysicalResult::get_max_depth() const {
    if (strucs.size() == 0) return 0;
    using str_type = typename decltype(strucs)::value_type;
    return std::max_element(strucs.begin(), strucs.end(),
                            smaller_depth<str_type>)->get_max_depth();
}


}
}
