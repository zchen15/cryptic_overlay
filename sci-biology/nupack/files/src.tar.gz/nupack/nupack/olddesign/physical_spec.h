#pragma once

#include "named_spec.h"
#include "nupack_invariants.h"

#include "structure_spec.h"
#include "tube_spec.h"

#include "adapter.h"

#ifdef JSONCPP_FOUND
#include <json/json.h>
#endif

#include <vector>
#include <string>
#include <utility>

namespace nupack {
namespace design {


// Forward declare these so we can use them during decomposition
class PhysicalResult;
class SequenceState;

class PhysicalSpec : public NamedSpec {
    bool off_targets;

    vec<TubeSpec> tubes;
    vec<StructureSpec> strucs;
    vec<OrderSpec> orders;

    vec<int> struc_ord_map;
    vec<int> ord_struc_map;

public:
    PhysicalSpec() : NamedSpec("-default", "specset"), off_targets(false) {}

    void add_tube(const TubeSpec & spec) { this->tubes.push_back(spec); }
    std::pair<int, int> add_structure(const StructureSpec & spec);

    void enumerate_off_targets(const std::map<string, int> & strands);
    void compute_target_matrices() { for (auto & s : strucs) s.compute_target_matrix(); }

    StructureSpec & get_struc(string name);
    TubeSpec & get_tube(string name);

    std::pair<int, int> get_struc_id(string name) const;
    int get_tube_id(string name) const;

    const vec<StructureSpec> & get_strucs() const { return this->strucs; }
    const vec<OrderSpec> & get_orders() const { return this->orders; }

    const vec<int> & get_struc_ord_map() const { return this->struc_ord_map; }
    const vec<int> & get_ord_struc_map() const { return this->ord_struc_map; }
    const vec<TubeSpec> & get_tubes() const { return this->tubes; }

    int get_max_depth() const;

    void decompose(const NupackInvariants & invars) { for (auto & s : strucs) s.decompose(invars); }
    void decompose_ppair(int i, int k, const PhysicalResult & res,
                         const SequenceState & seqs, const NupackInvariants & invars);
    void add_off_target(int i, const SequenceSpec & seqs);

    PhysicalSpec get_depth(int depth, bool off_targets=false) const;
    bool eval_off_targets() const { return this->off_targets; }

#ifdef JSONCPP_FOUND
    Json::Value make_json_structures(const SequenceSpec & seqs,
                                     const NupackInvariants & invars) const;
    Json::Value make_json_tubes(const NupackInvariants & invars) const;
#endif
};

}
}
