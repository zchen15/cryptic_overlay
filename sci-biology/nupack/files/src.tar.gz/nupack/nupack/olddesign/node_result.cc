#include "node_result.h"
#include "sequence_state.h"
#include "sequence_utils.h"
#include "design_debug.h"
#include "algorithms.h"
#include "wrapper.h"

#include <memory>

namespace nupack {
namespace design {

int NodeResult::get_max_depth() const {
    if (children.size() == 0) return 0;
    return (*std::max_element(children.begin(), children.end(),
                              smaller_depth<NodeResult>)).get_max_depth() + 1;
}

real NodeResult::merge_pfuncs(const NodeResult & left, const NodeResult & right, const NupackInvariants & invars) {
    auto split_len = (invars.include_dummies) ? invars.H_split : 0;
    auto i = right.to_full[split_len];
    auto j = right.to_full[right.eval_sequence.size() - split_len - 1];
    auto d = i - 1;
    auto e = j + 1;
    auto a0 = left.eval_sequence[left.native_index(d)];
    auto a1 = right.eval_sequence[split_len];
    auto b0 = right.eval_sequence[right.eval_sequence.size() - split_len - 1];
    auto b1 = left.eval_sequence[left.native_index(e)];

    static auto const mod = model(invars);
    using SequenceUtils::nuc_to_char;
    Sequence first;
    first.push_back(Base(nuc_to_char(a0, invars.material)));
    first.push_back(Base(nuc_to_char(b1, invars.material)));

    Sequence second;
    second.push_back(Base(nuc_to_char(a1, invars.material)));
    second.push_back(Base(nuc_to_char(b0, invars.material)));

    // Sequence second = {Base(nuc_to_char(a1, invars.material)), nuc_to_char(b0, invars.material)};
    real int_ene = mod.interior_energy(first, second);

    // real int_ene = HelixEnergy(a0, b1, a1, b0);
    return left.get_pfunc() + right.get_pfunc() + (-int_ene / (Kb * invars.temperature));
}

void NodeResult::replace_node(const NodeResult & other, int k, const NupackInvariants & invars) {
    int num_children = get_n_children();
    int other_num_children = other.get_n_children();
    int c_k = k;
    if (other_num_children == 0 || num_children == 0) {
        NUPACK_CHECK(k == 0, "Reached leaf with child index: " + to_string(other_num_children) +
                     ", " + to_string(num_children) + " k = " + to_string(k));
        NUPACK_DEBUG_PRINT("Current pfunc: " << -Kb * invars.temperature * pfunc_corrected);
        NUPACK_DEBUG_PRINT("Other pfunc: " << -Kb * invars.temperature * other.pfunc_corrected);
        *this = other;
    } else {
        NUPACK_CHECK(other_num_children == num_children,
                     "Alternate decomposition must be sourced from the same tree");
        for (auto i = 0; i < other_num_children; ++i) {
            auto child_n_leaves = other.children[i].get_n_leaves();
            child_n_leaves = std::min(child_n_leaves, children[i].get_n_leaves());
            if (c_k >= child_n_leaves) {
                c_k -= child_n_leaves;
            } else {
                children[i].replace_node(other.children[i], c_k, invars);
                c_k = -1;
                break;
            }
        }

        pfunc_corrected = -1.0 * std::numeric_limits<real>::infinity();
        for (auto it = children.begin(); it != children.end(); it += 2) {
            auto merged = merge_pfuncs(*(it), *(it + 1), invars);
            pfunc_corrected = log_sum_exp(pfunc_corrected, merged);
            NUPACK_CHECK(it != children.end(), "children incorrectly formatted.");
        }
        if (c_k < 0) {
            NUPACK_DEBUG_PRINT("Merged 1: " << -Kb * invars.temperature * pfunc_corrected)
        }
    }
}

int NodeResult::get_n_leaves() const {
    if (children.size() == 0) return 1;
    using child = typename decltype(children)::value_type;
    return accumulate(children, 0, [](const int a, const child & b) {
        return a + b.get_n_leaves();
    });
}

int NodeResult::native_index(int i) const {
    // Native indices are sorted by construction => binary search
    auto it = std::lower_bound(to_full.begin(), to_full.end(), i);
    NUPACK_CHECK(it != to_full.end(), "Error finding native index");
    return it - to_full.begin();
}

// TODO make NodeSpec::get_children() public
void NodeResult::init(const NodeSpec & spec) {
    clear();
    for (auto i = 0; i < spec.get_n_children(); ++i) {
        auto tmp = NodeResult();
        tmp.init(spec.get_child(i));
        children.emplace_back(tmp);
    }
}

real NodeResult::evaluate_dummy_pfuncs(const NodeSpec & spec, const StructureSpec & struc, const NupackInvariants & invars) {
    static auto const mod = model(invars);
    int n_nucs = 2 * (invars.H_split + 1);
    auto const & assumed = spec.get_assume();
    const vec<int> & sequence = this->eval_sequence;
    vec<int> to_node = spec.get_to_node(struc, invars);

    // One for break, one for termination
    vec<int> curseq(n_nucs + 2, 0);
    real res = 0;

    // TODO make the dummy sequences, should be from assumed_i to assumed_i + H_split then
    // strand break, then assumed_j - H_split + 1 through assumed_j evaluate the partition function
    // and take QB of the upper right hand corner

    if (invars.include_dummies) {

    } else {
        for (auto & a : assumed) {
            if (sequence[to_node[a.first]] != BASE_C && sequence[to_node[a.second]] != BASE_C) {
                auto AT_penalty = mod.terminal_penalty(Base::from_index(sequence[to_node[a.first]]),
                                                       Base::from_index(sequence[to_node[a.second]]));
                res += (-AT_penalty / (Kb * invars.temperature));
            }
        }
    }

    return res;
}


void NodeResult::evaluate_leaf(const NodeSpec & spec, const SequenceState& seqs,
                               const StructureSpec & strucspec, const StructureResult & struc,
                               const NupackInvariants & invars) {
    real bonus = invars.dG_clamp;
    real start_time = get_current_time();
    int j_nuc;
    vec<int> to_node = spec.get_to_node(strucspec, invars);
    auto const & strucs = strucspec.get_structures();

    // Set the permanent info on the node
    this->nuc_ids = spec.get_nuc_ids(strucspec, invars);
    this->eval_sequence = seqs.get_sequence(this->nuc_ids);
    this->breaks = spec.get_breaks(strucspec, invars);
    this->to_full = spec.get_native_map(strucspec, invars);
    this->native = spec.get_native(strucspec, invars);

    int n_nucs = this->eval_sequence.size();
    NUPACK_CHECK((int)this->to_full.size() == n_nucs,
                 "to_full size does not match eval_sequence size");

    // Construct eval sequence with breaks
    vec<int> fullseq;
    auto i_nuc = 0;
    for (auto & br : this->breaks) {
        fullseq.insert(fullseq.end(), this->eval_sequence.begin() +
                       i_nuc, this->eval_sequence.begin() + br);
        fullseq.push_back(STRAND_PLUS);
        i_nuc = br;
    }
    int n_brs = this->breaks.size();
    if (n_brs > 0) {
        fullseq.insert(fullseq.end(), this->eval_sequence.begin() +
                       this->breaks[n_brs - 1], this->eval_sequence.end());
    } else {
        fullseq.insert(fullseq.end(), this->eval_sequence.begin(),
                       this->eval_sequence.end());
    }
    fullseq.push_back(-1);
    NUPACK_CHECK(fullseq.size() == n_brs + 1 + eval_sequence.size(),
                 "Fullseq size: " + to_string(fullseq.size()) + " evalseq size: "
                 + to_string(eval_sequence.size()) + " n breaks: " + to_string(n_brs));

    vec<real> pp((n_nucs + 1) * n_nucs, 0.0);

    auto const & assumed = spec.get_assume();
    real pfunc = 0;
    if (invars.include_dummies) {

    } else {
        vec<real> bonuses(n_nucs * n_nucs, 1);
        real bonus_per = bonus;
        real total_bonus = 1.0;
        for (auto & a : assumed) {
            i_nuc = to_node[a.first];
            auto j_nuc = to_node[a.second];
            if (!(i_nuc < j_nuc)) std::swap(i_nuc, j_nuc);
            bonuses[i_nuc * n_nucs + j_nuc] *= std::exp(-bonus_per / (Kb * invars.temperature));
            total_bonus *= std::exp(-bonus_per / (Kb * invars.temperature));
        }
        pfunc = pfuncFullWithBonuses(fullseq, invars, bonuses, pp);
        pfunc -= std::log(total_bonus);
    }

    this->ppairs.clear();
    for (i_nuc = 0; i_nuc < n_nucs; ++i_nuc) {
        if (this->native[i_nuc]) {
            vec<bool> saved_inds(n_nucs + 1, false);
            for (auto i_str = 0; i_str < strucs.size(); ++i_str) {
                auto m_j_nuc = strucs[i_str][to_full[i_nuc]];
                if (m_j_nuc >= 0) {
                    j_nuc = to_node[m_j_nuc];
                    if (j_nuc >= 0) saved_inds[j_nuc] = true;
                } else {
                    saved_inds[n_nucs] = true;
                }
            }
            for (j_nuc = 0; j_nuc < n_nucs; ++j_nuc) {
                if (this->native[j_nuc]) {
                    if (pp[i_nuc * (n_nucs + 1) + j_nuc] > invars.min_ppair
                            || saved_inds[j_nuc]) {
                        this->ppairs.push_back(to_full[i_nuc], to_full[j_nuc],
                                               pp[i_nuc * (n_nucs + 1) + j_nuc]);
                    }
                }
            }
            if (pp[i_nuc * (n_nucs + 1) + n_nucs] > invars.min_ppair
                    || saved_inds[n_nucs]) {
                this->ppairs.push_back(to_full[i_nuc], -1,
                                       pp[i_nuc * (n_nucs + 1) + j_nuc]);
            }
        }
    }

    real min_ppair = 1.0;
    for (auto & a : assumed) {
        auto i_nuc = to_node[a.first];
        auto j_nuc = to_node[a.second];
        auto ppair = pp[i_nuc * (n_nucs + 1) + j_nuc];
        min_ppair = std::min(min_ppair, ppair);
    }
    min_ppair = std::max<real>(min_ppair, 0.0001);

    pfunc += std::log(min_ppair);
    real dummy_pfuncs = this->evaluate_dummy_pfuncs(spec, strucspec, invars);
    real orig_pfunc = pfunc;
    if (dummy_pfuncs < 0.0 && invars.include_dummies) dummy_pfuncs = 1.0;
    pfunc = orig_pfunc - dummy_pfuncs;
    this->pfunc_corrected = pfunc;
    if (!(pfunc > -1.0 * std::numeric_limits<real>::infinity())) {
        NUPACK_DEBUG_PRINT("PFUNC: " << exp_format << orig_pfunc);
        NUPACK_DEBUG_PRINT("DUMMY: " << exp_format << dummy_pfuncs);
    }

    real end_time = get_current_time();
    this->eval_time = end_time - start_time;
}

void NodeResult::evaluate(const NodeSpec & spec, const SequenceState & seqs,
                          const StructureResult & struc, const StructureSpec & strucspec,
                          const NupackInvariants & invars) {
    int n_children = this->children.size();
    if (n_children != spec.get_n_children()) {
        this->clear();
        this->init(spec);
        n_children = this->children.size();
    }

    if (n_children == 0) {
        vec<int> nuc_ids = spec.get_nuc_ids(strucspec, invars);
        vec<int> breaks = spec.get_breaks(strucspec, invars);
        vec<int> eval_seq = seqs.get_sequence(nuc_ids);
        if (eval_seq != this->eval_sequence || breaks != this->breaks ||
                nuc_ids != this->nuc_ids) {
            this->evaluate_leaf(spec, seqs, strucspec, struc, invars);
        }
    } else {
        this->eval_time = 0;
        for (auto i = 0; i < n_children; ++i) {
            this->children[i].evaluate(spec.get_child(i), seqs, struc,
                                       strucspec, invars);
        }
        this->pfunc_corrected = -1.0 * std::numeric_limits<real>::infinity();
        for (auto i = 0; i < n_children; i += 2) {
            auto merged = merge_pfuncs((this->children[i]), (this->children[i + 1]), invars);
            this->pfunc_corrected = log_sum_exp(this->pfunc_corrected, merged);
        }
    }

    this->to_full = spec.get_native_map(strucspec, invars);
    this->nuc_ids = spec.get_nuc_ids(strucspec, invars);
    this->breaks = spec.get_breaks(strucspec, invars);
    this->eval_sequence = seqs.get_sequence(nuc_ids);
}

void NodeResult::serialize(std::ostream & out, int indent, const string & prefix, int & id) const {
    string ind_str(indent, ' ');
    ind_str = prefix + ind_str;
    int n_tot = *std::max_element(to_full.begin(), to_full.end());
    string outstr(n_tot + 1, ' ');
    string ids("0123456789abcdefghijklmnopqrstuvwxyz");
    auto id_char = ids[id % ids.size()];
    for (auto tf : to_full) outstr[tf] = id_char;
    out << ind_str << outstr << std::endl;

    ++id;
    if (this->children.size() > 0) {
        for (auto & c : children) c.serialize(out, indent, prefix, id);
    }
}

real NodeResult::collect_eval_times() const {
    if (this->children.size() == 0) return this->eval_time;

    real ret = 0.0;
    for (auto & c : children) ret += c.collect_eval_times();
    return ret;
}

PairProbs NodeResult::collect_pair_probs(const NupackInvariants & invars) const {
    if (this->children.size() == 0) return this->ppairs;

    PairProbs ppairs_tot;
    real pfunc = -1.0 * std::numeric_limits<real>::infinity();
    for (auto i = 0; i < this->children.size(); i += 2) {
        real cur_pfunc = merge_pfuncs((this->children[i]),
                                      (this->children[i + 1]), invars);
        if (cur_pfunc > 0) {
            PairProbs ppairs1 = this->children[i].collect_pair_probs(invars);
            PairProbs ppairs2 = this->children[i + 1].collect_pair_probs(invars);
            ppairs1.merge(ppairs2, 1.0, 1.0);
            auto other_scale = std::exp(cur_pfunc - log_sum_exp(cur_pfunc, pfunc));
            auto this_scale = std::exp(pfunc - log_sum_exp(cur_pfunc, pfunc));
            ppairs_tot.merge(ppairs1, other_scale, this_scale);
            pfunc = log_sum_exp(pfunc, cur_pfunc);
        }
    }
    return ppairs_tot;
}

void NodeResult::clear_children() { children.clear(); }

void NodeResult::clear() {
    clear_children();
    this->eval_sequence.clear();
    this->nuc_ids.clear();
    this->to_full.clear();
    this->breaks.clear();
    this->nuc_defects.clear();
    this->ppairs.clear();
    this->pfunc_corrected = -1.0 * std::numeric_limits<real>::infinity();
}

}
}
