#pragma once

#include "pair_probabilities.h"
#include "physical_spec.h"

#include <vector>
#include <string>
#include <memory>

namespace nupack {
namespace design {

class NodeResult;
class StructureSpec;
class StructureResult;

/**
  * This class is used to build the decomposition tree for a single complex
  * the leaf nodes are used to perform the pair probability and partition
  * function evaluations. Parental nodes recursively merge the resulting
  * leaf properties to estimate the root-node properties.
  */

using ChildPair = std::pair<NodeResult, NodeResult>;
class NodeResult {
    vec<int> eval_sequence;
    vec<int> nuc_ids;
    vec<int> to_full;
    vec<int> breaks;
    vec<bool> native;
    vec<real> nuc_defects;

    PairProbs ppairs;
    real pfunc_corrected;
    real eval_time;

    void copy(const NodeResult & other);

protected:
    vec<NodeResult> children;
    vec<ChildPair> paired_children;
    int native_index(int i) const;
    void clear();
    void clear_children();

public:
    NodeResult() {}

    real get_pfunc() const { return pfunc_corrected; }

    real collect_eval_times() const;
    PairProbs collect_pair_probs(const NupackInvariants & invars) const;
    void map_defects(vec<real> &nuc_defects);

    real evaluate_dummy_pfuncs(const NodeSpec & spec, const StructureSpec & struc, const NupackInvariants & invars);
    void evaluate_leaf(const NodeSpec & spec, const SequenceState& seqs,
            const StructureSpec & strucspec, const StructureResult & strucres, const NupackInvariants & invars);
    void evaluate(const NodeSpec & spec, const SequenceState & seqs,
            const StructureResult & struc, const StructureSpec & strucspec, const NupackInvariants & invars);
    void init(const NodeSpec & spec);
    void serialize(std::ostream & out, int indent, const string & prefix, int & id) const;

    int get_n_leaves() const;
    int get_n_children() const { return children.size(); }

    void replace_node(const NodeResult & other, int k, const NupackInvariants & invars);

    /* Static utilities */
    static real merge_pfuncs(const NodeResult & left, const NodeResult & right, const NupackInvariants & invars);
    int get_max_depth() const;

    friend class NodeSpec;
};

}
}
