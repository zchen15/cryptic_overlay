#pragma once

#include "eval_result.h"

#include <vector>

namespace nupack {
namespace design {
struct DesignSpec;

class DesignResult {
    using Tabu = vec<vec<std::pair<int, int> > >;
    Tabu tabu;

public:

    void init_random(const DesignSpec & spec);

    bool is_tabu(const vec<int> & vars);
    void add_tabu(const vec<int> & vars);
    void clear_tabu() { this->tabu.clear(); }

    vec<std::pair<int, int> > get_mutations(const vec<int> & vars);

    EvalResult eval;
    vec<real> objectives;
    vec<bool> satisfied;
};

}
}
