
#include "sys/time.h"

#include "design_spec.h"
#include "design_debug.h"
#include "pathway_utils.h"
#include "physical_spec.h"
#include "algorithms.h"

#include <iomanip>

namespace nupack {
namespace design {

real get_current_time() {
    real time = 0;
    timeval timev;
    gettimeofday(&timev, NULL);
    time = timev.tv_sec + 1e-6 * timev.tv_usec;
    return time;
}

int sample_weighted_int(const vec<real> & weights) {
    real tot_weight = sum(weights);
    real stop = random_float() * tot_weight;
    return find_cumulative(weights, stop).first - begin_of(weights);
}

}
}
