#include "wrapper.h"

#include "sequence_utils.h"
#include "adapter.h"
#include "../execution/Local.h"
#include "../thermo/Engine.h"
#include "../thermo/CachedModel.h"
#include "../state/State.h"

namespace nupack {
namespace design {

Model<> const & model(NupackInvariants const &invars) {
    static ModelConditions conditions{invars.temperature, invars.sodium, invars.magnesium};

    string name;
    switch (invars.material) {
        case DNA: {name = "dna04"; break;}
        case RNA37: {name = "rna06"; break;}
        case USE_SPECIFIED_PARAMETERS_FILE: {name = invars.material_string; break;}
        default: {name = "rna95"; break;}
    }

    static ParameterFile parameters(name);
    static Model<real> mod{invars.ensemble, parameters, conditions};
    return mod;
}

real pfuncFull(vec<int> & seq, NupackInvariants const &invars) {
    static thermo::CachedModel mod64(thermo::PF(), Model<real>(model(invars)));
    static thermo::CachedModel mod32(thermo::PF(), Model<real32>(model(invars)));
    mod64.distinguishable = true;
    mod32.distinguishable = true;

    // static auto cache = map_variant(mod.energy_model.ensemble_type(), [](auto d) {
    //     return thermo::Cache<3, decltype(d), overflow<real>>(TotalRAM / 2);
    // });

    string sequence = SequenceUtils::nuc_to_str(seq);
    sequence.pop_back();

    return thermo::dynamic_program<3, 0, 1, 1>(Local(), to_sequences(sequence), std::tie(mod64, mod32, mod64));
    // return fork(cache, [&](auto &c) {
    //      return thermo::dynamic_program<3, 1>(Local(), to_sequences(sequence), mod, c);
    // });
}

real pfuncFullWithBonuses(vec<int> & seq, NupackInvariants const &invars,
                                 vec<real> &bonuses, vec<real> &pp) {
    static thermo::CachedModel mod64(thermo::PF(), Model<real>(model(invars)));
    static thermo::CachedModel mod32(thermo::PF(), Model<real32>(model(invars)));
    mod64.distinguishable = true;
    mod32.distinguishable = true;

    auto str_seq = SequenceUtils::nuc_to_str(seq);
    str_seq.pop_back();
    auto sequences = to_sequences(str_seq);

    auto pairing = [&, n=sum(sequences, len)](auto i, auto j, bool can_pair, auto const & A,
                auto const &, auto const & s, auto const &model, auto && recursion) {
        i = (i + s.offset) % n;
        j = (j + s.offset) % n;
        value_type_of<decltype(model)> bonus = bonuses[min(i, j) * n + max(i, j)];
        return !can_pair ? A.zero() : A.maybe() & A.product(recursion(), bonus);
    };

    auto intermediate = thermo::pair_probability<3, 0, 1, 1>(Local(), sequences, std::tie(mod64, mod32, mod64), False(), {}, pairing);
    auto & pair_probs = intermediate.first;

    auto pp2 = [&](auto i, auto j) -> real & { return pp[i * (len(pair_probs) + 1) + j]; };

    for (auto i : indices(pair_probs))
        for (auto j : range(i + 1, len(pair_probs)))
            pp2(i, j) = pp2(j, i) = *pair_probs(i, j) / bonuses[i * len(pair_probs) + j];

    for (auto i : indices(pair_probs)) {
        auto accum = 1.0;
        for (auto j : indices(pair_probs)) if (i != j) accum -= pp2(i, j);
        pp2(i, len(pair_probs)) = accum;
        pp2(i, i) = 0.0;
    }
    return intermediate.second;
}

}
}
