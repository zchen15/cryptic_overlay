#pragma once

#include "nupack_invariants.h"
#include "../thermo/CachedModel.h"

namespace nupack {
namespace design {

Model<> const & model(NupackInvariants const &invars);

real pfuncFull(vec<int> & seq, NupackInvariants const &invars);

real pfuncFullWithBonuses(vec<int> & seq, NupackInvariants const &invars,
                          vec<real> &bonuses, vec<real> &pp);

}
}
