#pragma once

#include "physical_spec.h"
#include "sequence_spec.h"

#include <vector>
#include <string>
#include <memory>


namespace nupack {
namespace design {

class SequenceSpec;
class SingleSequenceSpec;
/**
 * This class holds a fully defined sequence for a domain or strand
 */
class SingleSequenceState {
    vec<int> nucs;
    vec<int> nuc_ids;

public:

    SingleSequenceState() {}
    SingleSequenceState(const vec<int> & nucs,
                        const SingleSequenceSpec & nuc_ids) {
        set_seqs(nucs, nuc_ids);
    }

    void serialize(const SingleSequenceSpec & spec,
                   const NupackInvariants & invars, std::ostream & out) const;
    void set_seqs(const vec<int> & nucs,
                  const SingleSequenceSpec & nuc_ids);

    const vec<int> & get_nuc_ids() const { return this->nuc_ids; }
    const vec<int> & get_nucs() const { return this->nucs; }
};

/**
 * This class holds a fully defined sequence for a set of domains
 * and strands.
 */
class SequenceState {
    void fill_in_sequences(const SequenceSpec & spec);

    vec<int> variables;
    vec<int> nucleotides;
    vec<SingleSequenceState> domains;
    vec<SingleSequenceState> strands;

public:
    SequenceState() {};

    // int init_random(const SequenceSpec & spec);
    const vec<int> & get_variables() const { return this->variables; }
    void set_variables(const vec<int> & vars, const SequenceSpec & spec);

    void serialize(const SequenceSpec & spec,
                   const NupackInvariants & invars, std::ostream & out,
                   int indent = 0, string prefix = "") const;

    const vec<SingleSequenceState> & get_strands() const { return this->strands; }

    vec<int> get_sequence(const vec<int> & nuc_ids) const;

    int n_nucs() const;

    static int random_nucleotide(int con, int cur);
    static vec<int> random_nucleotides(const vec<int> & nucleotides);
};

}
}
