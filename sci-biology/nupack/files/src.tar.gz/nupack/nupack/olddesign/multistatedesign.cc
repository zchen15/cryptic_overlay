
#include <tclap/CmdLine.h>

#include "designer.h"
#include "design_spec.h"
#include "design_result.h"
#include "pathway_input.h"

#ifdef NUPACK_MPI
#include <mpi.h>
#endif

#include <fstream>
#include <list>
#include <sys/time.h>

using nupack::real;
using nupack::string;
using nupack::print;

int main(int argc, char ** argv) {
    int rval = 0;

    try {
        string filename;
        bool _nodesign = false;
        bool _drawjson = false;
        bool _prettyjson = false;
        bool _default_stops = false;
        bool _ppairsopt = false;
        bool _jsonopt = false;
        bool _print_seed = false;

        try {
            TCLAP::CmdLine cmds(
                "multitubedesign is the multi-tube design algorithm from NUPACK.  "
                "It allows linked optimization of test tube and structural "
                "ensemble defects under a variety of sequence constraints.  "
                "See the user guide for further information",
                ' ', nupack::Version);

            TCLAP::SwitchArg nodesign("n", "nodesign",
                                      "Don't design (just parse) and output any preliminary results", false);
            TCLAP::SwitchArg ppairsopt("p", "ppairs",
                                       "print ppairs file for each structure", false);
            TCLAP::SwitchArg jsonopt("", "strucjson",
                                     "print json file for each structure", false);
            TCLAP::SwitchArg default_stops("", "addstops",
                                           "Automatically set default stop conditions for"
                                           " structures and tubes without a stop condition. "
                                           "(typically 1%)", false);
            TCLAP::SwitchArg print_seed("s", "print_seed",
                                        "Print out the random seed for reproducibility "
                                        "at the start of design.", false);
            TCLAP::UnlabeledValueArg<string> file_arg("input", "script input file (.np)",
                    true, "",
                    "input script");
#ifdef JSONCPP_FOUND
            TCLAP::SwitchArg drawjson("j", "drawjson",
                                      "Output a json summary file for the specification", false);
            TCLAP::SwitchArg prettyjson("", "prettyjson",
                                        "Output a pretty-printed json summary of the specification "
                                        "(overrides drawjson)", false);

            cmds.add(drawjson);
            cmds.add(prettyjson);
#endif
            cmds.add(ppairsopt);
            cmds.add(jsonopt);
            cmds.add(nodesign);
            cmds.add(file_arg);
            cmds.add(default_stops);
            cmds.add(print_seed);

            cmds.parse(argc, argv);

            _nodesign = nodesign.getValue();
            _ppairsopt = ppairsopt.getValue();
            _jsonopt = jsonopt.getValue();
            _print_seed = print_seed.getValue();
#ifdef JSONCPP_FOUND
            _drawjson = drawjson.getValue();
            _prettyjson = prettyjson.getValue();
#endif
            _default_stops = default_stops.getValue();
            filename = file_arg.getValue();
        } catch (TCLAP::ArgException &e) {
            NUPACK_DESIGN_ERROR(e.error() + " " + e.argId());
        }

        nupack::design::DesignSpec fullspec;

        auto & invars = fullspec.eval.options;
        invars.add_global_stop = _default_stops;
        invars.print_json = _jsonopt;
        invars.print_ppairs = _ppairsopt;

        nupack::design::ScriptProcessor(filename, fullspec).parse_design();

        string output_prefix = invars.file_prefix;

#ifdef JSONCPP_FOUND
        if (_drawjson || _prettyjson) {
            string json_filename = output_prefix + ".json";
            std::fstream jsonfile(json_filename, std::fstream::out | std::fstream::trunc);
            fullspec.serialize_json(jsonfile, _prettyjson);
        }
#endif

        if (! _nodesign) {
            timeval starttime;
            gettimeofday(&starttime, NULL);

            NUPACK_DEBUG_PRINT("seed: " + std::to_string(invars.seed));
            if (_print_seed) {
                print("seed: " + std::to_string(invars.seed));
            }
            nupack::StaticRNG.seed(invars.seed);

            nupack::design::Designer maindes(fullspec);
            maindes.optimize();
            auto const & res = maindes.get_results();

            timeval endtime;
            gettimeofday(&endtime, NULL);
            real elapsed = (endtime.tv_sec - starttime.tv_sec);
            elapsed += 1e-6 * (endtime.tv_usec - starttime.tv_usec);
            invars.elapsed_time = elapsed;

            auto it = res.begin();
            for (; it != res.end(); ++it) {
                string full_output_prefix = output_prefix + "_" + nupack::design::to_string(it - res.begin());
                string npo_filename = full_output_prefix + ".npo";

                std::fstream npofile(npo_filename, std::fstream::out | std::fstream::trunc);

                invars.serialize(npofile, 0, "");
                it->eval.sequences.serialize(fullspec.eval.sequences, invars, npofile, 0, "");
                it->eval.physical.serialize(fullspec.eval.physical, invars, npofile, 0, "");
                it->eval.physical.print_res_files(fullspec.eval.physical, invars, full_output_prefix);
                fullspec.objectives.serialize(fullspec.eval, it->eval, npofile, 0, "");
            }
        }
    } catch (nupack::design::NupackException & np_exc) {
        np_exc.print_message();
        rval = 1;
    }

    return rval;
}
