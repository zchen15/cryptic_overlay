#include "split_set.h"

#include "nupack_invariants.h"
#include "design_debug.h"

namespace nupack {
namespace design {
bool SplitSet::allowed(int i, int j, int n, const NupackInvariants & invars) {
    int l1 = j - i + 1;
    int l2 = n - j + i - 1;
    return !((i < invars.H_split) || (j < i) || (j + invars.H_split >= n) ||
            (l1 < invars.N_split) || (l2 < invars.N_split));
}

SplitSet::SplitSet(const SplitSet & other, const vec<int> & map) {
    this->clear();
    try {
        for (auto & point : other.points) {
            points.emplace_back(map.at(point.left), map.at(point.right));
        }
    } catch (...) {
        this->clear();
        throw NupackException("Invalid map being used to create split set");
    }
    this->prob = other.prob;
}

void SplitSet::clear() {
    this->points.clear();
    this->prob = 0;
}

void SplitSet::serialize(std::ostream & out) {
    out << "SplitSet" << std::endl;
    for (auto & point : points) {
        out << point.left << " " << point.right << std::endl;
    }
    out << prob << std::endl;
}

void SplitSet::clone(const SplitSet & other) {
    this->points = other.points;
    this->prob = other.prob;
}

void SplitSet::push_back(int i, int j, real prob) {
    Split cur(i,j);
    bool found = any_of(points, [&](auto const &p) {return p == cur;});
    if (!found) {
        this->prob += prob;
        points.emplace_back(cur);
    }
}

real SplitSet::get_cost(int n) {
    real cost = 0;
    for (auto & point : points) {
        auto l1 = n - point.right + point.left - 1;
        auto l2 = point.right - point.left + 1;
        cost += pow((double) l1, 3) + pow((double) l2, 3);
    }
    return cost;
}

bool SplitSet::crosses_all(int i, int j) const {
    if (i > j) std::swap(i, j);
    for (auto & point : points) {
        auto d = point.left;
        auto e = point.right;
        if (d > e) std::swap(d, e);
        if (d == i && e == j) return false; // redundant
        if ((d > i && d < j) && (e > i && e < j)) return false; // inside
        if ((d < i || d > j) && (e < i || e > j)) return false; // outside
    }
    return true;
}

}
}
