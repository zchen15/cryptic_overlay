#pragma once

#include "parsestruc.h"
#include "constraint_handler.h"
#include "physical_spec.h"
#include "weight_spec.h"
#include "design_spec.h"

#include <vector>
#include <map>
#include <set>
#include <string>
#include <tuple>

namespace nupack {
namespace design {

class DesignSpec;
int parse_design(string filename, DesignSpec &spec);

class SourceSpec : public NamedSpec
{
    PairProbs ppairs;
    vec<int> nucs;

  public:
    SourceSpec(const string &name, const vec<int> &nucs) : NamedSpec(name, "source"),
                                                           nucs(nucs) {}

    const vec<int> &get_nucs() const { return this->nucs; }
};

class WindowSpec : public NamedSpec
{
    vec<int> nuc_ids;
    vec<string> domains;
    // need vectors for each of these
    vec<string> source_names;
    vec<int> source_nucs;
    vec<bool> allowed;

    bool exclude_allowed = true;

  public:
    WindowSpec(const string &name, const vec<SingleSequenceSpec> &domains);

    void set_source(vec<SourceSpec *>);
    void allow_similar(const SourceSpec &osource, real min_sim, real max_sim);
    void exclude_range(int min_int, int max_int);

    const string &get_source() const { return this->source_names[0]; }
    vec<int> get_nuc_ids() const { return this->nuc_ids; }
    vec<vec<int>> get_constraints() const;
};

class DomainListSpec : public NamedSpec
{
    // Just the lists of domain names
    vec<string> dlist1;
    vec<string> dlist2;
    int line;

    vec<int> get_nuc_ids_helper(const vec<string> &dnames,
                                const SequenceSpec &seqspec) const;

  public:
    // type_str either "identical", "wobble", or "complementary"
    DomainListSpec(string type_str, const vec<string> &dlist1,
                   const vec<string> &dlist2, int line = 0) : NamedSpec("", type_str), dlist1(dlist1), dlist2(dlist2), line(line) {}

    vec<int> get_nuc_ids1(const SequenceSpec &seqspec) const
    {
        return this->get_nuc_ids_helper(this->dlist1, seqspec);
    }

    vec<int> get_nuc_ids2(const SequenceSpec &seqspec) const
    {
        return this->get_nuc_ids_helper(this->dlist2, seqspec);
    }

    int get_line() const { return this->line; }
};

using Strands = vec<string>;

struct Prevent {
    vec<string> strands;
    vec<string> prevented_sequences;

    bool has_specific_targets() const { return !strands.empty(); }
};

class ScriptProcessor {
    using Names = std::set<string>;

    using LibraryValue = std::pair<string, vec<string> >;
    using LibraryPair = std::pair<string, LibraryValue>;
    using LibraryMap = std::map<string, std::map<string, vec<string> > >;
    using LibraryAssignmentMap = std::multimap<string, LibraryValue>;

    using PreventTargets = vec<string>;
    using Prevents = vec<vec<string>>;

    DesignSpec & spec;
    NupackInvariants & invars;
    Names names;
    string filename;

    std::map<string, SingleSymmetrySpec> SSM_map;
    std::map<string, StructureSpec> structure_map;
    std::map<string, TubeSpec> tube_map;
    std::map<string, MatchSpec> match_spec_map;
    std::map<string, SourceSpec> source_map;
    std::map<string, WindowSpec> window_map;
    std::map<string, DomainListSpec> complement_map;
    std::map<string, DomainListSpec> identical_map;
    std::map<string, DomainListSpec> wobble_map;
    std::map<string, Strands> complex_map;

    value_struc_t * root;
    int line = 1;
    value_struc_t * cur;

    void resolve_all(WeightSpec & weights);
    void resolve_SSM();
    void resolve_weights(WeightSpec & weights);

    void generate_default_parameter_spec();

    // used during AST traversal for the different token types
    void process_temperature();
    void process_material();
    void process_sodium();
    void process_magnesium();
    real process_global_stopdef();
    void process_dangles();
    void process_domain();
    void process_strand();
    void process_structure();
    void process_tube();
    void process_concdef();
    void process_stopdef();
    void process_maxsize();
    void process_prevent(vec<Prevent> &);
    void process_library(LibraryMap & libraries);
    void process_libseq(LibraryAssignmentMap & library_assignments);
    void process_symmetry_min();
    void process_source();
    void process_similarity();
    void process_window();
    void process_exclude();
    void process_complementary(int & n_comp);
    void process_identical(int & n_ident);
    void process_match();
    void process_complex();

    void process_off_targets();
    void make_off_target_list(NameList & names, NameList & list);

public:
    ScriptProcessor(string & script_name, DesignSpec & spec) :
        spec(spec), invars(spec.eval.options) {
        std::tie(filename, invars.file_prefix) = split_filename(script_name);
    }
    ~ScriptProcessor() { np_tt_destroy_value_struc(root); }

    bool already_named(string & name) { return !(names.find(name) == names.end()); }


    void add_library_constraints(LibraryMap lib_defs, LibraryAssignmentMap lib_assignments);
    void add_match_constraints();
    void add_pattern_constraints(vec<Prevent> &);
    void add_implied_constraints();

    void set_window_source(WindowSpec & wind, value_struc_t * source);
    void set_window_similarity(WindowSpec * wind, value_struc_t * unitsource, value_struc_t * range);
    void add_window(string name, vec<string> domains, const SequenceSpec & seqs);

    void add_exclusions(WindowSpec * wind, value_struc_t * vals);
    void set_ssm_wordsize(value_struc_t * cur);
    void set_item_weight(value_struc_t * cur, WeightSpec & weights);
    void add_match_domain(value_struc_t * cur);

    void gather_independent_entities(Names & tubes_to_add, Names & strucs_to_add);

    void add_global_objective(real stop);
    void add_default_stop_conditions();

    real process_conc_units(value_struc_t * cur, real baseval);
    real process_frac_units(value_struc_t * cur, real baseval);
    real get_frac_units(const string & unit_name);

    void parse_design();
    void process_design();

    static void convert_to_lower(string & str) { for (auto & s : str) s = tolower(s); }
    static vec<string> collect_string_list(value_struc_t * linkedlist);
    static NameList collect_complexes(value_struc_t * list);
    static std::pair<string, string> split_filename(string filename);
};

}
}
