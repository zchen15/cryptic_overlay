#pragma once

#include "named_spec.h"

#include "adapter.h"

#include <string>
#include <vector>
#include <map>

namespace nupack {
namespace design {

class SequenceSpec;
class SequenceState;

class SingleSymmetrySpec : public NamedSpec {
    vec<string> names;
    vec<vec<int>> nuc_ids;
    vec<int> word_len;
    vec<real> weights;
    real weightscale;

    const static real default_weight;

public:
    SingleSymmetrySpec(const string & name, const vec<string> & domains);

    void resolve(const SequenceSpec & seqs);

    void set_word_len(vec<int> lengths);

    void set_weights(real weight);
    void set_weights(vec<real> weights);

    const vec<vec<int>> & get_nuc_ids() const { return this->nuc_ids; }
    const vec<int> & get_word_len() const { return this->word_len; }
    const vec<real> & get_weights() const { return this->weights; }
};

class SingleSymmetryResult {
    vec<vec<real>> symmetries;
    vec<vec<int>> last_seqs;
    std::map<int, real> nuc_defects;
    real defect;

public:
    void evaluate(const SequenceState & seqs,
                  const SingleSymmetrySpec & spec);

    real get_defect() const { return this->defect; }
    std::map<int, real> get_nuc_defects() const { return this->nuc_defects; }
};

class SymmetrySpec {
    vec<SingleSymmetrySpec> specs;
    
public:
    void add_objective(const SingleSymmetrySpec & spec) { this->specs.push_back(spec); }
    const vec<SingleSymmetrySpec> & get_specs() const { return this->specs; }
};

class SymmetryResult {
    vec<SingleSymmetryResult> results;
    
public:
    void evaluate(const SequenceState & seqs, const SymmetrySpec & spec);
    const vec<SingleSymmetryResult> & get_results() const { return this->results; }
};

}
}
