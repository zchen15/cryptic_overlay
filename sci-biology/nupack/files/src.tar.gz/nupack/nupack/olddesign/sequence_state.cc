#include "sequence_state.h"

#include "design_debug.h"
#include "pathway_utils.h"

#include <array>

namespace nupack {
namespace design {
void SingleSequenceState::serialize(const SingleSequenceSpec & spec,
                                    const NupackInvariants & invars, std::ostream & out) const {
    const string & name = spec.get_name();
    string seq;
    NUPACK_EXC_CHECK(seq = SequenceUtils::nuc_to_str(this->nucs, invars.material),
                     "Error converting nucleotides");

    out << name;
    // TODO use this after validation
    // if (name.back() != '*') out << " ";
    // out << ": " << seq;
    out << " : " << seq; // TODO and remove this line
}

void SingleSequenceState::set_seqs(const vec<int> & nucs,
                                   const SingleSequenceSpec & nuc_ids) {
    this->nuc_ids = nuc_ids.get_nuc_ids();
    
    this->nucs = vmap(nuc_ids.get_nuc_ids(), [&](auto const n) {
        NUPACK_CHECK(n < nucs.size(),
                     "Invalid nucleotide index specified "
                     + to_string(n) + " >= " + to_string(nucs.size()));
        return nucs[n];
    });
}

// can avoid RNG when only one nucleotide type is possible. TODO fix after
// refactoring as results will otherwise be different due to different number
// of calls to RNG.
int SequenceState::random_nucleotide(int con, int cur) {
    NUPACK_CHECK(con >= 0 && con <= 15, "Invalid constraint " + to_string(con));

    std::array<double, 5> weight {{0.0, 0.0, 0.0, 0.0, 0.0}};
    constexpr std::array<double, 5> def_weight {{0.0, 1.0, 1.0, 1.0, 1.0}};
    const vec<vec<int>> allowed_seqs {
        {1, 2, 3, 4}, // N
        {1}, // A
        {2}, // C
        {3}, // G
        {4}, // U / T
        {1, 3}, // AG
        {1, 2}, // AC
        {2, 3}, // CG
        {1, 4}, // AU
        {3, 4}, // GU
        {2, 4}, // CU
        {1, 2, 3}, // ACG
        {1, 2, 4}, // ACU
        {1, 3, 4}, // AGU
        {2, 3, 4}, // CGU
    };

    int n_choices = allowed_seqs[con].size();
    for (auto i_con = 0; i_con < n_choices; i_con++) {
        weight[allowed_seqs[con][i_con]] = def_weight[allowed_seqs[con][i_con]];
    }
    weight[cur] = 0;

    auto tot_weight = 0.0;
    for (auto i = 1; i < weight.size(); ++i) tot_weight += weight[i];

    auto nuc = 1;
    auto r_num = random_float() * tot_weight;
    auto cur_weight = 0.0;
    for (; nuc < 4; nuc++) {
        cur_weight += weight[nuc];
        if (cur_weight > r_num) break;
    }
    return nuc;
}

vec<int> SequenceState::random_nucleotides(const vec<int> & cons) {
    return vmap(cons, [&](auto c) {return random_nucleotide(c, 0);});
}

void SequenceState::fill_in_sequences(const SequenceSpec & spec) {
    using el = typename decltype(domains)::value_type;
    
    domains = vmap(spec.get_domains(), [&](auto const & dom) {return fw<el>({nucleotides, dom});});
    strands = vmap(spec.get_strands(), [&](auto const & str) {return fw<el>({nucleotides, str});});
}

void SequenceState::set_variables(const vec<int> & vars, const SequenceSpec & spec) {
    auto const & var_map = spec.get_variables();
    NUPACK_CHECK(var_map.size() <= vars.size(), "Invalid variable map " +
                 to_string(var_map.size()) + " out of " + to_string(vars.size()));

    variables = vars;
    nucleotides.resize(var_map.size(), 0);
    
    transform(var_map, nucleotides, [&](auto v) {return vars[v];});
    fill_in_sequences(spec);
}

vec<int> SequenceState::get_sequence(const vec<int> & nuc_ids) const {
    auto nucs = vmap(nuc_ids, [&](auto n) {
        NUPACK_CHECK(n >= 0 && n < nucleotides.size(),
                     "Invalid nucleotide id: " + to_string(n));
        return nucleotides[n];
    });
    return nucs;
}

void SequenceState::serialize(const SequenceSpec & spec, const NupackInvariants & invars,
                              std::ostream & out, int indent, string prefix) const {
    string namestring(indent, ' ');
    out << namestring << "sequences:" << std::endl;

    string ind_str(indent + 4, ' ');
    ind_str = prefix + ind_str;

    auto const & domains = spec.get_domains();
    out << ind_str << "domains:" << std::endl;
    for (auto i = 0; i < this->domains.size(); i++) {
        out << ind_str << "    ";
        NUPACK_EXC_CHECK(this->domains[i].serialize(domains[i], invars, out),
                         "Error serializing domain");
        out << std::endl;
    }

    auto const & strands = spec.get_strands();
    out << ind_str << "strands:" << std::endl;
    for (auto i = 0; i < this->strands.size(); i++) {
        out << ind_str << "    ";
        NUPACK_EXC_CHECK(this->strands[i].serialize(strands[i], invars, out),
                         "Error serializing strand");
        out << std::endl;
    }
}

}
}
