#include "structure_result.h"

#include "complex_result.h"
#include "node_result.h"
#include "sequence_state.h"

#include "structure_utils.h"
#include "sequence_utils.h"
#include "pair_probabilities.h"

#include "design_debug.h"
#include "pathway_utils.h"

#include <json/json.h>

#include "wrapper.h"
#include "adapter.h"

#include "../design/Structure.h"

#include <fstream>

namespace nupack {
namespace design {

string StructureResult::get_structure_string(int i_struc) const {
    return StructureUtils::pairs_to_dpp(structures[i_struc], breaks);
}

string StructureResult::get_sequence_string(const NupackInvariants & invars) const {
    vec<int> breaks = this->breaks;
    breaks.push_back(sequence.size());

    vec<int> seqnucs;
    seqnucs.reserve(len(sequence) + len(breaks));
    int i_nuc = 0;
    for (auto br : breaks) {
        extend(seqnucs, view(sequence.begin() + i_nuc, sequence.begin() + br));
        seqnucs.push_back(STRAND_PLUS);
        i_nuc = br;
    }
    seqnucs.pop_back();

    return SequenceUtils::nuc_to_str(seqnucs, invars.material);
}

void StructureResult::serialize(const StructureSpec & spec, const NupackInvariants & invars,
        std::ostream & out, int indent, string prefix) const {
    string ind_str(indent, ' ');
    string name_ind(indent, ' ');
    ind_str = prefix + ind_str;

    if (indent > 2) name_ind = prefix + string(indent - 2, ' ') + "- ";

    string seq = get_sequence_string(invars);

    for (auto i_tar = 0; i_tar < defects.size(); i_tar++) {
        out << name_ind << "name: " << spec.get_names()[i_tar] << std::endl;
        out << ind_str << "structure: " << get_structure_string(i_tar) << std::endl;
        out << ind_str << "sequence:  " << seq << std::endl;
        if (tree.get_max_depth() > 0) {
            int ind = 0;
            tree.serialize(out, indent + 11, prefix, ind);
        }
        out << ind_str << "defect[nt]: " << flt_format << defects[i_tar] << std::endl;
        out << ind_str << "normalized defect: "<< flt_format << get_normalized_defect(i_tar) << std::endl;
        // if (defects.size() == 1) {
        out << ind_str << "target free energy[kcal/(mol K)]: " << flt_format << struc_energies[i_tar] << std::endl;
        real complex_ene = -Kb * invars.temperature * pfunc;
        out << ind_str << "target probability: " << flt_format << std::exp((complex_ene - struc_energies[i_tar]) / (Kb * invars.temperature)) << std::endl;
        // }
        out << ind_str << "complex free energy[kcal/(mol K)]: " << flt_format << complex_ene << std::endl;
    }

    if (defects.size() == 0) {
        out << name_ind << "name: " << spec.get_name() << std::endl;
        out << ind_str << "complex free energy[kcal/(mol K)]: " << flt_format << -Kb * invars.temperature * pfunc << std::endl;
    }
}

void StructureResult::print_strucfiles(const StructureSpec & spec,
                                       const NupackInvariants & invars,
                                       string file_prefix) const {
    const vec<string> & names = spec.get_names();
    auto it = names.begin();
    for (auto i = 0; it != names.end(); ++i, ++it) {
        string ppair_filename = file_prefix + "_" + *it + ".ppairs";
        string json_filename = file_prefix + "_" + *it + ".json";

        if (invars.print_ppairs) {
            std::fstream ppair_file(ppair_filename, std::fstream::out);

            auto print_line = [&] (auto const &k, auto const &v, auto const &f) {
                ppair_file << COMMENT_STRING << " " << k << ": " << f << v << std::endl;
            };

            print_line("Version", Version, null_format);
            print_line("Program", "multistatedesign", null_format);
            print_line("Start time", invars.start_timestamp, null_format);
            print_line("Parameters", invars.mat_str(), null_format);
            print_line("Dangles", invars.dangle_str(), null_format);
            print_line("Temperature (C)", (invars.temperature - ZeroCinK), flt_format);
            print_line("Sodium concentration (M)", invars.sodium, null_format);
            print_line("Magnesium concentration (M)", invars.magnesium, null_format);
            print_line("Name", *it, null_format);
            print_line("Sequence", get_sequence_string(invars), null_format);
            print_line("Structure", get_structure_string(i), null_format);
            print_line("v(pi)", symmetry, null_format);
            print_line("Structure free energy", struc_energies[i], null_format);
            print_line("Ensemble free energy", - Kb * invars.temperature * pfunc, null_format);
            print_line("Partition function", std::exp(pfunc), exp_format);
            print_line("Ensemble defect", (defects[i]), flt_format);
            print_line("Normalized ensemble defect", (defects[i] / size()), flt_format);

            ppair_file << std::endl;
            ppair_file << size() << std::endl;

            ppairs.serialize(ppair_file, size());
            ppair_file.close();
        }

        if (invars.print_json) {
            std::fstream json_file(json_filename, std::fstream::out);

            string material = "rna";
            if (invars.mat_str() == "dna" || invars.mat_str() == "dna1998") material = "dna";

            vec<string> snames = spec.get_strand_names();

            Json::Value root;

            Json::Value strands(Json::arrayValue);
            for_each(snames, [&](auto const &s) {strands.append(s);});

            Json::Value nuc_probs(Json::arrayValue);
            for_each(pos_defects[i], [&](auto p) {nuc_probs.append(1 - p);});

            root["nupack version"]              = Version;
            root["program"]                     = "multitubedesign";
            root["start time"]                  = invars.start_timestamp;
            root["parameters"]                  = invars.mat_str();
            root["material"]                    = material;
            root["dangles"]                     = invars.dangle_str();
            root["temperature (C)"]             = invars.temperature - ZeroCinK;
            root["name"]                        = *it;
            root["strand names"]                = strands;
            root["sodium concentration (M)"]    = invars.sodium;
            root["magnesium concentration (M)"] = invars.magnesium;
            root["sequence"]                    = get_sequence_string(invars);
            root["structure"]                   = get_structure_string(i);
            root["v(pi)"]                       = symmetry;
            root["energypreamble"]              = "Free energy of secondary structure";
            root["target free energy"]          = struc_energies[i];
            root["ensemble free energy"]        = (- Kb * invars.temperature * pfunc);
            root["partition function"]          = std::exp(pfunc);
            root["ensemble defect"]             = defects[i];
            root["normalized ensemble defect"]  = (defects[i] / size());
            root["nucleotide probabilities"]    = nuc_probs;

            json_file << root;
            json_file.close();
        }
    }
}

void StructureResult::evaluate(const SequenceState & seqs,
                               const StructureSpec & spec,
                               const NupackInvariants & invars) {

    auto const & strands = seqs.get_strands();
    auto const & strand_ids = spec.get_strands();

    vec<int> fullseq;
    breaks.clear();
    for (auto c_str : strand_ids) {
        NUPACK_CHECK(c_str >= 0 &&
                     c_str < strands.size(), "Invalid strand id " + to_string(c_str) + ", negative or greater than " +
                     to_string(strands.size()));

        auto const & curseq = strands[c_str].get_nucs();
        auto const & cur_nuc_ids = strands[c_str].get_nuc_ids();
        append(fullseq, curseq);
        append(nuc_ids, cur_nuc_ids);
        breaks.push_back(fullseq.size());
    }
    breaks.pop_back();

    int n_nucs = spec.size();
    NUPACK_CHECK(fullseq.size() == n_nucs,
                 "structure and sequence lengths don't agree. " + to_string(fullseq.size()) + " != " + to_string(
                     n_nucs));

    // Compare old and new sequences. Mark any changed nodes
    // If the sequence length changed, mark all nodes as changed
    sequence = fullseq;
    f_sequence = fullseq;
    structures = spec.get_structures();
    target = spec.get_target();
    this->strands = spec.get_strands();
    domain_map = spec.get_domain_map();
    strand_map = spec.get_strand_map();
    struc_ids = spec.get_struc_ids();
    symmetry = spec.get_symmetry();

    // if (nullptr == &tree) tree = NodeResult();
    tree.evaluate(spec.get_tree(), seqs, *this, spec, invars);

    pfunc = get_pfunc();
    ppairs = tree.collect_pair_probs(invars);
    eval_time = tree.collect_eval_times();
    update_defects();

    struc_energies.resize(structures.size());
    for (auto i_tar = 0; i_tar < structures.size(); i_tar++) {
        struc_energies[i_tar] = get_energy(i_tar, invars);
    }
}

const WeightMap & StructureResult::get_nuc_defects(int i_target) const {
    NUPACK_DEBUG_CHECK(i_target < nuc_defects.size(),
                       "Invalid target specified in StructureResult::get_nuc_defects");
    return nuc_defects[i_target];
}

real StructureResult::get_normalized_defect(int i_target) const {
    return get_structural_defect(i_target) / size();
}

real StructureResult::get_structural_defect(int i_target) const {
    NUPACK_CHECK(i_target < defects.size(),
                 "Invalid target " + to_string(i_target) + " out of "
                 + to_string(defects.size()));
    return defects[i_target];
}

real StructureResult::get_pfunc() const {
    return tree.get_pfunc() - std::log(symmetry);
}

real StructureResult::get_energy(int i, const NupackInvariants & invars) {
    static auto const mod = model(invars);

    auto energy = structure_energy(get_sequence_string(invars), get_structure_string(i), mod);

    /* add symmetry correction if necessary */
    if (symmetry > 1) {
        newdesign::Structure struc(get_structure_string(i));
        for (auto i : ~range(1, symmetry+1)) {
            auto current = struc;
            for (auto j : range(i)) current.rotate();
            if (current == struc) return energy + std::log(i) / mod.beta;
        }
    }
    return energy;
}

void StructureResult::update_defects() {
    pos_defects.resize(structures.size());
    nuc_defects.resize(structures.size());
    defects.resize(structures.size());

    for (auto i = 0; i < structures.size(); i++) {
        auto struc_id = struc_ids[i];

        pos_defects[i] = ppairs.get_nuc_defects(target);
        defects[i] = sum(pos_defects[i]);

        int n_nucs = structures[0].size();
        for (auto j = 0; j < n_nucs; j++) {
            vec<int> ind{struc_id, strand_map[j], domain_map[j], j, nuc_ids[j]};

            nuc_defects[i][ind] = pos_defects[i][j];
        }
    }
}

void StructureResult::replace_node(const StructureResult & other, int k,
                                   const NupackInvariants & invars) {
    tree.replace_node(other.tree, k, invars);
    pfunc = get_pfunc();
    ppairs = tree.collect_pair_probs(invars);
    update_defects();
}

}
}
