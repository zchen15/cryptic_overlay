#pragma once

#include "sequence_state.h"
#include "structure_result.h"
#include "complex_result.h"
#include "tube_result.h"

#include "physical_spec.h"
#include "pair_probabilities.h"

#include "types.h"

#include <vector>
#include <string>

namespace nupack {
namespace design {

/**
 * This holds the physical results for a set of tubes using a
 * single material and at a single temperature (so using a single
 * parameter set).
 */
class PhysicalResult {
    vec<real> order_pfuncs;
    vec<bool> order_included;
    WeightMap nuc_defects;

protected:
    vec<StructureResult> strucs;
    vec<OrderResult> orders;

    vec<TubeResult> tubes;

public:
    void replace_node(const PhysicalResult & other,
                      const PhysicalSpec & spec, 
                      int i, int k, const NupackInvariants & invars);

    void evaluate(const SequenceState & seqs,
                  const PhysicalSpec & spec,
                  const NupackInvariants & invars);

    void print_res_files(const PhysicalSpec & spec,
                         const NupackInvariants & invars, string file_prefix) const;
    void serialize(const PhysicalSpec & spec,
                   const NupackInvariants & invars, std::ostream & out,
                   int indent, string prefix) const;

    vec<real> get_tube_defects();

    /*
     * Nucleotide defect i at position j
     * nuc_defects[i][j]
     */
    const vec<TubeResult> & get_tubes() const { return this->tubes; }
    const vec<StructureResult> & get_strucs() const { return this->strucs; }
    const vec<OrderResult> & get_orders() const { return this->orders; }

    int get_max_depth() const;

    real get_eval_time() const;

    friend class PhysicalSpec;
};

}
}

