#pragma once

#include "adapter.h"

#include <iostream>
#include <vector>
#include <utility>

namespace nupack {
namespace design {
struct NupackInvariants;

struct Split {
    Split() = default;
    Split(int l, int r) : left(l), right(r) {};

    int left;
    int right;
    
    bool operator==(Split const &other) const {return left == other.left && right == other.right;}
};

class SplitSet {
    vec<Split> points;
    real prob {0};

    void clear();
    void clone(const SplitSet & other);

public:
    SplitSet() {}
    SplitSet(const SplitSet & other, const vec<int> & map);

    void push_back(int i, int j, real prob);
    bool crosses_all(int i, int j) const;

    void add_prob(real prob) { this->prob += prob; }
    void set_prob(real prob) { this->prob = prob; }
    real get_prob() const { return this->prob; }

    const vec<Split> & get_points() const { return this->points; }

    real get_cost(int n);

    static bool allowed(int i, int j, int n, const NupackInvariants & invars);

    void serialize(std::ostream & out);
};

}
}
