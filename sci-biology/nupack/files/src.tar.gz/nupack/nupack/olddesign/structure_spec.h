#pragma once

#include "node_spec.h"
#include "named_spec.h"
#include "complex_spec.h"
#include "pair_probabilities.h"

#include "types.h"

#include <memory>
#include <vector>
#include <string>
#include <map>
#include <utility>
#include <iostream>

namespace nupack {
namespace design {
struct NupackInvariants;
class StructureResult;
class SequenceSpec;
class SequenceState;


class StructureSpec : public NamedSpec {
    void clone(const StructureSpec & other);
    void rotate();

    // Used in pre-resolved phase
    vec<string> strand_names;

    vec<vec_structure> strucs;
    PairProbs target_matrix;
    vec<int> strands;
    vec<int> breaks;

    vec<string> struc_names;
    vec<int> struc_ids;
    vec<int> nuc_ids;

    vec<int> domain_map;
    vec<int> strand_map;

    vec<std::pair<int, int> > forbidden;

    int symmetry;

    std::shared_ptr<NodeSpec> tree;

public:
    StructureSpec(const string & name, const string & struc);
    StructureSpec(const string & name, const vec<int> & struc,
                  const vec<int> & breaks, const vec<int> & strands);
    StructureSpec(const StructureSpec & other);

    StructureSpec(StructureSpec &&) = default;


    virtual void set_id(int id);
    StructureSpec & operator=(const StructureSpec & other);
    StructureSpec & operator=(StructureSpec && other) = default;

    void set_strand_names(const vec<string> & strand_names) {this->strand_names = strand_names;}
    void set_no_target() {strucs.clear();}

    void resolve_strand_names(const std::map<string, int> & namemap);
    void resolve_nuc_ids(const SequenceSpec & seqs);

    void set_strands(const vec<int> & strand_ids);

    void decompose(const NupackInvariants & invars) {tree->decompose(*this, invars);}
    void decompose_ppair(int k, const StructureResult & res, const SequenceState & seqs, const NupackInvariants & invars);

    void merge(const StructureSpec & other);
    void compute_target_matrix();

    StructureSpec get_depth(int depth) const;

    int get_symmetry() const {return symmetry;}

    int size() const;

    const vec<int> & get_strands() const {return strands;}
    const vec<int> & get_nuc_ids() const {return nuc_ids;}
    const vec<int> & get_breaks() const {return breaks;}

    const vec<string> & get_strand_names() const {return strand_names;}
    const vec<vec_structure> & get_structures() const {return strucs;}
    const PairProbs & get_target() const {return target_matrix;}
    const vec<string> & get_names() const {return struc_names;}

    int get_n_nodes() const {return tree->get_n_nodes();}
    int get_n_leaves() const {return tree->get_n_leaves();}
    int get_max_depth() const {return tree->get_max_depth();}
    bool is_forbidden(int i, int j) const;
    void add_forbidden(int i, int j) {forbidden.emplace_back(i, j);}

    void serialize(std::ostream & out = std::cout, int indent = 0,
                   string prefix = "") const {target_matrix.serialize(out, target_matrix.get_n());}

    OrderSpec make_order() const;

    const NodeSpec & get_tree() const {return *(tree);}
    const vec<int> & get_domain_map() const {return domain_map;}
    const vec<int> & get_strand_map() const {return strand_map;}
    const vec<int> & get_struc_ids() const {return struc_ids;}
};

}
}
