#pragma once

#include "physical_spec.h"
#include "objective_handler.h"

#include <string>
#include <vector>

namespace nupack {
namespace design {
    
class SymmetryObjective : public Objective_CRTP<SymmetryObjective> {
    int id;

public:
    SymmetryObjective(string name, real stop) :
        Objective_CRTP(name, "SSM", stop), id(0) {}

    real get_defect(const EvalSpec & spec,
                    const EvalResult & res, WeightSpec & weightspec);
    void get_variable_mut_weights(const EvalSpec & spec,
                                  const EvalResult & res, WeightSpec & weightspec,
                                  vec<real> & weights);

    bool satisfied(const EvalSpec & spec, const EvalResult & res,
                   WeightSpec & weightspec);
};

}
}

