#pragma once

#include "physical_spec.h"

// #include "equilibrium_concentrations.h"

#include "types.h"

#include <vector>
#include <string>
#include <memory>

// Constants used in trust region
#define TRUST_REGION_DELTABAR 1000.0 // Maximal size of trust region
#define TRUST_REGION_ETA 0.125 // Decision criterion for trust region

namespace nupack {
namespace design {
    
class StructureResult;
class OrderResult;

struct ConcSolverParams {
    static constexpr int n_points = 1;
    static constexpr int max_iters = 10000;
    static constexpr double tol = 1e-8;
    static constexpr double delta_bar = TRUST_REGION_DELTABAR;
    static constexpr double eta = TRUST_REGION_ETA;
    static constexpr double min_delta = 1e-12;
    static constexpr int max_trial = 1000;
    static constexpr int perturb_scale = 100;
    static constexpr int quiet = 1;
    static constexpr int write_log_file = 0;
    static constexpr char *log_file = NULL;
    static constexpr int seed = 0; // Don't reseed the RNG!
};

/**
 * This class holds the physical results for a tube of interacting
 * nucleic acids.
 */
class TubeResult {
    vec<vec<real> > target_x;
    vec<real> x;
    WeightMap nucleotide_defects;
    real defect;
    real nuc_conc;
    
public:
    TubeResult() : defect(DBL_MAX), nuc_conc(1.0) {};

    void evaluate(const vec<StructureResult> & strucs, const vec<OrderResult> & orders,
        const vec<int> & ord_struc_map, const TubeSpec & spec, const NupackInvariants & invars);
    
    const vec<real> & get_concentrations() const {return this->x;}
    const WeightMap & get_nuc_defects() const {return this->nucleotide_defects;}
    real get_nuc_conc() const {return this->nuc_conc;}
    real get_defect() const {return this->defect;}

    void serialize(const TubeSpec & spec, const vec<StructureSpec> & strucspecs,
            const vec<int> & order_specs, const NupackInvariants & invars,
            std::ostream & out, int indent = 0, string prefix = "") const;

    void clear_state();
};


}
}
