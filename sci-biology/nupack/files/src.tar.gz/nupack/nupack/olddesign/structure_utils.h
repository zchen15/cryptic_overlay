#pragma once

#include "types.h"

#include <vector>
#include <string>
#include <utility>

namespace nupack {
namespace design {

struct NupackInvariants;
class SplitSet;
class StructureSpec;
class PairProbs;

namespace StructureUtils {
using structure_pair = std::pair<vec_structure, vec<int>>;

structure_pair dpp_to_pairs(const string & struc);
string pairs_to_dpp(const vec_structure & pairs,
                    const vec<int> & breaks);
void get_strand_lengths(const vec_structure & pairs,
                        const vec<int> & breaks, vec<int> & lengths);
void get_strand_lengths(const string & struc,
                        vec<int> & lengths);
vec<SplitSet> get_consistent_splits(
        const vec<vec<int>> & strucs,
        const NupackInvariants & invars);
SplitSet get_minimal_splits(const vec<SplitSet> & set, const PairProbs & ppairs, int n,
                            const NupackInvariants & invars);
};

}
}
