#pragma once

#include "weight_spec.h"
#include "eval_spec.h"
#include "eval_result.h"

#include "types.h"
#include "adapter.h"

#include <memory>
#include <vector>
#include <map>
#include <string>
#include <iostream>
#include <functional>

namespace nupack {
namespace design {

// generic implementation
inline int get_nuc_id(const vec<int> & ind) { return ind.back(); }
WeightMap weight_defects(const WeightMap &, WeightSpec &, vec<int>);

void get_variable_mut_weights(const vec<int> &, WeightSpec &,
                              vec<real> &, vec<int>, const WeightMap &, real);

class Objective {
protected:
    string name;
    string objective_type;
    real stop;

public:
    Objective(string name, string ob_type, real stop) :
        name(name), objective_type(ob_type), stop(stop) {}
    virtual real get_defect(const EvalSpec & spec,
                                const EvalResult & res, WeightSpec & weightspec) = 0;

    virtual void get_variable_mut_weights(const EvalSpec & spec,
                                          const EvalResult & res, WeightSpec & weightspec,
                                          vec<real> & weights) = 0;

    virtual std::shared_ptr<Objective> clone() const = 0;


    virtual vec<int> get_struc_id() const { return {}; }

    virtual vec<int> get_tube_id() const { return {}; }

    bool satisfied(const EvalSpec & spec, const EvalResult & res,
                   WeightSpec & weightspec) {
        return !(get_defect(spec, res, weightspec) > get_stop(spec, res));
    }

    virtual string get_objective_type(const EvalSpec & spec, const EvalResult & res) {
        return objective_type;
    }

    real get_stop(const EvalSpec & spec, const EvalResult & res) const {
        return stop * pow(spec.options.f_stringent, res.physical.get_max_depth());
    }

    const string & get_name() const { return name; }

    virtual void serialize(const EvalSpec & spec, const EvalResult & res,
                           WeightSpec & weightspec, std::ostream & out, int indent = 4,
                           string prefix = "") {
        string ind_string = prefix + string(indent, ' ');
        string name_ind = ind_string;
        if (indent > 2) name_ind = prefix + string(indent - 2, ' ') + "- ";

        out << name_ind << "name: " << name << std::endl;
        out << ind_string << "defect: " << get_defect(spec, res, weightspec) << std::endl;
        out << ind_string << "satisfied: " <<
            (satisfied(spec, res, weightspec) ? "true" : "false") << std::endl;
        out << ind_string << "stop: " << get_stop(spec, res) << std::endl;
        out << ind_string << "type: " << get_objective_type(spec, res) << std::endl;
    };

    virtual ~Objective() = default;
};

template <typename T>
struct Objective_CRTP : public Objective {
    Objective_CRTP(string name, string ob_type, real stop) :
        Objective(name, ob_type, stop) {}
    virtual std::shared_ptr<Objective> clone() const {
        return std::make_shared<T>(static_cast<T const &>(*this));
    };
};

class TubeObjective : public Objective_CRTP<TubeObjective> {
    int id;
    // Add in ignored nucleotide ids/domain names/strand names here.
    // Not sure precisely how to organize it.

public:
    TubeObjective(string name, real stop) :
        Objective_CRTP(name, "tube", stop), id(-1) {}
    ~TubeObjective() {}

    real get_defect(const EvalSpec & spec, const EvalResult & res,
                        WeightSpec & weightspec);
    void get_variable_mut_weights(const EvalSpec & spec, const EvalResult & res,
                                  WeightSpec & weightspec, vec<real> & weights);

    vec<int> get_tube_id() const;

    /**
     * \brief Weight the given map of defects according to
     *    the given weight specification. This is used to
     *    perform user-specified weighting of defects at the
     *    nucleotide level.
     */
    WeightMap weight_defects(WeightMap const &nuc_defects, WeightSpec & weights);
};

class StructureObjective : public Objective_CRTP<StructureObjective> {
    int id;
    int targ_id;
    // Add in ignored nucleotide ids/domain names/strand names here.
    // Not sure how exactly to organize it

public:
    StructureObjective(string name, real stop) :
        Objective_CRTP(name, "structure", stop), id(-1), targ_id(-1) {}

    real get_defect(const EvalSpec & spec,
                        const EvalResult & res, WeightSpec & weightspec);
    void get_variable_mut_weights(const EvalSpec & spec,
                                  const EvalResult & res, WeightSpec & weightspec,
                                  vec<real> & weights);

    vec<int> get_struc_id() const { return {this->id}; }


    WeightMap weight_defects(WeightMap const &nuc_defects, WeightSpec & weights);
};

class CombinedObjective : public Objective_CRTP<CombinedObjective> {
    vec<string> element_names;
    vec<int> struc_ids;
    vec<int> target_ids;
    vec<int> tube_ids;

    void resolve_names(const EvalSpec & spec);

public:
    CombinedObjective(vec<string> names, real stop) :
        Objective_CRTP("combined_objective", "combined", stop), element_names(names) {}

    real get_defect(const EvalSpec & spec,
                        const EvalResult & res, WeightSpec & weightspec);
    void get_variable_mut_weights(const EvalSpec & spec, const EvalResult & res,
                                  WeightSpec & weightspec, vec<real> & weights);


    vec<int> get_struc_id() const { return struc_ids; }
    vec<int> get_tube_id() const { return tube_ids; }

    vec<WeightMap> weight_defects(vec<WeightMap> const &nuc_defects, WeightSpec & weights);

    virtual void serialize(const EvalSpec & spec, const EvalResult & res,
                           WeightSpec & weightspec, std::ostream & out, int indent = 4,
                           string prefix = "");
};

class ObjectiveHandler {
    void copy(const ObjectiveHandler & other);
    void clear() { objectives.clear(); }

    vec<std::shared_ptr<Objective>> objectives;
    WeightSpec weights;

public:
    ObjectiveHandler() {}
    ObjectiveHandler(const ObjectiveHandler & other) { this->copy(other); }
    ObjectiveHandler & operator=(const ObjectiveHandler & other);
    ~ObjectiveHandler() {}

    void add_objective(const Objective & ob) { this->objectives.push_back(ob.clone()); }
    void set_weights(const WeightSpec & weights) { this->weights = weights; }

    vec<real> get_defects(EvalSpec & spec, EvalResult & res);

    void get_variable_mut_weights(const EvalSpec & spec,
                                  const EvalResult & res, vec<real> & weights);

    void serialize(const EvalSpec & spec, const EvalResult & res,
                   std::ostream & out, int indent = 0, string prefix = "");

    void short_serial(const EvalSpec & spec, const EvalResult & res,
                      std::ostream & out, int indent = 0, string prefix = "");

    vec<int> get_struc_id(int ob_i) { return objectives.at(ob_i)->get_struc_id(); }
    vec<int> get_tube_id(int ob_i) { return objectives.at(ob_i)->get_tube_id(); }

    bool all_satisfied(const EvalSpec & spec, const EvalResult & res);
    vec<bool> satisfied(const EvalSpec & spec, const EvalResult & res);

    vec<real> get_stops(const EvalSpec & spec, const EvalResult & res);

    vec<string> get_names();
};


}
}
