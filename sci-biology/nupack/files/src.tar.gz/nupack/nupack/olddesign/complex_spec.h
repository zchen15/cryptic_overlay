#pragma once

#include "adapter.h"

namespace nupack {
namespace design {

class OrderSpec {
    int symmetry;

protected:
    vec<int> strands;

public:
    friend bool operator< (const OrderSpec & o1, const OrderSpec & o2) {
        return o1.strands < o2.strands;
    }
    friend bool operator> (const OrderSpec & o1, const OrderSpec & o2) {
        return o1.strands > o2.strands;
    }
    friend bool operator==(const OrderSpec & o1, const OrderSpec & o2) {
        return o1.strands == o2.strands;
    }
    friend bool operator!= (const OrderSpec & o1, const OrderSpec & o2) {
        return o1.strands != o2.strands;
    }

    OrderSpec(const OrderSpec & o) : strands(o.strands), symmetry(o.symmetry) {}

    OrderSpec(const vec<int> & order);

    int get_symmetry() const { return this->symmetry; }
    const vec<int> & get_strands() const { return this->strands; }
};
}
}
