#include "weight_spec.h"

namespace nupack {
namespace design {
WeightSpec::WeightSpec() {}

void WeightSpec::add_weight(const vec<string> & s, real w) {
    specs.push_back(s);
    weight.push_back(w);
    cached_weight.clear();
}

void WeightSpec::resolve_names(const vec<std::map<string, int> > & maps) {
    int m_depth = maps.size();
    resolved_ids = decltype(resolved_ids)(specs.size(), vec<int>(m_depth, -1));

    // fill in resolved_ids
    zip(specs, resolved_ids, [&](auto const & spec, auto & res_id) {
        auto spec_depth = spec.size();
        for (int k = 0, j = 0; k < spec_depth && j < m_depth; j++) {
            auto it = maps[j].find(spec[k]);
            if (it != maps[j].end()) {
                res_id[j] = it->second;
                k++;
            }
        }
    });

    cached_weight.clear();
}

// look in cached_weights, if not there find in weight based on resolved_ids and add
// to cache.
real WeightSpec::get_weight(const vec<int> & spec) {
    auto cache_it = cached_weight.find(spec);
    if (cache_it != cached_weight.end()) return cache_it->second;

    real cur_weight = 1.0;
    zip(resolved_ids, weight, [&](auto const & rid, auto const & w) {
        auto s = spec.cbegin();
        if (all_of(rid, [&](auto r) {
            return r == *s++ || r == -1;
        }))
            cur_weight *= w;
    });

    cached_weight[spec] = cur_weight;

    return cur_weight;
}

}
}
