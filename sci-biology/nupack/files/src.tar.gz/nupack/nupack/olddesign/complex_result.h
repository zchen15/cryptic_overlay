#pragma once

#include "physical_spec.h"

#include <vector>
#include <string>
#include <memory>

namespace nupack {
namespace design {

/**
  * This class holds the evaluation results for a single complex without
  * a target structure (or decomposition tree).
  */
class OrderResult {
    vec<int> strands;
    vec<int> sequence;
    int n_nucs;
    real pfunc;
    real eval_time;
    bool evaluated;
    
public:
    OrderResult() : n_nucs(0), pfunc(0), eval_time(0), evaluated(false) {}
    void evaluate(const SequenceState & seqs, const OrderSpec & spec,
            const NupackInvariants & invars);

    void clear_evaluated();
    bool get_evaluated() const { return this->evaluated; }
    real get_pfunc() const { return this->pfunc; }
    const vec<int> & get_strands() const { return this->strands; }
    real get_eval_time() const { return this->eval_time; }
    int size() const { return this->n_nucs; }

    void update_sequence(const SequenceState & seqs);
};

}
}
