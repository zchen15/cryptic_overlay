#pragma once

#include "types.h"

#include "adapter.h"

#include <map>
#include <vector>
#include <string>

namespace nupack {
namespace design {

class WeightSpec {
    /* Raw specifications */
    vec<vec<string>> specs;
    vec<real> weight;

    /* Resolved ids */
    vec<vec<int>> resolved_ids;

    /* Cached weights */
    WeightMap cached_weight;

public:
    WeightSpec();

    void add_weight(const vec<string> & spec, real weight);
    /*
     * Resolve the names using a vector of name-maps. In our case,
     * this is currently:
     * tube, structures, strands, domains
     *
     * This is written to be generic across index depth in case
     * further levels of indexing are necessary. The resolution is
     * required for efficient weight lookups.
     */
    void resolve_names(const vec<std::map<string, int> > & maps);

    void serialize(std::ostream & out) const;

    real get_weight(const vec<int> & spec);
};

}
}
