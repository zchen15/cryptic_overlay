#include "physical_spec.h"
#include "sequence_spec.h"
#include "pair_probabilities.h"
#include "structure_utils.h"

#include "physical_result.h"
#include "design_debug.h"
#include "constants.h"
#include "algorithms.h"

#include <json/json.h>

#include <sys/time.h>

#include <set>
#include <map>
#include <algorithm>
#include <list>
#include <ctime>
#include <cfloat>

namespace nupack {
namespace design {

std::pair<int, int> PhysicalSpec::add_structure(const StructureSpec & spec) {
    OrderSpec temp_ord = spec.make_order();

    unsigned int ord_id = 0;
    while (ord_id < orders.size() && orders[ord_id] != temp_ord) {
        ord_id++;
    }
    int struc_id = strucs.size();
    std::pair<int, int> ret(-1, -1);

    if (ord_id < orders.size() && ord_struc_map[ord_id] >= 0) {
        struc_id = ord_struc_map[ord_id];
        strucs[struc_id].merge(spec);
        NUPACK_DEBUG_PRINT("Merging: " << name << " at " << struc_id);
        ret.first = ord_id;
        ret.second = strucs[struc_id].get_structures().size() - 1;
    } else {
        if (ord_id == orders.size()) {
            ord_struc_map.push_back(strucs.size());
            orders.push_back(temp_ord);
        } else {
            ord_struc_map[ord_id] = strucs.size();
        }

        struc_ord_map.push_back((int)ord_id);
        strucs.push_back(spec);

        ret.first = (int)ord_id;
        ret.second = 0;
    }

    return ret;
}

PhysicalSpec PhysicalSpec::get_depth(int depth, bool off_targets) const {
    PhysicalSpec res(*this);
    res.strucs.clear();
    for (auto const & str : strucs) {
        res.strucs.emplace_back(str.get_depth(depth));
    }

    res.off_targets = off_targets;
    return res;
}

int PhysicalSpec::get_max_depth() const {
    using str = typename decltype(strucs)::value_type;
    return std::max_element(strucs.begin(), strucs.end(), smaller_depth<str>)->get_max_depth();
}

void PhysicalSpec::enumerate_off_targets(
    const std::map<string, int> & strands) {
    std::map<OrderSpec, int> off_target_map;
    int n_on_target = this->orders.size();
    NUPACK_DEBUG_PRINT("N on targets " << n_on_target);

    for (auto i = 0; i < n_on_target; i++) {
        auto & strands = this->orders[i].get_strands();
        NUPACK_CHECK(!contains(strands, off_target_map), "Duplicate strand orderings.")
        off_target_map[strands] = i;
    }

    for (auto & tube : tubes) {
        tube.enumerate_off_targets(off_target_map);
        tube.resolve_listed_offtargets(strands, off_target_map);
    }

    this->orders.resize(off_target_map.size(), vec<int>());
    this->ord_struc_map.resize(off_target_map.size(), -1);

    for (auto & ot : off_target_map) {
        this->orders[ot.second] = ot.first;
        if (ot.second >= n_on_target) this->ord_struc_map[ot.second] = -1;
    }
    NUPACK_DEBUG_PRINT("Total orders: " << this->ord_struc_map.size());
}

StructureSpec & PhysicalSpec::get_struc(string name) {
    for (auto & str : strucs) {
        if (name == str.get_name()) return str;
    }
    NUPACK_DESIGN_ERROR("Invalid structure " + name);
}

std::pair<int, int> PhysicalSpec::get_struc_id(string name) const {
    int i = 0;
    int j = 0;
    for (; i < this->strucs.size(); i++) {
        auto const & cnames = this->strucs[i].get_names();
        for (j = 0; j < cnames.size(); j++) {
            if (name == cnames[j]) break;
        }

        if (j < cnames.size() && name == cnames[j]) break;
    }

    std::pair<int, int> ret(-1, -1);
    if (i < this->strucs.size()) {
        ret.first = i;
        ret.second = j;
    }
    return ret;
}

int PhysicalSpec::get_tube_id(string name) const {
    for (auto i = 0; i < this->tubes.size(); i++) {
        if (this->tubes[i].get_name() == name) return i;
    }
    NUPACK_DESIGN_ERROR("Tube " + name + " not found");
}

void PhysicalSpec::add_off_target(int i_ord, const SequenceSpec & seqs) {
    vec<int> strands = this->orders.at(i_ord).get_strands();
    vec<int> breaks;
    string name = "S-";
    unsigned int n_nucs = 0;
    for (auto s : strands) {
        auto & str = seqs.get_strands()[s];
        n_nucs += str.size();
        name += str.get_name();
        breaks.push_back(n_nucs);
    }
    vec<int> struc(n_nucs, -1);
    breaks.pop_back();

    StructureSpec newstruc(name, struc, breaks, strands);
    newstruc.set_no_target();
    newstruc.resolve_nuc_ids(seqs);

    NUPACK_CHECK(ord_struc_map[i_ord] < 0, "Reading structure that is present: " +
                 to_string(i_ord));

    this->strucs.push_back(newstruc);
    this->struc_ord_map.push_back(i_ord);
    this->ord_struc_map[i_ord] = this->strucs.size() - 1;
}

void PhysicalSpec::decompose_ppair(int i, int k, const PhysicalResult & res,
                                      const SequenceState & seqs, const NupackInvariants & invars) {
    NUPACK_CHECK(i < this->strucs.size(), "Invalid index " + to_string(i) + " in decompose_ppair");
    this->strucs[i].decompose_ppair(k, res.strucs[i], seqs, invars);
}

#ifdef JSONCPP_FOUND
Json::Value PhysicalSpec::make_json_structures(const SequenceSpec & seqs,
        const NupackInvariants & invars) const {
    // Make json structures
    Json::Value root(Json::arrayValue);
    for (auto & struc : strucs) {
        Json::Value curstruc;
        auto const & names = struc.get_names();
        auto const & pairs = struc.get_structures();
        auto const & breaks = struc.get_breaks();

        auto n_size = names.size();
        auto p_size = pairs.size();
        NUPACK_DEBUG_PRINT("names: " << n_size << " pairs: " << p_size);
        NUPACK_CHECK(n_size == p_size,
                     "Name structure size mismatch: " + to_string(n_size)
                     + " != " + to_string(p_size));

        Json::Value strands(Json::arrayValue);
        auto strand_names = struc.get_strand_names();

        for (auto & sn : strand_names) strands.append(sn);

        for (auto j = 0; j < n_size; j++) {
            curstruc["name"] = names[j];
            curstruc["structure"] = StructureUtils::pairs_to_dpp(pairs[j], breaks);
            curstruc["strands"] = strands;
            root.append(curstruc);
        }
    }
    return root;
}

Json::Value PhysicalSpec::make_json_tubes(const NupackInvariants & invars) const {
    Json::Value root(Json::arrayValue);
    real water_conc = water_molarity(invars.temperature);
    for (auto & t : tubes) {
        Json::Value curtube;

        curtube["name"] = t.get_name();
        auto const & complexes = t.get_complexes();

        Json::Value strucs(Json::arrayValue);

        for (auto & comp : complexes) {
            auto struc_ind = ord_struc_map[comp.order_ind];
            if (struc_ind >= 0) {
                auto & names = this->strucs[struc_ind].get_names();

                for (auto k = 0; k < comp.target_inds.size(); k++) {
                    Json::Value curtarget;

                    curtarget["name"] = names[comp.target_inds[k]];
                    curtarget["concentration[M]"] =
                        static_cast<double>(water_conc * comp.target_concs[k]);
                    strucs.append(curtarget);
                }
            }
        }
        root.append(curtube);
    }
    return root;
}
#endif // JSONCPP_FOUND

}
}
