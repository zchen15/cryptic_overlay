#include "tube_result.h"
#include "structure_result.h"
#include "complex_result.h"
#include "design_debug.h"
#include "pathway_utils.h"
#include "wrapper.h"
#include "adapter.h"
#include "algorithms.h"

// #include "equilibrium_concentrations.h"

#include <fstream>

namespace nupack {
namespace design {
void TubeResult::evaluate(const vec<StructureResult> & strucs,
        const vec<OrderResult> & orders, const vec<int> & ord_struc_map,
        const TubeSpec & tube, const NupackInvariants & opts) {

    using sp = ConcSolverParams;

    clear_state();

    auto const & complexes = tube.get_complexes();
    const int tube_id = tube.get_id();

    vec<real> pfuncs;
    vec<int> included_ids;
    vec<int> included_local_inds;
    vec<real> cur_target_x;
    vec<vec<int> > strands;
    vec<bool> include_strand;
    vec<int> strand_map;
    vec<int> rev_strand_map;

    double deflate = 1.0;

    int n_strucs = complexes.size();
    for (auto i_ord = 0; i_ord < n_strucs; i_ord++) {
        auto const & comp = complexes[i_ord];
        auto c_ord = comp.order_ind;
        NUPACK_CHECK(c_ord >= 0 && c_ord < ord_struc_map.size(),
                     to_string(c_ord) + " is an invalid structure index");

        if (ord_struc_map[c_ord] >= 0) {
            real cur_pfunc = strucs[ord_struc_map[c_ord]].get_pfunc();
            if (cur_pfunc > std::log(sp::min_delta)) {
                pfuncs.push_back(strucs[ord_struc_map[c_ord]].get_pfunc());
                included_ids.push_back(c_ord);
                included_local_inds.push_back(i_ord);

                real cur_x = 0.0;
                for (auto conc : comp.target_concs) cur_x += conc;
                cur_target_x.push_back(cur_x);

                strands.push_back(strucs[ord_struc_map[c_ord]].get_strands());
            }
        } else if (orders[c_ord].get_evaluated()) {
            real cur_pfunc = orders[c_ord].get_pfunc();
            if (cur_pfunc > std::log(sp::min_delta)) {
                pfuncs.push_back(cur_pfunc);
                included_ids.push_back(c_ord);
                included_local_inds.push_back(i_ord);

                real cur_x = 0.0;
                for (auto conc : comp.target_concs) cur_x += conc;
                cur_target_x.push_back(cur_x);

                strands.push_back(orders[c_ord].get_strands());
            }
        } else {
            deflate = 1.0 - tube.get_passive();
        }
    }

    int m_strucs = pfuncs.size();
    for (auto i_struc = 0; i_struc < m_strucs; i_struc++) {
        for (auto i_strand = 0; i_strand < strands[i_struc].size(); i_strand++) {
            if (strands[i_struc][i_strand] >= (int)include_strand.size()) {
                include_strand.resize(strands[i_struc][i_strand] + 1, false);
            }
            include_strand[strands[i_struc][i_strand]] = true;
        }
    }

    int j_strand = 0;
    int n_strands = include_strand.size();
    strand_map.resize(include_strand.size());
    for (auto i_strand = 0; i_strand < n_strands; i_strand++) {
        if (include_strand[i_strand]) {
            strand_map[i_strand] = j_strand;
            rev_strand_map.push_back(i_strand);
            j_strand++;
        } else {
            strand_map[i_strand] = -1;
        }
    }

    int m_strands = rev_strand_map.size();

    // Fill out the evaluation arrays
    vec<double> A;
    vec<double> x0;
    vec<double> logq;
    A.resize(rev_strand_map.size() * m_strucs, 0);

    for (auto i_struc = 0; i_struc < m_strucs; i_struc++) {
        logq.push_back((double) pfuncs[i_struc]);
        x0.push_back((double) cur_target_x[i_struc] * deflate);
        for (auto i_strand = 0; i_strand < strands[i_struc].size(); i_strand++) {
            j_strand = strand_map[strands[i_struc][i_strand]];
            A[j_strand * m_strucs + i_struc] += 1;
        }
    }

    real_mat mat_A = real_col(A);
    mat_A.reshape(m_strucs, m_strands);
    real_col mat_x0 = x0;
    real_col mat_logq = logq;

    // final concentrations
    vec<double> x;
    x.resize(m_strucs);

    // solver options
    concentration::Options ops;
    ops.tolerance = sp::tol;
    ops.delta_max = sp::delta_bar;
    ops.delta_min = sp::min_delta;
    ops.max_iters = sp::max_iters;

    auto sol = concentration::equilibrate(mat_A, mat_x0, mat_logq, ops);
    if (!sol.converged) NUPACK_ERROR("not converged");
    x = decltype(x)(sol.solution.begin(), sol.solution.end());
    // calc_conc_from_free_energies(x.data(), A.data(), dG.data(), x0.data(),
    // m_strands, m_strucs, sp::n_points, sp::max_iters, sp::tol, sp::delta_bar,
    // sp::min_delta, sp::max_trial, sp::perturb_scale, sp::quiet,
    // sp::write_log_file, sp::log_file, sp::seed, NULL);

    // Remap to Full concentration vec
    this->x.assign(n_strucs, 0);
    for (auto i_struc = 0; i_struc < m_strucs; i_struc++) {
        this->x[included_local_inds[i_struc]] = x[i_struc];
    }

    vec<vec<real>> target_x;
    for (auto & c : complexes) target_x.push_back(c.target_concs);
    this->target_x = target_x;


    // Calculate nodal and nucleotide defects
    for (auto i_ord = 0; i_ord < n_strucs; i_ord++) {
        auto & comp = complexes[i_ord];
        for (auto i_tar = 0; i_tar < comp.target_concs.size(); i_tar++) {
            auto c_ord = comp.order_ind;
            auto c_tar = comp.target_inds[i_tar];
            auto c_struc = ord_struc_map[c_ord];

            NUPACK_CHECK(c_struc >= 0, "on-target marked as off-target");

            real tx = target_x[i_ord][i_tar];
            real ax = this->x[i_ord];
            real x_defect = tx - ax;
            real x_act = ax;
            if (x_defect < 0) {
                x_defect = 0;
                x_act = tx;
            }

            real struc_defect = strucs[c_struc].get_structural_defect(c_tar);
            this->nuc_conc += strucs[c_struc].size() * tx;
            this->defect += (x_act * struc_defect + (strucs[c_struc].size() * x_defect));

            auto const & nuc_defects = strucs[c_struc].get_nuc_defects(c_tar);
            for (auto & nd : nuc_defects) {
                vec<int> ind(1, tube_id);
                append(ind, nd.first);
                this->nucleotide_defects[ind] += (x_act * nd.second + x_defect);
            }
        }
    }
}

void TubeResult::clear_state() {
    defect = 0.0;
    nuc_conc = 0.0;
    nucleotide_defects.clear();
}

void TubeResult::serialize(const TubeSpec & tube, const vec<StructureSpec> & strucspecs,
        const vec<int> & ord_struc_map, const NupackInvariants & invars,
        std::ostream & out, int indent, string prefix) const {

    auto const & complexes = tube.get_complexes();
    string ind_str(indent, ' ');
    string name_prefix(indent, ' ');

    ind_str = prefix + ind_str;
    if (indent >= 2) name_prefix = prefix + string(indent - 2, ' ') + "- ";
    real water_conc = water_molarity(invars.temperature);

    out << name_prefix << "name: " << tube.get_name() << std::endl;
    out << ind_str << "defect[M nt]: " << exp_format
        << this->get_defect() * water_conc << std::endl;
    out << ind_str << "nucleotide conc[M nt]: " << exp_format
        << this->nuc_conc * water_conc << std::endl;
    out << ind_str << "normalized defect: " << flt_format
        << this->get_defect() / this->nuc_conc << std::endl;
    out << ind_str << "complexes: " << std::endl;

    for (auto i_ord = 0; i_ord < complexes.size(); i_ord++) {
        auto i_struc = ord_struc_map[complexes[i_ord].order_ind];
        if (i_struc >= 0) {
            const string & name = strucspecs[i_struc].get_name();

            out << ind_str << "  - name: " << name << std::endl;
            out << ind_str << "    concentration: " << exp_format
                << (water_conc * this->x[i_ord]) << std::endl;

            real target_x = 0;
            for (auto i = 0; i < this->target_x[i_ord].size(); i++) {
                target_x += this->target_x[i_ord][i];
            }
            out << ind_str << "    target concentration: " << exp_format <<
                (water_conc * target_x) << std::endl;
        }
    }
}

}
}
