#include "design_result.h"
#include "design_debug.h"
#include "design_spec.h"

#include "algorithms.h"

#include <algorithm>

namespace nupack {
namespace design {

void DesignResult::init_random(const DesignSpec & spec) {
    const vec<int> vars = spec.constraints.init_random();
    this->eval.sequences.set_variables(vars, spec.eval.sequences);
}

bool DesignResult::is_tabu(const vec<int> & vars) {
    auto mutations = this->get_mutations(vars);
    return mutations.empty() || lin_contains(mutations, tabu);
}

void DesignResult::add_tabu(const vec<int> & vars) {
    vec<std::pair<int, int> > mutations = this->get_mutations(vars);
    this->tabu.push_back(mutations);
}

vec<std::pair<int, int> > DesignResult::get_mutations(const vec<int> & vars) {
    vec<std::pair<int, int> > mutations;
    const vec<int> & seqvars = this->eval.sequences.get_variables();

    NUPACK_CHECK(vars.size() == seqvars.size(),
                 "variable size " + to_string(vars.size())
                 + " does not match seqvar size " + to_string(seqvars.size()));

    for (auto i = 0; i < vars.size(); i++) {
        if (vars[i] != seqvars[i]) mutations.emplace_back(i, vars[i]);
    }
    return mutations;
}
}
}
