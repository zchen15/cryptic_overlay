#pragma once

#include "physical_spec.h"
#include "pair_probabilities.h"
#include "node_result.h"

#include "types.h"
#include "adapter.h"

#include <vector>
#include <string>
#include <memory>

//the character to use for comments.  This only affects the output,
//not the input files.
#define COMMENT_STRING "%"

namespace nupack {
namespace design {

class NodeResult;
/**
  * This class holds the evaluation results for a single complex that
  * may have a decomposition tree.
  */
class StructureResult {
    vec<int> sequence;
    vec<int> f_sequence;
    vec<int> nuc_ids;
    vec<vec<int>> structures;
    vec<int> struc_ids;
    vec<int> breaks;
    vec<int> strands;
    vec<int> strand_map;
    vec<int> domain_map;

    real defect;
    vec<real> defects;
    vec<vec<real>> pos_defects;
    vec<WeightMap> nuc_defects;

    vec<real> struc_energies;
    real pfunc;
    PairProbs ppairs;
    PairProbs target;
    int symmetry;

    real eval_time;
    
    void copy(const StructureResult & other);
protected:
    NodeResult tree;

public:
    StructureResult() : defect(DBL_MAX) {}

    void evaluate(const SequenceState & seqs, const StructureSpec & spec, const NupackInvariants & invars);
    
    int get_n_leaves() const { return this->tree.get_n_leaves(); }
    const WeightMap & get_nuc_defects(int i_target) const;

    real get_pfunc() const;
    real get_structural_defect(int i_target) const;
    real get_normalized_defect(int i_target) const;

    void serialize(const StructureSpec & spec, const NupackInvariants & invars, std::ostream & out,
                   int indent = 0, string prefix = "") const;

    const vec<int> & get_sequence() const { return this->sequence; }
    const vec<int> & get_strands() const { return this->strands; }
    const vec<int> & get_fake_sequence() const { return this->f_sequence; }

    string get_structure_string(int i_struc = 0) const;
    string get_sequence_string(const NupackInvariants & invars) const;

    int size() const { return this->sequence.size(); }
    int get_max_depth() const { return this->tree.get_max_depth(); }

    void replace_node(const StructureResult & other, int k,
                     const NupackInvariants & invars);

    void update_defects();

    void print_strucfiles(const StructureSpec & spec, const NupackInvariants & invars, string file_prefix) const;

    real get_energy(int i, const NupackInvariants & invars);

    real get_eval_time() const { return this->eval_time; }

    friend class StructureSpec;
};

}
}
