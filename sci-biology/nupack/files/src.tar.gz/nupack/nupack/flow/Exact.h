#pragma once
#include "../markov/Enumerate.h"
#include "../external/SDD.h"
#include "../standard/Flat.h"
#include "../jump/Jump.h"

namespace nupack {

/******************************************************************************************/

/// S = inv(n outer(p, p) - diag(p) R) - 1/n
/// S = -(1/n + inv(diag(p) R - outer(p, p)))
template <class Rates, class P, class V, NUPACK_IF(!la::is_sparse<Rates>)>
auto partial_inverse(Rates R, P const &pi, V const &index) {
    auto const scale = 1 / norm(R.diag());
    R *= scale;
    for (auto j : indices(pi)) R.col(j) = pi % (R.col(j) - pi(j));
    Mat<value_type_of<Rates>> rhs(len(pi), len(index));
    rhs.zeros(); izip(index, [&](auto i, auto j) {rhs(j, i) = 1;});
    R = solve(std::move(R), std::move(rhs));
    R = (-scale) + (-scale) * std::move(R);
    return R;
}

template <class Rates, class P, class V, class Solver, NUPACK_IF(la::is_sparse<Rates>)>
auto partial_inverse(Rates R, P const &pi, V const &index, Solver &&solve) {
    auto const scale = 1;// / norm(nonzeros(R.diag()));
    R *= scale;
    for (auto j : range(R.n_nonzero)) remove_const(R.values[j]) *= pi(R.row_indices[j]);

    Col<real> ones = pi; ones.fill(1);
    print(arma::max(R * ones), arma::max(arma::abs(R) * ones), arma::max(R.t() * ones), arma::max(arma::abs(R).t() * ones));
    print(arma::min(R * ones), arma::min(arma::abs(R) * ones), arma::min(R.t() * ones), arma::min(arma::abs(R).t() * ones));

    Mat<value_type_of<Rates>> rhs(len(pi), len(index)), S(len(pi), len(index));
    izip(index, [&](auto i, auto j) {rhs.col(i) =  pi; rhs(j, i) -= 1;});
    BEEP(norm(nonzeros(R)), norm(nonzeros(R - R.t())));
    solve(S, std::move(R), std::move(rhs), 1.e-20);
    // print(real(S(index[0], 1)), real(S(index[1], 0)));
    Col<value_type_of<Rates>> residual = S.t() * pi;
    BEEP(residual);

    for (auto i : indices(residual)) S.col(i) -= residual(i);
    BEEP(norm(R * S - rhs), norm(arma::abs(R) * S - rhs));
    // print(S(index[0], 1), S(index[1], 0));
    S *= scale;
    return S;
}

/******************************************************************************************/

template <class States, class BCs>
auto separated_rates(States const &ws, BCs const &bcs) {
    Mat<real> Rbc(len(bcs), len(ws)); Rbc.zeros();
    auto p = stationary_populations(ws);

    deque<std::tuple<usize, usize, real>> rs;
    for (auto i : range(len(ws) - len(bcs))) rs.emplace_back(i, i, 0);

    for_each_rate(ws, [&](auto i0, auto i1, auto r) {
        auto s = p(i0) * r;
        auto it0 = bcs.lower_bound(i0), it1 = bcs.lower_bound(i1);

        if (it0->first == i0) {
            auto j = it0 - begin_of(bcs);
            Rbc(j, j) -= s;
            if (it1->first == i1) Rbc(j, it1 - begin_of(bcs)) = s;
            else Rbc(it0 - begin_of(bcs), end_of(bcs) - it1 + i1) = s;
        } else {
            third_of(rs[begin_of(bcs) + i0 - it0]) -= s;
            if (it1->first != i1) rs.emplace_back(begin_of(bcs) + i0 - it0, begin_of(bcs) + i1 - it1, s);
        }
    });

    return std::make_pair(std::move(Rbc), la::matrix_from_tuples<SpMat<real>>(
        len(ws) - len(bcs), len(ws) - len(bcs), std::move(rs)));
}

/******************************************************************************************/

template <class Rates, class Map, class Solver, class Observer=NoOp>
auto enumerated_flow(Rates R, Map const &bcs, Solver &&solve, Observer &&callback={}) {
    auto scale = 1.0 / norm(nonzeros(R.second.diag()));
    R.first *= scale; R.second *= scale;

    auto const n = la::shape(R.first)[1];

    Col<real> g(n); g.zeros();
    izip(bcs, [&](auto i, auto p) {g(i) = p.second;});

    Col<real> rhs = R.first.tail_cols(n - len(bcs)).t() * -g.head(len(bcs));

    callback("Solving time (s):", time_it([&] {
        solve(g.tail(n - len(bcs)), std::move(R.second), rhs);
    }));

    real commute = -scale / as_scalar(g.head(len(bcs)).t() * R.first * g);
    return std::make_pair(g, commute);
}

/******************************************************************************************/

template <class W>
auto separated_system(W const &a, W const &b) {
    auto ws = enumerate_states(a.with_structure());
    print("Partition function", sum(ws, [](auto const &w){return w.boltz();}));
    FlatMap<usize, real> bcs;
    bcs[binary_search_index(ws, a)] = 0;
    bcs[binary_search_index(ws, b)] = 1;
    auto R = separated_rates(ws, bcs);
    return std::make_pair(std::move(R), std::move(bcs));
}

template <class T, class V>
auto all_rates(V const &states, real delta) {
    auto ws = enumerate_states(front(states).with_structure());
    auto index = vmap(states, [&](auto const &w) {return binary_search_index(ws, w);});
    auto pi = stationary_populations(ws);
    print("pf", sum(ws, [](auto const &w) {return w.boltz();}));
    print(imap(index, pi));
    auto R = rates_from_states<T>(ws, [&](auto i) {return delta / pi(i);});
    return move_as_tuple(R, pi, index);
}

/******************************************************************************************/

inline auto enumerated_partial_inverse(SddSolver const &solver, vec<JumpState<>> const &ws) {
    solver.wait();

    auto const Rpi = all_rates<real_csc>(ws, 0);
    auto const pi = second_of(Rpi);

    auto S = partial_inverse(first_of(Rpi), second_of(Rpi), third_of(Rpi), solver);

    Col<arma::uword> idx(len(third_of(Rpi)));
    izip(third_of(Rpi), [&](auto i, auto j) {idx(i) = j;});

    BEEP(la::eval(pi.rows(idx)));
    S = S.rows(idx);
    return S;
}

}
