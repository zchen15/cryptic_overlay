#pragma once

namespace nupack { namespace flow {

template <>
hierarchical_petal_decomposition(G, x0, t) {
    if (rad(x0, X)) <= 10 * log(n) * log(log(n)) return BFS(G);
    auto petals = petal_decomposition(G, x0, t);

    vec<T> Ts;
    for (auto p : petals) {
        P.set_path(p.x, p.t, 0.5);
        Ts.emplace_back(hierarchical_petal_decomposition(G, p.x, p.t));
    }
    return combine_trees(Ts);
}

template <>
auto petal_decomposition(G, x0, t) {
    auto delta = rad(x0, X), r0 = delta / 2;
    if (distance(x0, t) < r0) {
        G.add_path()
    } else {

    }
}


}}
