#pragma once
#include "../markov/Enumerate.h"
#include "../types/PairList.h"

namespace nupack {

/******************************************************************************************/

template <class State>
struct Subgraph {
    std::map<PairList, usize> pair_map;
    deque<State> states;
    SpMat<double> R;
    Col<double> p, g, flux, rhs, residual, diag;

    auto size() const {return len(states);}

    Subgraph(usize m) : R(m, m), p(m), g(m), flux(m), rhs(m), residual(m), diag(m) {
        R.zeros(); g.zeros(); flux.zeros(); rhs.zeros(); p.zeros(); residual.zeros(); diag.zeros();
    }

    usize lookup(usize i, PairList const &p) const {
        auto it = find(pair_map, p);
        return it == end_of(pair_map) ? i : it->second;
    }

    template <class ...Ts>
    void emplace(Ts &&...);

    void emplace_neighbor(usize);

    template <class Solver>
    void run_milestone_1(State const &, State const &, Solver &&);
};

/******************************************************************************************/

template <class State> template <class ...Ts>
void Subgraph<State>::emplace(Ts &&...ts) {
    auto i = size();
    states.emplace_back(fw<Ts>(ts)...);
    State &w = states.back();
    pair_map.emplace(w.pairs, i);

    //print("Emplaced", w.dp(), w.energy);
    p(i) = w.boltz();

    fork(w.model.rate_function, [&](auto const &rf) {
        for_all_moves(w, [&](auto b, auto c, auto dE) {
            auto s = p(i) * rf.unimolecular_rate(dE);

            w.pairs.toggle_pair(w.sys->index(b), w.sys->index(c));
            usize j = this->lookup(i, w.pairs);
            w.pairs.toggle_pair(w.sys->index(b), w.sys->index(c));

            if (j != i) {
                R(i, j) = s; R(j, i) = s;
                R(i, i) -= s; R(j, j) -= s;
                diag(i) += s; diag(j) += s;
                g(i) += g(j) * s;
            }
            if (j == 1 && i > 1) {
                print(i, j, s, p(i), rf.unimolecular_rate(dE), dE);
                rhs(i) = -s;
            }
        });
    });

    g(i) /= diag(i);
    flux(i) = p(i) * w.total_rate();
}

/******************************************************************************************/

template <class State>
void Subgraph<State>::emplace_neighbor(usize i) {
    auto w = states[i];
    if (!Release) NUPACK_REQUIRE(-R(i, i), <=, p(i) * w.total_rate());
    w.step([&](auto &&s) {
        w.pairs.toggle_pair(w.sys->index(s.base1), w.sys->index(s.base2));
        bool found = pair_map.count(w.pairs);
        w.pairs.toggle_pair(w.sys->index(s.base1), w.sys->index(s.base2));
        return !found;
    });
    this->emplace(std::move(w));
}

/******************************************************************************************/

template <class State> template <class Solver>
void Subgraph<State>::run_milestone_1(State const &wa, State const &wb, Solver &&solve) {
    this->emplace(wa);
    g(0) = 0;
    this->emplace(wb);
    g(1) = 1;

    for_pairlists_between(wa.pairs, wb.pairs, [&](auto const &p) {this->emplace(wa.with_structure(p));});
    izip(states, [](auto i, auto const &w) {print(i, w.dp());});

    auto t = span(0, size());
    auto s = span(2, size());
    g(s) = arma::linspace<real_col>(0, 1, size())(s - 1);

    for (auto i : range(p.n_elem - size())) {
        t = span{0, size()};
        s = span{2, size()};

        print("Solved", R.n_nonzero, size()-2, time_it([&]{
            try {
                real_col d; NUPACK_ERROR("fix me");// = R.diag();
                d = 1 / arma::sqrt(arma::abs(d(s)));
                real_col rhs2 = rhs(s) % d;
                real_col g2 = g(s);
                decltype(R) R2 = R(s, s);
                for (auto c : range(R2.n_cols)) R2.col(c) %= d;
                for (auto r : range(R2.n_rows)) R2.row(r) %= d.t();
                solve(g2, R2, rhs2);
                g(s) = g2 % d;
                //solve(g(s), R(s, s), rhs(s));
            } catch (...) {
                print_lns("rhs", rhs(s));
                print_lns("R", R(s,s));

                real_mat m = arma::conv_to<real_mat>::from(R(s, s));
                real_col r = rhs(s);
                m.save("R_error.txt", arma::raw_ascii);
                r.save("rhs_error.txt", arma::raw_ascii);
                std::throw_with_nested(Error("Couldnt solve ", i));
            }
        }));
        auto dirichlet_sum = -dot(R(t, t).row(1), g(t).t());
        auto commute = accu(p(t)) / dirichlet_sum;
        residual(t) = 2 * (1 - flux(t) / diag(t)) % (2 * g(t) % (R(t, t) * g(t)) - R(t, t) * square(g(t)));
        auto total_residual = accu(residual(t));

        print(i, no_space, ":", commute, dirichlet_sum, (1 + total_residual / dirichlet_sum) * commute);

        if (total_residual < 0.001 * dirichlet_sum) {
            print("Approximate Dirichlet sum =", dirichlet_sum);
            print("Approximate commute time =", commute);
            break;
        }

        auto r = random_range(0, total_residual);
        auto pick = find_cumulative(residual, r).first - begin_of(residual);
        emplace_neighbor(pick);
    }

}

/******************************************************************************************/

}
