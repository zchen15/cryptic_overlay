#pragma once
#include "Operations.h"
#include <taskflow/taskflow.hpp>
#include <atomic>
#include <thread>

namespace nupack {

/******************************************************************************************/

inline auto this_thread_id() {return std::this_thread::get_id();}

/******************************************************************************************/

inline auto default_thread_number() {return std::thread::hardware_concurrency();}

/******************************************************************************************/

template <class T, class U>
auto div_round_up(T const &t, U const &u) {return (t + u - 1) / u;}

struct SharedImpl {
    struct State {
        using simple_type = True;
        State(usize n=std::thread::hardware_concurrency()) : executor(n), max(n) {}

        tf::Executor executor;
        std::mutex mut;
        usize max;
    };

    SharedImpl(usize n=0) : state(std::make_shared<State>(n ? n : default_thread_number())) {}

    template <class E, class V, class F>
    bool spread(E &&env, V const &v, GrainSize const g, F const &f, Ignore) const {
        using I = decltype(len(v));
        tf::Taskflow flow;
        flow.parallel_for(static_cast<I>(0), len(v), static_cast<I>(1), [&](auto const i) {f(env, v[i], i);}, g.value);
        state->executor.run(flow).wait();
        return false;
    }

    template <class E, class V, class F>
    bool spread(E &&env, V const &v, GrainSize const g, F const &f, OrderedSplit) const {
        std::atomic<usize> count{0u};
        tf::Taskflow flow;
        for (std::size_t i = 0; i != div_round_up(len(v), g.value); ++i) flow.emplace([&] {
            auto begin = g.value * count++;
            auto const end = min(begin + g.value, len(v));
            for (; begin != end; ++begin) f(env, v[begin], begin);
        });
        state->executor.run(flow).wait();
        return false;
    }

    template <class R, class V>
    auto reduce(V const &v, R const &r) const {
        return std::accumulate(begin_of(v), end_of(v), value_type_of<V>(), r);
    }

    template <class E, class V, class F, class T>
    void map(E &&env, V &out, GrainSize g, F const &fun, T tag) const {
        spread(env, out, g, [&](auto &&env, auto const &, auto i) {
            out[i] = fun(env, out[i], i);
        }, tag);
    }

    auto n_workers() const {return state->max;}

    NUPACK_REFLECT(SharedImpl, state);

private:
    std::shared_ptr<State> state;
};

/******************************************************************************************/

}
