#pragma once

namespace nupack {

class Serializable_Task {

    struct Concept {
        virtual bool call() = 0;
        virtual ~Concept() = default;
    };

    template <class F, class ...Ts>
    struct Model : Concept {
        F f;
        std::tuple<Ts...> args;

        template <std::size_t ...Is>
        bool call(indices_t<Is...>) {return f(std::move(std::get<Is>(args))...);}

        bool call() override {return call(indices_in(args));}
    };

    std::unique_ptr<Concept> self;

public:
    template <class ...Ts>
    Serializable_Task(Ts const &...ts) : self(std::make_unique<Model<Ts...>>(ts...)) {}

    bool operator()() {return self->call();}

    NUPACK_REFLECT(Serializable_Task, self);
};

}
