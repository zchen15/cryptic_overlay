#pragma once

#include "H5.h"
#include "../standard/Map.h"

namespace nupack {

/******************************************************************************************/

struct H5Cache {

    struct Function_Cache {
        H5_Node node;
        Map<vec<char>, string> items;
        Function_Cache(H5_Node const &n, string s) : node(n, s) {
            for (auto &&i : node.keys())
                items.emplace(H5_Object(node, i).get_attribute("id"), i);
        }
    };

    H5_Node node;
    Map<string, Function_Cache> functions;

    /**************************************************************************************/

    template <class ...Ts>
    vec<char> serialization_key(Ts const &...ts) const {
        std::stringstream ss;
        Default_OArchive oa{ss};
        for_each(std::tie(ts...), [&](auto const &t){write_unique_or_serialize(oa, t);});
        auto s = std::move(ss).str();
        return {move_begin(s), move_end(s)};
    }

    /**************************************************************************************/

    H5Cache() = default;

    template <class ...Ts>
    H5Cache(Ts &&...ts) : node(fw<Ts>(ts)...) {
        for (auto &&f : node.keys()) functions.emplace(f, Function_Cache(node, f));
    }

    /**************************************************************************************/

    template <class F, class ...Ts>
    auto check_call(F &&f, Ts const &...ts) {
        decltype(f()) r;
        // Look up the function
        auto name = type_name(f);
        auto &fun = functions.emplace(name, Function_Cache(node, name)).first->second;
        // Look up the arguments
        auto key = serialization_key(ts...);
        auto p = fun.items.emplace(key, std::to_string(size(fun.items)));
        // Calculate or look up if it's there
        if (!p.second) H5_Object(fun.node, p.first->second).load(r);
        else H5_Object(fun.node, p.first->second, r = f()).set_attribute("id", key);
        return std::make_pair(r, p.second);
    }

    template <class F, class ...Ts>
    auto call(F &&f, Ts const &...ts) {return check_call(fw<F>(f), ts...).first;}

    /**************************************************************************************/

    H5Cache & inside(string) {return *this;}
};

/******************************************************************************************/

}
