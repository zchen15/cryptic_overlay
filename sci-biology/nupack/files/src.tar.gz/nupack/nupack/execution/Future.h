#pragma once
#include <future>

namespace nupack {

/******************************************************************************************/

template <class T>
class Future_State {
    std::atomic<bool> done;
    type_in<std::aligned_storage<sizeof(T), alignof(T)>> value;
    std::exception_ptr eptr;
    std::condition_variable cv;
    std::mutex mut;

public:

    Future_State() : done{false} {}

    template <class ...Ts>
    void set_value(Ts &&...ts) {
        new(&value) T(fw<Ts>(ts)...);
        done.store(true);
        cv.notify_all();
    }

    void wait() {
        std::lock_guard<std::mutex> lk{mut};
        cv.wait(lk, [&]{return done.load();});
    }

    T get() {
        wait();
        if (eptr) std::rethrow_exception(state->eptr);
        return std::move(*reinterpret_cast<T *>(&value));
    }
};

/******************************************************************************************/

template <class T>
class Future {
    std::shared_ptr<Future_State> state;
public:

    Future(Future const &) = delete;
    Future(Future &&) = delete;
    Future(std::shared_ptr<Future_State> p) : state(std::move(p)) {}

    void wait() {
        if (!state) throw std::future_error(std::future_errc::no_state);
        state->wait();
    }

    T get() {
        if (!state) throw std::future_error(std::future_errc::no_state);
        return std::move(state)->get();
    }

    template <class F, class R=decltype(declval<F>()(declval<T>()))>
    auto then(F &&f) {
        if (!state) throw std::future_error(std::future_errc::no_state);
        Promise<R> promise;
        auto ret = promise.get_future();
        std::thread([s=std::move(state)] {
            try {promise->set_value(f(s->get());}
            catch (...) {promise->set_exception(std::current_exception());}
        });
        return ret;
    }
}

/******************************************************************************************/

template <class T>
class Promise {
    bool done;
    std::shared_ptr<Future_State> state;
public:

    Promise(Promise const &) = delete;
    Promise(Promise &&) = delete;

    Promise() : done(false), state(std::make_shared<Future_State>(false)) {}

    template <class ...Ts>
    void set_value(Ts &&...ts) {
        if (done) throw std::future_error(std::future_errc::promise_already_satisfied);
        state->set_value(fw<Ts>(ts)...);
    }

    void set_exception(std::exception_ptr p) {
        if (done) throw std::future_error(std::future_errc::promise_already_satisfied);
        state->set_exception(p);
    }

    auto get_future() {return Future<T>(state);}
}

/******************************************************************************************/

}
