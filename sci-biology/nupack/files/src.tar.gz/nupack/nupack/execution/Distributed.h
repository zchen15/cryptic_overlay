/**
 * @brief Distributed memory parallelism
 * @todo Rework this API
 * @file Distributed.h
 * @author Mark Fornace
 * @date 2018-05-31
 */
#pragma once
#include "Local.h"

#ifndef NUPACK_MPI
    namespace nupack {using DistributedExec = Local;}
    namespace nupack {using HybridExec = Local;}
#else

#include <boost/mpi/collectives.hpp>

namespace nupack {

/******************************************************************************************/

//template <class T>
//struct MPI_Future {
//    boost::mpi::request request;
//
//    MPI_Future(boost::mpi::communicator &comm, int rank, int flag)
//
//};

/******************************************************************************************/

struct DistributedExec {
    boost::mpi::environment env;
    boost::mpi::communicator comm;
    using is_distributed = True;

    DistributedExec() = default;

    auto rank() const {return comm.rank();}
    auto m_size() const {return comm.size();}

    bool should_parallelize(real cost) const {
        return cost > 500.e-6; // 500 microseconds is smallest loop that should be parallelized
    }

    True lock() const {return {};} // return a dummy struct

    /**************************************************************************************/

    template <class B, class E, class F>
    bool spread(B const &b, E const &e, F const &f) {
        for (auto i : range(e - b)) if (i % m_size() == rank()) f(*this, b + i);
        return true;
    }

    template <class B, class E, class F>
    bool spread_if(bool p, B const &b, E const &e, F const &f) {
        if (p) return spread(b, e, f); else return Local().spread(b, e, f);
    }

    template <class B, class E, class F>
    bool spread_if(real cost, B const &b, E const &e, F const &f) {
        return spread_if(should_parallelize(cost), b, e, f);
    }

    /**************************************************************************************/

    template <class R=DefaultReducer, class T>
    void sync(T &t, R const &r={}) const {
        boost::mpi::all_reduce(comm, boost::mpi::inplace(t), r);
    }

    template <class R=DefaultReducer, class F>
    auto map_reduce(usize n, F &&f, R const &r={}) const {
        auto ret = serial_gather(n, fw<F>(f), r);
        boost::mpi::all_reduce(comm, boost::mpi::inplace(ret), r);
        return ret;
    }

    // maybe not the right functionality to perform
    template <class R=DefaultReducer, class T>
    auto reduce(T t, R const &r={}) const {
        boost::mpi::all_reduce(comm, boost::mpi::inplace(t), r);
        return t;
    }

    template <class C=DefaultConcatenator, class F>
    auto map(usize n, F const &f, C const &c={}) const {
        auto ret = serial_collect(n, f);
        boost::mpi::all_reduce(comm, boost::mpi::inplace(ret), c);
        return ret;
    }
};

/******************************************************************************************/

}

#endif
