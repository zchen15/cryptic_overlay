#pragma once
#include "ThreadPool.h"
#include "../algorithms/Utility.h"

#include <boost/asio.hpp>
#include <boost/asio/deadline_timer.hpp>

namespace nupack {
namespace asio = boost::asio;
namespace ip = boost::asio::ip;

/******************************************************************************************/

class Network_Task {

    struct Concept {
        virtual bool call() = 0;
        virtual ~Concept() = default;
    };

    template <class F, class ...Ts>
    struct Model : Concept {
        Model(F f_, Ts ...ts) : f(std::move(f_)), pack(std::move(ts)...) {}
        F f;
        std::tuple<Ts...> pack;

        template <std::size_t ...Is>
        bool call(indices_t<Is...>) {return f(std::move(std::get<Is>(pack))...);}

        bool call() override {return call(indices_in(pack));}
    };

    std::unique_ptr<Concept> self;

public:
    Network_Task() = default;

    template <class F, class ...Ts>
    Network_Task(F f, Ts ...ts) : self(std::make_unique<Model<F, Ts...>>(std::move(f), std::move(ts)...)) {}

    bool operator()() {return self->call();}

    NUPACK_REFLECT(Network_Task, self);

    ///  These have to be redone
    void load(std::istream &is) {BinaryInputArchive{is}(self);}
    void save(std::ostream &os) && {BinaryOutputArchive{os}(std::move(self));}

    operator bool() const {return bool(self);}
};

/******************************************************************************************/

struct Network_Resource {
    using Socket = typename asio::ip::tcp::socket;
    using Acceptor = typename asio::ip::tcp::acceptor;
    using Resolver = typename asio::ip::tcp::resolver;

    Resolver resolver;
    Acceptor acceptor;
    Socket socket;
    bool connected;

    template <class F>
    void accept(F const &action) {
        print("Starting listening for connection");
        acceptor.async_accept(socket, [action, this](auto ec) {
            if (ec) {print(ec.message()); return;}
            connected = true;
            action();
        });
    }

    void connect(char const *s) {
        typename Resolver::query q{"localhost", s};
        auto it = resolver.resolve(q);
        print("Resolved");
        asio::connect(socket, it);
        connected = true;
    }

    // Asynchronously sets up a function to be run whenever something is input
    template <class F> void listen(F const &action) {
        auto buf = std::make_shared<std::array<char, 3>>();
        asio::async_read(socket, asio::buffer(*buf), [this, buf, action](auto ec, auto n) {
            if (ec) print(ec.message());
            else {action(*buf); listen(action);}
        });
    }

    Network_Resource(asio::io_service &ios, asio::ip::tcp::endpoint e)
        : resolver(ios), acceptor(ios, e), socket(ios), connected(false) {}

};

/******************************************************************************************/

struct NetworkPool {
    using Queue = moodycamel::BlockingConcurrentQueue<Network_Task>;
    using Endpoint = typename asio::ip::tcp::endpoint;
    using Pool = ThreadResource<Network_Task>;

    std::shared_ptr<Pool> pool;
    std::shared_ptr<Network_Resource> resource;

    void connect(char const *s) {
        resource->connect(s);
        print("socket is connected and ready to write");
    }

    NetworkPool(asio::io_service &ios, asio::ip::tcp::endpoint e)
        : resource(std::make_shared<Network_Resource>(ios, e)), pool(std::make_shared<Pool>()) {
            usize n=1;//std::thread::hardware_concurrency();

        for (auto i : range(n)) pool->launch(true, [resource=this->resource](auto &threads) {
            print("Starting worker");
            moodycamel::ConsumerToken tok(threads.tasks);
            while (true) {
                Network_Task task;
                bool b = threads.tasks.try_dequeue(tok, task);
                if (b && task()) break;
                else if (resource->connected) {
                    print("No tasks to do, asking for one");
                    std::array<char, 3> ask = {'A', 'S', 'K'};
                    asio::write(resource->socket, asio::buffer(ask));
                    print("Wrote into buffer", ask);

                    asio::streambuf task_buffer;
                    asio::read(resource->socket, task_buffer);
                    std::istream is(&task_buffer);
                    task.load(is);
                    print("Read task from buffer", bool(task));
                    sleep(2s);
                }
            }
        });

        resource->accept([resource=this->resource, pool=this->pool] {
            print("Accepted connection");
            resource->listen([resource, pool](auto &buffer){
                print("Got a task request", buffer);
                Network_Task t;
                bool b = pool->tasks.try_dequeue(t);
                asio::streambuf task_buffer;
                std::ostream os(&task_buffer);
                std::move(t).save(os);
                print("Sending a task in return", b);
                asio::write(resource->socket, task_buffer);
            });
        });

        print("Exited constructor");
    }

    ~NetworkPool() {print("Closing NetworkPool"); resource->socket.close();}
};

/******************************************************************************************/

}
