#pragma once

#include "Distributed.h"
#include "Local.h"

namespace nupack {

/******************************************************************************************/

template <bool Root=true>
struct HybridExec : DistributedExec {
    using mpi = DistributedExec;
    std::conditional<Root, Local, Local &>::type shared;

    template <class ...Ts>
    HybridExec(boost::mpi::environment e={}, boost::mpi::communicator c={}, Ts &&...ts)
        : base_type(e, c), shared(fw<Ts>(ts...)) {}

    decltype(auto) lock() {return shared.lock();}

    // 500 microseconds is smallest loop that should be parallelized
    bool should_distribute(real cost) const {return cost > 500.e-6;}

    // 500 microseconds is smallest loop that should be parallelized
    bool should_parallelize(real cost) const {return cost > 500.e-6;}

    usize n_workers() const {return mpi::m_size() * shared.n_workers();}

    /**************************************************************************************/

    template <class T, class F>
    bool spread(T const &b, T const &e, F const &f) {
        tbb::parallel_for(tbb::blocked_range<usize>(mpi::rank(), e - b, mpi::m_size()), [&] (usize i) {f(*this, b + i);});
        return true;
    }

    template <class B, class E, class F>
    bool spread_if(bool p, B const &b, E const &e, F const &f) {
        if (p) return spread(b, e, f); else return Local().spread(b, e, f);
    }

    template <class B, class E, class F>
    bool spread_if(real cost, B const &b, E const &e, F const &f) {
        if (should_distribute(cost)) return spread(b, e, f);
        if (should_parallelize(cost)) return shared.spread(b, e, f);
        else return Local().spread(b, e, f);
    }

    /**************************************************************************************/

    template <class R=DefaultReducer, class V>
    auto reduce(V const &v, R const &r=DefaultReducer()) const {
        auto ret = shared_reduce(v, r);
        boost::mpi::all_reduce(base_type::comm, boost::mpi::inplace(ret), r);
        return ret;
    }

    template <class R=DefaultReducer, class F>
    auto map_reduce(usize n, F &&f, R const &r=DefaultReducer()) const {
        return reduce(base_type::comm, shared.map(n, f), r);
    }

    template <class C=DefaultConcatenator, class F>
    auto map(usize n, F const &f, C const &c=DefaultConcatenator()) const {
        return reduce(base_type::comm, shared.map(n, f), c);
    }
};

/******************************************************************************************/

}
