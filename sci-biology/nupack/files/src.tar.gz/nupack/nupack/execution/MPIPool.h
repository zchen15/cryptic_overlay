#pragma once

#include "ThreadPool.h"
#include "Task.h"
#include <boost/mpi.hpp>

namespace nupack {

/******************************************************************************************/

class MPI_Task {

    struct Concept {
        virtual string call() = 0;
        virtual ~Concept() = default;
    };

    template <class F, class ...Ts>
    struct Model : Concept {
        F f;
        std::tuple<Ts...> args;

        /// has to be redone
        template <std::size_t ...Is>
        string call(indices_t<Is...>) {
            std::stringstream ss;
            BinaryOutputArchive(ss)(f(std::move(std::get<Is>(args))...));
            return ss.str();
        }

        string call() override {return call(indices_in(args));}
    };

    std::unique_ptr<Concept> self;

public:
    template <class ...Ts>
    MPI_Task(Ts const &...ts) : self(std::make_unique<Model<Ts...>>(ts...)) {}

    string operator()() {return self->call();}

    NUPACK_REFLECT(MPI_Task, self);
};

/******************************************************************************************/

struct MpiPool {
    enum flag int {ASK_FOR_TASK, TASK_OFFER};

    boost::mpi::environment env;
    boost::mpi::communicator comm;
    ThreadPool local;
    std::thread listener;

    std::atomic<bool> kill;
    std::vector<boost::mpi::request> send_requests;

    void listen() {
        int task_requester;
        auto message = std::make_shared<std::pair<MPI_Task, int>>();
        auto request = boost::mpi::irecv(boost::mpi::any_source, ASK_FOR_TASK, task_requester);

        while (true) {
            if (kill.load()) return;
            if (request.test()) {
                try_dequeue(task);
                boost::mpi::send(task_requester, TASK_OFFER, task);
            }


            local.enqueue([m=std::move(message)] {
                try {
                    boost::mpi::send(m->second, 0, m->first());
                } catch (...) {
                    boost::mpi::send(m->second, 1);
                }
            });
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }
    }

    MpiPool(usize n=std::thread::hardware_concurrency()) : local(n), kill(false) {
        listener = std::thread(listen);
    }

    ~MpiPool() {kill.store(true); listener.join();}
};

/******************************************************************************************/

}
