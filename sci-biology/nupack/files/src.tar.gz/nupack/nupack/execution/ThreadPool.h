#pragma once
#include "../../external/concurrent-queue/blockingconcurrentqueue.h" // fix sometime
#include "Local.h"
#include "../iteration/Range.h"
#include <future>
#include "../algorithms/Utility.h"

namespace nupack {

/******************************************************************************************/

template <class T> void wait(std::future<T> &f);
template <class T> T get(std::future<T> &f);

/******************************************************************************************/

template <class Task=std::function<bool()>>
struct ThreadResource : std::enable_shared_from_this<ThreadResource<Task>> {
    using Queue = moodycamel::BlockingConcurrentQueue<Task>;

    Queue tasks;
    std::atomic<int> active, sleeping;
    int requested;
    std::condition_variable cv;
    std::mutex cv_mut;

    static thread_local ThreadResource * owner;

    ThreadResource() : active(0), sleeping(0), requested(0) {}

    template <class W>
    void launch(bool acting, W const &work) {
        ++requested;
        auto thread = std::thread([self=this->shared_from_this(), work] {
            owner = self.get();
            work(*self);
            --self->active;
        });
        if (acting) ++active;
        thread.detach();
    }

    void launch_worker() {
        launch(true, [](auto &self) {
            Task t;
            moodycamel::ConsumerToken tok(self.tasks);
            while (true) {
                self.tasks.wait_dequeue(tok, t);
                if (t()) break;
            }
        });
    }

    void launch_helper() {
        launch(false, [](auto &self) {
            Task t;
            moodycamel::ConsumerToken tok(self.tasks);
            while (true) {
                ++self.sleeping;
                std::lock_guard<std::mutex> lk{self.cv_mut};
                bool got = self.cv.wait_for(lk, std::chrono::milliseconds(100), [&] {
                    auto n = self.active++;
                    bool ret = n < self.requested;
                    if (!ret) --self.active;
                    return ret;
                });
                --self.sleeping;
                if (!got) return;
                while (true) {
                    self.tasks.wait_dequeue(tok, t);
                    if (t()) {--self.active; return;}
                    if (self.active.load() > self.requested) {--self.active; break;}
                }
            }
        });
    }
};

/******************************************************************************************/

template <class Task=std::function<bool()>>
class ThreadPool {

    std::shared_ptr<ThreadResource<Task>> self;

public:

    ThreadPool(ThreadPool const &) = delete;

    ThreadPool(usize n=std::thread::hardware_concurrency())
        : self(std::make_shared<ThreadResource<Task>>()) {
        for (auto i : range(n)) self->launch_worker();
    }

    template <class W>
    void launch(W const &work) {self->launch(true, work);}

    auto shared() {return self;}

    template <class F>
    auto enqueue(F &&fun) {
        auto prom = std::make_shared<std::promise<decltype(fun())>>();
        auto ret = prom->get_future();
        self->tasks.enqueue([prom, f=fun] {
            try {prom->set_value(f());}
            catch (...) {prom->set_exception(std::current_exception());}
            return false;
        });
        return ret;
    }

    template <class V, class F>
    void spread(V const &v, F &&f) {
        std::vector<Task> funs{indirect_view(v, [=](auto &&i) {return Task([=] {f(i); return false;});})};
        self->tasks.enqueue_bulk(begin_of(funs), len(funs));
    }

    struct Spread {
        Spread(int n) : count(n) {}
        std::atomic<int> count;
        moodycamel::BlockingConcurrentQueue<usize> indices;
        std::promise<void> promise;
    };

    template <class V, class F>
    std::future<void> spread(V v, usize m, F const &f) {
        int n = self->requested;
        auto sp = std::make_shared<Spread>(n);
        sp->indices.enqueue_bulk(begin_of(indices(v)), len(v));
        auto ret = sp->promise.get_future();

        auto bulk_f = [=] {
            moodycamel::ConsumerToken tok(sp->indices);
            std::vector<usize> is;
            while (true) {
                //auto adjusted_m = clamp<usize>(m, 1, sp->n_indices.load() / n);
                is.resize(m);
                auto got = sp->indices.try_dequeue_bulk(begin_of(is), m);
                if (!(got)) break;
                for (auto i : view(is, 0, got)) f(Local(), v[i]);
            }
            if (--sp->count == 0) sp->promise.set_value();
            return false;
        };

        self->tasks.enqueue_bulk(begin_of(copies(bulk_f, n)), n);
        ret.get();
        return ret;
    }

    ~ThreadPool() {
        if (!self) return; // was moved from
        for (auto i : range(self->requested)) self->tasks.enqueue(AlwaysTrue());
    }
};

/******************************************************************************************/

//template <class T> void wait(std::future<T> &f) {
//    auto self = ThreadResource::owner;
//
//    if (self) {
//        if (f.wait_for(std::chrono::seconds(0)) == std::future_status::ready) return;
//        else {
//            int expected = 0;
//            if (self->sleeping.compare_exchange_weak(expected, 1)) self->launch_helper();
//            --self->active;
//            self->cv.notify_one();
//            f.wait();
//            ++self->active;
//        }
//    } else f.wait();
//}

/******************************************************************************************/

//template <class T> T get(std::future<T> &f) {wait(f); return f.get();}

/******************************************************************************************/

template <class T> thread_local ThreadResource<T> * ThreadResource<T>::owner{nullptr};

/******************************************************************************************/

class Thread_Exec {
    struct Body {
        using simple_type = True;
        Body() = default;
        Body(usize n) : pool(n), max(n) {}
        ThreadPool<> pool;
        std::mutex mut;
        usize max;
    };

    std::shared_ptr<Body> body;
public:

    NUPACK_REFLECT(Thread_Exec, body);
    auto max() const {return body->max;}

    using is_distributed = False;

    struct in_order {};

    in_order affinity_split() const {return {};}
    in_order fixed_split() const {return {};}
    in_order ordered_split() const {return {};}

    Thread_Exec() = default;
    Thread_Exec(usize n) : body(std::make_shared<Body>(n)) {}

    /**************************************************************************************/

    // 500 microseconds is smallest loop that should be parallelized
    bool should_parallelize(real cost) const {return cost > 500.e-6;}

    /**************************************************************************************/

    template <class V, class F, class P=True>
    bool spread(V const &v, usize grain_size, F const &f, P={}) const {body->pool.spread(v, [&](auto i) {return f(*this, i);}); return true;}

    template <class V, class F>
    bool spread_if(bool p, V const &v, F const &f) const {if (p) return spread(v, f); return Local().spread(v, f);}

    template <class V, class F>
    bool spread_if(real cost, V const &v, F const &f) const {return spread_if(should_parallelize(cost), v, f);}

    /**************************************************************************************/

    template <class T> void sync(T const &) const {}

    /// Call a function on each input and return all results in a vector
    template <class F> auto map(usize n, F const &f) const {
        vec<no_ref<decltype(f(*this, n))>> ret(n);
        //tbb::parallel_for(usize(0), n, [&] (usize i) {ret[i] = f(*this, i);});
        return ret;
    }

    /**************************************************************************************/

    template <class R=DefaultReducer, class V>
    auto reduce(V const &v, R const &r=DefaultReducer()) const {
        //auto range = tbb::blocked_range<const_iterator_of<V>>(begin_of(v), end_of(v));
        //auto const acc = DefaultAccumulator();
        //return tbb::parallel_reduce(range, value_type_of<V>(),
        //    [&r, &acc](auto const &a, auto const &o) {return acc(begin_of(a), end_of(a), o, r);}, r);
    }

    /**************************************************************************************/

    template <class R=DefaultReducer, class F>
    auto map_reduce(usize n, F const &f, R const &r=DefaultReducer()) const {return reduce(map(n, f), r);}

    /**************************************************************************************/

    friend std::ostream & operator<<(std::ostream &os, Thread_Exec const &t) {return os << "Thread_Exec(" << t.max() << ")";}

    /**************************************************************************************/
};

}
