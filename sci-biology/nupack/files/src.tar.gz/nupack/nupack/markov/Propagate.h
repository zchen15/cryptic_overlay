#pragma once
#include "../types/Matrix.h"

#include <boost/serialization/array_wrapper.hpp>
#include <boost/numeric/odeint/stepper/runge_kutta_cash_karp54.hpp>
#include <boost/numeric/odeint/stepper/controlled_runge_kutta.hpp>
#include <boost/numeric/odeint/integrate/integrate_adaptive.hpp>

namespace nupack {

namespace odeint = boost::numeric::odeint;

/******************************************************************************************/

/// Propagate for one timestep of given length, by calculating matrix exponential
template <class M, class V>
void propagate_exactly(V &v, M const &R, real time) {v = v * arma::expmat(R * time);}

/******************************************************************************************/

template <class M, class V>
M propagate_exactly(V v, M R, real timestep, int reps) {
    R = arma::expmat(R * timestep);
    M ret(v.size(), reps);
    ret.col(0) = R * v;
    for (auto t : range(1, reps)) ret.col(t) = R * ret.col(t - 1);
    return ret;
}

/******************************************************************************************/

template <class M, class V>
M propagate_exactly(V const &v, M R, vec<real> const &times) {
    // Eigenvalue decomposition to get right hand side of expression
    Mat<complex_real> eigvec;
    Col<complex_real> eigval;
    eig_gen(eigval, eigvec, R);
    Col<complex_real> rhs = eigvec.i() * v;
    // Propagate for each timestep
    for (auto t : indices(times)) R.col(t) = la::re(eigvec * (arma::exp(eigval * times[t]) % rhs));
    return R;
}

/******************************************************************************************/

/// Use Runge-Kutta 4-5 to propagate a rate matrix and initial vector
template <class M, class V, class Obs=NoOp, typename=void_if<is_arma<M>>>
void rk_propagate(V &x, M const &R, real time, real timestep, Obs &&obs=NoOp()) {
    using error_stepper_t = odeint::runge_kutta_cash_karp54<vec<real>>;
    using controlled_stepper_t = odeint::controlled_runge_kutta<error_stepper_t>;
    // Derivative generating function
    auto f = [&] (vec<real> &x, vec<real> &dxdt, real const) {
        V dxdt_copy(&dxdt[0], len(dxdt), true); // See armadillo documentation
        dxdt_copy = R * V(&x[0], len(x), true);
    };
    // Copy into std::vector
    vec<real> x_init(x.begin(), x.end());
    // Make observer by converting std::vector to armadillo vector
    auto o = [&] (vec<real> &x, real t) {obs(t, V(&x[0], len(x), true));};
    // Plug into odeint
    controlled_stepper_t controlled_stepper;
    odeint::integrate_adaptive(controlled_stepper, f, x_init, real(), time, timestep, o);
    // Overwrite initial vector
    x = V(x_init);
}

/******************************************************************************************/

}
