#pragma once
#include "../types/Matrix.h"
#include "../common/Random.h"

namespace nupack::markov {

/*
 * Random stochastic matrix with uniform positive rates
 * Would be good to work in normal distribution, or maybe some distribution on the eigenvalues?
 */
template <class T>
auto random_stochastic(std::size_t n, bool symmetric=true) {
    Col<T> pi = la::randu<Col<T>>(n);
    pi *= 1 / la::accu(pi);
    Mat<T> R = la::randu<Mat<T>>(n, n);
    if (symmetric) R += R.t();
    R -= la::diagmat(la::sum(R, 1));
    R = la::diagmat(1/pi) * R;
    return std::make_pair(std::move(R), std::move(pi));
}

/******************************************************************************************/

struct HittingTime {
    usize dest;
    HittingTime(usize d) : dest(d) {};
    bool operator() (usize i, usize j, real) const {return dest == j;};
};

/******************************************************************************************/

template <class T>
struct RandomWalker {

    /// Transposed prefix sum matrix
    Mat<T> Rp;
    /// Flux out of each node
    Col<T> flux;

    NUPACK_REFLECT(RandomWalker, Rp, flux);

    /**************************************************************************************/

    RandomWalker(Mat<T> const &R) : flux(-R.diag()), Rp(R.t()) {
        Rp.diag().fill(0);
        NUPACK_ASSERT(la::all(R.diag() <= 0), "Diagonal of R should be negative by convention");
        for (auto j : range(R.n_cols))
            for (auto i : lrange(1, R.n_rows))
                Rp(i, j) += Rp(i - 1, j);
    };

    /**************************************************************************************/

    /*
     * Callback with state i, time spent in state i, next state j. Return true if trajectory should stop early.
     * time in state i is truncated if trajectory goes beyond max_time
     */
    template <class Obs, class RNG=decltype(StaticRNG)>
    std::pair<usize, real> operator() (usize i, real max_time, Obs &&obs, RNG &rng=StaticRNG) const {
        real t = 0;
        usize j = i;
        while (true) {
            // Add timestep
            auto ts = std::exponential_distribution<real>(flux(i))(rng);
            // Get the move
            auto r = std::uniform_real_distribution<real>(0, flux(i))(rng);
            j = binary_search_index(Rp.unsafe_col(i), r);
            t += ts;
            if (t < max_time) {if (obs(i, j, ts)) break;}
            else {obs(i, j, ts + max_time - t); break;}
            i = j;
        }
        return {j, t};
    }

    /**************************************************************************************/

    template <class I=std::uint32_t, class RNG=decltype(StaticRNG)>
    auto path(usize i, real max_time, RNG &rng=StaticRNG) const {
        vec<std::tuple<T, I, I>> out;
        (*this)(i, max_time, [&](auto i, auto j, auto t) {out.emplace_back(t, i, j); return false;}, rng);
        return out;
    }

    template <class I=std::uint32_t, class RNG=decltype(StaticRNG)>
    auto arrays(usize i, real max_time, RNG &rng=StaticRNG) const {
        auto const p = path(i, max_time, rng);

        Col<T> t(len(p) + 1);
        t(0) = 0;
        copy_range(indirect_view(p, first_of), view(t.begin() + 1, t.end()));

        Col<I> s(len(p) + 1);
        copy_range(indirect_view(p, second_of), view(s.begin(), s.end() - 1));
        s.end()[-1] = third_of(p.back());

        return std::make_pair(std::move(t), std::move(s));
    }

    /**************************************************************************************/

    template <class RNG=decltype(StaticRNG)>
    std::optional<real> hitting_time(usize i, usize j, real max_time, RNG &rng=StaticRNG) const {
        auto p = (*this)(i, max_time, HittingTime(j), rng);
        return p.first == j ? std::make_optional(p.second) : std::nullopt;
    }
};

void render(Document &doc, Type<RandomWalker<real>> t);

/******************************************************************************************/

}
