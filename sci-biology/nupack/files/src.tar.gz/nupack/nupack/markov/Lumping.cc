#include "Lumping.h"
#include <rebind/Document.h>

namespace nupack {

constexpr real ExactLumper::unused;

/******************************************************************************************/

ExactLumper::ExactLumper(usize n) {
    for (auto i : range(n)) {
        states.emplace_back(i, unused);
        state_locs.emplace_back(0, i);
    }
    blocks.emplace_back(begin_of(states), begin_of(states), end_of(states), false);
}

/******************************************************************************************/

ExactLumper::ExactLumper(vec<usize> const &v) {
    for (auto i : range(sum(v))) {
        states.emplace_back(i, unused);
        state_locs.emplace_back(0, i);
    }
    usize i = 0; for (auto const &b : v) {
        blocks.emplace_back(begin_of(states) + i, begin_of(states) + i, begin_of(states) + i + b, false);
        i += b;
    }
}

/******************************************************************************************/

void ExactLumper::update_locs(usize b) {
    for (auto i : iterators(blocks[b]))
        state_locs[i->index] = {b, static_cast<usize>(i - begin_of(blocks[b]))};
}

/******************************************************************************************/

usize ExactLumper::split_marked(usize b) {
    blocks.emplace_back(blocks[b]);
    blocks.back().set_end(blocks[b].middle());
    blocks[b].set_begin(blocks[b].middle());
    return len(blocks) - 1;
}

/******************************************************************************************/

void ExactLumper::split_by_weight(usize b, vec<usize> &v) {
    // If all weights are the same, nothing to do
    auto first_mismatch = find_first_mismatch(begin_of(blocks[b]), end_of(blocks[b]));
    if (first_mismatch == end_of(blocks[b])) return;
    // Sort states by weight
    sort(blocks[b], [](auto const &s1, auto const &s2) {return s1.weight < s2.weight;});
    auto it = first_mismatch;
    while (it != end_of(blocks[b])) {
        auto last_it = it;
        it = find_first_mismatch(it, end_of(blocks[b]));
        v.emplace_back(len(blocks));
        blocks.emplace_back(last_it, it, it, blocks[b].processed);
        update_locs(len(blocks) - 1);
    }
    blocks[b].set_end(first_mismatch);
    blocks[b].set_middle(first_mismatch);
    update_locs(b);
}

/******************************************************************************************/

// States should be in order
void ExactLumper::operator() (SortedRates const &R) {
    vec<usize> BT, UB = linspace<vec<usize>>(size());

    while (!UB.empty()) {
        // Take any block out of UB
        auto b1 = UB.back(); UB.pop_back(); blocks[b1].processed = true;
        vec<usize> ST;

        for (auto target : blocks[b1]) R.for_sources_of(target.index, [&](auto source, auto rate) {
            if (this->weight_of(source) != unused) this->weight_of(source) += rate;
            else {ST.emplace_back(source); this->weight_of(source) = rate;}
        });

        // Force split if there is only 1 block
        if (len(blocks) == 1 && all_equal(states)) weight_of(0) = unused;

        for (auto s : ST) if (weight_of(s)) {
            auto loc = find_state(s);
            if (!blocks[loc.block].n_marked()) BT.emplace_back(loc.block);
            mark(s, loc);
        }

        while (!BT.empty()) {
            auto b = BT.back(); BT.pop_back();
            // Give marked states to b1
            if (!blocks[b].n_unmarked()) b1 = b;
            else split_marked(b);
            // Find pmc
            int count = 0; real pmc = unused;
            for (auto s : blocks[b1]) {
                if (!count) pmc = s.weight;
                else if (close(s.weight, pmc)) ++count;
                else --count;
            }
            // Give all states with weight != pmc to b2
            auto b2 = split(b1, [=](auto s){return close(s.weight, pmc);});
            // Get new blocks by splitting by weight
            vec<usize> new_bs = {b1};
            if (!blocks[b2].empty()) {
                split_by_weight(b2, new_bs);
                new_bs.emplace_back(b2);
            }
            // Exclude the largest block if B was already processed
            if (blocks[b].processed) {
                if (b != b1) new_bs.emplace_back(b);
                swap_erase(new_bs, max_element(new_bs, [&](auto b){return len(blocks[b]);}));
            }
            // Add blocks to the unprocessed list
            extend(UB, new_bs);
            for (auto b : new_bs) blocks[b].processed = false;
        }
        for (auto s : ST) weight_of(s) = unused;
    }
}

/******************************************************************************************/

}
