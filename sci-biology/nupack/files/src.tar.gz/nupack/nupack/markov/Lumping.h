#pragma once

#include "../iteration/Search.h"
#include "../iteration/View.h"
#include "../common/Config.h"
#include "../standard/Vec.h"

#include "Matrices.h"

namespace nupack {

/******************************************************************************************/

// This fails if there are disconnected states
struct SortedRates {
    using RateTuples = deque<std::tuple<usize, usize, real>>;

    RateTuples rates;
    vec<RateTuples::iterator> locs;

    SortedRates(RateTuples rt) : rates(rt), locs({begin_of(rates)}) {
        sort(rates, [](auto const &r1, auto const &r2){return std::get<1>(r1) < std::get<1>(r2);});
        while (locs.back() != end_of(rates))
            locs.emplace_back(find_first_mismatch(locs.back(), end_of(rates),
                              [](auto const &r){return std::get<1>(r);}));
    }

    template <class F> void for_sources_of(usize target, F &&f) const {
        for (auto it : range(locs[target], locs[target + 1]))
            f(std::get<0>(*it), std::get<2>(*it));
    }

    friend std::ostream & operator<<(std::ostream &os, SortedRates const &r) {
        print_os(os, r.rates);
        vec<usize> ilocs; for (auto const &l : r.locs) ilocs.emplace_back(l - begin_of(r.rates));
        print_os(os, ilocs);
        return os;
    }
};

/******************************************************************************************/

struct ExactLumper {
    static bool close(real const &f1, real const &f2) {return std::abs(f1 - f2) < 0.01;};

    struct State_Loc {
        usize block, pos;
        NUPACK_REFLECT(State_Loc, block, pos);
        State_Loc(usize b, usize p) : block(b), pos(p) {};
    };

    struct State {
        usize index; real weight;
        NUPACK_REFLECT(State, index, weight);
        State(usize i, real w) : index(i), weight(w) {};

        friend bool operator==(State const &s1, State const &s2) {return close(s1.weight, s2.weight);}
        friend bool operator!=(State const &s1, State const &s2) {return !(s1 == s2);}
    };

    struct Block {
        using size_type = vec<State>::size_type;
        using iterator = vec<State>::iterator;

        View<iterator> marked, unmarked;
        bool processed;

        NUPACK_REFLECT(Block, marked, unmarked, processed);

        Block(iterator b, iterator m, iterator e, bool p=true)
            : marked(b, m), unmarked(m, e), processed(p) {};

        size_type n_marked() const {return end_of(marked) - begin_of(marked);};
        size_type n_unmarked() const {return end_of(unmarked) - begin_of(unmarked);};

        void set_begin(iterator it) {marked.set_begin(it);}
        void set_end(iterator it) {unmarked.set_end(it);}
        void set_middle(iterator it) {marked.set_end(it); unmarked.set_begin(it);}

        bool empty() const {return end_of(unmarked) == begin_of(marked);}

        auto begin() const {return begin_of(marked);};
        auto end() const {return end_of(unmarked);};
        auto middle() const {return end_of(marked);}
        size_type size() const {return end() - begin();}
    };

    void mark(usize s, State_Loc loc) {
        auto &b = blocks[loc.block];
        if (loc.pos < b.n_marked()) return; // already marked
        std::swap(state_locs[s], state_locs[front(b.unmarked).index]);
        std::swap(b.unmarked[loc.pos - b.n_marked()], front(b.unmarked));
        b.marked.set_end(b.marked.end()+1);
        b.unmarked.set_begin(b.unmarked.begin()+1);
    };

    static constexpr real unused = std::numeric_limits<real>::max();

    ExactLumper(usize n);
    ExactLumper(vec<usize> const &v);
    vec<State_Loc> state_locs;
    vec<State> states;
    vec<Block> blocks;

    NUPACK_REFLECT(ExactLumper, state_locs, states, blocks);

    void update_locs(usize b);

    usize split_marked(usize b);

    template <class F> usize split(usize b1, F const &f);

    void split_by_weight(usize b, vec<usize> &v);

    auto find_state(vec<State_Loc>::size_type i) const {return state_locs[i];}

    auto const & weight_of(usize i) const {return states[i].weight;}

    auto & weight_of(usize i) {return states[i].weight;}

    void operator() (SortedRates const &R);

    auto size() const {return len(blocks);}
};

/******************************************************************************************/

template <class F>
usize ExactLumper::split(usize b1, F const &f) {
    usize b2 = len(blocks); blocks.emplace_back(blocks[b1]);
    auto m = partition(blocks[b1].marked, f), um = partition(blocks[b1].unmarked, f);
    auto it = std::rotate(m, blocks[b1].middle(), um);
    blocks[b2].set_begin(it); blocks[b2].set_middle(it + (blocks[b1].middle() - m));
    blocks[b1].set_end(it); blocks[b1].set_middle(m);
    update_locs(b1); update_locs(b2);
    if (blocks.back().empty()) blocks.pop_back();
    return b2;
}

/******************************************************************************************/

}
