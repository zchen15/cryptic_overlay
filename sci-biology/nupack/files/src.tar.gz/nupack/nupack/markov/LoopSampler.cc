#include "LoopSampler.h"
#include "../jump/JumpSequenceSet.h"
#include "../model/Model.h"

namespace nupack {

bool has_pairable_bases(SequenceList const &v, Model<> const &model) {
    JumpSequenceSet s(SequenceSet(vmap<SubsequenceList>(v, caster<Subsequence>)), moves::full);
    s.update(model);
    return s.total_add_rate() > 0;
}

/******************************************************************************************/

/// Returns a vector of length max_len of one-hot encoded bases, padded with la::zeros from the middle
LoopSampler::EncodedSequence LoopSampler::encode_sequence(Sequence const &s, usize max_len) {
    EncodedBase const null = {false, false, false, false};
    EncodedSequence seq;
    seq.reserve(max_len);
    for (auto const c : s) if (c != Base('_'))
        seq.emplace_back(EncodedBase{c == Base('A') ? 1.0 : 0.0,
                                     c == Base('C') ? 1.0 : 0.0,
                                     c == Base('G') ? 1.0 : 0.0,
                                     c == Base('T') ? 1.0 : 0.0});
    /// fill the middle of the sequence with blanks
    seq.insert(seq.begin() + seq.size() / 2, max_len - seq.size(), null);
    return seq;
}

/// Returns a rank 3 tensor [# sequences, nick tag + # bases, # letters]
LoopSampler::EncodedLoop LoopSampler::encode_loop(SequenceList const &loop, usize max_seqs, usize max_len) {
    EncodedLoop A(max_seqs, max_len+1, 4, la::fill::zeros);
    izip(loop, [&](auto i, auto const &seq){
        A(i, 0, 0) = seq.back() == Base('_'); // sequence comes before strand break
        A(i, 0, 1) = seq.front() == Base('_');  // sequence comes after strand break
        izip(encode_sequence(seq, max_len), [&](auto j, auto const &b) {
            for (auto k: range(4)) A(i, j+1, k) = b[k];
        });
    });
    return A;
}

/******************************************************************************************/

void LoopSampler::discard(std::size_t ms, std::size_t ml) {
    auto filter = [ms, ml](Pos p) {
        return len(p->first) <= ms && all_of(p->first, [ml](auto const &s){
            return len(s) <= ml && !contains(s, Base('_'));
        });
    };
    // remove unpaired strands that are bigger than ml
    // remove reactions with any bigger than ms, ml
    // remove loops with any bigger than ms, ml
    decltype(unpaired) u;
    for (auto const &x: unpaired) if (filter(x)) u.emplace_hint(end_of(u), x);
    unpaired = std::move(u);

    decltype(reactions) r;
    for (auto const &x: reactions) if (all_of(x, filter)) r.emplace_hint(end_of(r), x);
    reactions = std::move(r);

    for (auto it = begin_of(loops); it != end_of(loops);) {
        if (filter(std::addressof(*it))) ++it;
        else it = loops.erase(it);
    }

    max_seqs = ms;
    max_len = ml;
}

/// Return matrix where row 0 is counts, rows 1: is free energies
Mat<real> LoopSampler::outputs(vec<Model<>> const &ems) const {
    auto const m = len(ems);
    auto Y = la::zeros<Mat<real>>(m + 1, len(loops));
    usize i = 0;
    izip(loops, [&](auto i, auto const &o) {
        Y(0, i) = o.second;
        izip(ems, [&](auto j, auto const &em) {Y(j+1, i) = em.loop_energy(o.first, find_nick(o.first));});
    });
    Y.row(0) /= accu(Y.row(0));
    return Y;
}

/******************************************************************************************/

/// Returns a vector of loop encodings for loops that are <= max_seqs by max_len
vec<LoopSampler::EncodedLoop> LoopSampler::inputs() const {
    vec<EncodedLoop> X;
    X.reserve(len(loops));
    for (auto const &o : loops)
        X.emplace_back(encode_loop(o.first, max_seqs, max_len));
    return X;
}

/******************************************************************************************/

SpMat<double> LoopSampler::reaction_matrix() const {
    auto const n = static_cast<iseq>(len(loops));
    auto const lookup = make_lookup();

    Col<double>  c(3 * len(reactions) + len(unpaired));   // the reaction coefficients
    arma::umat locs(2, 3 * len(reactions) + len(unpaired)); // the reaction coefficient locations

    usize i = 0, e = 0; // row, element index
    for (auto r : reactions) {
        std::array<int, 16> check;
        check.fill(0);
        for (auto const &s : first_of(r)->first) for (auto b : s) --check[b];
        for (auto const &s : second_of(r)->first) for (auto b : s) --check[b];
        for (auto const &s : third_of(r)->first) for (auto b : s) ++check[b];
        if (any_of(check, [](int i) {return i != 0 && i != -1;}))
            NUPACK_ERROR("Base mismatch", *first_of(r), *second_of(r), *third_of(r), check);
        if (sum(check) != -2)
            NUPACK_ERROR("Total mismatch", *first_of(r), *second_of(r), *third_of(r), check);

        locs(0, e) = i; locs(1, e) = lookup(first_of(r));  c(e) = -1; ++e;
        locs(0, e) = i; locs(1, e) = lookup(second_of(r)); c(e) = -1; ++e;
        locs(0, e) = i; locs(1, e) = lookup(third_of(r));  c(e) = +1; ++e;
        ++i;
    }

    for (auto const &u : unpaired) {
        locs(0, e) = i;
        locs(1, e) = lookup(u);
        c(e) = 1;
        ++e; ++i;
    }

    if (e < locs.n_cols) {locs.shed_cols(e, locs.n_cols-1); c.shed_rows(e, c.n_rows-1);}

    return {true, locs, c, i, n};
}

/******************************************************************************************/

void render(Document &doc, Type<LoopSampler> t) {
    doc.render<State>();
    doc.render<SpMat<double>>();
    doc.type(t, "core.LoopSampler");
    doc.method(t, "inputs", &LoopSampler::inputs);
    doc.method(t, "outputs", &LoopSampler::outputs);
    doc.method(t, "discard", &LoopSampler::discard);
    doc.method(t, "encode_loop", [](LoopSampler const &ls, SequenceList const &o) {return LoopSampler::encode_loop(o, ls.max_seqs, ls.max_len);});
    doc.method(t, "encode_sequence", [](LoopSampler const &ls, Sequence const &s) {return LoopSampler::encode_sequence(s, ls.max_len);});
    doc.method(t, "strings", &LoopSampler::strings);
    doc.method(t, "reaction_matrix", &LoopSampler::reaction_matrix);
    doc.method(t, "update_with_state", &LoopSampler::update_with_state<string, string>);
    doc.method(t, "pairable", [](LoopSampler const &s, Model<real> const &m) {return s.pairable(m);});
        //.pickle()
}

static_assert(is_arma<typename LoopSampler::EncodedLoop>, "");

void render_loop_sampler(Document &doc) {doc.render<LoopSampler>();}

}
