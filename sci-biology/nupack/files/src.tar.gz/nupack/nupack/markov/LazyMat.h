#pragma once
#include "../types/Matrix.h"
#include "../iteration/Range.h"

namespace nupack {

/******************************************************************************************/

struct Low_Rank_Mat {
    using size_type = arma::mat::size_type;

    arma::mat lh_evecs, rh_evecs;
    arma::vec evals;

    arma::mat operator() (span i, span j) const {
        return lh_evecs(i, arma::span::all) * diagmat(evals) * rh_evecs(arma::span::all, j);
    };

    static Low_Rank_Mat from_full(arma::mat const &M) {
        Low_Rank_Mat ret;
        arma::cx_mat evecs; arma::cx_vec evals;
        eig_gen(evals, evecs, M);
        ret.rh_evecs = pinv(la::re(evecs));
        ret.lh_evecs = la::re(std::move(evecs));
        ret.evals = la::re(std::move(evals));
        return ret;
    }
};

/******************************************************************************************/

template <class Mat>
struct AccessWrap {
    using size_type = arma::uword;

    AccessWrap(size_type r, size_type c, Mat const &m) : n_rows(r), n_cols(c), mat(m) {};
    size_type const n_rows, n_cols;
    Mat mat;

    arma::mat operator() (span i, span j) const {return mat(i, j);}
    arma::rowvec operator() (usize i, span j) const {return vectorise(mat(span(i, i+1), j));}
    arma::vec operator() (span i, usize j) const {return vectorise(mat(i, span(j, j+1)));}
    auto operator() (usize i, usize j) const {return as_scalar(mat(span(i, i+1), span(j, j+1)));}

    arma::mat Full() const {return mat(span(0, n_rows), span(0, n_cols));}

    arma::vec col(size_type j) const {return vectorise(mat(span(0, n_rows), span(j, j+1)));};
    arma::rowvec row(size_type i) const {return vectorise(mat(span(i, i+1), span(0, n_cols)));};

    arma::mat cols(size_type j1, size_type j2) const {return mat(span(0, n_rows), span(j1, j2+1));}
    arma::mat rows(size_type i1, size_type i2) const {return mat(span(i1, i2+1), span(0, n_cols));}
};

template <class Mat>
auto make_lazy(arma::uword r, arma::uword c, Mat m) {return AccessWrap<Mat>(r, c, m);}

/******************************************************************************************/

}
