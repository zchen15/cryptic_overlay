#pragma once

#include "LazyMat.h"
#include "../types/Matrix.h"
#include "../math/Matrices.h"
#include "../common/Config.h"
#include "../common/Random.h"
#include "../standard/Deque.h"
#include "../iteration/Search.h"

#include <utility>

namespace nupack {

/******************************************************************************************/

template <class M>
auto real_eigenvalues(M const &m) {
    Col<value_type_of<M>> eigs = la::real(la::eig_gen(m));
    std::sort(eigs.begin(), eigs.end(), greater_abs);
    return eigs;
}

/******************************************************************************************/

std::pair<la::vec, la::mat> eigs_gen_sm(la::sp_mat M, usize n);

/******************************************************************************************/

struct Distance {
    template <class Mat=la::mat, class vec, class X=bitwise_xor_t>
    static Mat from_states(vec const &v, X const &x={}) {
        auto ret = Mat(len(v), len(v));
        for (auto i : indices(v)) for (auto j : indices(v)) ret(i, j) = x(v[i], v[j]);
        return ret;
    };
};

/******************************************************************************************/

template <class UMat=la::umat, class Mat>
UMat integer_pp_distance(Mat const &D, usize n) {
    UMat ID(D.n_rows, D.n_cols);
    for_pairs(0, D.n_rows, [&](auto j, auto i){ID(i, j) = std::round(n * D(i, j));});
    return ID;
}

/******************************************************************************************/

template <class M>
auto fundamental_from_rates(M R, real_col pi) {
    auto const scale = 1 / norm(R.diag());
    R *= scale;
    // R.each_row() -= pi;
    for (auto i : indices(pi)) R.col(i) -= pi(i);
    R = la::inv(std::move(R));
    // R.each_row() += pi;
    for (auto i : indices(pi)) R.col(i) += pi(i);
    R *= -scale;
    return R;
}

template <class M, class C>
auto fundamental_from_rates(M const &R, C const &c, usize n) {
    Low_Rank_Mat ret;
    std::tie(ret.evals, ret.lh_evecs) = eigs_gen_sm(R, n);
    ret.rh_evecs = pinv(ret.lh_evecs);
    auto zero = max_element(ret.evals);
    ret.evals = -1.0 / ret.evals; *zero = 0;
    return make_lazy(R.n_rows, R.n_cols, ret);
}

/******************************************************************************************/

template <class Mat, NUPACK_IF(la::is_dense<Mat>)>
auto hitting_from_fundamental(Mat const &Z0, real_col const &p) {
    auto &&Z = Z0.eval();
    decay<decltype(Z)> H(Z.n_rows, Z.n_cols);
    la::for_cols(Z, [&](auto j) {H.col(j) = (Z(j, j) - Z.col(j)) / p(j);});
    return H;
};

template <class Mat, NUPACK_IF(!la::is_dense<Mat>)>
auto hitting_from_fundamental(Mat const &Z, real_col const &p) {
    return make_lazy(Z.n_rows, Z.n_cols, [&](span i, span j) {
        la::mat H = Z(i, j);
        for (auto k : j) H.col(k) = (Z(k, k) - Z(i, k)) / p(k);
        return H;
    });
};

/******************************************************************************************/

template <class Mat, NUPACK_IF(is_arma<Mat>)>
auto commute_from_hitting(Mat const &H) {return (H + H.t()).eval();}


template <class Mat, NUPACK_IF(!is_arma<Mat>)>
auto commute_from_hitting(Mat const &H) {
    return make_lazy(H.n_rows, H.n_cols,
        [&](auto i, auto j) -> la::mat {return H(i, j) + trans(H(j, i));});
};

template <class Mat, NUPACK_IF(is_arma<Mat>)>
auto commute_from_hitting_by_inverse(Mat const &H) {
    return (1.0 / (1.0 / H + 1.0 / H.t())).eval();
}


template <class Mat, NUPACK_IF(!is_arma<Mat>)>
auto commute_from_hitting_by_inverse(Mat const &H) {
    return make_lazy(H.n_rows, H.n_cols, [&](auto i, auto j) -> la::mat
        {return 1.0 / (1.0 / H(i, j) + 1.0 / trans(H(i, j)));});
};

/******************************************************************************************/

template <class V, class F=AlwaysZero>
auto rate_tuples_from_states(V const &v, F &&delta={}) {
    using T = real;
    deque<std::tuple<usize, usize, T>> tuples;
    // print("delta(0) =", T{delta(0)});
    for (auto i : indices(v)) tuples.emplace_back(i, i, delta(i));
    for_each_rate(v, [&](usize i, usize j, T rate) {
        tuples.emplace_back(i, j, rate);
        third_of(tuples[i]) -= rate; // subtract off the diagonal
    });
    return tuples;
}


template <class Mat=la::mat, class V, class F=AlwaysZero>
Mat rates_from_states(V const &v, F &&f={}) {
    return la::matrix_from_tuples<Mat>(len(v), len(v), rate_tuples_from_states(v, fw<F>(f)));
}

template <class Mat>
auto reversed_rates(Mat const &R, real_col const &p) {
    // p(i) R'(i, j) = p(j) R(i, j)
    return (outer(p, ((1.0 / p.t())) % R).eval()).eval();
}

/******************************************************************************************/

template <class V>
value_type_of<V> pearson_r2(V const &x, V const &y) {
    auto &&xx = x.n_elem * accu(x % x) - accu(x) * accu(x);
    auto &&yy = y.n_elem * accu(y % y) - accu(y) * accu(y);
    auto &&xy = x.n_elem * accu(x % y) - accu(x) * accu(y);
    return xy * xy / xx / yy;
}

/******************************************************************************************/

template <class vec=la::vec, class UMat, class Mat>
vec commute_histogram(UMat const &ID, Mat const &C, usize n) {
    auto times = la::zeros<vec>(n);
    auto counts = la::zeros<vec>(n);
    for_pairs(0, C.n_cols, [&](auto j, auto i){
        times(ID(i, j)) += C(i, j);
        counts(ID(i, j)) += 1;
    });
    return times / counts;
}

/******************************************************************************************/

template <class T>
Col<T> stationary_state(Mat<T> const &M) {
    Col<std::complex<T>> eigval;
    Mat<std::complex<T>> eigvec;
    eig_gen(eigval, eigvec, M.t());
    Col<T> eigs = abs(real(std::move(eigval)));
    auto min = min_index(eigs);
    print("min", eigs(min));
    eigs = real(eigvec.col(min));
    return eigs / accu(eigs);
}

/******************************************************************************************/

}
