#include "RandomNetwork.h"

#include <boost/graph/graphviz.hpp>

namespace nupack {

void RandomRateNetwork::write_graphviz(std::ostream & os) {
    Directed d;
    boost::copy_graph(graph, d);
    for (auto e = ebegin(); e != eend(); ++e) {
        auto ed = boost::add_edge(boost::target(*e, graph), boost::source(*e, graph), d).first;
        d[ed].rf = graph[*e].rb; d[ed].rb = graph[*e].rf;
    }
    auto es = boost::edges(d);
    for (auto e = es.first; e != es.second; ++e) d[*e].rf = std::log10(d[*e].rf);
    using E = decltype(*es.first);
    auto minmax = std::minmax_element(es.first, es.second, [&](E e1, E e2){return d[e1].rf < d[e2].rf;});
    auto fl = d[*minmax.first].rf;
    auto scale = 16.0 / (d[*minmax.second].rf - fl);
    for (auto e = es.first; e != es.second; ++e) d[*e].rf = 0.01 + (d[*e].rf - fl) * scale;

    boost::dynamic_properties dp;
    dp.property("node_id", get(boost::vertex_index, d));
    dp.property("penwidth", get(& Edge::rf, d));
    dp.property("label", get(& Vertex::energy, d));
    boost::write_graphviz_dp(os, d, dp);
}

}
