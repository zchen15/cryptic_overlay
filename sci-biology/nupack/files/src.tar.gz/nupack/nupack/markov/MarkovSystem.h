#pragma once
#include "Matrices.h"

namespace nupack {

/******************************************************************************************/

struct DenseMarkovSystem {
    real_mat Rates, Propagator;
    real_mat Hitting, Fundamental, Commute, Eigenvectors;
    real_col eigenvalues;

    NUPACK_REFLECT(DenseMarkovSystem, Rates, Propagator, Hitting, Fundamental, Commute, Eigenvectors, eigenvalues);

    template <class ...Ts>
    DenseMarkovSystem(Ts &&...ts) : Rates(fw<Ts>(ts)...) {
        Col<std::complex<real>> eigval;
        Mat<std::complex<real>> eigvec;
        eig_gen(eigval, eigvec, Rates.t());
        eigenvalues = la::re(std::move(eigval));
        Eigenvectors = la::re(std::move(eigvec));
        arma::uvec indices = sort_index(eigenvalues, "descend");
        eigenvalues = eigenvalues(indices);
        Eigenvectors = Eigenvectors.cols(indices);
        NUPACK_REQUIRE(std::abs(eigenvalues(0)), <, 1.e-6);

        Fundamental = fundamental_from_rates(Rates, stationary_state());
        Hitting = hitting_from_fundamental(Fundamental, stationary_state());
        Commute = commute_from_hitting(Hitting);
        Propagator = expmat(Rates);
    }

    real_col stationary_state() const {return Eigenvectors.col(0) / accu(Eigenvectors.col(0));}

    real mix_time() const {return -1 / eigenvalues(1);}

    real spectral_gap() const {return eigenvalues(1);}
};

/******************************************************************************************/

template <class M>
struct Basis {
    Basis(usize r, vec<usize> const &map, real_col const &p)
        : S_lump(la::zeros<M>(r, len(map))), S_unlump(la::zeros<M>(len(map), r)) {
        real_col p_lump(r); p_lump.zeros();
        izip(map, [&](auto i, auto j) {
            S_lump(j, i) = 1;
            S_unlump(i, j) = p(i);
            p_lump(j) += p(i);
        });
        for (auto i : range(r)) S_unlump.col(i) /= p_lump(i);
    }

    M S_lump, S_unlump;

    NUPACK_REFLECT(Basis, S_lump, S_unlump);

    M const & lump() const {return S_lump;}
    M const & unlump() const {return S_unlump;}
    auto n_lumped() const {return S_lump.n_rows;}
};

/******************************************************************************************/

}
