#pragma once
#include "../common/Random.h"
#include "../types/Matrix.h"
#include "../algorithms/Utility.h"

#include <boost/graph/random.hpp>
#include <boost/graph/adjacency_list.hpp>  // for vecS (ptr only), etc

namespace boost {struct directedS; struct undirectedS;}

namespace nupack {

/******************************************************************************************/

template <class Graph, class RNG=decltype(StaticRNG)>
Graph make_random_graph(usize v, usize e, RNG & gen=StaticRNG) {
    Graph g; boost::generate_random_graph(g, v, e, gen, false, false); return g;
}

/******************************************************************************************/

struct RandomRateNetwork {
    struct Vertex {double energy;};
    struct Edge {double rf, rb, scale;};
    using Graph = boost::adjacency_list<boost::vecS, boost::vecS, boost::undirectedS, Vertex, Edge>;
    using Directed = boost::adjacency_list<boost::vecS, boost::vecS, boost::directedS, Vertex, Edge>;

    Graph graph;

    auto ebegin() const {return boost::edges(graph).first;};
    auto eend() const {return boost::edges(graph).second;};
    auto vbegin() const {return boost::vertices(graph).first;};
    auto vend() const {return boost::vertices(graph).second;};

    template <class RNG=decltype(StaticRNG)>
    RandomRateNetwork(usize v, usize e, double e_spread, double r_spread, RNG & gen=StaticRNG) :
        graph(make_random_graph<Graph>(v, e, gen)) {
        for (auto v = vbegin(); v != vend(); ++v)
            graph[*v].energy = random_float(gen) * e_spread;

        auto rdist = uniform_distribution(1.0, r_spread);
        for (auto e = ebegin(); e != eend(); ++e) {
            graph[*e].scale = rdist(gen);
            auto dE = graph[boost::target(*e, graph)].energy - graph[boost::source(*e, graph)].energy;
            graph[*e].rf = graph[*e].scale * std::exp(-dE);
            graph[*e].rb = graph[*e].scale * std::exp(+dE);
        }
    }

    template <class M> void fill_rate_matrix(M & m) const {
        la::fill_zero(m);
        for (auto e = ebegin(); e != eend(); ++e) {
            auto i = boost::source(*e, graph), j = boost::target(*e, graph);
            la::at(m, i, j) = graph[*e].rf;
            la::at(m, j, i) = graph[*e].rb;
        }
        for (auto i = 0; i != la::n_cols(m); ++i) la::at(m, i, i) = -la::esum(m.col(i));
    }

    void write_graphviz(std::ostream & os);
};

/******************************************************************************************/

}
