#include "RandomWalk.h"

namespace nupack::markov {

void render(Document &doc, Type<RandomWalker<real>> t) {
    doc.type(t, "markov.RandomWalker");
    render_public(doc, t);
    doc.method(t, "new", rebind::construct<Mat<real> const &>(t));
    doc.method(t, "path", [](RandomWalker<real> const &w, uint i, real t) {return w.arrays(i, t);});
}

}

namespace nupack {

void render_markov(Document &doc) {
    doc.render<markov::RandomWalker<real>>();
}

}

