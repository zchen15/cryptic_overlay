#pragma once

#ifdef NUPACK_MLPACK
#include <mlpack/methods/kmeans/kmeans.hpp>
#endif

#include "../types/Matrix.h"
#include "../types/IO.h"
#include "../algorithms/Utility.h"

namespace nupack {

/******************************************************************************************/

#ifdef NUPACK_MLPACK
template <class Mat, typename=void_if<is_arma<Mat>>>
void k_means(Mat const &m, usize n, arma::Col<usize> &clusters, Mat &centroids) {
    mlpack::kmeans::KMeans<> k;
    k.Cluster(m, n, clusters, centroids);
}
#endif

/******************************************************************************************/

struct Simple_Acceptor {
    template <class T> bool operator() (T const &t1, T const &t2) const {return t2 < t1;};
};

/******************************************************************************************/

template <class D, class A=Simple_Acceptor>
arma::uvec k_medoids(usize n, usize max, D const &distance, A &&accept=Simple_Acceptor()) {

    arma::uvec medoids = linspace<arma::uvec>(n);// * (distance.n_cols / n);
    arma::uvec ret = medoids;
    arma::mat M(distance.n_rows, n+1);
    for (auto m : range(n)) M.col(m) = distance.col(medoids(m));

    // Current and previous cost
    auto c1 = accu(arma::min(M.head_cols(n), 1)), c0 = c1 * 2;
    //print(M);
    //print_lns(min(M, 1).eval(), "");
    print("Start:", c1);

    while (max--) {
        c0 = c1;
        for (auto m : range(n)) {
            la::for_cols(distance, [&](auto j) {
                M.col(n) = M.col(m);
                M.col(m) = distance.col(j);
                auto c2 = accu(arma::min(M.head_cols(n), 1));
                if (accept(c1, c2)) {
                    if (c2 > c1) NUPACK_BUG("ugh");
                    medoids(m) = j;
                    if(c2 < c1) ret = medoids;
                    c1 = c2;
                } else M.swap_cols(m, n);
                //print(accu(min(M, 1)));
            });
        }
    }
    //print(M);
    print("Finish", c1);
    return ret;
}

/******************************************************************************************/

template <class vec, class Mat>
vec clusters_from_medoids(vec const &medoids, Mat const &D) {
    vec ret(D.n_cols);
    Mat M = D.cols(medoids).t();
    for (auto i : range(ret.n_elem)) ret(i) = M.col(i).min();
    return ret;
}

/******************************************************************************************/

//lump
//    start with N clusters as consecutive chunks
//    while cost decreases
//        for c in clusters
//            for j in elements
//                propose moving j to c
//                if cost decreases accept

template <class Mat, class vec>
arma::uvec find_lumps(Mat const &M, vec const &p, usize n) {
    arma::uvec ret(M.n_rows), cluster_sizes(n);
    arma::umat clusters(M.n_rows, n);
    arma::mat rates(n, n, arma::fill::zeros);

    for_chunks(0, M.n_rows, n, [&](usize c, std::pair<usize, usize> p){
        print(c, p);
        cluster_sizes(c) = p.second - p.first;
        for (auto k : range(cluster_sizes(c))) clusters(k, c) = p.first + k;
        ret.subvec(p.first, p.second-1).fill(c);
    });

    print_lns(ret, cluster_sizes, clusters);

    auto cluster = [&](auto c){return clusters.col(c).subvec(0, cluster_sizes(c)-1);};

    real cost = 0;
    for (auto c : range(n)) for (auto d : range(n)) if (d != c) {
        // Total rate between clusters
        rates(c, d) = accu(M.submat(cluster(c), cluster(d)));
        // Total residual
        auto res = accu(square(sum(M.submat(cluster(c), cluster(d)), 1) - rates(c, d)));
        // Average for each element
        auto avg = res / (cluster(c).n_elem * cluster(d).n_elem);
        // Weighted by probability of cluster
        cost += avg / accu(p(cluster(c))) / accu(p(cluster(d)));
    }

    print(cost);

    return ret;
}

/******************************************************************************************/

}
