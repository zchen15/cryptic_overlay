#include "Matrices.h"
#include "../common/Error.h"

namespace nupack {

/******************************************************************************************/

std::pair<arma::vec, arma::mat> eigs_gen_sm(arma::sp_mat M, usize n) {
    arma::cx_mat evecs; arma::cx_vec evals;
    eigs_gen(evals, M, 1, "lm");
    real shift = la::re(evals(0));
    M -= shift * arma::speye<arma::sp_mat>(M.n_rows, M.n_cols);
    eigs_gen(evals, evecs, M, n, "lm", 0.01);
    if (!evals.n_elem) NUPACK_ERROR("couldn't converge eigen-decomposition");
    return {la::re(std::move(evals)) + shift, la::re(std::move(evecs))};
}

/******************************************************************************************/

arma::vec stationary_populations(arma::mat const &M) {
    arma::cx_vec eigval;
    arma::cx_mat eigvec;
    eig_gen(eigval, eigvec, M.t());
    arma::vec eigs = arma::abs(la::re(std::move(eigval)));
    auto min = min_index(eigs);
    eigs = arma::sort(eigs);
    print(eigs);
    eigs = la::re(eigvec.col(min));
    return eigs / accu(eigs);
}

/******************************************************************************************/

//arma::vec stationary_populations(arma::sp_mat const &M) {
//    arma::vec eigval; arma::mat eigvec;
//    std::tie(eigval, eigvec) = eigs_gen_sm(M.t(), 1);
//    NUPACK_REQUIRE(std::abs(eigval(0)) < 0.1);
//    return eigvec.col(0) / accu(eigvec.col(0));
//}

}
