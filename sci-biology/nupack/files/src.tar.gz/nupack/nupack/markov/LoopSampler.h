#pragma once
#include "../state/State.h"
#include "../types/Matrix.h"

namespace nupack {

/******************************************************************************************/

bool has_pairable_bases(SequenceList const &v, Model<> const &model);

struct LoopSampler {
    NUPACK_REFLECT(LoopSampler, loops, reactions, unpaired, max_seqs, max_len);

    /// Map of loops (lists of sequences) to count
    std::map<SequenceList, usize> loops;
    using Pos = value_type_of<decltype(loops)> const *;
    /// each reaction, has pointers to the 3 loops
    std::set<std::array<Pos, 3>> reactions;
    /// all the unpaired strands
    std::set<Pos> unpaired;

    std::size_t max_seqs=0, max_len=0;

    friend std::ostream & operator<<(std::ostream &os, LoopSampler const &) {return os << "LoopSampler()";}

    /// Put in a possibly new loop, return the iterator
    template <class O> auto emplace(O const &o) {
        auto seqs = lowest_rotation(vmap<SequenceList>(o, caster<Sequence>));
        auto p = loops.emplace(std::move(seqs), 0);
        if (o.exterior() && len(o) == 1) unpaired.emplace(iter_ptr(p.first)); // keep track of unpaired strands
        p.first->second += 1; // update count
        return p.first;
    }

    /// Put in all loops in a given state
    template <class ...Ts> void update_with_state(Ts ...ts) {
        State const w(std::move(ts)...);
        for (auto o : w) {
            auto kit = emplace(o);
            if (!o.is_root()){
                auto p = w[o.parent()];
                auto pit = emplace(p);
                auto w2 = w;
                o = merge_loops(p, o, w2);
                auto mit = emplace(o);
                if (pit->first > kit->first) swap(pit, kit); // sort reactants
                reactions.insert({iter_ptr(pit), iter_ptr(kit), iter_ptr(mit)});
            }
        }
    }

    /**************************************************************************************/

    /// Return a predicate that gives true if length constraints are satisfied on a sequence list
    void discard(usize n_seqs, usize seq_len);

    using EncodedBase = std::array<double, 4>;
    using EncodedSequence = vec<EncodedBase>;
    using EncodedLoop = la::Dense<double, 3>;
    // encoding is [sequence index, base index, nucleotide index]

    static EncodedSequence encode_sequence(Sequence const &o, usize max_len);
    static EncodedLoop encode_loop(SequenceList const &o, usize max_seqs, usize max_len);

    /**************************************************************************************/

    /// Return list of lists of sequences
    auto strings() const {
        return vmap(loops, [](auto const &o) {return SequenceList(view(o.first));});
    }

    /// Return matrix where row 0 is counts, rows 1: is free energies
    Mat<real> outputs(vec<Model<>> const &ems) const;

    /// Return matrix where row 0 is counts, row 1 is free energies, row >1 is encodings
    vec<EncodedLoop> inputs() const;

    // Makes a lookup from position to index
    auto make_lookup() const {
        using P = std::pair<Pos, usize>;
        auto ptrs = sorted(vmap(loops, [i=0](auto const &p) mutable {return P{address_of(p), i++};}));
        return [ptrs=std::move(ptrs)](Pos p) {
            auto it = lower_bound(ptrs, P(p, 0));
            if (it->first != p) NUPACK_ERROR("Index mismatch");
            return it->second;
        };
    }

    // Return sparse matrix of reaction coefficients
    SpMat<double> reaction_matrix() const;

    /**************************************************************************************/

    template <class M>
    auto pairable(M const &model) const {
        return vmap<small_vec<bool>>(loops, [&](auto const &p) {return has_pairable_bases(p.first, model);});
    }

    /**************************************************************************************/

    static constexpr auto repr_names() {return make_names("loops", "reactions", "unpaired");}

    using Triple = std::array<usize, 3>;

    /// serialization to a file
    auto save_repr() const {
        auto const lookup = make_lookup();
        auto rxns = vmap<vec<Triple>>(reactions, [&](auto const &r) -> Triple {
            return {lookup(r[0]), lookup(r[1]), lookup(r[2])};
        });
        auto uns = vmap<vec<usize>>(unpaired, lookup);
        return make_members(loops, std::move(rxns), std::move(uns));
    }

    /// serialization from a file
    void load_repr(decltype(loops) lps, vec<Triple> const &rxns, vec<usize> const &uns) {
        loops = std::move(lps);
        auto const pos = vmap(loops, address_of);
        for (auto r : rxns) reactions.insert({pos[r[0]], pos[r[1]], pos[r[2]]});
        for (auto u : uns) unpaired.insert(pos[u]);
    }
};

void render(Document &doc, Type<LoopSampler>);

/******************************************************************************************/

}
