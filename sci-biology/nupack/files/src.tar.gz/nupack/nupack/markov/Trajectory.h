#pragma once
#include "../types/Matrix.h"

namespace nupack {

template <class Mat>
struct Trajectory {

    Mat distances, rates, pinv;

    void load(std::istream &is) {
        string d, r;
        std::getline(is, d); distances.load(is);
        std::getline(is, r); rates.load(is);
    };

    void save(std::ostream &os) const {
        os << "Distances:\n"; distances.save(os);
        os << "Rates:\n"; rates.save(os);
    };

    friend std::ostream & operator<<(std::ostream &os, Trajectory const &t) {
        return os << "Distances:\n" << t.distances << "Rates:\n" << t.rates;
    }
};



}
