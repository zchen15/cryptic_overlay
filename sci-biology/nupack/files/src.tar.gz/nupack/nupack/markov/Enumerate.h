#pragma once
#include "Matrices.h"
// #include "../state/State.h"

namespace nupack {

/******************************************************************************************/

template <class V=arma::vec, class V2> V stationary_populations(V2 const &v) {
    V ret(len(v)); if (len(v) == 0) return ret;
    auto const &km = begin_of(v)->model;
    auto const scale = fork(km.rate_function, [](auto &&f) {return f.bimolecular_rate(0) / f.unimolecular_rate(0);});
    auto const beta = fork(km.rate_function, [](auto &&f) {return f.beta;});

    for (auto i : indices(v)) {
        ret(i) = boltzmann_factor(beta, v[i].energy) * pow(scale, len(v[i].sys->strands) - len(v[i].complexes));
    }
    return ret / arma::accu(ret);
}

/******************************************************************************************/

/// Allow recursion if it is lexicographically later; short-circuit with GU so GU pairs added later
template <class P>
bool enumerated_pair_compare(P const &p0, P const &p1) {
    return std::forward_as_tuple(is_gu(*p0.first, *p0.second), p0)
         < std::forward_as_tuple(is_gu(*p1.first, *p1.second), p1);
}

/**
 * @brief Enumerate states
 * @todo redo with reverse moves so only there are less copies
 * @todo fix isfinite to be is inf
 * @param w State
 * @param p least base-pair to consider
 * @param f visitor function
 */
template <class State, class P, class F>
void for_enumerated_states_impl(State w, P const &p0, F &&f) {
    // Exclude infinite energy states from the enumeration
    if (!std::isfinite(w.energy)) NUPACK_ERROR("State has non-finite energy", w.energy);
    // All hairpin additions possible
    for (auto const &o : w) for (auto const &m : o.add_moves()) {
        if (!std::isfinite(m.dE)) continue; // happens with terminal GT pairs
        auto const p1 = ordered_pair(m.b1, m.b2);
        if (enumerated_pair_compare(p0, p1)) {
            auto w1 = w;
            w1.emplace();
            w1[o.index()].split(w1, back(w1), m, w1.model);
            if (!std::isfinite(w1.energy)) NUPACK_ERROR("State has non-finite energy", m, w.energy, w1.energy);
            // reverse: something like w1[o.index()].merge(back(w1))
            for_enumerated_states_impl(std::move(w1), p1, f);
        }
    }
    // All complex joins possible
    for_all_joins(w, [&](auto const &m) {
        if (!std::isfinite(m.dE())) return;  // happens with terminal GT pairs
        auto const p1 = ordered_pair(m.loc1.b, m.loc2.b);
        if (enumerated_pair_compare(p0, p1)) {
            auto w1 = w;
            w1.associate(m);
            if (!std::isfinite(w1.energy)) NUPACK_ERROR("State has non-finite energy", m, w.energy, w1.energy);
            // reverse: another merge I guess
            for_enumerated_states_impl(std::move(w1), p1, f);
        }
    });
    f(std::move(w));
}

template <class State, class F>
void for_enumerated_states(State w, F &&f) {
    w.update_rates();
    auto p = std::make_pair(w.sys->total_begin(), w.sys->total_begin());
    return for_enumerated_states_impl(std::move(w), p, fw<F>(f));
}

/// Call a functor for every state that is a connected complex with the input order of strands
template <class State, class F>
void for_complex_states(State w, F &&f) {
    for_enumerated_states(std::move(w), [&](auto const &w) {
        // remove disconnected states
        if (len(w.complexes) != 1) return;
        // strands might be in a rotated order
        auto inds = w.complexes.complex_indices[0];
        rotate_min(inds);
        if (view(inds) == indices(inds)) f(w);
    });
}

/******************************************************************************************/

template <class State> vec<State> enumerate_states(State t) {
    deque<State> ws;

    for_enumerated_states(std::move(t),
        [&](auto &&w){ws.emplace_back(fw<decltype(w)>(w));});

    vec<State> ret; ret.reserve(len(ws));
    ret.assign(move_begin(ws), move_end(ws));
    return sorted(std::move(ret));
}

/******************************************************************************************/

template <class States, class State, class F>
void for_each_rate(States const &ws, State const &w, F &&f) {
    auto pairs = w.pairs;
    fork(w.model.rate_function, [&](auto const &rf) {
        for (auto const &o : w.loops) if (!o.is_root()) {
            auto bp = o.parent_base_pair();
            // Toggle base pair
            pairs.toggle_pair(w.sys->index(bp.first), w.sys->index(bp.second));
            // Find position in matrix
            auto pos = std::lower_bound(begin_of(ws), end_of(ws), pairs,
                [](auto const &w, auto const &p){return w.pairs < p;}) - begin_of(ws);
            // Toggle base pair back
            pairs.toggle_pair(w.sys->index(bp.first), w.sys->index(bp.second));
            // Forwards rate
            if (o.del_move.dE == decltype(o.del_move.dE)(*inf)) continue;
            f(true, pos, o.del_move.rate);
            // Backwards rate
            if (o.exterior() && w[o.parent()].exterior()) {
                f(false, pos, rf.bimolecular_rate(-o.del_move.dE));
            } else {
                f(false, pos, rf.unimolecular_rate(-o.del_move.dE));
            }
        }
    });
}

template <class States, class F> void for_each_rate(States const &ws, F &&f) {
    for (auto i : indices(ws))
        for_each_rate(ws, ws[i], [&](bool forward, usize j, auto r) {
            if (forward) f(i, j, r);
            else f(j, i, r);
        });
}

/******************************************************************************************/

template <class States, class Macrostates, class F>
auto map_lumped_states(States const &ws, Macrostates const &us, F &&f) {
    return vmap(ws, [&](auto const &w) -> usize {
        return min_element(us, [&](auto const &u){return f(w, u);}) - begin_of(us);
    });
}

/******************************************************************************************/

}
