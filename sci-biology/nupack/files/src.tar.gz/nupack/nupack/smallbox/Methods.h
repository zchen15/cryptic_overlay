#pragma once
#include "../types/Matrix.h"
#include "../iteration/Search.h"
#include "../standard/Deque.h"
#include "../kmc/Observables.h"

namespace nupack::kmc {

/******************************************************************************************/

/// For each trajectory, merge into an existing macrostate or make a new one
template <class V, class M>
V glob_trajectories(V const &ts, M match) {
    V us; // output macrostates
    for (auto const &t : ts) { // for each trajectory
        auto u = find_if(us, [&](auto const &u){return match(t, u);}); // find if any match it
        if (u == end_of(us)) us.emplace_back(t); // if not, add it as a new macrostate
        else for_each_zip(*u, t, [](auto &t, auto const &f) {t.merge(f);}); // else merge each component of the macrostate
    }
    return us;
}

/******************************************************************************************/

// Overly complicated templating, but this merges a vector of intervals into one interval
template <class V>
auto join_intervals(V const &v) {return join_intervals((value_type_of<V> *) nullptr, v);}

/******************************************************************************************/

// Build transition matrix from a list of transitions and return it
template <class Matrix, class T, class V>
auto matrix_from_transitions(T const &transitions, V const &times) {
    auto R = la::zeros<Matrix>(len(times), len(times));
    // Divide transition count by sample time
    for (auto p : transitions) R(p.first, p.second) += 1;
    for (auto i : indices(times)) R.row(i) /= times[i];
    return R;
}

// Correct rate matrix using detailed balance information
template <class Matrix, class F>
Matrix balanced_matrix(Matrix const &R0, F const &pf) {
    // Correct lower rate by detailed balance
    Matrix R = R0;
    for (auto i : range(R.n_rows)) for (auto j : range(R.n_cols)) {
        if (R0(i, j) < R0(j, i)) R(i, j) = R0(j, i) * pf(j) / pf(i); // correct the lower rate
        // BEEP(i,j,R(i,j),R(j,i), pf(i), pf(j)); // for some reporting on issues
    }
    return R;
}

template <class Matrix, class Us, class S, class M>
Matrix transition_matrix(Us &macros, S &&spawn, M &&matches) {
    // if (len(macros) <= 1) return la::zeros<Matrix>(len(macros), len(macros)); < this was bad
    // List of transitions between macrostates
    auto transitions = vec<std::pair<usize, usize>>();
    // Amount of time in reactant macrostate
    vec<real> times(len(macros));
    // # times a macrostate is hit, macrostates that have been explored, unexplored
    vec<usize> hits(len(macros)), explored, unexplored(indices(macros));

    while (!unexplored.empty()) {
        print(len(explored), '/', len(unexplored) + len(explored), "complete");
        // Get macrostate that has been most sampled
        auto it = max_element(unexplored, [&](auto i) {return hits[i];});
        // Move it to the explored category
        auto macro0 = *it; swap_erase(unexplored, it); explored.emplace_back(macro0);
        // Spawn trajectories from that macrostate (in this case macro0 is the index of the macrostate being explored)
        // stores as .first = slice of windows in trajectories and .second, whether or not those windows are good/complete
        for (auto pair_of_window_and_good : spawn(macros[macro0])) {
            auto stable_window = std::move(pair_of_window_and_good.first); // move the slice of windows
            bool trajectory_is_good = pair_of_window_and_good.second;
            times[macro0] += get(stable_window, end_time()) - get(stable_window, sample_time()) / 2;
            if (!trajectory_is_good) continue; // keep iterating through trajectory until a good set of windows is found
            // Find matching macrostate
            auto macro1 = find_if(macros, [&](auto const &u) {return matches(u, stable_window);}) - begin_of(macros);
            // "find_if" searches macros for newly discovered macrostate & returns the index. If it's not there, it will return index of length of vector + 1
            // subtract off begin_of(macros) means that now if macro1 is not in macros, it will be equal to the len(macros)
            // Add or merge in the trajectory
            if (macro1 == len(macros)) {
                unexplored.emplace_back(macro1);
                hits.emplace_back(0);
                times.emplace_back(0);
                macros.emplace_back(std::move(stable_window));
            }
            // Track transitions -- not sure if macro0==macro1 should be allowed
            if (macro0 != macro1) {transitions.emplace_back(macro0, macro1); ++hits[macro1];} // store a transition between macro0 and macro1 & a hit to macro1
        }
    } 
    print_lns("Occupancy times", times, "Hits", hits);
    return matrix_from_transitions<Matrix>(transitions, times);
}


/******************************************************************************************/

/// Pick a random state from an ordered set of states
/// Run it until a stop criterion and see if it lands outside that set
template <class States, class R, class S>
auto test_retention(States const &ws, R run, S stop) {
    return [&, run, stop] (auto &&...) -> usize {
        auto s = stop;
        auto w = run(* random_choice(ws), s); // take a random secondary structure from the set given
        return ordered_find(ws, w) != end_of(ws); // return if it is still in the set
    };
}

/******************************************************************************************/

/// Find hitting times between the MFEs, I think this is given the enumerated hitting time matrix H
template <class States, class Macrostates, class Hitting_Matrix>
real_mat transit_times(States const &ws, Macrostates const &us, Hitting_Matrix const &H) {
    real_mat ret(len(us), len(us));
    izip(us, [&](auto i, auto const &u) {
        izip(us, [&](auto j, auto const &v) {
        ret(i, j) = H(binary_search_index(ws, get(u, mfe_state())),
                      binary_search_index(ws, get(v, mfe_state())));

        });
    });
    return ret;
}

/******************************************************************************************/

}
