#pragma once
#include "../types/IO.h"
#include "../types/Matrix.h"
#include "../algorithms/Utility.h"
#include "../kmc/FreeEnergy.h"

namespace nupack {

/******************************************************************************************/

// Data for a macrostate in the small box algorithm
template <class Matrix, class State>
struct Macrostate {
    NUPACK_REFLECT(Macrostate, time, count, mfe, ppm);

    real time; // total time simulated in the macrostate
    usize count; // number of times the macrostate is encountered
    State mfe; // mfe state of the macrostate
    Matrix ppm; // pair probability matrix
    FE_Calc fe; // free energy calculation data

    Macrostate() : time(0), count(0) {};

    template <class Interval> Macrostate(Interval const & i)
        : mfe(i.mfe()), ppm(i.ppm), count(1), time(i.time()), fe(i.fe) {};

    // Merge a new trajectory slice in
    template <class Interval>
    void merge(Interval const & i) {
        ppm = weight_avg(ppm, i.ppm, time, i.time()); // take weighted average of current pairs and interval's pairs
        ++count; time += i.time(); // increment encountered count, increment time
        fe = fe + i.fe; // merge free energies
        if (i.mfe().energy < mfe.energy) mfe = i.mfe(); // update mfe
    }

    friend std::ostream & operator<<(std::ostream &os, Macrostate const &t) {
        return os << "Macrostate" << std::make_tuple(t.mfe.energy, t.mfe.dp(), t.count, t.fe.result());
    }
};

/******************************************************************************************/

}


