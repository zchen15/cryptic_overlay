#pragma once
#include "../standard/Deque.h"

namespace nupack::kmc {

/******************************************************************************************/

NUPACK_UNARY_FUNCTOR(next_window, t.next()); // functor to call .next() on an object

/// Class that scans across windows
template <class ...Ts>
struct Scanner : public ConstIndexable<Scanner<Ts...>> {
    std::tuple<Ts...> trackers; // tuple of things that are calculating quantities based on the trajectory
    bool full = true; // whether last window has been filled

    deque<decltype(map_each(declref<std::tuple<Ts...>>(), next_window))> contents; // data for each window
    usize max; // maximum number of windows, or 0 if no maximum

    using size_type = size_type_of<decltype(contents)>;
    using value_type = value_type_of<decltype(contents)>;

    explicit Scanner(usize max_, Ts ...ts) : trackers{std::move(ts)...}, max(max_) {}

    template <class State>
    void operator()(State const &w, real t) {
        // update each tracker
        for_each(slice<1, sizeof...(Ts)>(trackers), [&](auto &x){x(w, t);}); // update each tracker
        // if full, make a new interval
        if ((full = first_of(trackers)(w, t))) {
            contents.emplace_back(map_each(trackers, next_window));
            if (max && len(contents) > max) contents.pop_front(); // pop from front if growing too long
        }
    }

    bool good() const {return full && len(contents) >= 2;} // has at least 2 windows and is full right now

    auto const & iter() const {return contents;}

    /// Return view of the intervals by some key
    template <class P>
    auto intervals(P p) const {
        return indirect_view(contents, [p](auto const &i) -> decltype(get(i, p)) {return get(i, p);});
    }
};

template <class ...Ts>
auto scanner(usize max_, Ts &&...ts) {return Scanner<decay<Ts>...>{max_, fw<Ts>(ts)...};}

/******************************************************************************************/

// merge data between different intervals
template <class V, std::size_t ...Is>
auto join_tuple_intervals(V const &v, indices_t<Is...>) {
    return value_type_of<V>{join_intervals(indirect_view(v, at_c<Is>()))...};
}

// merge data between different intervals
template <class T, class V, NUPACK_IF(is_tuple<T>)>
auto join_intervals(T *, V const &v) {return join_tuple_intervals(v, indices_in<T>());}

}
