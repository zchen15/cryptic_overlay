#pragma once
#include "Methods.h"
#include "Scanner.h"
#include "../standard/Optional.h"
#include "../execution/Local.h"
#include "../kmc/Timer.h"
#include "../kmc/Pairing.h"
#include "../kmc/MFE.h"
#include "../kmc/Run.h"
#include "../kmc/FreeEnergy.h"
#include "../markov/Enumerate.h"
#include "../markov/MarkovSystem.h"
#include "../markov/Matrices.h"
#include "../types/Matrix.h"

namespace nupack::kmc {

/******************************************************************************************/

template <class E, class Ws>
auto run_small_box(E const &env, Ws const &states, real tau=2e-4, real match_=0.2, int spread=500, int n_pfunc=5000, real max_time=1000.0, bool log=false) {
    // criterion to decide if trajectory is stable based on windows
    // if log is true, uses changing time-window length method to find macrostates, returns log_scan
    // where is windows calculated?
    // criterion is "match" value
    auto check = [log](auto const &windows, auto const &criterion) {return log ? log_scan(windows, criterion) : last2_scan(windows, criterion);};
    /// criterion to decide if 2 macrostates are the same
    auto match = [=](auto const &...trajectories) {return pair_probability_l1(trajectories...) < match_;};

    // thing that scans the windows of a trajectory
    auto const scan0 = scanner(0, Timer::with_max_time(tau), // 0 means there's no limit on the number of windows
                              PairIntegrator<real_mat>(),
                            //   PairProbabilityBoltzmann<real_mat>(),
                              MfeRecorder<value_type_of<Ws>>(1),
                              FreeEnergyIntegrator(front(states).model.beta));
                            //   FreeEnergyIntegrator(front(states), front(states).model.beta));
                              

    // cutoff for too long trajectories
    auto const timer0 = Timer::with_max_time(max_time);

    /// Run the algorithm to get initial trajectories
    auto trajectories = vmap_if(env.map(len(states), 1, [&](auto &&, unsigned int i) {
        // copying these so they don't get modified
        auto scan = scan0;
        auto timer = timer0;

        // stop trajectory if ergodic
        auto stop_condition = [&] (Ignore, auto t) -> uint {
            if (timer(Ignore(), t)) return 1; // timer0 ran out
            if (scan.good() && len(scan) >= 2) return check(scan, match); // return true if windows are ergodic
            return 0; // otherwise return false, which means keep going
        };

        // run the trajectory
        auto n = runner()(copy(states[i]), stop_condition, scan);
        /// if timer0 ran out, return null, otherwise return the average quantities for the stable windows
        return timer.done() ? std::nullopt : std::make_optional(join_intervals(last_n(scan, 2 * n)));
    }));

    print("Initial trajectories:", len(trajectories));
    for (auto const &t : trajectories) print("   ", get(t, mfe_state()).dp(), get(t, mfe_state()).energy);

    // Glob close macrostates to get initial macrostates
    auto macrostates = glob_trajectories(std::move(trajectories), match);
    print("Initial macrostate MFEs:");
    for (auto const &macrostate: macrostates)
        print("   ", third_of(macrostate), tau * get(macrostate, mfe_state()).energy);



    /// exploration from these macrostates
    // spawn will store the trajectories run from the macrostates, which will stop if a new macrostate is reached (transition matrix will evaluate if that macrostate is unique & store info if true)
    auto spawn = [&](auto const &macrostate) {
        return env.map(spread, 1, [&](auto const &...) {
            auto scan = scan0;
            auto timer = timer0;
            // real macro_mfe_energy = get(macrostate, mfe_state()).energy

            /// stop if the trajectory is ergodic but doesn't match the macrostate it started in
            auto stop_condition = [&] (auto &&, auto t) -> uint {
                if (timer(Ignore(), t)) return 1; // timed out
                if (scan.good() && len(scan) >= 2 && len(scan)) // check that the windows are good/complete, there are at least 2 of them
                    if (!match(join_intervals(last_n(scan, 2)), macrostate)) // check that trajectory has ended in a state that doesn't match starting macrostate
                        return check(scan, [&](auto const &window_slices) {
                            return match(window_slices) && !match(join_intervals(window_slices), macrostate); // is stable and doesn't match original
                        });
                return 0;
            };

            // run the trajectory
            auto n = runner()(copy(get(macrostate, mfe_state())), stop_condition, scan);

            if (len(scan) < 2) NUPACK_ERROR("timeout is probably too small to get any valid intervals");
            // return 1) the slices of the stable part of the trajectory
            // and 2) whether the trajectory became stable
            return std::make_pair(join_intervals(last_n(scan, 2 * n)), !timer.done());
        });
    };
    /// counts transitions between macrostates and build the rate matrix from them
    // This is what actually RUNS the trajectories, accumulates counts as exploration proceeds and explores successive macrostates as those with most hits so far
    auto R0 = transition_matrix<real_mat>(macrostates, spawn, match);
    print_lns("Unbalanced rate matrix", R0);

    print("Final macrostate MFEs:");
    // for (auto const &macrostate: macrostates) print("   ", second_of(macrostate));
    for (auto const &macrostate: macrostates) print("   ", third_of(macrostate));

    // Calculate approximate PFs for each macrostate
    auto pfs = env.map(len(macrostates), 1, [&](auto &&, auto i) {
        auto weight = env.map_reduce(n_pfunc, 1,
            test_retention(
                get(macrostates[i], sampled_pairs()), // the set of encountered microstates that were ever seen in this macrostate
                pairs_runner(get(macrostates[i], mfe_state())), // says to run a trajectory from a given set of pairs
                Timer::with_max_time(tau))) // this says to run for length tau
                 / real(n_pfunc);
        return get(macrostates[i], partition_function()) / weight;
    });
    print_lns("Partition functions", pfs);

    /// fix up rate matrix so detailed balance is satisfied
    auto R = balanced_matrix(R0, [&](auto i) {return pfs[i];});

    Col<real> pi(pfs); pi /= la::accu(pi);

    R -= la::diagmat(la::sum(R, 1));
    print_lns("Balanced rate matrix", R);

    Col<real> check_residual = R.t() * pi; // If Rate matrix is balanced, this quantity should be zero
    print_lns("Pi", pi);

    return move_as_tuple(macrostates, R, pfs);
}

/******************************************************************************************/

template <class W, class Macrostates>
void enumerate_small_box(Macrostates macrostates) {
    auto const v = sorted(enumerate_states(W(get(front(macrostates), mfe_state()).sys, {})));
    print("Number of states:", len(v));

    macrostates = unique_sorted(std::move(macrostates), [](auto const &macrostate){return get(macrostate, mfe_state());});

    print("Calculating R");
    auto R = rates_from_states<Mat<real>>(v);
    auto p = stationary_populations(v);
    auto Z = fundamental_from_rates(R, p);
    auto H = hitting_from_fundamental(Z, p);

    print("Sparsity:", sparsity(R));

    for (auto const &macrostate : macrostates) print(get(macrostate, mfe_state()).dp());
    print_lns("Transit times between MFEs:", transit_times(v, macrostates, H));

    auto map = map_lumped_states(v, macrostates, [](auto const &w, auto const &macrostate) -> real {
        return pair_probability_l1(pp_from_state(w), get(macrostate, pair_probability()));
    });

    print_lns("Map from microstate to macrostate", map);

    auto S = Basis<real_mat>(len(macrostates), map, p);

    print_lns("Macrostate basis", S);

    real_col p1 = S.lump() * p;
    print_lns("Macrostate probabilities", p1);

    BEEP(la::shape(H), la::shape(S.unlump()), la::shape(S.lump()), la::shape(R));
    real_mat m2 = S.unlump().t() * R * S.lump().t();
    real_mat m3 = S.unlump().t() * Z * S.lump().t();
    print_lns("Matrices", m2, m3);

    for (auto i : indices(macrostates))
        p1(i) = p(binary_search(v, get(macrostates[i], mfe_state())) - begin_of(v));

    print_lns("MFE probabilities", p1);
}

/******************************************************************************************/

template <class M>
M run_enumerated(M const &R, Basis<M> const &S, real timestep, usize n) {
    print(accu(R));
    // Starting condition in minimal basis
    real_col x_min(S.n_lumped());
    x_min.zeros(); x_min(0) = 1;
    // Run system in Full basis
    M Xf = propagate_exactly(S.unlump() * x_min, R, timestep, n);
    // Back to minimal basis
    return S.lump() * Xf;
}

/******************************************************************************************/

inline real_mat optimize_small_box(real_col const &p, real_mat const &X) {
    auto n = X.n_rows, t = X.n_cols;
    // Define reactant and product states
    auto Xi = X.cols(0, t - 2);
    auto Xf = X.cols(1, t - 1);
    // Define optimization B
    real_mat B(n+2, n), A(n+2, n+2);
    B.row(0).fill(1);
    B.row(1) = trans(p);
    B.rows(2, n+1) = trans(Xi) * Xf + trans(Xf) * Xi;
    print_lns("B", B);
    // Define optimization A
    A(span(0, 0), span(0, n-1)).fill(1);
    A(span(1, 1), span(0, n-1)) = trans(p);
    A(span(2, n+1), span(0, n-1)) = 2 * trans(Xi) * Xi;
    A(span(2, n+1), span(n, n)) = p;
    A(span(2, n+1), span(n+1, n+1)).fill(1);
    A(span(0, 1), span(n, n+1)).fill(0);
    print_lns("A", A);
    // Run optimization
    real_mat R_min = solve(A, B);
    print("R", R_min);
    return R_min;
}

}
