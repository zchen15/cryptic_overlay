#pragma once
#include "Methods.h"
#include "Scanner.h"
#include "../standard/Optional.h"
#include "../execution/Local.h"
#include "../kmc/Timer.h"
#include "../kmc/Pairing.h"
#include "../kmc/MFE.h"
#include "../kmc/Run.h"
#include "../kmc/FreeEnergy.h"
#include "../markov/Enumerate.h"
#include "../markov/MarkovSystem.h"
#include "../markov/Matrices.h"
#include "../types/Matrix.h"

namespace nupack::kmc {

template <class E, class Ws>
auto original_small_box(E const &env, Ws const &states, real tau=2e-4, real match_=0.4, int spread=500, int n_pfunc=5000, real max_time=1000.0) {

    real match_equilibrium_ = 0.1; // this sets the requirement for two consecutive windows to be considered "ergodic"

    // check scans the last 2 windows using the match requirement to determine if either the system has transitioned to another macrostate or is still in starting one
    auto check = [&](auto const &windows, auto const &criterion) {return last2_scan(windows, criterion);};

    /// criterion to decide if 2 macrostates are the same
    auto match = [=](auto const &...trajectories) {return pair_probability_l1(trajectories...) < match_;};
    /// criterion to determine if 2 consecutive windows are in equilibrium
    auto match_equilibrium = [=](auto const &...trajectories) {return pair_probability_l1(trajectories...) < match_equilibrium_;};

    // thing that scans the windows of a trajectory
    auto const scan0 = scanner(0, Timer::with_max_time(tau), // 0 means there's no limit on the number of windows
                                // PairIntegrator<real_mat>(),
                                MfeRecorder<value_type_of<Ws>>(1));

    // cutoff for too long trajectories
    auto const timer0 = Timer::with_max_time(max_time);

    /// Run the algorithm to get initial trajectories
    auto trajectories = vmap_if(env.map(len(states), 1, [&](auto &&, unsigned int i) {
        // copying these so they don't get modified
        auto scan = scan0;
        auto timer = timer0;

        // stop trajectory if ergodic
        auto stop_condition = [&] (Ignore, auto t) -> uint {
            if (timer(Ignore(), t)) return 1; // timer0 ran out
            if (scan.good() && len(scan) >= 2) return check(scan, match_equilibrium); // return true if windows are ergodic
            return 0; // otherwise return false, which means keep going
        };

        // run the trajectory
        auto n = run_until(copy(states[i]), stop_condition, scan);
        /// if timer0 ran out, return null, otherwise return the average quantities for the stable windows
        // join interval of length tau, centered around midpoint of last two intervals
        return timer.done() ? std::nullopt : std::make_optional(join_intervals(view(end_of(scan) - (1.5 * tau), end_of(scan) - (0.5 * tau))));
    }));

    print("Initial trajectories:", len(trajectories));
    for (auto const &t : trajectories) print("   ", get(t, mfe_state()).dp(), get(t, mfe_state()).energy);

    // Get initial macrostates, count hits to each as initial probability
    auto [macrostates, init_hits] = match_trajectories(std::move(trajectories), match);
    print("Initial macrostate MFEs:");
    for (auto const &macrostate: macrostates)
        print("   ", third_of(macrostate), tau * get(macrostate, mfe_state()).energy);
    print("Initial macrostate probabilities");
    for (auto const &hit: init_hits)
        print("  ", (hit/len(states)));










    /// exploration from these macrostates
    // spawn will store the trajectories run from the macrostates, which will stop if a new macrostate is reached (transition matrix will evaluate if that macrostate is unique & store info if true)
    auto spawn = [&](auto const &macrostate) {
        return env.map(spread, 1, [&](auto const &...) {
            auto scan = scan0;
            auto timer = timer0;
            // real macro_mfe_energy = get(macrostate, mfe_state()).energy

            /// stop if the trajectory is ergodic but doesn't match the macrostate it started in
            auto stop_condition = [&] (auto &&, auto t) -> uint {
                if (timer(Ignore(), t)) return 1; // timed out
                if (scan.good() && len(scan) >= 2 && len(scan)) // check that the windows are good/complete, there are at least 2 of them
                    if (!match(join_intervals(last_n(scan, 2)), macrostate)) // check that trajectory has ended in a state that doesn't match starting macrostate
                        return check(scan, [&](auto const &window_slices) {
                            return match(window_slices) && !match(join_intervals(window_slices), macrostate); // is stable and doesn't match original
                        });
                return 0;
            };

            // run the trajectory
            auto n = runner()(copy(get(macrostate, mfe_state())), stop_condition, scan);

            if (len(scan) < 2) NUPACK_ERROR("timeout is probably too small to get any valid intervals");
            // return 1) the slices of the stable part of the trajectory
            // and 2) whether the trajectory became stable
            return std::make_pair(join_intervals(last_n(scan, 2 * n)), !timer.done());
        });
    };
    /// counts transitions between macrostates and build the rate matrix from them
    // This is what actually RUNS the trajectories, accumulates counts as exploration proceeds and explores successive macrostates as those with most hits so far
    auto R0 = transition_matrix<real_mat>(macrostates, spawn, match);
    print_lns("Unbalanced rate matrix", R0);

    print("Final macrostate MFEs:");
    // for (auto const &macrostate: macrostates) print("   ", second_of(macrostate));
    for (auto const &macrostate: macrostates) print("   ", third_of(macrostate));

    // Calculate approximate PFs for each macrostate
    auto pfs = env.map(len(macrostates), 1, [&](auto &&, auto i) {
        auto weight = env.map_reduce(n_pfunc, 1,
            test_retention(
                get(macrostates[i], sampled_pairs()), // the set of encountered microstates that were ever seen in this macrostate
                pairs_runner(get(macrostates[i], mfe_state())), // says to run a trajectory from a given set of pairs
                Timer::with_max_time(tau))) // this says to run for length tau
                 / real(n_pfunc);
        return get(macrostates[i], partition_function()) / weight;
    });
    print_lns("Partition functions", pfs);

    /// fix up rate matrix so detailed balance is satisfied
    auto R = balanced_matrix(R0, [&](auto i) {return pfs[i];});

    Col<real> pi(pfs); pi /= la::accu(pi);

    R -= la::diagmat(la::sum(R, 1));
    print_lns("Balanced rate matrix", R);

    Col<real> check_residual = R.t() * pi; // If Rate matrix is balanced, this quantity should be zero
    print_lns("Pi", pi);

    return move_as_tuple(macrostates, R, pfs);

}


//******************************************************************************************************************//


/// For each trajectory, match to an existing macrostate or make a new one, count # hits to macros as initial probability estimate
template <class V, class M>
V match_trajectories(V const &ts, M match) {
    V us; // output macrostates
    vec<usize> init_hits(len(us)); // record # hits to a macrostate from starting state
    for (auto const &t : ts) { // for each trajectory
        auto u = find_if(us, [&](auto const &u){return match(t, u);})- begin_of(us); // find if any match it
        if (u == len(us)) {
            us.emplace_back(t); // if not, add it as a new macrostate
            init_hits.emplace_back(1);
        }
        else {++init_hits[u];}; // add hit to known macrostate
    }
    return us, init_hits;
}


}
