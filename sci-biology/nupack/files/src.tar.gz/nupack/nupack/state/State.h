#pragma once
#include "StaticState.h"
#include "../model/Model.h"

namespace nupack {

/******************************************************************************************/

template <class S, class Model>
auto structure_energy(S &&sequences, PairList p, Model const &em) {
    StaticState<> w(sequences, std::move(p));
    return w.calculate_energy(em);
}

/******************************************************************************************/

}
