#pragma once

#include "../types/Sequence.h"
#include "../iteration/Patterns.h"

namespace nupack {

/******************************************************************************************/

struct LazySeqData {
    using simple_type = True;

    struct Base_Data {
        using simple_type = True;
        Base_Data() : hrate1(zero), hrate2(zero) {};
        Base_Array<real> dE_prev, dE_next, dE;
        Base_Array<real> hrate1, hrate2;

        friend std::ostream & operator<<(std::ostream &os, Base_Data const &t) {return os << t.dE;};
    };

    small_vec<Base_Data> base_data;
    real d3, d5;
    BaseMat<real> rate_sum, hrate1_sum, hrate2_sum;

    LazySeqData() : rate_sum(zero), hrate1_sum(zero), hrate2_sum(zero) {};
    template <class D, class It> void init(SubsequenceList const &, It, D const &);
    template <class Seq, class EM, class RF> void calc_me_hrate1(Seq const &, real, real &, EM const &, RF const &);
    template <class Seq, class EM, class RF> void calc_me_hrate2(Seq const &, real, real &, EM const &, RF const &);
    template <class Seq, class EM, class RF> void calc_mm_hrates(Seq const &, EM const &, RF const &);

    template <class Seq, class EM, class D, class Terminal_Prev, class Terminal_Next>
    void calc_sequence_dE(Seq const &, EM const &, D const &, Terminal_Prev const &, Terminal_Next const &);
};

void render(Document &doc, Type<LazySeqData>);

/******************************************************************************************/

template <class Seq, class EM, class D, class TPrev, class TNext>
void LazySeqData::calc_sequence_dE(Seq const &s, EM const &em, D const &dangle, TPrev const &tp, TNext const &tn) {
    NUPACK_DREQUIRE(len(s), >, 2);
    auto & d = base_data;
    if (len(s) == 3) {
        for (auto c : em.pairs(s[1])) {
            d[0].dE_prev[c] = tp(s[1], c) - dangle.reduce(d3, d5);
            d[0].dE_next[c] = tn(s[1], c) - dangle.reduce(d3, d5);
            d[0].dE[c] = tp(s[1], c) + tn(s[1], c) - dangle.reduce(d3, d5);
        }
    } else if (len(s) == 4) {
        for (auto c : em.pairs(s[1])) {
            d[0].dE_next[c] = tn(s[1], c) - d3 - d5;
            d[0].dE_prev[c] = tp(s[1], c) + dangle.reduce(dangle.energy5(c, s[1], s[2]), d3) - d5 - d3;
            d[0].dE[c] = d[0].dE_prev[c] + tn(s[1], c);
        }

        for (auto c : em.pairs(s[2])) {
            d[1].dE_prev[c] = tp(s[2], c) - d3 - d5;
            d[1].dE_next[c] = tn(s[2], c) + dangle.reduce(dangle.energy3(s[1], s[2], c), d5) - d5 - d3;
            d[1].dE[c] = d[1].dE_next[c] + tp(s[2], c);
        }
    } else if (len(s) == 5) {
        for (auto c : em.pairs(s[1])) {
            d[0].dE_next[c] = tn(s[1], c) - d3 - d5;
            d[0].dE_prev[c] = tp(s[1], c) + dangle.energy5(c, s[1], s[2]) - d5;
            d[0].dE[c] = d[0].dE_prev[c] + tn(s[1], c);
        }
        for (auto c : em.pairs(s[2])) {
            d[1].dE_prev[c] = tp(s[2], c) + dangle.reduce(dangle.energy5(c, s[2], s[3]), d3) - d3 - d5;
            d[1].dE_next[c] = tn(s[2], c) + dangle.reduce(dangle.energy3(s[1], s[2], c), d5) - d3 - d5;
        }
        d[1].dE = d[1].dE_prev + d[1].dE_next + d5 + d3;
        for (auto c : em.pairs(s[3])) {
            d[2].dE_prev[c] = tp(s[3], c) - d3 - d5;
            d[2].dE_next[c] = tn(s[3], c) + dangle.energy3(s[2], s[3], c) - d3;
            d[2].dE[c] = d[2].dE_next[c] + tp(s[3], c);
        }
    } else {
        decltype(len(s)) i = 1; for (auto c : em.pairs(s[i])) {
            d[i-1].dE_next[c] = tn(s[i], c) - d3 - d5;
            d[i-1].dE_prev[c] = tp(s[i], c) + dangle.energy5(c, s[i], s[i+1]) - d5;
            d[i-1].dE[c] = d[i-1].dE_prev[c] + tn(s[i], c);
        }
        i = 2; for (auto c : em.pairs(s[i])) {
            d[i-1].dE_prev[c] = tp(s[i], c) + dangle.energy5(c, s[i], s[i+1]) - d5;
            d[i-1].dE_next[c] = tn(s[i], c) + dangle.reduce(dangle.energy3(s[i-1], s[i], c), d5) - d5 - d3;
        }
        d[i-1].dE = d[i-1].dE_prev + d[i-1].dE_next + d3 + d5;
        i = len(s) - 3; for (auto c : em.pairs(s[i])) {
            d[i-1].dE_next[c] = tn(s[i], c) + dangle.energy3(s[i-1], s[i], c) - d3;
            d[i-1].dE_prev[c] = tp(s[i], c) + dangle.reduce(dangle.energy5(c, s[i], s[i+1]), d3) - d5 - d3;
        }
        d[i-1].dE = d[i-1].dE_prev + d[i-1].dE_next + d5 + d3;
        i = len(s) - 2; for (auto c : em.pairs(s[i])){
            d[i-1].dE_prev[c] = tp(s[i], c) - d3 - d5;
            d[i-1].dE_next[c] = tn(s[i], c) + dangle.energy3(s[i-1], s[i], c) - d3;
            d[i-1].dE[c] = d[i-1].dE_next[c] + tp(s[i], c);
        }
        i = 2; for (auto b = begin_of(s) + 3; b < end_of(s) - 3; ++i, ++b) {
            for (auto c : em.pairs(*b)) {
                d[i].dE_prev[c] = tp(s[i], c) + dangle.energy5(c, b[0], b[1]) - d5;
                d[i].dE_next[c] = tn(s[i], c) + dangle.energy3(b[-1], b[0], c) - d3;
            }
            d[i].dE = d[i].dE_prev + d[i].dE_next + d5 + d3;
        }
    }
}

/******************************************************************************************/

template <class D, class It> void LazySeqData::init(SubsequenceList const &v, It s, D const &dangle) {
    d5 = (front(*s) == Base('_')) ? *zero : dangle.energy5(back(*cyclic_prev(v, s)), s[0][0], s[0][1]);
    d3 = (back(*s) == Base('_'))  ? *zero : dangle.energy3(back(*s, -1), back(*s), front(*cyclic_next(v, s)));
    base_data.resize(len(*s) - 2);
}

/******************************************************************************************/

template <class Seq, class EM, class RF>
void LazySeqData::calc_me_hrate1(Seq const &s, real e_seqs, real & e_bases, EM const &em, RF const &rf) {
    // Update partial sums with this sequence
    zip(s.offset(1, -1), base_data, [&](auto b, auto &bd) {
        for (auto c : em.pairs(b))
            hrate1_sum(b, c) += bd.hrate1[c] = rf.nondimensional_rate(bd.dE[c] + e_bases + e_seqs);
        e_bases -= em.multi_base();
    });
}

/******************************************************************************************/

template <class Seq, class EM, class RF>
void LazySeqData::calc_me_hrate2(Seq const &s, real e_seqs, real & e_bases, EM const &em, RF const &rf) {
    // Update partial sums with this sequence
    zip(reversed(s).offset(1, -1), reversed(base_data), [&](auto b, auto &bd) {
        for (auto c : em.pairs(b))
            hrate2_sum(b, c) += bd.hrate2[c] = rf.nondimensional_rate(bd.dE[c] + e_bases + e_seqs);
        e_bases -= em.multi_base();
    });
}

/******************************************************************************************/

template <class Seq, class EM, class RF>
void LazySeqData::calc_mm_hrates(Seq const &s, EM const &em, RF const &rf) {
    zip(s.offset(1, -1), base_data, [&](auto b, auto &bd) {
        for (auto c : em.pairs(b))
            hrate1_sum(b, c) += bd.hrate1[c] = rf.nondimensional_rate(bd.dE[c]);
    });
}

/******************************************************************************************/

}
