#pragma once
#include "ParameterSet.h"

#include <boost/numeric/ublas/vector_sparse.hpp>

namespace nupack {

template <class T>
using Compressed_Vector = boost::numeric::ublas::vector<T>;

//template <class T>
//using Compressed_Vector = boost::numeric::ublas::mapped_vector<T, std::map<usize, T>>;

//template <class T>
//using Compressed_Vector = Eigen::SparseVector<T>;

template <class T, class V>
auto insert(T & t, usize i, V v) -> decltype(t.insert_element(i, v)) {return t.insert_element(i, v);}

template <class T, class V>
auto insert(T & t, usize i, V v) -> decltype(t.insert(i, v)) {return t.insert(i, v);}


class XPrime; class EPrime;

// Parameter with exponential operators
struct Indexed_Exp {
    usize index;
    double value;
    friend XPrime boltz(double, Indexed_Exp);

    friend EPrime operator*(Indexed_Exp e, double d);
    friend EPrime operator*(double d, Indexed_Exp e);
    friend EPrime operator+(Indexed_Exp e1, Indexed_Exp e2);

    explicit operator double() {return value;};

    friend std::ostream & operator<<(std::ostream &os, Indexed_Exp const &t) {return os << std::make_pair(t.index, t.value);}

    friend bool operator<(Indexed_Exp const &e1, Indexed_Exp const &e2) {return e1.value > e2.value;}
};

/******************************************************************************************/

// Derivative tracker with exponential operators
class EPrime {
    double value;
    Compressed_Vector<double> primes;
public:
    EPrime & operator+=(EPrime const &e) {
        primes = primes * e.value + value * e.primes;
        value *= e.value; return *this;
    };
    friend EPrime operator+(EPrime e1, EPrime const &e2) {return e1 += e2;}

    EPrime & operator*=(double d) {
        primes *= d * pow(value, d - 1);
        value = pow(value, d);
        return *this;
    }
    friend EPrime operator*(EPrime e, double d) {return e *= d;}
    friend EPrime operator*(double d, EPrime e) {return e *= d;}

    EPrime() : value(1.0), primes(N_Params) {};
    EPrime(Indexed_Exp e) : value(e.value), primes(N_Params) {insert(primes, e.index, 1.0);}
    EPrime(usize i, double val, double prime) : primes(N_Params), value(val) {insert(primes, i, prime);}

    friend std::ostream & operator<<(std::ostream &os, EPrime const &t) {return os << t.value;}
    friend bool operator==(EPrime const &e1, EPrime const &e2) {return e1.value == e2.value;}

    friend bool operator<(EPrime const &e1, EPrime const &e2) {return e1.value > e2.value;}

    friend XPrime boltz(double, EPrime e);
    friend class XPrime;
};

inline EPrime operator+(Indexed_Exp e1, Indexed_Exp e2) {return EPrime(e1) + EPrime(e2);}

inline EPrime operator*(Indexed_Exp e, double d) {return EPrime(e) * d;}

inline EPrime operator*(double d, Indexed_Exp e) {return EPrime(e) * d;}

/******************************************************************************************/

// Derivative tracker with normal operators
class XPrime {
    double value;
    Compressed_Vector<double> primes;
public:
    XPrime & operator+=(XPrime const &e) {value += e.value; primes += e.primes; return *this;};
    friend XPrime operator+(XPrime e1, XPrime const &e2) {return e1 += e2;}

    XPrime & operator*=(XPrime e) {
        primes = primes * e.value + value * e.primes; value *= e.value; return *this;}
    friend XPrime operator*(XPrime e1, XPrime const &e2) {return e1 *= e2;}

    XPrime() : value(0.0), primes(N_Params) {};
    XPrime(double d) : value(d), primes(N_Params) {};
    XPrime(EPrime e) : value(e.value), primes(e.primes) {};
    XPrime(Indexed_Exp e) : value(e.value), primes(N_Params) {insert(primes, e.index, 1.0);}

    friend std::ostream & operator<<(std::ostream &os, XPrime const &x) {return os << x.value;}
    friend bool operator==(XPrime const &e1, XPrime const &e2) {return e1.value == e2.value;}
};

inline XPrime boltz(double, Indexed_Exp e) {return XPrime(e);};
inline XPrime boltz(double, EPrime e) {return XPrime(e);};

/******************************************************************************************/

template <> template <class F>
void ParameterSet<Indexed_Exp>::init_dG(real t, F const &f) {
    ParameterSet<Energy> dG; dG.init_dG(t, Energy());
    auto const &dG_array = dG.as_array(); auto & pp_array = as_array();
    NUPACK_REQUIRE(size(dG_array), ==, size(pp_array));
    auto mbeta = -1.0 / (Kb * t);
    for (auto i : range(size(pp_array))) pp_array[i].index = i;
    for (auto i : range(size(pp_array))) pp_array[i].value = std::exp(mbeta * dG_array[i]);
}

/******************************************************************************************/

}
