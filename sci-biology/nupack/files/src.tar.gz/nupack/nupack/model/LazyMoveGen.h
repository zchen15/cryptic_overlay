#pragma once

#include "../iteration/Search.h"
#include "../algorithms/Utility.h"

#include "Move.h"
#include "FullMoveGen.h"
#include "LazySeqData.h"

namespace nupack {

struct Lazy {};

/******************************************************************************************/

class LazyMoveGen {
    template <class EM, class D> void update_dEs(SubsequenceList const &, int, EM const &, D);

    template <class EM, class RF> real calc_mm_rates(SubsequenceList const &, EM const &, RF const &);
    template <class EM, class RF> real calc_me_rates(SubsequenceList const &, usize, EM const &, RF const &);

    template <class EM, class RF> BasePairAddition choose_mm_move(real, SubsequenceList const &, EM const &, RF const &) const;
    template <class EM, class RF> BasePairAddition choose_me_move(real, SubsequenceList const &, usize, EM const &, RF const &) const;

    template <class EM> void calc_mi_moves(SubsequenceList const &, EM const &);
    template <class EM> void calc_ei_moves(SubsequenceList const &, usize, EM const &);

    template <class EM> void calc_mh_moves(SubsequenceList const &, EM const &);
    template <class EM> void calc_eh_moves(SubsequenceList const &, usize, EM const &);

public:
    real lazy_rate = 0;
    small_vec<BasePairAddition> easy_moves;
    vec<LazySeqData> seq_data;

    NUPACK_REFLECT(LazyMoveGen, lazy_rate, easy_moves, seq_data);

    LazyMoveGen(Lazy={}) {}
    auto const & moves() const {return easy_moves;};

    template <class EM, class RF> void update(real, SubsequenceList const &, int n, EM const &, RF const &);
    template <class EM> void update(real, SubsequenceList const &, int n, EM const &);

    real total_rate() const {return easy_moves.empty() ? lazy_rate : lazy_rate + back(easy_moves).rate;};

    template <class EM> BasePairAddition choose(real r, SubsequenceList const &, int n, EM const &) const;
};

void render(Document &doc, Type<LazyMoveGen>);

/******************************************************************************************/

template <class EM, class D>
void LazyMoveGen::update_dEs(SubsequenceList const &v, int n, EM const &em, D dangle) {
    struct Zero_E {constexpr real operator() (...) const {return real();};};

    seq_data.resize(len(v)); auto sd = begin_of(seq_data);
    if (n == -1) {
        if (em.has_terminal_penalty) {
            auto const tp = [&] (Base b, Base c) {return 0.5 * em.terminal_penalty(b, c);};
            auto const tn = [&] (Base b, Base c) {return 0.5 * em.terminal_penalty(c, b);};
            for (auto s = begin_of(v); s != end_of(v); ++s, ++sd) if (len(*s) > 2) {
                sd->init(v, s, dangle);
                sd->calc_sequence_dE(*s, em, dangle, tp, tn);
            }
        } else {
            for (auto s = begin_of(v); s != end_of(v); ++s, ++sd) if (len(*s) > 2) {
                sd->init(v, s, dangle);
                sd->calc_sequence_dE(*s, em, dangle, Zero_E(), Zero_E());
            }
        }
    } else {
        for (auto s = begin_of(v) + n; s != end_of(v); ++s, ++sd) if (len(*s) > 2) {
            sd->init(v, s, dangle);
            sd->calc_sequence_dE(*s, em, dangle, Zero_E(), Zero_E());
        }
        for (auto s = begin_of(v); s != begin_of(v) + n; ++s, ++sd) if (len(*s) > 2) {
            sd->init(v, s, dangle);
            sd->calc_sequence_dE(*s, em, dangle, Zero_E(), Zero_E());
        }
    }
}

/******************************************************************************************/

template <class EM, class RF> void LazyMoveGen::update(real e, SubsequenceList const &v, int n, EM const &em, RF const &rf) {
    if (len(v) < 3 || sum(v, len) < 16) {generate_add_moves(easy_moves, e, v, n, em); return;}

    em.dangle_switch([&](auto const &d) {update_dEs(v, n, em, d);});

    if (n != -1) {calc_eh_moves(v, n, em); calc_ei_moves(v, n, em);}
    else {calc_mh_moves(v, em); calc_mi_moves(v, em);}

    if (!easy_moves.empty()) {
        for (auto & m : easy_moves) m.rate = rf.unimolecular_rate(m.dE);
        for (auto m = begin_of(easy_moves) + 1; m != end_of(easy_moves); ++m) m[0].rate += m[-1].rate;
    }

    if (n != -1) lazy_rate += calc_me_rates(v, n, em, rf);
    else if (len(v) == 3) return;
    else lazy_rate += calc_mm_rates(v, em, rf);
}

template <class EM> void LazyMoveGen::update(real e, SubsequenceList const &v, int n, EM const &em) {
    lazy_rate = 0.0; easy_moves.clear(); seq_data.clear();
    fork(em.rate_function, [&](auto const &f) {update(e, v, n, em, f);});
}

/******************************************************************************************/

/// base pair in exterior loop yields a multi and exterior loop - GU forbidden
template <class EM, class RF>
real LazyMoveGen::calc_me_rates(SubsequenceList const &v, usize n, EM const &em, RF const &rf) {
    NUPACK_DREQUIRE(len(v), >=, 3);
    // Calculate hrates1 going forward
    auto df = begin_of(seq_data); df->hrate1_sum.fill(0);
    auto e_seqs = real(), e_bases = real();
    for (auto s = begin_of(v) + n; s != end_of(v); ++s, ++df, e_seqs -= em.multi_pair()) {
        if (df != begin_of(seq_data)) df->hrate1_sum = df[-1].hrate1_sum;
        df->calc_me_hrate1(*s, e_seqs, e_bases, em, rf);
    }
    for (auto s = begin_of(v); s != begin_of(v) + n; ++s, ++df, e_seqs -= em.multi_pair()) {
        if (df != begin_of(seq_data)) df->hrate1_sum = df[-1].hrate1_sum;
        df->calc_me_hrate1(*s, e_seqs, e_bases, em, rf);
    }
    // Calculate hrates2 going backward
    auto sr = seq_data.rbegin(); sr->hrate2_sum.fill(0);
    e_seqs = -e_seqs, e_bases = -e_bases;
    for (auto s = std::make_reverse_iterator(begin_of(v) + n); s != std::make_reverse_iterator(begin_of(v)); ++s, ++sr, e_seqs -= em.multi_pair()) {
        if (sr != seq_data.rbegin()) sr->hrate2_sum = sr[-1].hrate2_sum;
        sr->calc_me_hrate2(*s, e_seqs, e_bases, em, rf);
    }
    for (auto s = std::make_reverse_iterator(end_of(v)); s != std::make_reverse_iterator(begin_of(v) + n); ++s, ++sr, e_seqs -= em.multi_pair()) {
        if (sr != seq_data.rbegin()) sr->hrate2_sum = sr[-1].hrate2_sum;
        sr->calc_me_hrate2(*s, e_seqs, e_bases, em, rf);
    }
    // Calculate rate sums
    seq_data[0].rate_sum = times_transpose(seq_data[0].hrate1_sum, seq_data[2].hrate2_sum);
    for (auto s = begin_of(seq_data) + 1; s < end_of(seq_data) - 2; ++s)
        s->rate_sum = s[-1].rate_sum + times_transpose(s[0].hrate1_sum - s[-1].hrate1_sum, s[2].hrate2_sum);
    return rf.unimolecular_rate(em.multi_init() - 2 * em.multi_base()) * accu(end_of(seq_data)[-3].rate_sum);
}

/******************************************************************************************/

/// Base pair in multiloop yields 2 multiloops - GU forbidden
template <class EM, class RF>
real LazyMoveGen::calc_mm_rates(SubsequenceList const &v, EM const &em, RF const &rf) {
    NUPACK_DREQUIRE(len(v), >=, 4);
    // Calculate hrate1 sums
    auto sd = begin_of(seq_data); for (auto s = begin_of(v); s != end_of(v); ++s, ++sd) {
        // Continue partial sum of sequence hrates
        if (sd != begin_of(seq_data)) sd->hrate1_sum = sd[-1].hrate1_sum;
        else sd->hrate1_sum.fill(0);
        sd->calc_mm_hrates(*s, em, rf);
    }
    // Calculate rate sums
    seq_data[0].rate_sum = times_transpose(seq_data[0].hrate1_sum,
        end_of(seq_data)[-2].hrate1_sum - seq_data[1].hrate1_sum);
    for (auto s = begin_of(seq_data) + 1; s < end_of(seq_data) - 2; ++s)
        s->rate_sum = s[-1].rate_sum + times_transpose(s[0].hrate1_sum - s[-1].hrate1_sum,
            seq_data.back().hrate1_sum - s[1].hrate1_sum);
    return rf.unimolecular_rate(-2 * em.multi_base() + em.multi_init()
        + 2 * em.multi_pair()) * accu(end_of(seq_data)[-3].rate_sum);
}

/******************************************************************************************/

/// base pair in multiloop leads to interior and multiloop - GU forbidden
template <class EM> void LazyMoveGen::calc_mi_moves(SubsequenceList const &v, EM const &em) {
    for (auto s : range(len(v) - 1))
        for (auto b = begin_of(v[s]) + 1; b != end_of(v[s]) - 1; ++b)
            for (auto c = begin_of(v[s+1]) + 1; c != end_of(v[s+1]) - 1; ++c)
                if (em.pairable.can_close(*b, *c)) {
                    auto dE = em.interior_energy(view(b, end_of(v[s])), view(begin_of(v[s+1]), c + 1));
                    dE += seq_data[s].base_data[b-begin_of(v[s])-1].dE_next[*c];
                    dE += seq_data[s+1].base_data[c-begin_of(v[s+1])-1].dE_prev[*b];
                    dE -= em.multi_base() * ((c - begin_of(v[s+1])) + (end_of(v[s]) - b - 1));
                    easy_moves.emplace_back(b, c, s, s + 1, dE);
                }
    for (auto b = begin_of(v[0]) + 1; b != end_of(v[0]) - 1; ++b)
        for (auto c = begin_of(v.back()) + 1; c != end_of(v.back()) - 1; ++c)
            if (em.pairable.can_close(*b, *c)) {
                auto dE = em.interior_energy(view(c, end_of(v.back())), view(begin_of(v[0]), b + 1));
                dE += seq_data[0].base_data[b-begin_of(v[0])-1].dE_prev[*c];
                dE += seq_data.back().base_data[c-begin_of(v.back())-1].dE_next[*b];
                dE -= em.multi_base() * ((b - begin_of(v[0])) + (end_of(v.back()) - c - 1));
                easy_moves.emplace_back(b, c, 0, len(v) - 1, dE);
            }
}

/******************************************************************************************/

/// base pair in exterior loop yields interior and exterior loop - GU forbidden
template <class Seq, class EM, class LSD, class F>
void calc_ext_int_pair(Seq const &s1, Seq const &s2, LSD const &d1,
                       LSD const &d2, EM const &em, F const &f) {
    for (auto b : iterators(s1).offset(1, -1))
        for (auto c : iterators(s2).offset(1, -1))
            if (em.pairable.can_close(*b, *c)) {
                auto dE = em.interior_energy(view(b, end_of(s1)), view(begin_of(s2), c + 1));
                dE += d1.base_data[b-begin_of(s1)-1].dE_next[*c];
                dE += d2.base_data[c-begin_of(s2)-1].dE_prev[*b];
                f(b, c, dE);
            }
}

/// base pair in exterior loop yields interior and exterior loop - GU forbidden
template <class EM>
void LazyMoveGen::calc_ei_moves(SubsequenceList const &v, usize n, EM const &em) {
    usize d = 0; for (auto s = n; s + 1u != len(v); ++s, ++d)
        calc_ext_int_pair(v[s], v[s+1], at(seq_data, d), at(seq_data, d+1), em,
            [&](auto b, auto c, auto dE) {easy_moves.emplace_back(b, c, s, s + 1, dE);});

    if (n) {
        calc_ext_int_pair(v.back(), v.front(), at(seq_data, d), at(seq_data, d+1), em,
            [&](auto b, auto c, auto dE) {easy_moves.emplace_back(c, b, 0, len(v) - 1, dE);});

        ++d; for (usize s = 0u; s + 1u != n; ++s, ++d)
            calc_ext_int_pair(v[s], v[s+1], at(seq_data, d), at(seq_data, d+1), em,
                [&](auto b, auto c, auto dE) {easy_moves.emplace_back(b, c, s, s + 1, dE);});
    }
}

/******************************************************************************************/

/// base pair in multi loop yields hairpin and multi loop - GU forbidden
template <class EM>
void LazyMoveGen::calc_mh_moves(SubsequenceList const &v, EM const &em) {
    for (auto s : indices<int>(v))
        for (auto b = begin_of(v[s]) + 1; b < end_of(v[s]) - em.pairable.turn() - 2; ++b)
            for (auto c = b + em.pairable.turn() + 1; c < end_of(v[s]) - 1; ++c) if (em.pairable.can_close(*b, *c)) {
                auto dE = em.hairpin_energy(view(b, c + 1));
                dE += seq_data[s].base_data[b-begin_of(v[s])-1].dE_next[*c] + seq_data[s].d3;
                dE += seq_data[s].base_data[c-begin_of(v[s])-1].dE_prev[*b] + seq_data[s].d5;
                dE += em.multi_pair() - em.multi_base() * (c + 1 - b);
                easy_moves.emplace_back(b, c, s, s, dE);
            }
}

/******************************************************************************************/

/// base pair in exterior loop yields hairpin and exterior loop - GU forbidden
template <class EM>
void LazyMoveGen::calc_eh_moves(SubsequenceList const &v, usize n, EM const &em) {
    auto sd = begin_of(seq_data);
    for (auto s = n; s != len(v); ++s, ++sd)
        for (auto b = begin_of(v[s]) + 1; b < end_of(v[s]) - em.pairable.turn() - 2; ++b)
            for (auto c = b + em.pairable.turn() + 1; c < end_of(v[s]) - 1; ++c) if (em.pairable.can_close(*b, *c)) {
                auto dE = em.hairpin_energy(view(b, c + 1));
                dE += sd->base_data[b-begin_of(v[s])-1].dE_next[*c] + sd->d3;
                dE += sd->base_data[c-begin_of(v[s])-1].dE_prev[*b] + sd->d5;
                easy_moves.emplace_back(b, c, s, s, dE);
            }
    for (usize s = 0; s != n; ++s, ++sd)
        for (auto b = begin_of(v[s]) + 1; b < end_of(v[s]) - em.pairable.turn() - 2; ++b)
            for (auto c = b + em.pairable.turn() + 1; c < end_of(v[s]) - 1; ++c) if (em.pairable.can_close(*b, *c)) {
                auto dE = em.hairpin_energy(view(b, c + 1));
                dE += sd->base_data[b-begin_of(v[s])-1].dE_next[*c] + sd->d3;
                dE += sd->base_data[c-begin_of(v[s])-1].dE_prev[*b] + sd->d5;
                easy_moves.emplace_back(b, c, s, s, dE);
            }
}

/******************************************************************************************/

template <class EM, class RF>
BasePairAddition LazyMoveGen::choose_mm_move(real r, SubsequenceList const &v, EM const &em, RF const &rf) const {
    r /= rf.unimolecular_rate(em.multi_init() -2 * em.multi_base() + 2 * em.multi_pair());
    // Base identities
    auto tup = find_cumulative_mat(end_of(seq_data)[-3].rate_sum, r);
    auto const b = Base::from_index(first_of(tup)), c = Base::from_index(second_of(tup));
    r = third_of(tup);
    NUPACK_ASSERT(em.pairable(b, c), b, c);
    // Find sequence 1
    auto s1 = binary_it_search(begin_of(seq_data), end_of(seq_data) - 2, r, [=](auto sd){return sd.rate_sum(b, c);});
    if (s1 != begin_of(seq_data)) r -= s1[-1].rate_sum(b, c);
    auto s1_hrate = element_from_sum(seq_data, s1, [&](auto sd){return sd.hrate1_sum(b, c);});
    // Find sequence 2
    auto s2 = binary_search(seq_data, r / s1_hrate + s1[1].hrate1_sum(c, b), [=](auto sd){return sd.hrate1_sum(c, b);});
    r -= (s2[-1].hrate1_sum(c, b) - s1[1].hrate1_sum(c, b)) * s1_hrate;
    auto s2_hrate = element_from_sum(seq_data, s2, [&](auto sd){return sd.hrate1_sum(c, b);});
    // Base 1
    auto spot1 = find_cumulative(s1->base_data, min_floor(r / s2_hrate), [=](auto bd){return bd.hrate1[c];});
    auto b1 = spot1.first; r -= spot1.second * s2_hrate;
    // Base 2
    auto spot2 = find_cumulative(s2->base_data, min_floor(r / s1_hrate), [=](auto bd){return bd.hrate1[b];});
    auto b2 = spot2.first; r -= spot2.second;
    // Construct the right move...
    auto dE = b1->dE[c] + b2->dE[b] + em.multi_init() -2 * em.multi_base() + 2 * em.multi_pair();
    iseq is2 = s2 - begin_of(seq_data), is1 = s1 - begin_of(seq_data);
    auto ib1 =  b1 + 1 - begin_of(s1->base_data);
    NUPACK_DREQUIRE(v[is1][ib1], ==, b, v[is1], *s1);
    auto ib2 = b2 + 1 - begin_of(s2->base_data);
    NUPACK_DREQUIRE(v[is2][ib2], ==, c, v[is2], *s2);
    return {begin_of(v[is1]) + ib1, begin_of(v[is2]) + ib2, is1, is2, dE};
}

/******************************************************************************************/

template <class EM, class RF>
BasePairAddition LazyMoveGen::choose_me_move(real r, SubsequenceList const &v, usize n, EM const &em, RF const &rf) const {
    NUPACK_DREQUIRE(r, <, lazy_rate);
    real d1_hrate, d2_hrate;

    // Get rid of flat scaling
    r /= rf.unimolecular_rate(em.multi_init() - 2 * em.multi_base());

    // Base identities
    auto tup = find_cumulative_mat(end_of(seq_data)[-3].rate_sum, r);
    auto const b = Base::from_index(first_of(tup)), c = Base::from_index(second_of(tup));
    r = third_of(tup);
    NUPACK_ASSERT(em.pairable(b, c), b, c);

    // Find sequence 1
    auto d1 = binary_it_search(begin_of(seq_data), end_of(seq_data) - 2, r, [&](auto sd){return sd.rate_sum(b, c);});
    if (d1 == begin_of(seq_data)) d1_hrate = d1[0].hrate1_sum(b, c);
    else {r -= d1[-1].rate_sum(b, c); d1_hrate = d1[0].hrate1_sum(b, c) - d1[-1].hrate1_sum(b, c);}

    // Find sequence 2
    auto d2 = binary_it_search(seq_data.rbegin(), seq_data.rend(), r / d1_hrate, [&](auto sd){return sd.hrate2_sum(c, b);});
    if (d2 == seq_data.rbegin()) d2_hrate = d2[0].hrate2_sum(c, b);
    else {r -= d2[-1].hrate2_sum(c, b) * d1_hrate; d2_hrate = d2[0].hrate2_sum(c, b) - d2[-1].hrate2_sum(c, b);}

    // Find base 1
    auto spot1 = find_cumulative(d1->base_data, min_floor(r / d2_hrate), [&](auto bd){return bd.hrate1[c];});
    auto b1 = spot1.first; r -= spot1.second * d2_hrate;

    // Find base 2
    auto spot2 = find_it_cumulative(d2->base_data.rbegin(), d2->base_data.rend(), min_floor(r / d1_hrate), [&](auto bd){return bd.hrate2[b];});
    auto b2 = spot2.first; r -= spot2.second;

    // Construct the right move...
    iseq is1 = n + d1 - begin_of(seq_data); if (is1 >= len(v)) is1 -= len(v);
    iseq is2 = n + (d2 + 1).base() - begin_of(seq_data); if (is2 >= len(v)) is2 -= len(v);
    NUPACK_DREQUIRE(len(v[is1]), ==, len(d1->base_data) + 2);
    NUPACK_DREQUIRE(len(v[is2]), ==, len(d2->base_data) + 2);
    auto ib1 = b1 + 1 - begin_of(d1->base_data);
    NUPACK_DREQUIRE(v[is1][ib1], ==, b, v[is1], is1, v, d1 - begin_of(seq_data), *d1, *d2);
    auto ib2 = (b2 + 1).base() + 1 - begin_of(d2->base_data);
    NUPACK_DREQUIRE(v[is2][ib2], ==, c, v[is2], is2, v, *d2, *d1);

    // Figure out energy
    auto dE = b1->dE[c] + b2->dE[b] + em.multi_init();
    dE += ((d2 + 1).base() - d1 + 1) * em.multi_pair();
    auto n_unpaired = (end_of(d1->base_data) - b1 - 2) + ib2;
    for (auto d = d1 + 1; d < (d2 + 1).base(); ++d) n_unpaired += len(d->base_data);
    dE += n_unpaired * em.multi_base();

    // Make the move which has correct s1 < s2 ordering
    if (is2 > is1) return {begin_of(v[is1]) + ib1, begin_of(v[is2]) + ib2, is1, is2, dE};
    else return {begin_of(v[is2]) + ib2, begin_of(v[is1]) + ib1, is2, is1, dE};
}

/******************************************************************************************/

template <class EM> BasePairAddition LazyMoveGen::choose(real r, SubsequenceList const &v, int n, EM const &em) const {
    if (!easy_moves.empty() && r < back(easy_moves).rate) {
        auto it = binary_search(easy_moves, r, [](auto const &m){return m.rate;});
        auto ret = *it;
        if (it != begin_of(easy_moves)) ret.rate -= std::prev(it)->rate;
        return ret;
    }
    if (!easy_moves.empty()) r -= back(easy_moves).rate;
    return fork(em.rate_function, [&](auto const &rf) {
        if (n == -1) return choose_mm_move(r, v, em, rf);
        else return choose_me_move(r, v, n, em, rf);
    });
}

/******************************************************************************************/

}
