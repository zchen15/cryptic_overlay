#include "Model.h"
#include "ParameterSet.h"
#include "../common/Error.h"
#include "../common/Runtime.h"
#include "../state/State.h"
#include "../reflect/Serialize.h"
#include <fstream>

namespace nupack {

/******************************************************************************************/

ParameterFile::ParameterFile(string p) : path(p) {
    if (path == "RNA") path = "rna95";
    if (path == "DNA") path = "dna04";
    if (path.size() < 5 || path.substr(path.size() - 5) != ".json") path += ".json";
}

json ParameterFile::open() const {
    string name = path;
    // BEEP(DefaultParametersPath);
    if (!path_exists(name)) {
        name = path_join(DefaultParametersPath, path);
    }
    if (!path_exists(name)) {
        auto s = get_env("NUPACKHOME");
        if (!s.empty()) name = path_join(path_join(s, "parameters"), path);
    }

    std::ifstream file(name);
    if (!file.good()) {
        vec<string> directories = {".", DefaultParametersPath, "$NUPACKHOME/parameters"};
        NUPACK_ERROR("failed to open parameter file ", path, directories);
    }
    json j;
    file >> j;
    return j;
}

#define NUPACK_TMP(OP) bool operator OP(ParameterMetadata const &t, ParameterMetadata const &u) {return members_of(t) OP members_of(u);}
    NUPACK_TMP(==); NUPACK_TMP(!=); NUPACK_TMP(<); NUPACK_TMP(>); NUPACK_TMP(<=); NUPACK_TMP(>=);
#undef NUPACK_TMP

std::array<char const *, 5> EnsembleNames = {"nostacking", "stacking",  "min", "all", "none"};

Ensemble as_ensemble(string_view s) {
    if (auto it = find(EnsembleNames, s); it != EnsembleNames.end())
        return Ensemble(it - EnsembleNames.begin());
    NUPACK_ERROR("invalid ensemble type", s);
}

/******************************************************************************************/

void render(Document &doc, Type<ParameterFile> t) {
    doc.type(t, "model.ParameterFile");
    doc.method(t, "new", rebind::construct<string>(t));
    NUPACK_PUBLIC(ParameterFile, path);
}

void render(Document &doc, Type<ModelConditions> t) {
    doc.type(t, "model.Conditions");
    doc.method(t, "new", rebind::construct<>(t));
    NUPACK_PUBLIC(ModelConditions, temperature, na_molarity, mg_molarity);
}

void render(Document &doc, Type<ParameterMetadata> t) {
    doc.type(t, "model.ParameterMetadata");
    NUPACK_PUBLIC(ParameterMetadata, temperature, loop_bias, kind, file);
}

void render(Document &doc, Type<Pairable> t) {
    doc.type(t, "model.Pairable");
    doc.method(t, "()", &Pairable::can_pair);
}

/******************************************************************************************/

void render(Document &doc, Type<Kawasaki> t) {
    doc.type(t, "model.Kawasaki");
    render_public(doc, t);
    doc.method(t, "new", rebind::construct<real, real, real>(t));
    doc.method(t, "unimolecular_rate",   &Kawasaki::unimolecular_rate);
    doc.method(t, "bimolecular_rate",    &Kawasaki::bimolecular_rate);
    doc.method(t, "nondimensional_rate", &Kawasaki::nondimensional_rate);
}

void render(Document &doc, Type<Metropolis> t) {
    doc.type(t, "model.Metropolis");
    render_public(doc, t);
    doc.method(t, "new", rebind::construct<real, real, real>(t));
    doc.method(t, "unimolecular_rate",   &Metropolis::unimolecular_rate);
    doc.method(t, "bimolecular_rate",    &Metropolis::bimolecular_rate);
    doc.method(t, "nondimensional_rate", &Metropolis::nondimensional_rate);
}

/******************************************************************************************/

void render(Document &doc, Type<ParameterData<real32>> t) {
    // render(doc, t, 0);
}

void render(Document &doc, Type<ParameterData<real64>> t) {
    render(doc, t, 0);
//     doc.method(t, "check", [](ParameterData<real64> const &x, string const &s) {
//         auto y = set_parameters(x, json::parse(s)["dG"]);
//         zip(x.as_array(), y.as_array(), [](auto x, auto y) {
//             NUPACK_REQUIRE(x, ==, y);
//         });
//     });
}

void render(Document &doc, Type<ParameterSet<real32>> t) {render(doc, t, 0);}
void render(Document &doc, Type<ParameterSet<real64>> t) {render(doc, t, 0);}
void render(Document &doc, Type<Model<real64>> t) {render(doc, t, 0);}
void render(Document &doc, Type<Model<real32>> t) {render(doc, t, 0);}

void render_model(Document &doc) {
    doc.render<ParameterSet<real64>>();
    doc.render<Model<real64>>();
    doc.render<ParameterSet<real32>>();
    doc.render<Model<real32>>();
    doc.render<Kawasaki>();

    doc.function("model.structure_energy", &structure_energy<SequenceList, Model<real64>>);
    doc.function("model.structure_energy", &structure_energy<SequenceList, Model<real32>>);
}

/******************************************************************************************/

}

