#pragma once

#include "Move.h"

#include "../iteration/Transform.h"

namespace nupack {

/******************************************************************************************/

template <class EM, class Moves>
void generate_add_moves(Moves &, real, SubsequenceList const &, int, EM const &);

/******************************************************************************************/

struct Full {};

struct FullMoveGen {
    small_vec<BasePairAddition> add_moves;
    NUPACK_REFLECT(FullMoveGen, add_moves);

    FullMoveGen(Full={}) {}

    real total_rate() const {return add_moves.empty() ? 0.0 : add_moves.back().rate;};

    auto const & moves() const {return add_moves;};

    template <class EM> void update(real e, SubsequenceList const &v, int n, EM const &em) {
        add_moves.clear(); generate_add_moves(add_moves, e, v, n, em);}

    template <class EM> auto choose(real r, SubsequenceList const &, int, EM const &) const {
        auto it = binary_search(add_moves, r, [](auto const &m){return m.rate;});
        auto ret = *it; if (it != begin_of(add_moves)) ret.rate -= std::prev(it)->rate;
        return ret;
    }
};

void render(Document &doc, Type<FullMoveGen>);

/******************************************************************************************/

template <class EM, class Moves>
void generate_add_moves(Moves & mvs, real e, SubsequenceList const &v, int n, EM const &em) {
    int const z = len(v);
    auto const dE_start = -e;

    SubsequenceList views; views.reserve(2 * z);
    extend(views, v); extend(views, v);

    // Inter-sequence pairing
    for (auto s1 : range(z)) for (auto s2 : lrange(s1 + 1, z)) {
        // nick of first and second loops
        int n1, n2; if (n == -1) n1 = n2 = -1;
        else if (s2 < n) {n1 = n - s2; n2 = -1;} // pair before nick
        else if (s1 < n) {n1 = -1; n2 = n - s1;} // pair crosses nick
        else {n1 = n + z - s2; n2 = -1;} // pair after nick

        for (auto b1 = begin_of(v[s1]) + 1; b1 != end_of(v[s1]) - 1; ++b1)
            for (auto b2 = begin_of(v[s2]) + 1; b2 != end_of(v[s2]) - 1; ++b2) if (em.pairable(*b1, *b2)) {
                real dE = dE_start;
                // One loop wraps around s=0
                views[s2].set_begin(b2); views[s1 + z].set_end(b1 + 1);
                NUPACK_DREQUIRE(find_nick(view(views, s2, s1 + z + 1)), ==, n1);
                dE += em.loop_energy(view(views, s2, s1 + z + 1), n1);
                views[s1 + z].set_begin(b1);
                views[s1 + z].set_end(end_of(v[s1]));

                // The other is contiguous
                views[s2 + z].set_end(b2 + 1);
                NUPACK_DREQUIRE(find_nick(view(views, s1 + z, s2 + z + 1)), ==, n2);
                dE += em.loop_energy(view(views, s1 + z, s2 + z + 1), n2);
                views[s1 + z].set_begin(begin_of(v[s1]));
                mvs.emplace_back(b1, b2, s1, s2, dE);
            }
        // Reverse the loopotomies
        views[s1 + z] = v[s1]; views[s2 + z] = v[s2]; views[s2] = v[s2];
    }

    // Intra-sequence pairing
    views.resize(z + 1); std::copy(begin_of(v), end_of(v), begin_of(views) + 1);
    for (auto const s : range(z)) {
        views[s] = v[s];

        for (auto b1 = begin_of(v[s]) + 1; b1 < end_of(v[s]) - em.pairable.turn() - 2; ++b1)
            for (auto b2 = b1 + em.pairable.turn() + 1; b2 < end_of(v[s]) - 1; ++b2) if (em.pairable(*b1, *b2)) {
                real dE = dE_start;
                dE += em.hairpin_energy(view(b1, b2 + 1));
                views[s].set_end(b1 + 1); views[s + 1].set_begin(b2);
                static_assert(decltype(n)(-1) < decltype(s)(0), "Types result in improper comparison");
                dE += em.loop_energy(views, n + (s < n));
                mvs.emplace_back(b1, b2, s, s, dE);
            }

        views[s] = v[s];
    }

    if (mvs.empty()) return;
    fork(em.rate_function, [&](auto const &f) {for (auto &m : mvs) m.rate = f.unimolecular_rate(m.dE);});
    for (auto m = begin_of(mvs) + 1; m != end_of(mvs); ++m) m[0].rate += m[-1].rate;
}

/******************************************************************************************/

}
