#pragma once
#include "../standard/Array.h" // for multi_array
#include "../common/Constants.h" // for temperature
#include "../types/IO.h" // for goto_line_after
#include "../types/Sequence.h"
#include "../reflect/Serialize.h"

#include <mutex>


namespace nupack {

/******************************************************************************************/

struct ParameterFile : MemberOrdered {

    string path;
    NUPACK_REFLECT(ParameterFile, path);

    /* Take a material type and optional dG and dH paths, to look up the parameter file
    Priority ranking:
        1) the specified path
        2) "NUPACKHOME" environment variable
        3) then the NUPACK parameters folder (set by CMake)
    */
    ParameterFile(string name="RNA");

    json open() const;
};

NUPACK_DEFINE_TYPE(is_parameter_file, ParameterFile);

void render(Document &doc, Type<ParameterFile>);

/******************************************************************************************/

template <class T>
struct ParameterData {
    using value_type = T;

    auto & as_array() {
        static_assert(alignof(ParameterData) >= alignof(std::array<T, sizeof(*this)/sizeof(T)>), "reinterpret_cast will fail");
        return * reinterpret_cast<std::array<T, sizeof(*this)/sizeof(T)> *>(this);
    }
    auto const & as_array() const {return remove_const(*this).as_array();}

    void from_json(json const &j);
    json to_json() const;

    ParameterData() = default;
    explicit ParameterData(json const &j) {from_json(j);}
    explicit ParameterData(string const &s) {from_json(json::parse(s));}

    template <class U>
    ParameterData(ParameterData<U> const &p) {zip(as_array(), p.as_array(), assign_eq);}

    multi_array<T, 4, 4, 4, 4, 4, 4, 4, 4> interior_2_2;
    multi_array<T, 4, 4, 4, 4, 4, 4, 4> interior_1_2;
    multi_array<T, 4, 4, 4, 4, 4, 4> interior_1_1;
    multi_array<T, 4, 4, 4, 4> interior_mismatch;
    multi_array<T, 4, 4, 4, 4> terminal_mismatch;
    multi_array<T, 4, 4, 4, 4> stack;
    multi_array<T, 4, 4, 4, 4> coax_stack;
    multi_array<T, 4, 4, 4, 4, 4, 4> hairpin_tetra;
    multi_array<T, 4, 4, 4, 4, 4> hairpin_tri;
    multi_array<T, 4, 4, 4, 4> hairpin_mismatch;
    multi_array<T, 4, 4, 4> dangle3, dangle5;
    multi_array<T, 4, 4> terminal_penalty;

    std::array<T, 30> interior_size;
    std::array<T, 30> bulge_size;
    std::array<T, 30> hairpin_size;
    std::array<T, 5> ninio;

    T multi_base, multi_init, multi_pair;
    T log_loop_penalty;
    T join_penalty;

    template <class F>
    void scale_by(ParameterData const &o, F &&f) {
        zip(as_array(), o.as_array(), [&f](auto &x, auto const &y) {x = f(std::move(x), y);});
    }

    NUPACK_REFLECT(ParameterData, interior_2_2, interior_1_2, interior_1_1,
        terminal_mismatch, interior_mismatch, stack, coax_stack, hairpin_tetra, hairpin_tri, hairpin_mismatch,
        dangle3, dangle5, terminal_penalty, interior_size, bulge_size, hairpin_size, ninio,
        multi_base, multi_init, multi_pair, log_loop_penalty, join_penalty);

    void add_loop_bias(T t) {
        multi_init += t;
        for_each(std::tie(stack, bulge_size, interior_size, hairpin_size, interior_1_1, interior_1_2, interior_2_2),
            [t](auto &v) {for (auto &i : flat_view(v)) i += t;});
        join_penalty += t;
    }
};

template <class T>
void render(Document &doc, Type<ParameterData<T>> t, int=0) {
    doc.type(t, "model.ParameterData");
    doc.method(t, "new", [](ParameterFile const &file, string const &kind) {return ParameterData<T>(file.open().at(kind));});
    doc.method(t, "save", &ParameterData<T>::to_json);
    doc.method(t, "load", &ParameterData<T>::from_json);
    render_public(doc, t);
}

void render(Document &doc, Type<ParameterData<real>>);
void render(Document &doc, Type<ParameterData<float>>);


struct ParameterMetadata {
    ParameterFile file;
    string kind;
    real loop_bias;
    real temperature;

    NUPACK_REFLECT(ParameterMetadata, temperature, loop_bias, kind, file);
    using is_member_ordered = True;
};

void render(Document &doc, Type<ParameterMetadata>);

/******************************************************************************************/

template <class T>
struct ParameterSet : ParameterData<T> {
    using base_type = typename ParameterSet::ParameterData;
    ParameterMetadata metadata;
    bool default_wobble_pairing;
    NUPACK_EXTEND_REFLECT(ParameterSet, base_type, metadata, default_wobble_pairing);

    template <class U>
    ParameterSet(ParameterSet<U> const &o) : metadata{o.metadata} {
        static_assert(!is_same<T, U>, "Should use normal copy constructor");
        zip(base_type::as_array(), o.as_array(), assign_eq);
    }

    ParameterSet() = default;

    explicit ParameterSet(ParameterMetadata data);

    friend std::ostream & operator<<(std::ostream &os, ParameterSet const &p) {
        return os << "ParameterSet(" << p.metadata.file.path << ", " << p.metadata.kind << ", " << p.metadata.temperature << " K)";
    }

    static vec<std::weak_ptr<ParameterSet<T> const>> cache;

    static std::mutex cache_mutex;

    static auto shared(ParameterMetadata key);
};

template <class T>
std::mutex ParameterSet<T>::cache_mutex{};

template <class T>
vec<std::weak_ptr<ParameterSet<T> const>> ParameterSet<T>::cache{};


template <class T>
auto ParameterSet<T>::shared(ParameterMetadata key) {
    std::shared_ptr<ParameterSet<T> const> out;

    std::lock_guard<std::mutex> lk{cache_mutex};
    auto b = cache.begin(), e = cache.end();
    for (; b != e; ++b) {
        if (b->expired()) {
            if (b != --e) std::iter_swap(b, e);
            else break;
        } else {
            auto ptr = b->lock();
            if (ptr->metadata == key) {out = std::move(ptr); break;}
        }
    }
    cache.erase(e, cache.end());
    if (!out) {
        out = std::make_shared<ParameterSet<T> const>(std::move(key));
        cache.emplace_back(out);
    }
    return out;
}

NUPACK_DEFINE_TEMPLATE(isParameterSet, ParameterSet, class);

template <class P, NUPACK_IF(isParameterSet<P>)>
void render(Document &doc, Type<P> t, int=0) {
    doc.type(t, "model.ParameterSet");
    render_public(doc, t);
    doc.method(t, "new", rebind::construct<ParameterMetadata>(t));
}

void render(Document &doc, Type<ParameterSet<real32>>);
void render(Document &doc, Type<ParameterSet<real64>>);

/******************************************************************************************/

template <class T>
ParameterSet<T>::ParameterSet(ParameterMetadata data) : metadata{std::move(data)} {
    auto const &t = metadata.temperature;
    auto const &p = metadata.file;
    json j = p.open();
    static_cast<base_type &>(*this) = base_type(j.at("dG"));
    j.at("default_wobble_pairing").get_to(default_wobble_pairing);

    if (t != DefaultTemperature)
        base_type::scale_by(base_type(j.at("dH")), [=](auto dG, auto dH) {return (dG - dH) * t / (DefaultTemperature) + dH;});
    base_type::join_penalty -= std::log(water_molarity(t)) * Kb * t;
    base_type::add_loop_bias(metadata.loop_bias);
}

/******************************************************************************************/

namespace base_index {

/******************************************************************************************/

template <class T>
decltype(auto) nd_base(T &&t) {return t;}

template <class T, class ...Is>
decltype(auto) nd_base(T &&t, BaseIndex i, Is const ...is) {return nd_base(t[i], is...);}

template <class T, std::size_t N, std::size_t ...Is>
decltype(auto) nd_sequence(T &&t, std::array<BaseIndex, N> const &i, indices_t<Is...>) {return nd_base(t, i[Is]...);}

template <std::size_t N, class S>
std::array<BaseIndex, N> nd_sequence_index(S const &key) {
    std::array<BaseIndex, N> out;
    NUPACK_REQUIRE(N, ==, key.size(), "Incorrect number of nucleotides");
    zip(out, key, [](auto &o, auto c) {o = Base::lookup(c);});
    return out;
}

/******************************************************************************************/

template <class T>
void set_array(T &t, json const &x) {
    constexpr auto N = std::tuple_size_v<decltype(shape<T>())>;
    for (auto const & [key, value] : x.items())
        value.get_to(nd_sequence(t, nd_sequence_index<N>(key), indices_up_to<N>()));
}

template <class ...Is>
std::string nd_string(Is const ...is) {
    std::string out;
    (out.push_back(Base::names[is]), ...);
    return out;
}

/******************************************************************************************/

template <class T, class ...Is>
void get_to_array(json &j, T const &t, Is const ...is) {
    if constexpr(std::is_scalar_v<T>) {if (t != 0) j[nd_string(is...)] = t;}
    else for (auto i : range(4)) get_to_array(j, t[i], is..., i);
}

template <class T>
json get_array(T const &t) {
    json out = json::object();
    get_to_array(out, t);
    return out;
}

/******************************************************************************************/

}

template <class T>
void ParameterData<T>::from_json(json const &j) {
    fill(as_array(), T(0));
    j.at("log_loop_penalty").get_to(log_loop_penalty);
    j.at("hairpin_size").get_to(hairpin_size);
    j.at("bulge_size").get_to(bulge_size);
    j.at("multiloop_init").get_to(multi_init);
    j.at("multiloop_pair").get_to(multi_pair);
    j.at("multiloop_base").get_to(multi_base);
    j.at("join_penalty").get_to(join_penalty);
    j.at("interior_size").get_to(interior_size);
    j.at("asymmetry_ninio").get_to(ninio);
    base_index::set_array(stack, j.at("stack"));
    base_index::set_array(coax_stack, j.at("coaxial_stack"));
    base_index::set_array(hairpin_tri, j.at("hairpin_triloop"));
    base_index::set_array(hairpin_tetra, j.at("hairpin_tetraloop"));
    base_index::set_array(hairpin_mismatch, j.at("hairpin_mismatch"));
    base_index::set_array(interior_mismatch, j.at("interior_mismatch"));
    base_index::set_array(terminal_mismatch, j.at("terminal_mismatch"));
    base_index::set_array(dangle5, j.at("dangle_5"));
    base_index::set_array(dangle3, j.at("dangle_3"));
    base_index::set_array(interior_1_1, j.at("interior_1_1"));
    base_index::set_array(interior_1_2, j.at("interior_1_2"));
    base_index::set_array(interior_2_2, j.at("interior_2_2"));
    base_index::set_array(terminal_penalty, j.at("terminal_penalty"));
}

template <class T>
json ParameterData<T>::to_json() const {
    json j;
    j["log_loop_penalty"] = log_loop_penalty;
    j["hairpin_size"] = hairpin_size;
    j["bulge_size"] = bulge_size;
    j["multiloop_init"] = multi_init;
    j["multiloop_pair"] = multi_pair;
    j["multiloop_base"] = multi_base;
    j["join_penalty"] = join_penalty;
    j["interior_size"] = interior_size;
    j["asymmetry_ninio"] = ninio;
    j["stack"] = base_index::get_array(stack);
    j["coaxial_stack"] = base_index::get_array(coax_stack);
    j["hairpin_triloop"] = base_index::get_array(hairpin_tri);
    j["hairpin_tetraloop"] = base_index::get_array(hairpin_tetra);
    j["hairpin_mismatch"] = base_index::get_array(hairpin_mismatch);
    j["interior_mismatch"] = base_index::get_array(interior_mismatch);
    j["terminal_mismatch"] = base_index::get_array(terminal_mismatch);
    j["dangle_5"] = base_index::get_array(dangle5);
    j["dangle_3"] = base_index::get_array(dangle3);
    j["interior_1_1"] = base_index::get_array(interior_1_1);
    j["interior_1_2"] = base_index::get_array(interior_1_2);
    j["interior_2_2"] = base_index::get_array(interior_2_2);
    j["terminal_penalty"] = base_index::get_array(terminal_penalty);
    return j;
}

/******************************************************************************************/

}
