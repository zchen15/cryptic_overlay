/**
 * @brief Equilibrium toolkit functionality
 *
 * @file Equilibrate.h
 * @author Mark Fornace
 * @date 2018-05-31
 */
#pragma once
#include "../types/Matrix.h"

namespace nupack {

NUPACK_NAMESPACE(concentration);
namespace concentration {

enum class Init : uint {uniform=0, given=1, absls=2, nnls=3};

struct Options {
    usize max_iters = 10000;
    real tolerance = 1.e-8;
    real delta_min = 1.e-12;
    real delta_max = 1000.0;
    real cond_tolerance = 1e-10;
    bool orthogonalize = true; //< takes care of cases where # strands > # complexes
    Init init = Init::uniform; //< usually the non-uniform init is better
    NUPACK_REFLECT(max_iters, tolerance, delta_min, delta_max, init, cond_tolerance, orthogonalize);
};

template <class V>
struct Output {
    V solution;
    real max_rel_grad;
    usize iters;
    bool converged;
    NUPACK_REFLECT(solution, max_rel_grad, iters, converged);
};

template <class M, class V>
Output<V> equilibrate(M A, V const &x0, V const &g, Options ops={});

extern template Output<Col<double>> equilibrate(Mat<double>, Col<double> const &, Col<double> const &, Options);
extern template Output<Col<float>> equilibrate(Mat<float>, Col<float> const &, Col<float> const &, Options);

}}
