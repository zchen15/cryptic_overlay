#pragma once
#include "BasicBlock.h"
#include "CoaxialBlock.h"
#include "../types/LRU.h"
#include "../standard/Variant.h"

namespace nupack::thermo {

/**************************************************************************************/

/// Type of record emitted by a given Block type
template <class Block>
using BlockRecord = decltype(declval<Block>().write(span(0, 0), span(0, 0), true));

/// Type of record emitted by a Block of the given data type, dangles, and complexity
template <class T, class Ensemble, int N>
using RecordType = BlockRecord<BlockMatrix<T, Ensemble, N>>;

/**************************************************************************************/

/// Convenience wrapper for LRU<...> cache class for easier use with variants
template <int N, class Ensemble, class ...Ts>
struct Cache : LRU<NickSequence, MaybeVariant<RecordType<Ts, Ensemble, N>...>> {
    using base_type = typename Cache::LRU;
    using is_lru = False;
    Cache(std::size_t n=0) : base_type(n) {}
};

NUPACK_DEFINE_VARIADIC(is_cache, Cache, int, class, class);

template <int N, class Ensemble, class ...Ts>
void render(Document &doc, Type<Cache<N, Ensemble, Ts...>> t) {
    using C = Cache<N, Ensemble, Ts...>;
    doc.render<typename C::base_type>();
    doc.type(t, "analysis.Cache", std::make_tuple(N,  EnsembleType(Ensemble()).index(), overflow_bits<Ts>...));
    // <base_type_of<L>>
    doc.method(t, "new", rebind::construct<std::size_t>(t));
    doc.method(t, "[]", [](C const &l, NickSequence const &k) {
        auto it = l.find(k);
        if (it == end_of(l)) throw std::out_of_range("Key not found in LRU");
        return it->second;
    });
}

}
