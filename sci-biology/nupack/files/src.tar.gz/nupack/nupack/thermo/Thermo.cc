#include "CachedModel.h"
#include "Adapters.h"
#include "EngineAPI.h"
#include "../Forward.h"
#include "../model/Model.h"

namespace nupack::thermo {

/******************************************************************************************/

void render(Document &doc, Type<CachedModel<MFE, Model<real32>>> t) {render(doc, t, 0);}
void render(Document &doc, Type<CachedModel<PF,  Model<real64>>> t) {render(doc, t, 0);}
void render(Document &doc, Type<CachedModel<PF,  Model<real32>>> t) {render(doc, t, 0);}

void render_pf(Document &doc);

void render_mfe(Document &doc) {
    doc.render<CachedModel<MFE, Model<real32>>>();
    doc.render<CachedModel<PF,  Model<real64>>>();
    doc.render<CachedModel<PF,  Model<real32>>>();
    render_lru<3, real32>(doc);
    render_engine<MFE, 3, 0>(doc, pack<real32>(), as_pack<EnsembleType>());
}

/******************************************************************************************/

}


namespace nupack {
    void render_thermo(Document &doc) {thermo::render_mfe(doc); thermo::render_pf(doc);}
}

