#pragma once
#include "Serialize.h"
#include "../types/Matrix.h"

namespace nlohmann {

/******************************************************************************************/

template <class T>
struct adl_serializer<arma::Col<T>> {
    static void to_json(json &j, arma::Col<T> const &t) {
        j = nlohmann::json::array_t(t.begin(), t.end());
    }
    static void from_json(json const &j, arma::Col<T> &t) {
        t.set_size(j.size());
        std::copy(j.begin(), j.end(), t.begin());
    }
};

/******************************************************************************************/

template <class T>
struct adl_serializer<arma::Mat<T>> {
    static void to_json(json &j, arma::Mat<T> const &t) {
        for (arma::uword i = 0; i != t.n_cols; ++i)
            j.emplace_back(nlohmann::json::array_t(t.begin_col(i), t.end_col(i)));
    }
    static void from_json(json const &j, arma::Mat<T> &t) {
        if (j.size() == 0) return;
        auto cols = j.size();
        auto it = j.begin();
        auto rows = it->size();
        t.set_size(rows, cols);
        for (arma::uword i = 0; i != t.n_cols; ++i, ++it)
            std::copy(it->begin(), it->end(), t.begin_col(i));
    }
};

/******************************************************************************************/

}
