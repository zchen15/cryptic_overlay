#pragma once
#include "Print.h"
#include <rebind/Signature.h>

namespace nupack {

using rebind::Type;

template <class T>
struct Dumpable {
    std::string operator()(T const &t) const {
        std::ostringstream os;
        dump_os(os, t);
        return os.str();
    }
};

template <class T>
Dumpable<T> dumpable(Type<T> t={}) {return {};}

}
