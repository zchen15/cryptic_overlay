#pragma once
#include "Reflection.h"

namespace nupack {

template <class C>
rebind::Dictionary to_dictionary(C c) {
    rebind::Dictionary out;
    out.reserve(tuple_size<decltype(names_of(c))>);
    for_each_zip(names_of(c), members_of(c), [&](auto c, auto &m) {
        out.emplace_back(std::string_view(c), std::move(m));
    });
    std::sort(out.begin(), out.end(),
        [](auto const &i, auto const &j) {return i.first < j.first;});
    return out;
}

template <class C>
bool from_dictionary(rebind::Dictionary v, C &c, rebind::Dispatch &msg) {
    bool ok = true;
    for_each_zip(names_of(c), members_of(c), [&](std::string_view c, auto &m) {
        if (!ok) return;
        auto it = std::lower_bound(v.begin(), v.end(), c,
            [&](auto const &p, auto const &s) {return p.first < s;});
        if (it == v.end() || it->first != c) ok = false;
        if (auto v = it->second.template request<std::decay_t<decltype(m)>>()) m = std::move(*v);
    });
    return ok;
}

template <class C>
std::optional<C> from_dictionary(rebind::Dictionary v, rebind::Dispatch &msg) {
    C c;
    if (from_dictionary(std::move(v), c, msg)) return c;
    return msg.error("member not found");
}

}
