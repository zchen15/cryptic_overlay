/**
 * @brief Wrapper for Mathematica C API
 *
 * @file Mathematica.h
 * @author Mark Fornace
 * @date 2018-05-31
 */
#pragma once
#if __has_include(<wstp.h>)

/******************************************************************************************/

#define NUPACK_MATHEMATICA 1
#include <wstp.h>

/******************************************************************************************/

#include "../algorithms/Utility.h"
#include "../common/Config.h"
#include "../types/IO.h"
#include "../types/Matrix.h"

#include <memory>
#include <type_traits>

namespace nupack {

namespace mma {

/******************************************************************************************/

template <class T> constexpr auto type();
template <> constexpr auto type<float>()   {return std::make_tuple(WSTKREAL, WSPutReal32, WSGetReal32, WSPutReal32Array, WSGetReal32Array, WSReleaseReal32Array);}
template <> constexpr auto type<double>()  {return std::make_tuple(WSTKREAL, WSPutReal64, WSGetReal64, WSPutReal64Array, WSGetReal64Array, WSReleaseReal64Array);}
template <> constexpr auto type<int8_t>()  {return std::make_tuple(WSTKINT, WSPutInteger8, WSGetInteger8, WSPutInteger8Array, WSGetInteger8Array, WSReleaseInteger8Array);}
template <> constexpr auto type<int16_t>() {return std::make_tuple(WSTKINT, WSPutInteger16, WSGetInteger16, WSPutInteger16Array, WSGetInteger16Array, WSReleaseInteger16Array);}
template <> constexpr auto type<int32_t>() {return std::make_tuple(WSTKINT, WSPutInteger32, WSGetInteger32, WSPutInteger32Array, WSGetInteger32Array, WSReleaseInteger32Array);}
template <> constexpr auto type<int64_t>() {return std::make_tuple(WSTKINT, WSPutInteger64, WSGetInteger64, WSPutInteger64Array, WSGetInteger64Array, WSReleaseInteger64Array);}

static constexpr std::array<int, 12> Codes = {WSTKERR, WSTKINT, WSTKFUNC, WSTKREAL,
    WSTKSTR, WSTKSYM, WSTKOLDINT, WSTKOLDREAL, WSTKOLDSTR, WSTKOLDSYM, WSTKOPTSTR, WSTKOPTSYM};
/******************************************************************************************/

class Engine {

    struct LinkDeleter {void operator()(WSLINK lp) const {WSClose(lp);}};
    struct EnvDeleter {void operator()(WSENV ep) const {WSDeinitialize(ep);}};

    // The order here matters because the link must be deleted first!
    std::unique_ptr<std::remove_pointer_t<WSENV>, EnvDeleter> env;
    std::unique_ptr<std::remove_pointer_t<WSLINK>, LinkDeleter> link;

    template <class ...Ts>
    struct Function {
        string name;
        std::tuple<Ts...> arguments;

        Function(string &&s, Ts &&...ts) : name(std::move(s)), arguments(std::move(ts)...) {}
    };

    struct Symbol {string name;};

    template <class T>
    void put_scalar(T t) {if (!second_of(type<T>())(link.get(), t)) throw Error("Could not put scalar");}

    template <class T>
    void get_scalar(T &t) {
        if (!third_of(type<T>())(link.get(), &t)) throw Error("Could not get scalar");
    }

    template <class T, class ...Ds>
    void put_array(T const *p, Ds ...dims) {
        int d[] = {dims...};
        if (!fourth_of(type<T>())(link.get(), p, &d, nullptr, sizeof...(Ds))) throw Error("Could not put array");
    }

    template <class ...Ts>
    void put(Function<Ts...> f) {
        if (!WSPutFunction(link.get(), f.name.c_str(), sizeof...(Ts))) throw Error("Could not put function");
        for_each(f.arguments, [this](auto &&t){this->put(std::move(t));});
    }

    template <class T, class F>
    auto get_array(F &&f) {
        T const *data; int *dims; char **heads; int d;
        fifth_of(type<T>())(link.get(), &data, &dims, &heads, &d);
        auto ret = f(data, dims, d);
        WSReleaseReal64Array(link.get(), data, dims, heads, d);
        return ret;
    }

    template <class T, std::size_t N, std::size_t ...Is>
    Dense<T, N> get_arma(indices_t<Is...>) {
        return get_array([](auto const *data, int *dims, int d){
            static_assert(N == sizeof...(Is), "Dimension mismatch");
            return Dense<T, N>(data, dims[sizeof...(Is) - 1 - Is]..., true, false);
        });
    }

public:

    struct Error : public ::nupack::Error {
        template <class ...Ts>
        Error(Ts const &...ts) : ::nupack::Error("Mathematica engine error", ts...) {};
    };

    Engine(bool interactive=false) {
        WSENV ep = WSInitialize((WSEnvironmentParameter)0);
        if(ep == (WSENV)0) throw Error("Could not initialize environment");
        else env.reset(ep);

        int err; WSLINK lp;
        if (interactive) lp = WSOpenString(env.get(), "-linkcreate", &err);
        else lp = WSOpenString(env.get(), ("-linkmode launch -linkname \"" + MathematicaCommand + "\" -wstp").c_str(), &err);

        if(lp == (WSLINK)0 || err != WSEOK) throw Error("Could not create link: interactive =", interactive);
        else link.reset(lp);
    }

    /**************************************************************************************/

    // Define symbol
    Symbol symbol(string s) const {return {std::move(s)};}
    // Define function
    template <class ...Ts>
    auto fn(string name, Ts ...ts) const {return Function<Ts...>(std::move(name), std::move(ts)...);}

    /**************************************************************************************/

    // Put scalar
    template <class T, NUPACK_IF(is_arithmetic<T>)>
    void put(T t) {put_scalar(t);}
    // Put string
    void put(string s) {if (!WSPutString(link.get(), s.c_str())) throw Error("Could not put string");}
    // Put 1D array
    template <class V, NUPACK_IF(!is_arma<V> && is_arithmetic<value_type_of<V>>)>
    auto put(V const &v) {put_array(std::vector<decltype(*begin_of(v))>(begin_of(v), end_of(v)).data(), len(v));}
    // Put armadillo 1d array
    template <class V, NUPACK_IF(is_col<V> || is_row<V>)>
    void put(V &&v) {auto &&c = eval(fw<V>(v)); put_array(c.data(), c.n_elem);}
    // Put armadillo 2d array
    template <class M, NUPACK_IF(is_dense<M> && !is_col<M> && !is_row<M>)>
    void put(M const &m) {put_array(m.data(), m.n_rows, m.n_cols);}
    // Put symbol
    void put(Symbol const &s) {if (!WSPutSymbol(link.get(), s.name.c_str())) throw Error("Could not put symbol: ", s.name);}
    // Put several things
    template <class ...Ts>
    void put_all(Ts &&...ts) {NUPACK_UNPACK(put(fw<Ts>(ts)));}

    /**************************************************************************************/

    // Get scalar
    template <class T, NUPACK_IF(is_arithmetic<T>)>
    T get() {T t; get_scalar(t); return t;}
    // Get string
    template <class T, NUPACK_IF(is_same<T, string>)>
    string get() {
        char const *s; if (!WSGetString(link.get(), &s)) throw Error("Could not put string");
        string ret(s); WSReleaseString(link.get(), s); return ret;
    }
    // Get armadillo type
    template <class T, std::size_t N, NUPACK_IF(N <= 3 && N >= 1)>
    Dense<T, N> get() {return get_arma<T, N>(indices_up_to<N>());}
    // Get vectors of dimensions and data
    template <class T, std::size_t N, NUPACK_IF(N == 0)>
    auto get() {
        return get_array<T>([](auto const *data, int *dims, int d){
            std::vector<int> v1(dims, dims + d);
            std::vector<T> v2(data, data + product(v1));
            return std::make_pair(v1, v2);
        });
    }

    /**************************************************************************************/

    template <class ...Ts>
    void put_fn(string const &name, Ts &&...ts) {
        if (!WSPutFunction(link.get(), "EvaluatePacket", 1)) throw Error("Could not put EvaluatePacket");
        if (!WSPutFunction(link.get(), name.c_str(), sizeof...(Ts))) throw Error("Could not put function");
        put_all(fw<Ts>(ts)...);
        if (!WSEndPacket(link.get())) throw Error("Could not end packet");

        int pkt;
        while((pkt = WSNextPacket(link.get()), pkt) && pkt != RETURNPKT) {
            WSNewPacket(link.get());
            if (WSError(link.get())) throw Error("Could not get result");
        }
    }

    /**************************************************************************************/

    // Evaluate some function and return the result
    template <class R=void, class ...Ts, NUPACK_IF(!is_same<R, void>)>
    R evaluate(string const &name, Ts &&...ts) {
        put_fn(name, fw<Ts>(ts)...);
        return get<R>();
    }

    // Evaluate some function and ignore the result
    template <class R=void, class ...Ts, NUPACK_IF(is_same<R, void>)>
    R evaluate(string const &name, Ts &&...ts) {
        put_fn(name, fw<Ts>(ts)...);
        if (!WSNewPacket(link.get())) throw Error("Could not make new packet");
    }

    // Evaluate a string
    template <class R=void>
    R evaluate(string const &name) {return evaluate<R>("ToExpression", name);}

    // Set a variable in the notebook
    template <class T>
    T set(string const &name, T const &t) {evaluate<void>("Set", symbol(name), t); return t;}
};

/******************************************************************************************/

}}

#endif
