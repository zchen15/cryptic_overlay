/**
 * @brief SDD linear system solvers
 *
 * @file SDD.h
 * @author Mark Fornace
 * @date 2018-05-31
 */
#pragma once
#include "../types/Matrix.h"
#include "Matlab.h"

namespace nupack {

#ifdef NUPACK_MATLAB

struct SddSolver : matlab::Solver, la::Solver {
    usize threshold;
    string method;

    // auto members() {return extend_members<matlab::Solver, la::Solver>(this, threshold, method);}
    // static constexpr auto names() {return extend_names<matlab::Solver, la::Solver>("threshold", "method");}

    SddSolver(string arma="superlu", string sdd="", usize t=100000)
        : matlab::Solver(sdd), la::Solver(arma), method(sdd), threshold(t) {
            if (!sdd.empty() && sdd != "lamg" && sdd != "cmg")
                NUPACK_ERROR("invalid SDD method with MATLAB", sdd);
        }

    void wait() const {matlab::Solver::wait();}

    // Solve A x = b, x and b may be matrices or vectors
    template <class X, class A, class B, NUPACK_IF(la::is_sparse<A>)>
    void operator()(X &&x, A &&a, B &&b, real tol=1e-12) const {
        if (!method.empty() && a.n_nonzero >= threshold) {
            auto scale = 1 / norm(nonzeros(a), 1);
            matlab::Solver::operator()(fw<X>(x), fw<A>(a) * scale, fw<B>(b), tol);
            x *= scale;
        } else la::Solver::operator()(fw<X>(x), fw<A>(a), fw<B>(b), tol);
    }

    template <class X, class A, class B, NUPACK_IF(!la::is_sparse<A>)>
    void operator()(X &&x, A &&a, B &&b, real tol=1e-12) const {
        la::Solver::operator()(fw<X>(x), fw<A>(a), fw<B>(b), tol);
    }

    friend std::ostream & operator<<(std::ostream &os, SddSolver const &t) {
        return os << "SddSolver(method=,'" << t.method << "', threshold=" << t.threshold << ")";
    }



};

#else

struct SddSolver : la::Solver {
    SddSolver(string arma="superlu", string sdd="", usize t=100000) : la::Solver(arma) {
        if (!sdd.empty()) NUPACK_ERROR("invalid SDD method without MATLAB", sdd);
    }
    void wait() const {}

    friend std::ostream & operator<<(std::ostream &os, SddSolver const &) {return os << "SddSolver(matlab=False)";}
};

#endif

void render(Document &doc, Type<SddSolver> t);

}
