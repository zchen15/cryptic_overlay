/**
 * @brief Wrapper for Mathematica C API
 *
 * @file Mathematica.h
 * @author Mark Fornace
 * @date 2018-05-31
 */
#pragma once
#ifdef NUPACK_MATLAB

#include "../types/Matrix.h"
#include "../math/Matrices.h"
#include "../types/IO.h"

#include <mex.h>
#include <engine.h>
#include "../standard/Future.h"

namespace nupack {

template <> struct memory::is_simple<::Engine, void> : True {};
template <> struct memory::is_simple<::mxArray, void> : True {};

namespace matlab {

/// Type code enumeration for MATLAB
static constexpr std::array<mxClassID, 17> Codes = {
    mxUNKNOWN_CLASS, mxCELL_CLASS,   mxSTRUCT_CLASS, mxLOGICAL_CLASS, mxCHAR_CLASS,  mxVOID_CLASS,
    mxDOUBLE_CLASS,  mxSINGLE_CLASS, mxINT8_CLASS,   mxUINT8_CLASS,   mxINT16_CLASS, mxUINT16_CLASS,
    mxINT32_CLASS,   mxUINT32_CLASS, mxINT64_CLASS,  mxUINT64_CLASS,  mxFUNCTION_CLASS
};

/// Look up type code from type
static constexpr auto const Lookup = std::make_tuple(
    std::pair<void *,     mxClassID>(nullptr, mxVOID_CLASS),
    std::pair<bool *,     mxClassID>(nullptr, mxLOGICAL_CLASS),
    std::pair<char *,     mxClassID>(nullptr, mxCHAR_CLASS),
    std::pair<float *,    mxClassID>(nullptr, mxSINGLE_CLASS),
    std::pair<double *,   mxClassID>(nullptr, mxDOUBLE_CLASS),
    std::pair<int8_t *,   mxClassID>(nullptr, mxINT8_CLASS),
    std::pair<int16_t *,  mxClassID>(nullptr, mxINT16_CLASS),
    std::pair<int32_t *,  mxClassID>(nullptr, mxINT32_CLASS),
    std::pair<int64_t *,  mxClassID>(nullptr, mxINT64_CLASS),
    std::pair<uint8_t *,  mxClassID>(nullptr, mxUINT8_CLASS),
    std::pair<uint16_t *, mxClassID>(nullptr, mxUINT16_CLASS),
    std::pair<uint32_t *, mxClassID>(nullptr, mxUINT32_CLASS),
    std::pair<uint64_t *, mxClassID>(nullptr, mxUINT64_CLASS)
);

template <class T> static constexpr mxClassID Code = std::get<std::pair<T *, mxClassID>>(Lookup).second;

/******************************************************************************************/

/// Wrapper for a MATLAB array of any depth
template <class VT, mwSize N>
class Array {
    using CX = is_complex<VT>;

    struct Error : public ::nupack::Error {
        template <class ...Ts>
        Error(Ts const &...ts) : ::nupack::Error("MATLAB array error", ts...) {};
    };

    struct Deleter {void operator() (mxArray *p) const {mxDestroyArray(p);}};

    std::unique_ptr<mxArray, Deleter> self;
    std::array<mwSize, N> dims;

    auto indices() const {return indices_up_to<N>();}

    void construct_data(bool zeros=true) {
        mxArray *p;
        if (zeros) p = mxCreateNumericArray(N, dims.data(), Code<type_in<CX>>, CX::value ? mxCOMPLEX : mxREAL);
        else p = mxCreateUninitNumericArray(N, dims.data(), Code<type_in<CX>>, CX::value ? mxCOMPLEX : mxREAL);
        if (!p) throw Error("Could not create numeric array");
        self.reset(p);
    }

    void construct_data(la::Dense<VT, N> const &a) {construct_data(false); set_data(a);}

    template <class T, usize ...Is, usize ...Js>
    Array(T t, indices_t<Is...>, indices_t<Js...>)
        : dims({static_cast<mwSize>(std::get<Is>(t))...}) {
        construct_data(fw<decltype(std::get<Js + N>(t))>(std::get<Js + N>(t))...);
    }

    template <usize ...Is>
    auto as_arma_helper(indices_t<Is...>) const {
        return la::Dense<VT, N>(data(), std::get<Is>(dims)..., false, true);
    }

public:

    NUPACK_REFLECT(Array, self, dims);

    mxArray const * raw() const {return self.get();}

    Array(mxArray *p) : self(p) {
        mwSize n = mxGetNumberOfDimensions(p);
        if (n != N) throw Error("Mismatch of array dimensions: got ", n, " but expected ", N);
        mwSize const *d = mxGetDimensions(p);
        std::copy(d, d + n, dims.data());
    }

    template <class T, class ...Ts, NUPACK_IF(is_integral<T>)>
    Array(T &&t, Ts &&...ts) : Array(std::forward_as_tuple(t, ts...), indices(),
        indices_up_to<sizeof...(Ts) + 1 - N>()) {}

    template <bool B=true, NUPACK_IF(B && N >= 1 && N <= 3 )>
    Array(la::Dense<VT, N> const &a) : Array(std::tuple_cat(la::shape(a), std::tie(a)),
        indices(), indices_up_to<1>()) {}

    auto data() {return mxGetPr(self.get());}
    auto data() const {return mxGetPr(self.get());}

    friend std::ostream & operator<<(std::ostream &os, Array const &t) {
        dump_os(os, "Matlab Array", t.dims, '\n', t.as_arma());
        return os;
    }

    auto n_elem() const {return product(dims);}

    auto shape() const {return dims;}

    template <class V> auto set_data(V const &v) {
        NUPACK_REQUIRE(std::distance(begin_of(v), end_of(v)), ==, n_elem());
        std::copy(begin_of(v), end_of(v), data());
    }

    auto begin() {return data();}
    auto begin() const {return data();}

    auto end() {return data() + n_elem();}
    auto end() const {return data() + n_elem();}

    auto & operator[](usize i) {return *(data() + i);}
    auto const & operator[](usize i) const {return *(data() + i);}

    template <bool B=true, NUPACK_IF(B && N >= 1 && N <= 3 )>
    auto as_arma() const {return as_arma_helper(indices());}

    template <bool B=true, NUPACK_IF(B && N >= 1 && N <= 3 )>
    auto as_arma() {return as_arma_helper(indices());}

    template <bool B=true, NUPACK_IF(B && N >= 1 && N <= 3 )>
    operator la::Dense<VT, N>() const {return la::Dense<VT, N>(as_arma());}

};


/******************************************************************************************/

/// 0 represents a sparse array
template <class VT>
class Array<VT, 0> {
    static_assert(is_same<double, type_in<is_complex<VT>>>, "MATLAB only has doubles for sparse arrays");

    struct Error : public ::nupack::Error {
        template <class ...Ts>
        Error(Ts const &...ts) : ::nupack::Error("MATLAB sparse array error", ts...) {};
    };

    struct Deleter {void operator() (mxArray *p) const {mxDestroyArray(p);}};

    std::unique_ptr<mxArray, Deleter> self;
    std::array<mwSize, 3> dims;

public:

    NUPACK_REFLECT(Array, self, dims);

    Array(SpMat<VT> &&S) : dims({S.n_rows, S.n_cols, S.n_nonzero}) {
        mxArray *p = mxCreateSparse(dims[0], dims[1], dims[2], is_complex<VT>::value ? mxCOMPLEX : mxREAL);
        if (!p) throw Error("Could not create numeric array");
        self.reset(p);
        set_data(std::move(S));
    }

    Array(SpMat<VT> const &S) : dims({S.n_rows, S.n_cols, S.n_nonzero}) {
        mxArray *p = mxCreateSparse(dims[0], dims[1], dims[2], is_complex<VT>::value ? mxCOMPLEX : mxREAL);
        if (!p) throw Error("Could not create numeric array");
        self.reset(p);
        set_data(S);
    }

    template <class V>
    Array(mwSize m, mwSize n, V &&v)
        : Array(la::matrix_from_tuples<SpMat<VT>>(m, n, fw<V>(v))) {}

    void set_data(SpMat<VT> &&S) {
        NUPACK_REQUIRE(S.n_cols, ==, dims[1]);
        NUPACK_REQUIRE(S.n_nonzero, ==, dims[2]);
        std::move(S.values, S.values + S.n_nonzero, mxGetPr(self.get()));
        std::move(S.row_indices, S.row_indices + S.n_nonzero, mxGetIr(self.get()));
        std::move(S.col_ptrs, S.col_ptrs + S.n_cols + 1, mxGetJc(self.get()));
    }

    void set_data(SpMat<VT> const &S) {
        NUPACK_REQUIRE(S.n_cols, ==, dims[1]);
        NUPACK_REQUIRE(S.n_nonzero, ==, dims[2]);
        std::copy(S.values, S.values + S.n_nonzero, mxGetPr(self.get()));
        std::copy(S.row_indices, S.row_indices + S.n_nonzero, mxGetIr(self.get()));
        std::copy(S.col_ptrs, S.col_ptrs + S.n_cols + 1, mxGetJc(self.get()));
    }

    auto as_arma() const {
        Col<VT> Pr(mxGetPr(self.get()), dims[2], false, true);
        Col<mwIndex> Ir(mxGetIr(self.get()), dims[2], false, true);
        Col<mwIndex> Jc(mxGetJc(self.get()), dims[1] + 1, false, true);
        return SpMat<VT>(arma::conv_to<arma::uvec>::from(std::move(Ir)),
                             arma::conv_to<arma::uvec>::from(std::move(Jc)),
                             Pr, dims[0], dims[1]);
    }

    auto shape() const {return dims;}

    mxArray const * raw() const {return self.get();}
};

/******************************************************************************************/

struct Buffer {
    std::shared_ptr<::Engine> engine;
    string buffer;

    Buffer(std::shared_ptr<::Engine> eng, int n) : engine(std::move(eng)), buffer(n, char(0)) {
        engOutputBuffer(engine.get(), &buffer[0], buffer.size());
    }

    ~Buffer() {if (engine) engOutputBuffer(engine.get(), NULL, 0);}
};

/******************************************************************************************/

class Engine {
    struct Deleter {void operator() (::Engine *p) const {engClose(p);}};

    std::shared_ptr<::Engine> self;
    /// Initialization is pretty slow, so it's done in a separate thread and tracked by a std::future
    std::shared_future<void> future;

public:
    NUPACK_REFLECT(Engine, self, future);

    struct Error : public ::nupack::Error {
        template <class ...Ts>
        Error(Ts const &...ts): ::nupack::Error("MATLAB engine error: ", ts...) {};
    };

    Engine(bool visible=false) {
        future = std::async(std::launch::async, [=] {
            ::Engine *p = engOpen((MatlabCommand + " -nodisplay").c_str());
            if (!p) throw Error("Could not open MATLAB engine with command ", MatlabCommand);
            engSetVisible(p, visible);
            self.reset(p, Deleter());
        });
    }

    void wait() const {future.wait();} // wait for engine to become available, sometimes useful for timing

    string eval(string const &s, int n=1024) const {
        wait();
        Buffer buff(self, n);
        int err = engEvalString(self.get(), s.c_str());
        if (err) throw Error("Error in evaluation of string '", s, "'");
        return buff.buffer;
    }

    string disp(string const &s, int n=1024) const {return eval("disp(" + s + ");", n);}

    template <class T, mwSize N> Array<T, N> get(string const &s) const {
        wait();
        mxArray *r = engGetVariable(self.get(), s.c_str());
        if (!r) throw Error("Could not retrieve variable '", s, "'");
        return {r};
    }

    template <class T, mwSize N> void put(string const &s, Array<T, N> const &a) const {
        wait();
        int err = engPutVariable(self.get(), s.c_str(), a.raw());
        if (err) throw Error("Could not put variable '", s, "'");
    }

    auto ptr() const {return self.get();}
};

/******************************************************************************************/

Array<double, 2> solve_sdd(Engine const &, Array<double, 0> const &A,
    Array<double, 2> const &b, string const &solver="lamg", double tol=1e-12);

/******************************************************************************************/

class Solver {
protected:
    string kind;
    Engine engine;

public:

    template <class ...Ts>
    Solver(string k="lamg", Ts &&...ts) : kind(k), engine(fw<Ts>(ts)...) {}
    NUPACK_REFLECT(Solver, kind, engine);

    void wait() const {engine.wait();}

    template <class X, class A, class B, NUPACK_IF(la::depth<B> == 1)>
    void operator()(X &&x, A &&a, B &&b, real tol=1e-12) const {
        Array<double, 0> a_(fw<A>(a));
        Array<double, 2> b_(fw<B>(b));
        x = vectorise(solve_sdd(engine, std::move(a_), std::move(b_), kind, tol).as_arma(), 0);
    }

    template <class X, class A, class B, NUPACK_IF(la::depth<B> == 2)>
    void operator()(X &&x, A &&a, B &&b, real tol=1e-12) const {
        Array<double, 0> a_(fw<A>(a));
        Array<double, 2> b_(fw<B>(b));
        x = solve_sdd(engine, std::move(a_), std::move(b_), kind, tol).as_arma();
    }
};

/******************************************************************************************/

}}

#endif
