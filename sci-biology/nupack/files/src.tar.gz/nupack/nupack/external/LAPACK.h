/**
 * @brief LAPACK routines, mainly for Cholesky decomposition. Could probably remove.
 *
 * @file LAPACK.h
 * @author Mark Fornace
 * @date 2018-05-30
 */
#pragma once
#include "../algorithms/TypeSupport.h"
#include "../reflect/Print.h"

namespace nupack::lapack {

/******************************************************************************************/

/// Type aliases for LAPACK data types
using s = float;
using d = double;
using c = std::complex<float>;
using z = std::complex<double>;
using i = int;

/// LAPACK error
class Error : public std::exception {
    i m_code;
public:
    i code() const {return m_code;}
    Error(i info) : m_code(info) {}
    const char * what() const noexcept override {return "LAPACK error";}
};

#ifndef NUPACK_NO_LAPACK

/******************************************************************************************/

/// Functor to make an lvalue into a pointer or leave a pointer as is
struct make_ptr {
    template <class T> constexpr auto operator()(T *t) const {return t;}
    template <class T, NUPACK_IF(!is_pointer<T>)> constexpr auto operator()(T &t) const {return &t;}
};

using Error_Base = Error;

/******************************************************************************************/

// Basic base class for a Fortran routine which may be a function
template <class F> struct function {
    template <class ...Ts> static auto call(Ts &&...ts) noexcept {
        // All values needed for the function call
        auto values = type_in<F>(fw<Ts>(ts)...);
        // Call the function with the pointers
        return unpack(map_each(values, make_ptr()), F::ptr());
    }
};

// Basic base class for a Fortran subroutine which has "integer info" as last parameter
template <class F> struct subroutine {
    static void handle_info(False, i info) {if (info) throw typename F::Error(info);}
    static i handle_info(True, i info) noexcept {return info;}

    template <class NoExcept, class ...Ts>
    static auto call(NoExcept, Ts &&...ts) noexcept(NoExcept::value) {
        // All values needed for the function call, add integer for "info"
        using Vs = decltype(std::tuple_cat(declval<type_in<F>>(), std::tuple<i>()));
        auto values = Vs(fw<Ts>(ts)..., 0);
        // Call the function with the pointers, any return value is discarded
        unpack(map_each(values, make_ptr()), F::ptr());
        auto info = std::get<tuple_size<Vs> - 1>(values);
        // Throw or return the status
        return handle_info(NoExcept(), info);
    }
};

/******************************************************************************************/

extern "C" {
    extern void spotrf_(char *uplo, i *n, s *A, i *lda, i *info);
    extern void dpotrf_(char *uplo, i *n, d *A, i *lda, i *info);
    extern void cpotrf_(char *uplo, i *n, c *A, i *lda, i *info);
    extern void zpotrf_(char *uplo, i *n, z *A, i *lda, i *info);
}

/// Computes the Cholesky factorization of a symmetric (Hermitian) positive-definite matrix
template <class T> struct potrf : subroutine<potrf<T>> {
    using type = std::tuple<char, i, T *, i>;
    struct Error : Error_Base {Error(i info) : Error_Base(info) {}};
    static constexpr auto ptr() {return match<T, s, d, c, z>(spotrf_, dpotrf_, cpotrf_, zpotrf_);}
};

/******************************************************************************************/

extern "C" {
    extern void spotrs_(char *uplo, i *n, i *nrhs, s *A, i *lda, s *b, i *ldb, i *info);
    extern void dpotrs_(char *uplo, i *n, i *nrhs, d *A, i *lda, d *b, i *ldb, i *info);
    extern void cpotrs_(char *uplo, i *n, i *nrhs, c *A, i *lda, c *b, i *ldb, i *info);
    extern void zpotrs_(char *uplo, i *n, i *nrhs, z *A, i *lda, z *b, i *ldb, i *info);
}

// Solves a system of linear equations with a Cholesky-factored symmetric (Hermitian) positive-definite coefficient matrix
template <class T> struct potrs : subroutine<potrs<T>> {
    using type = std::tuple<char, i, i, T *, i, T *, i>;
    struct Error : Error_Base {Error(i info) : Error_Base(info) {}};
    static constexpr auto ptr() {return match<T, s, d, c, z>(spotrs_, dpotrs_, cpotrs_, zpotrs_);}
};

/******************************************************************************************/

extern "C" {
    extern void spotri_(char *uplo, i *n, s *A, i *lda);
    extern void dpotri_(char *uplo, i *n, d *A, i *lda);
    extern void cpotri_(char *uplo, i *n, c *A, i *lda);
    extern void zpotri_(char *uplo, i *n, z *A, i *lda);
}

/// Computes the inverse of a symmetric (Hermitian) positive-definite matrix using the Cholesky factorization
template <class T> struct potri : subroutine<potri<T>> {
    using type = std::tuple<char, i, T *, i>;
    struct Error : Error_Base {Error(i info) : Error_Base(info) {}};
    static constexpr auto ptr() {return match<T, s, d, c, z>(spotri_, dpotri_, cpotri_, zpotri_);}
};

/******************************************************************************************/

extern "C" {
    extern void ssygv_(i *itype, char *jobz, char *uplo, i *n, s *a, i *lda, s *b, i *ldb, s *w, s *work, i *lwork, i *info);
    extern void dsygv_(i *itype, char *jobz, char *uplo, i *n, d *a, i *lda, d *b, i *ldb, d *w, d *work, i *lwork, i *info);
    extern void csygv_(i *itype, char *jobz, char *uplo, i *n, c *a, i *lda, c *b, i *ldb, c *w, c *work, i *lwork, i *info);
    extern void zsygv_(i *itype, char *jobz, char *uplo, i *n, z *a, i *lda, z *b, i *ldb, z *w, z *work, i *lwork, i *info);
}

/// Computes symmetric eigenvalues
template <class T> struct sygv : subroutine<sygv<T>> {
    using type = std::tuple<char, i, T *, i>;
    struct Error : Error_Base {Error(i info) : Error_Base(info) {}};
    static constexpr auto ptr() {return match<T, s, d, c, z>(ssygv_, dsygv_, csygv_, zsygv_);}
};

/******************************************************************************************/

extern "C" {
    extern void sysev_(char *jobz, char *uplo, i *n, s *a, i *lda, s *w, s *work, i *lwork, i *info);
    extern void dysev_(char *jobz, char *uplo, i *n, d *a, i *lda, d *w, d *work, i *lwork, i *info);
    extern void cheev_(char *jobz, char *uplo, i *n, c *a, i *lda, s *w, c *work, i *lwork, s *rwork, i *info);
    extern void zheev_(char *jobz, char *uplo, i *n, z *a, i *lda, d *w, z *work, i *lwork, d *rwork, i *info);
}

/// Computes all eigenvalues and, optionally, eigenvectors of a real symmetric matrix
template <class T> struct ysev : subroutine<ysev<T>> {
    struct Error : Error_Base {Error(i info) : Error_Base(info) {}};
    using type = std::tuple<char, char, i, T *, i, T *, T *, i>;
    static constexpr auto ptr() {return match<T, s, d>(sysev_, dysev_);}
};

/// Computes all eigenvalues and, optionally, eigenvectors of a Hermitian matrix
template <class T> struct heev : subroutine<heev<T>> {
    struct Error : Error_Base {Error(i info) : Error_Base(info) {}};
    using type = std::tuple<char, char, i, T *, i, value_type_of<T> *, T *, i, value_type_of<T> *, i>;
    static constexpr auto ptr() {return match<T, c, z>(cheev_, zheev_);}
};

/******************************************************************************************/

#endif

}
