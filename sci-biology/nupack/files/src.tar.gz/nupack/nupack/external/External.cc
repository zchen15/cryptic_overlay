/**
 * @brief SDD solver for LAMG MATLAB package
 *
 * @file Matlab.cc
 * @author Mark Fornace
 * @date 2018-05-31
 */
#include "Matlab.h"
#include "SDD.h"

#ifdef NUPACK_MATLAB
namespace nupack::matlab {

// From lamg_example_sdd_coord.m
Array<double, 2> solve_sdd(Engine const &eng, Array<double, 0> const &A,
    Array<double, 2> const &b, string const &solver, double tol) {
    // lamg   = Solvers.newSolver(solver, 'randomSeed', 1, 'tvInitialGuess', 'random', 'x0', put in x0!);
    eng.put("A", A);
    tol = 1e-100;

    eng.eval(joined_string('\n',
        joined_string("", "solver = '", solver, "';"),
        joined_string("", "x      = zeros(", b.shape()[0], ", ", b.shape()[1], ");"),
        "lamg   = Solvers.newSolver(solver, 'tvInitialGuess', 'random');", // 'randomSeed', 1
        "g      = graph.api.Graph.newNamedInstance('graph', 'sdd', A, []);",
        "setup  = lamg.setup('problem', lin.api.Problem(A, [], [], []));").data());

    eng.put("b", b);

    for (auto i : range(b.shape()[1]))
        echo | eng.eval(joined_string("",
            "setRandomSeed(now);\n",
            "[x(:, ", i+1, "), converged, history, details] = lamg.solve(setup, b(:, ", i+1,
            "), 'finalErrorNorm', 1e-100, 'steadyStateTol', 1e-100, 'numCycles', 1000, 'errorReductionTol', ", tol, ", 'maxIterations', ", 10000, ");").data());

    auto x = eng.get<double, 2>("x");

    //echo | eng.disp("converged");

    echo | eng.disp("details.errorNormHistory");
    echo | eng.disp("details.convHistory");
    echo | eng.disp("details.stats");
    echo | eng.disp("details");
    echo | eng.get<double, 2>("history");

    eng.eval("clear edges history converged A b x g setup lamg details;");
    return x;
}
}
#endif

namespace nupack {
void render(Document &doc, Type<SddSolver> t) {
    doc.type(t, "numeric.SddSolver");
    doc.method(t, "new", rebind::construct<string, string, usize>(t)); // 0
    doc.method(t, "()", [](SddSolver const &s, std::variant<real_csc, real_mat> A, std::variant<real_col, real_mat> B) {
        decay<decltype(B)> X;
        // s(X, std::move(A), std::move(B));
        return X;
    });
}
}
