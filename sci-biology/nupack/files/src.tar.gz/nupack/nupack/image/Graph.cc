#include "Graph.h"

namespace nupack::image {

#if NUPACK_LEMON
GraphMatching::GraphMatching(uint nsub, uint nedges, uint m, vec<uint> vlabels)
    : vertex_labels(std::move(vlabels)), sizes(nsub, 0), graphs(nsub) {

    edges.reserve(nedges);
    nodes.reserve(len(vertex_labels));
    edge_labels.reserve(nedges);

    izip(vertex_labels, [&](auto i, auto l) {
        ++sizes[l];
        if (i < m) nodes.emplace_back(graphs[l].graph.addRedNode());
        else nodes.emplace_back(graphs[l].graph.addBlueNode());
    });
}

void GraphMatching::add_edge(uint s, uint t) {
    NUPACK_ASSERT(graphs[vertex_labels[s]].graph.red(nodes[s]));
    NUPACK_ASSERT(graphs[vertex_labels[s]].graph.blue(nodes[t]));
    edges.emplace_back(graphs[vertex_labels[s]].graph.addEdge(
        lemon::SmartBpGraph::asRedNodeUnsafe(nodes[s]),
        lemon::SmartBpGraph::asBlueNodeUnsafe(nodes[t]))
    );
    edge_labels.emplace_back(vertex_labels[s]);
}

/******************************************************************************************/

small_vec<bool> GraphMatching::max_matching() const {
    small_vec<lemon::MaxWeightedBpMatching<lemon::SmartBpGraph, BipartiteGraph<real>::EdgeMap>> matchers;
    matchers.reserve(len(graphs));
    for (auto &s : graphs) {
        matchers.emplace_back(s.graph, *s.weights);
        matchers.back().run();
    }
    small_vec<bool> out(len(edges));
    zip(out, edge_labels, edges, [&](auto &o, auto l, auto const &e) {o = matchers[l].matching(e);});
    return out;
}

void GraphMatching::initialize_weights() {for (auto &s : graphs) s.weights.emplace(s.graph);}

#else

GraphMatching::GraphMatching(uint nsub, uint nedges, uint m, vec<uint> vlabels) {
    NUPACK_ERROR("LEMON graph library cannot be used in the current installation");
}
void GraphMatching::add_edge(uint s, uint t) {}
void GraphMatching::initialize_weights() {}
small_vec<bool> GraphMatching::max_matching() const {return {};}

#endif

/******************************************************************************************/

void MultipartiteGraph::initialize() {
    all_edges.set_size(2, boost::num_edges(all_vertices));
    for_each_edge([&, n=0](auto s, auto t) mutable {
        all_edges(0, n) = s;
        all_edges(1, n) = t;
        ++n;
    });

    arma::inplace_trans(all_edges);
    all_edges.col(1) -= prefixes[1];
}

arma::uvec MultipartiteMatcher::max_matching(Col<real> const &weights) {
    // set the subgraph weights to the new values
#if NUPACK_LEMON
    izip(weights, matching->edges, [&](auto i, auto w, auto const &e) {
        auto s = all_edges(i, 0);
        auto t = all_edges(i, 1) + prefixes[1];
        (*matching->graphs[matching->vertex_labels[s]].weights)[e] = w;
        // NUPACK_REQUIRE((*matching->graphs[matching->vertex_labels[s]].weights)[e], ==, w); verified
    });
#endif
    // run matching and gather edges that appear in the subgraph matchings
    auto const matched = matching->max_matching();
    arma::uvec out(count_if(matched));
    izip(matched, [&, n=0](auto i, bool b) mutable {if (b) out(n++) = i;});
    return out;
}

/******************************************************************************************/

}
