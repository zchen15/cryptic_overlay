#include "Leica.h"
#include <spdlog/fmt/fmt.h>

namespace nupack::image {


// Ex, Em: l x f, the spectra of the fluorophores
// D: 2 x 3 x s: the start and end indices of the 3 detectors for each sequence
// L: the excitation for each sequence
real leica_score(Mat<real> const &Ex, Mat<real> const &Em, Cube<uint> const &D, Col<uint> const &lasers) {
    // interpolate the excitation spectra at each l
    auto const nf = Em.n_cols, ns = D.n_slices;
    Mat<real> A(3 * ns, ns);
    for (auto f : range(nf))
        for (auto s : range(ns))
            for (auto d : range(3))
                A(3 * s + d, f) = Ex(lasers(s), f) * la::accu(Em(la::span(D(0, d, s), D(1, d, s)), f));
    Mat<real> X;
    if (la::inv_sympd(X, A.t() * A)) return X.diag().max();
    return *inf;
}

// return laser wavelength
uint random_laser() {
    auto r = random_float();
    if (r < 0.2) return 405;
    if (r < 0.4) return 440;
    return random_interval(470, 670);
}

// return 2 x 3 array
typename Mat<uint>::fixed<2, 3> random_detectors(uint laser) {
    std::array<uint, 6> draws;
    while (true) {
        for (auto &d : draws) d = random_interval(laser + 5, 800);
        sort(draws);
        if (draws[1] + 3 < draws[2] && draws[3] + 3 < draws[4]) break;
    }

    typename Mat<uint>::fixed<2, 3> D;
    D(0, 0) = draws[0]; D(1, 0) = draws[1];
    D(0, 1) = draws[2]; D(1, 1) = draws[3];
    D(0, 2) = draws[4]; D(1, 2) = draws[5];
    return D;
}

std::tuple<Col<uint>, Cube<uint>, real> optimize_leica(Mat<real> const &Ex, Mat<real> const &Em, uint ns, uint iters) {
    Col<uint> lasers(ns);
    Cube<uint> detectors(2, 3, ns);

    for (auto &l : lasers) l = random_laser();
    for (auto i : range(ns)) detectors.slice(i) = random_detectors(lasers(i));

    auto score = leica_score(Ex, Em, detectors, lasers);

    for (auto i : range(iters)) {
        auto s = random_range(0, ns);
        auto l2 = random_laser();
        auto d2 = random_detectors(l2);
        std::swap(lasers(s), l2);
        detectors.slice(s).swap(d2);
        auto score2 = leica_score(Ex, Em, detectors, lasers);
        if (score2 < score) {
            print(fmt::format("{:.2e}", score2));
            score = score2;
        } else {
            std::swap(lasers(s), l2);
            detectors.slice(s).swap(d2);
        }
    }
    return move_as_tuple(lasers, detectors, score);
}

}