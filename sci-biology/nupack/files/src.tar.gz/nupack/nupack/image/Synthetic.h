#pragma once
#include "../types/Matrix.h"
#include "../math/PDF.h"

namespace nupack::image {

real test_dots();

/******************************************************************************************/

template <class A>
struct ChannelParameters {
    A af;
    real detect, alpha, beta;
};

template <class S, class A>
struct Parameters {
    S sites;
    Mat<real> sigma;
    small_vec<A> af;
    small_vec<real> detect;
    small_vec<real> alpha;
    small_vec<real> beta;
    real truncate;
    uint max_sites = 100;

    NUPACK_REFLECT(Parameters, sites, sigma, af, detect, alpha, beta, truncate, max_sites);

    Parameters(S s, Mat<real> sig, small_vec<real> t, real trunc)
        : sites(std::move(s)), sigma(std::move(sig)), truncate(trunc) {
        NUPACK_REQUIRE(sigma.n_cols, ==, 2);
        NUPACK_REQUIRE(truncate, >, 0);
    }

    std::size_t update_sites_prior(Col<real> &prior_s) const {
        std::size_t s = 1;
        do {
            prior_s.set_size(++s);
            izip(prior_s, [&](auto n_sites, auto &o) {o = sites(n_sites);});
        } while (s <= max_sites && prior_s(s-1) > truncate * arma::accu(prior_s));
        return s;
    }

    Col<real> sites_prior() const {Col<real> s; update_sites_prior(s); return s;}

    bool update(Col<real> const &x) {
        if (any_of(x, is_negative)) return false;
        std::size_t n = 0;
        sites = S(x(n++));
        for (auto i : range(n_channels())) {
            af[i] = A(x(n), x(n+1)); n += 2;
            detect[i] = x(n++);
            alpha[i] = x(n++);
            beta[i] = x(n++);
        }
        NUPACK_REQUIRE(n, ==, len(x));
        if (any_of(detect, [](auto x) {return x > 1;})) return false;
        return true;
    }

    // if c is number of channels,
    // x(0) is the poisson mean
    // next c are AF alphas
    // next c are AF betas
    // next c are detect probs
    // next c are F alphas
    // next c are F betas
    Col<real> flatten() const {
        std::vector<real> x;
        for (auto t : sites.parameters()) x.push_back(t);
        for (auto c : range(n_channels())) {
            for (auto t : af[c].parameters()) x.push_back(t);
            x.push_back(detect[c]);
            x.push_back(alpha[c]);
            x.push_back(beta[c]);
        }
        return x;
    }

    ChannelParameters<A> channel(std::size_t c) const {return {af[c], detect[c], alpha[c], beta[c]};}

    auto n_channels() const {return len(detect);}
    auto n_dimensions() const {return sigma.n_rows;}
};

using DefaultParameters = Parameters<PDF<std::poisson_distribution<uint>>, PDF<std::gamma_distribution<double>>>;

/******************************************************************************************/

struct SyntheticData {
    Col<uint> sites;
    Mat<uint> labels;
    Mat<real> intensities;
    Cube<real> positions;
    NUPACK_REFLECT(SyntheticData, sites, labels, intensities, positions);


    template <class P, class RNG=decltype(StaticRNG)>
    SyntheticData(std::size_t n, P p, RNG &rng=StaticRNG) {
        sites = vmap<Col<uint>>(range(n), [&](auto) {return p.sites.dist(rng);});
        labels.resize(n, p.n_channels());
        izip(p.detect, [&](auto c, auto d) {
            izip(sites, [&](auto i, auto o) {
                labels(i, c) = std::binomial_distribution<uint>(o, d)(rng);
            });
        });
        intensities.resize(n, p.n_channels());
        for (auto c : range(p.n_channels())) {
            izip(labels.col(c), [&](auto i, auto l) {
                if (l == 0) intensities(i, c) = p.af[c].dist(rng);
                else intensities(i, c) = std::gamma_distribution<real>(p.alpha[c] * l, p.beta[c])(rng);
            });
        }
        positions.resize(p.n_channels(), n, p.n_dimensions());
        for (auto d : range(p.n_dimensions())) {
            std::uniform_real_distribution<real> uniform(-p.sigma(d, 0)/2, p.sigma(d, 0)/2);
            std::normal_distribution<real> gaussian(0, p.sigma(d, 1));

            for (auto i : range(n)) {
                auto const mean = uniform(rng);
                for (auto c : range(p.n_channels()))
                    positions(c, i, d) = (labels(i, c) > 0) ? mean + gaussian(rng) : uniform(rng);
            }
        }
    }
    // after this, take all nonzero intensities, put each in a vector
    // then do a distance search to match them together
};

/******************************************************************************************/

arma::umat matching_pairs(Mat<real> const &);

}
