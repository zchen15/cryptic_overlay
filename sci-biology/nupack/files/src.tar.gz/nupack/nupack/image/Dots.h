#pragma once
#include "Synthetic.h"
#include "../reflect/Print.h"
#include "../iteration/Search.h"
#include "../algorithms/Partition.h"
#include "Graph.h"

namespace nupack::image {

/******************************************************************************************/

/// The probability of observing an intensity from a given #sites = 0 in a channel, divided by the probablity of observing 0
template <class O, class V, class AF>
void make_fake_intensity(O &&i0_x, V const &int_x, AF const &af) {
    zip(i0_x, int_x, [&](auto &o, auto intensity) {o = af(intensity);});
    NUPACK_ASSERT(all_of(i0_x, is_finite));
}

/// The probability of observing that intensity from a given #sites > 0 in a channel
template <class O, class V>
void make_real_intensity(O &&i1_xl, V const &int_x, real alpha, real beta) {
    for (auto labels : range(i1_xl.n_cols)) {
        auto dist = PDF<std::gamma_distribution<double>>(alpha, beta * (labels + 1));
        zip(i1_xl.col(labels), int_x, [&](auto &c, auto o) {c = dist(o);});
    }
    NUPACK_ASSERT(all_of(i1_xl, is_finite));
}

/// The probability of seeing 0 labels in a channel given a # real sites starting at 1
template <class O>
void make_fake_label(O &&l0_s, real frac) {
    izip(l0_s, [&](auto s, auto &o) {o = PDF<std::binomial_distribution<uint>>(s+1, frac)(0);});
    NUPACK_ASSERT(all_of(l0_s, is_finite));
}

/// i1_ls(l, s) is probability of seeing l+1 labels given s+1 sites
template <class O>
void make_real_label(O &&i1_ls, real frac) {
    for (auto sites : range(i1_ls.n_cols)) {
        auto const dist = PDF<std::binomial_distribution<uint>>(sites + 1, frac);
        izip(i1_ls.col(sites), [&](auto labels, auto &o) {o = dist(labels + 1);});
    }
    NUPACK_ASSERT(all_of(i1_ls, is_finite));
}

/// The probability of a given #sites+1, given an observed >0 labels
/// Return a matrix of probabilities (location, # sites)
template <class O, class M>
void make_c_plus(O &&c1_xs, M const &i1_xl, M const &l1_ls) {
    c1_xs = i1_xl * l1_ls;
    NUPACK_ASSERT(all_of(c1_xs, is_finite));
}

/******************************************************************************************/

struct ChannelModel {
    // Raw observed data
    Col<real> intensities_x;
    Mat<real> positions_xd;

    Col<real> i0_x;
    Col<real> l0_s;
    Mat<real> i1_xl;
    Mat<real> l1_ls;  // max_labels-1
    Mat<real> c1_xs;  // max_sites-1
    Col<real> lone_x;

    NUPACK_REFLECT(ChannelModel, intensities_x, positions_xd, i0_x, l0_s, i1_xl, l1_ls, c1_xs, lone_x);

    ChannelModel(Col<real> i, Mat<real> p) : intensities_x(std::move(i)), positions_xd(std::move(p)), i0_x(len(intensities_x)) {}

    auto n_points() const {return len(intensities_x);}

    template <class P>
    Col<real> fake_component(P const &p, Col<real> const &intensities, uint i) const {
        Col<real> out(len(intensities));
        make_fake_intensity(out, intensities, p.af[i]);
        return out;
    }

    template <class P>
    Col<real> real_component(P const &p, Col<real> const &intensities, uint i) const {
        Col<real> s = p.sites_prior();
        Mat<real> xl(len(intensities), len(s)), ls(len(s), len(s));
        make_real_intensity(xl, intensities, p.alpha[i], p.beta[i]);
        make_real_label(ls, p.detect[i]);
        return xl * (ls * s);
    }

    template <class P>
    void update(P const &p, std::size_t s) {
        i1_xl.set_size(n_points(), s);
        l0_s.set_size(s);
        l1_ls.set_size(s, s);
        c1_xs.set_size(n_points(), s);

        make_fake_intensity(i0_x, intensities_x, p.af);
        make_real_intensity(i1_xl, intensities_x, p.alpha, p.beta);
        make_fake_label(l0_s, p.detect);
        make_real_label(l1_ls, p.detect);
        make_c_plus(c1_xs, i1_xl, l1_ls);
    }

    void update_lone(Col<real> const &prior_s, Col<real> const &l0) {
        lone_x = i0_x + c1_xs * (prior_s % l0);
    }
};

template <class V>
auto complement_indices(std::size_t n, V const &v2) {
    Col<arma::uword> out(n, arma::fill::zeros);
    constexpr auto sentinel = std::numeric_limits<arma::uword>::max();
    for (auto const &i : v2) out(i) = sentinel;
    izip(out, [](auto i, auto &x) {if (x == 0) x = i;});
    out.resize(std::remove(out.begin(), out.end(), sentinel) - out.begin());
    return out;
}


/******************************************************************************************/

struct Statistics {
    std::size_t count = 0;
    Col<real> edge_counts;
    small_vec<Col<real>> fake_counts;

    NUPACK_REFLECT(Statistics, count, edge_counts, fake_counts);

    void reset() {count = 0;}
};

/******************************************************************************************/

struct Result : Statistics {
    using base_type = Statistics;
    arma::umat edges;
    small_vec<Col<real>> iso_counts;

    NUPACK_EXTEND_REFLECT(Result, base_type, edges, iso_counts);

    Result(Statistics s, arma::umat e, bool avg) : Statistics(std::move(s)), edges(std::move(e)) {
        NUPACK_REQUIRE(edges.n_rows, ==, 2);
        if (!count) return;
        real factor = 1.0 / count;
        edge_counts *= factor; // prob its colocalized
        for (auto &x : fake_counts) x *= factor;

        // get the total probabilities that a node is not colocalized
        iso_counts = fake_counts;
        for (auto &x : iso_counts) x.ones();
        izip(edge_counts, [&](auto i, auto w) {
            iso_counts[0](edges(0, i)) -= w;
            iso_counts[1](edges(1, i)) -= w;
        });

        // set the probabilities that a node is fake, or real but not colocalized
        zip(iso_counts, fake_counts, [](auto &i, auto &f) {f %= i; i -= f;});

        if (!avg) {
            edge_counts *= count;
            for (auto &x : fake_counts) x *= count;
            for (auto &x : iso_counts) x *= count;
        }
    }
};

/******************************************************************************************/

struct Sampler {
    // Per-channel data (related to observed intensities_xc)
    small_vec<ChannelModel> channels;

    Col<real> prior_s; // Prior on number of sites (from 1 to max_sites)
    Statistics stats;
    Col<real> eweights, etotals;
    arma::uvec matching_edges;

    MultipartiteMatcher graph;

    NUPACK_REFLECT(Sampler, prior_s, channels, stats, eweights);

    Sampler(small_vec<ChannelModel> v, Col<real> const &thresh) : channels(std::move(v)),
        graph(vmap(channels, [](auto const &c) -> Mat<real> {return c.positions_xd.t();}), thresh) {
    }

    void update();

    Result result(bool avg) const {return {stats, graph.all_edges.t(), avg};}

    /**************************************************************************************/

    template <class P>
    void update_channels(P const &p) {
        std::size_t const s = p.update_sites_prior(prior_s);
        izip(channels, [&](auto i, auto &c) {c.update(p.channel(i), s);});
        channels[0].update_lone(prior_s, channels[1].l0_s);
        channels[1].update_lone(prior_s, channels[0].l0_s);
    }

    template <class P>
    void calculate_edges(P const &p, uint b, uint c, arma::umat const &pairs) {
        NUPACK_REQUIRE(pairs.n_cols, ==, 2);
        NUPACK_REQUIRE(b, <, p.n_channels());
        NUPACK_REQUIRE(c, <, p.n_channels());
        eweights.set_size(pairs.n_rows);
        eweights.zeros();
        for (auto d : range(p.n_dimensions())) {
            real const scale = -0.5 / (sq(p.sigma(d, 1)) + sq(p.sigma(d, 1)));
            etotals = channels[b].positions_xd.unsafe_col(d)(pairs.col(0));
            etotals -= channels[c].positions_xd.unsafe_col(d)(pairs.col(1));
            eweights += scale * (etotals % etotals);
        }
        real const logscale = accu(arma::log(p.sigma.col(0) / p.sigma.col(1))) - 0.5 * std::log(2 * M_PI) * p.n_dimensions();
        eweights = arma::exp(logscale + eweights);
        eweights %= (channels[b].c1_xs.rows(pairs.col(0)) % channels[c].c1_xs.rows(pairs.col(1))) * prior_s;
        etotals = channels[b].lone_x(pairs.col(0)) % channels[c].lone_x(pairs.col(1));
        etotals += eweights;
    }

    template <class P>
    Col<real> edge_probabilities(P const &p, uint b, uint c) {
        calculate_edges(p, b, c, graph.all_edges);
        return eweights / etotals;
    }

    template <class P>
    real logp(P const &p, uint b, uint c) {
        update_channels(p);
        calculate_edges(p, b, c, graph.all_edges);
        matching_edges = graph.max_matching(eweights / etotals);
        arma::uvec matched;

        auto logp = accu(arma::log(etotals(matching_edges))); // logp of the matchings (include unmatched probabilty)
        for (auto ch : {b, c}) {
            matched = graph.all_edges.unsafe_col(ch)(matching_edges);
            auto const v = complement_indices(channels[ch].n_points(), matched);
            logp += accu(arma::log(channels[ch].lone_x(v))); // logp of the non matchings
        }

        NUPACK_ASSERT(is_finite(logp), logp);
        return logp;
    }

    /**************************************************************************************/

    auto sample(uint iters, real beta, DefaultParameters p, Col<real> const &sd);

    /**************************************************************************************/
};

/******************************************************************************************/

template <class F, class A, class RNG=decltype(StaticRNG) &>
uint rwmh(uint const iters, real beta, Col<real> x0, Col<real> const &sd, F &&fun, A &&act, RNG &&gen=StaticRNG) {
    auto const n = x0.n_rows;
    uint n_success = 0;
    NUPACK_REQUIRE(n, ==, sd.n_rows);
    auto x1 = x0;
    auto dists = vmap(sd.col(0), [](auto const &sd) {return std::normal_distribution<real>(0, sd);});
    auto logp0 = fun(std::as_const(x0));
    for (uint i = 0; i != iters; ++i) {
        for (auto j : indices(x1)) x1(j) += dists[j](gen);
        auto logp1 = fun(std::as_const(x1));
        if (logp1 == logp0 && logp1 == real(minf)) {
            x0 = x1;
        } else if (logp1 >= logp0 || std::exp(beta * (logp1 - logp0)) > random_float(gen)) {
            x0 = x1;
            logp0 = logp1;
            act(std::as_const(x1), std::as_const(i), std::as_const(++n_success), std::move(logp1));
        } else x1 = x0;
    }
    return n_success;
}

/******************************************************************************************/

}
