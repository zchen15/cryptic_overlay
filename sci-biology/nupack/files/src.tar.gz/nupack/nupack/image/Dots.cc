#include "Dots.h"
#include "Leica.h"
#include <boost/geometry.hpp>
#include <boost/geometry/geometries/point.hpp>
#include <boost/geometry/geometries/box.hpp>
#include <boost/geometry/index/rtree.hpp>
#include "../reflect/Dump.h"

namespace nupack::image {

template <std::size_t N, class F, NUPACK_IF(N == 0)>
decltype(auto) switch_index(uint c, F &&f) {return static_cast<F &&>(f)(size_constant<0>());}


template <std::size_t N, class F, NUPACK_IF(N != 0)>
decltype(auto) switch_index(uint c, F &&f) {
    if (c == N) return static_cast<F &&>(f)(size_constant<N>());
    else return switch_index<N-1>(static_cast<F &&>(f));
}

/******************************************************************************************/

template <std::size_t N>
arma::umat matching_pairs_impl(Mat<real> const &m) {
    using Point = boost::geometry::model::point<real, N, boost::geometry::cs::cartesian>;
    // using Box = boost::geometry::model::box<Point>;
    boost::geometry::index::rtree<std::pair<Point, unsigned>, boost::geometry::index::quadratic<16>> rtree;
    for (auto i : range(m.n_cols)) rtree.insert(std::make_pair(Point(m(i, 0), m(i, 1), m(i, 2)), i));
    return {};
}

arma::umat matching_pairs(Mat<real> const &m) {
    return switch_index<0>(m.n_rows - 3, [&] (auto N) {
        return matching_pairs_impl<3 + decltype(N)::value>(m);
    });
}

/******************************************************************************************/

void Sampler::update() {
    if (stats.count == 0) {
        stats.edge_counts.set_size(len(eweights));
        stats.edge_counts.zeros();

        stats.fake_counts.resize(len(channels));
        zip(stats.fake_counts, channels, [](auto &x, auto const &c) {x.set_size(c.n_points()); x.zeros();});
    }

    ++stats.count;
    stats.edge_counts(matching_edges) += eweights(matching_edges) / etotals(matching_edges);

    zip(stats.fake_counts, channels, [](auto &x, auto const &c) {x += c.i0_x / c.lone_x;});

    // else if (total_p < last_logp) {
    //     auto rel = std::exp(total_p - last_logp);
    //     total_p = last_logp + std::log(rel + 1);
    //     // total = (1 / (1 + rel)) * p0 + (rel / (1 + rel)) * total;
    // } else {
    //     auto rel = std::exp(last_logp - total_p);
    //     total_p += std::log(rel + 1);
    //     // total = (1 / (1 + rel)) * total + (rel / (1 + rel)) * p0;
    // }
}

/******************************************************************************************/

auto Sampler::sample(uint iters, real beta, DefaultParameters p, Col<real> const &sd) {
    auto x0 = p.flatten();
    NUPACK_REQUIRE(x0.size(), ==, sd.size());
    Col<real> mu(x0.size(), arma::fill::zeros);
    Mat<real> cov(x0.size(), x0.size(), arma::fill::zeros);
    uint iter = 0;
    uint n = rwmh(iters, beta, std::move(x0), sd, [&](auto const &x) {
        if (!p.update(x)) return real(minf);
        auto out = logp(p, 0, 1);
        print(++iter, out, x.t().eval());
        return std::isnan(out) ? real(minf) : out;
    }, [&](auto const &x, auto const &...) {
        mu += x;
        cov += x * x.t();
        update();
    });
    return std::make_tuple(mu, cov, n);
}

/******************************************************************************************/

template <class S, class A>
void render(Document &doc, Type<Parameters<S, A>> t) {
    doc.type(t, "image.DotParameters");
    doc.method(t, "new", rebind::construct<S, Mat<real>, small_vec<real>, real>(t));
    doc.method(t, "update", &Parameters<S, A>::update);
    doc.method(t, "flatten", &Parameters<S, A>::flatten);
    doc.method(t, "channel", &Parameters<S, A>::channel);
    doc.method(t, "{}", dumpable(t));
    render_public(doc, t);
}

void render(Document &doc, Type<SyntheticData> t) {
    doc.type(t, "image.SyntheticDotData");
    doc.method(t, "new", rebind::construct<std::size_t, DefaultParameters>(t));
    render_public(doc, t);
}

void render(Document &doc, Type<ChannelModel> t) {
    doc.type(t, "image.DotChannelModel");
    doc.method(t, "new", rebind::construct<Col<real>, Mat<real>>(t));
    doc.method(t, "real_component", &ChannelModel::real_component<DefaultParameters>);
    doc.method(t, "fake_component", &ChannelModel::fake_component<DefaultParameters>);
    doc.method(t, "{}", dumpable(t));
    render_public(doc, t);
}

void render(Document &doc, Type<Statistics> t) {
    doc.type(t, "image.DotStatistics");
    doc.method(t, "reset", &Statistics::reset);
    render_public(doc, t);
}

void render(Document &doc, Type<Result> t) {
    doc.render<Statistics>();
    doc.type(t, "image.DotResult");
    render_public(doc, t);
}

void render(Document &doc, Type<Sampler> t) {
    doc.type(t, "image.DotSampler");
    doc.method(t, "new", rebind::construct<small_vec<ChannelModel>, Col<real> const &>(t));
    doc.method(t, "logp", &Sampler::logp<DefaultParameters>);
    doc.method(t, "update", &Sampler::update);
    doc.method(t, "result", &Sampler::result);
    doc.method(t, "sample", &Sampler::sample);
    doc.method(t, "update_channels", &Sampler::update_channels<DefaultParameters>);
    doc.method(t, "edge_probabilities", &Sampler::edge_probabilities<DefaultParameters>);
    render_public(doc, t);
}

/******************************************************************************************/

real test_dots() {
    PDF<std::poisson_distribution<uint>> sites(0.5);
    DefaultParameters p(sites, {{0.5, 0.05}, {0.5, 0.05}, {0.5, 0.05}}, {1e-4, 1e-4}, 1e-6);
    p.af.emplace_back(0.5, 2);
    p.af.emplace_back(0.6, 3);
    p.detect = {0.8, 0.7};
    p.alpha = {2.5, 3.1};
    p.beta = {3, 2};
    // p.threshold.pop_back();
    // p.af.pop_back();
    // p.detect.pop_back();
    // p.alpha.pop_back();
    // p.beta.pop_back();
    // auto data = SyntheticData(50, p);
    // BEEP(data.positions, data.intensities, data.labels);
    Sampler dots1({}, {0.5, 0.5, 0.5});
    // Sampler dots2(data.intensities, data.positions, 1e-10);
    auto o1 = dots1.logp(p, 0, 1);
    // auto o2 = dots2.logp(p);
    // NUPACK_REQUIRE(o1, ==, o2);
    return o1;
}

/******************************************************************************************/

/**
 * @brief
 *
 * @param C if A are the spectra, then A^T A
 * @param alpha multiplicative scaling for subdeterminant orders
 * @param q the order of the subdeterminants considered, but 0 means the full determinant
 * @return real the cost, defined as the negative sum of the log determinants considered
 */
real probe_cost(Mat<real> const &C, real const alpha, uint q) {
    real cost = 0;
    if (q == 0) {
        cost = -arma::log_det(C).real();
    } else {
        for (auto i : range(C.n_cols)) {
            real det = C(i, i);
            cost -= std::log(det);
            // fix alpha below? should not be pow I think
            if (q > 1) for (auto j : range(i + 1, C.n_cols)) {
                real det = C(i, i) * C(j, j) - sq(C(i, j));
                cost -= std::pow(2 * alpha / C.n_cols, 1) * std::log(det);

                if (q > 2) for (auto k : range(j + 1, C.n_cols)) {
                    real det = C(i, i) * C(j, j) * C(k, k) + 2 * C(i, j) * C(j, k) * C(i, k)
                            - sq(C(i, k)) * C(j, j) - sq(C(i, j)) * C(k, k) - sq(C(j, k)) * C(i, i);
                    cost -= std::pow(2 * alpha / C.n_cols, 2) * std::log(det);

                    if (q > 3) for (auto l : range(k + 1, C.n_cols))  {
                        arma::uvec::fixed<4> const idx = {i, j, k, l};
                        Mat<real>::fixed<4, 4> const p4 = C(idx, idx);
                        cost -= std::pow(2 * alpha / C.n_cols, 3) * std::log(arma::det(p4));
                    }
                }
            }
        }
    }
    NUPACK_ASSERT(!std::isnan(cost));
    return cost;
}

std::pair<arma::uvec, real> optimize_probes(Mat<real> const &A, uint n, uint q, real alpha, uint keep, std::size_t t) {
    BEEP(n, q, alpha, keep, t);
    arma::uvec x(n), y;
    std::iota(x.begin(), x.end(), 0);
    std::uniform_int_distribution<uint> index_dist(keep, n-1), probe_dist(0, A.n_cols-1);
    Mat<real> C = A.cols(x).t() * A.cols(x);
    real cost = probe_cost(C, alpha, q);
    for (auto t : range(t)) {
        auto const i = index_dist(StaticRNG), p = probe_dist(StaticRNG);
        if (x(i) == p) continue;
        y = x;
        y(i) = p;
        std::sort(y.begin(), y.end());
        if (std::adjacent_find(y.begin(), y.end()) != y.end()) continue;
        C = A.cols(y).t() * A.cols(y);
        real cost2 = probe_cost(C, alpha, q);
        if (cost2 < cost) {cost = cost2; x.swap(y);}
    }
    return {std::move(x), cost};
}

/******************************************************************************************/

}

/******************************************************************************************/

namespace nupack {
void render_image(Document &doc) {
    doc.function("image.test_dots", image::test_dots);
    doc.function("image.optimize_leica", image::optimize_leica);
    doc.render(Type<image::Sampler>());
    doc.render(Type<image::SyntheticData>());
    doc.function("image.optimize_probes", image::optimize_probes);
}
}

/******************************************************************************************/
