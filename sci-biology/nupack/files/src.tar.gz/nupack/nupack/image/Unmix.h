#pragma once
#include "../math/BoundSolve.h"
#include "../types/Matrix.h"

namespace nupack::image {
using rebind::Pack;

/******************************************************************************************/

template <class T>
struct SpectrumOptimizer {
    // Constants
    Col<T> k_l; // sigma^-2 in each wavelength
    Mat<T> R_l_f; // spectra
    Mat<T> S_l_e; // S: laser power at each wavelength

    // Primary variables
    SpMat<T> C_f_c; // C: fluorophore coefficient in each system
    Mat<T> G_f_e; // Gamma: laser coefficient of given fluorophore

    la::umat indices_fc;

    // Unmixing of last scanned image
    Mat<T> X_c_r, X_f_r, I_l_r;
    Col<T> w_r, norm2_r;

    // Stuff for solving X
    Mat<T> A_l_f, AkA_f_f, AkA_c_c, AkB_f_r, AkB_c_r;

    // Stuff for solving G
    Mat<T> A_fe_fe, A_f_f, B_f_e, S_l_fe;

    // Stuff for solving C
    Mat<T> A_fc_fc, Z_l_f, Z_f_f, A_c_c, B_c_f;
    Col<T> B_fc, residual_f_r, residual_c_r;

    SpectrumOptimizer(Col<T> sigma, Mat<T> R, Mat<T> S, Mat<T> G, Mat<T> const &C, la::umat idx) :
        G_f_e(std::move(G)), C_f_c(C), R_l_f(std::move(R)), S_l_e(std::move(S)), k_l(la::pow(sigma, -2)), indices_fc(std::move(idx)),
        B_fc(indices_fc.n_cols), A_fc_fc(indices_fc.n_cols, indices_fc.n_cols) {
            NUPACK_REQUIRE(indices_fc.n_rows, ==, 2);
            NUPACK_ALL_EQUAL("inconsistent # fluorophores", G_f_e.n_rows, C_f_c.n_rows, R_l_f.n_cols);
            NUPACK_ALL_EQUAL("inconsistent # wavelengths", k_l.n_rows, S_l_e.n_rows, R_l_f.n_rows);
            NUPACK_ALL_EQUAL("inconsistent # lasers", G_f_e.n_cols, S_l_e.n_cols);
            NUPACK_REQUIRE(indices_fc.row(0).max(), <, nf(), "fluorophore indices out of bounds");
            NUPACK_REQUIRE(indices_fc.row(1).max(), <, nc(), "coefficient indices out of bounds");
            reset_scans();
        }

    NUPACK_REFLECT(SpectrumOptimizer, X_f_r, X_c_r, G_f_e, C_f_c, S_l_fe, k_l,
                   R_l_f, indices_fc, residual_f_r, residual_c_r);

    auto nc() const {return C_f_c.n_cols;}
    auto nf() const {return G_f_e.n_rows;}
    auto ne() const {return G_f_e.n_cols;}
    auto nl() const {return R_l_f.n_rows;}

    template <class A, class ...Ts>
    static void reset(A &a, Ts ...ts) {a.set_size(ts...); a.zeros();}

    Mat<T> coefficients() const {return static_cast<Mat<T>>(C_f_c);}
    void set_coefficients(Mat<T> const &m) {C_f_c = m;}

    template <class F>
    using Options = std::pair<F, AlternatingOptions>;

    // reset accumulators for a new batch of images
    void reset_scans() {
        // accumulators for solving C
        reset(A_c_c, nc(), nc());
        reset(B_c_f, nc(), nf());
        // accumulators for solving gamma
        reset(A_f_f, nf(), nf());
        reset(B_f_e, nf(), ne());
    }

    template <class T2>
    T scan_image(Mat<T2> const &I_l_r2, T exponent) {
        I_l_r = la::conv_to<Mat<T>>::from(I_l_r2);
        if (exponent == 1) w_r = la::sum(I_l_r, 0).t();
        else w_r = la::sum(la::pow(I_l_r, exponent), 0).t();
        w_r *= w_r.n_rows / la::accu(w_r);
        norm2_r = (k_l.t() * (I_l_r % I_l_r)).t();
        T out = la::dot(norm2_r, w_r);
        // Clear each unmixing X since now looking at a new image
        X_f_r.set_size(nf(), I_l_r.n_cols); X_f_r.zeros();
        X_c_r.set_size(nc(), I_l_r.n_cols); X_c_r.zeros();
        return out;
    }

    Mat<T> spectrum(bool coefficients=false) const {
        print_lns("C", Mat<T>(C_f_c));
        if (coefficients) return ((S_l_e * G_f_e.t()) % R_l_f) * C_f_c;
        else return (S_l_e * G_f_e.t()) % R_l_f;
    }

    // (k_l, I_l_r, A_l_f, G_f_e, AkA_f_f) -> (X_f_r, A_f_f, B_f_e):
    // uses whatever the previous value of X was as the initial guess
    template <class B>
    AlternatingResult<T> unmix_gamma(Options<B> const &ops, bool increment) {
        A_l_f = (S_l_e * G_f_e.t()) % R_l_f;
        AkA_f_f = A_l_f.t() * diagmat(k_l) * A_l_f;
        AkB_f_r = A_l_f.t() * diagmat(k_l) * I_l_r;

        residual_f_r = norm2_r;
        auto out = bound_solve(X_f_r, AkA_f_f, AkB_f_r, ops.first, ops.second, &residual_f_r);
        out.objective = la::dot(residual_f_r, w_r);
        // accumulate G things
        switch_c(increment, [&](auto inc) {
            auto set = if_c(inc, plus_eq, assign_eq);
            set(A_f_f, X_f_r * diagmat(w_r) * X_f_r.t());
            set(B_f_e, (R_l_f.t() % (X_f_r * diagmat(w_r) * I_l_r.t())) * diagmat(k_l) * S_l_e);
        });
        return out;
    }

    // (k_l, R_l_f, S_l_e, B_f_e, A_f_f) -> (G_f_e, A_l_f, AkA_f_f)
    // uses whatever the previous value of G was as the initial guess
    template <class B>
    AlternatingResult<T> solve_gamma(Options<B> const &ops, bool normalize=false) {
        // column major raveling
        auto at = [n=nf()](auto f, auto e) {return f + e * n;};

        S_l_fe.set_size(nl(), ne() * nf());
        for (auto e: range(ne())) for (auto f: range(nf()))
            S_l_fe.col(at(f, e)) = S_l_e.col(e) % R_l_f.col(f);
        A_fe_fe = S_l_fe.t() * diagmat(k_l) * S_l_fe;

        for (auto e1: range(ne())) for (auto e2: range(ne()))
            for (auto f1: range(nf())) for (auto f2: range(nf()))
                A_fe_fe(at(f1, e1), at(f2, e2)) *= A_f_f(f1, f2);

        auto G_fe = la::raveled(G_f_e), B_fe = la::raveled(B_f_e);

        auto err = bound_solve(G_fe, A_fe_fe, B_fe, ops.first, ops.second);

        if (normalize) for (auto f : range(nf())) {
            T total = la::accu(G_f_e.row(f));
            if (total) G_f_e.row(f) *= nf() / total;
            else G_f_e.row(f).ones();
        }
        return err;
    }

    template <class B>
    AlternatingResult<T> joint_gamma_update(std::size_t iters, Options<B> const &x_ops, Options<B> const &g_ops, bool normalize=false) {
        NUPACK_ASSERT(!g_ops.second.warm_start);
        NUPACK_ASSERT(!x_ops.second.warm_start);

        AlternatingResult<T> out;
        for (auto i : range(iters)) {
            throw_if_signal();
            out = unmix_gamma(x_ops, false);
            auto p = solve_gamma(g_ops, normalize);
            print_lns("X error", out, "G error", p, "G", G_f_e);
            if (p.unconverged == 0) break;
        }
        return out;
    }

    template <class B>
    AlternatingResult<T> joint_coefficient_update(std::size_t iters, Options<B> const &x_ops, Options<B> const &c_ops, bool normalize=false) {
        NUPACK_ASSERT(!c_ops.second.warm_start);
        NUPACK_ASSERT(!x_ops.second.warm_start);

        AlternatingResult<T> out;
        for (auto i : range(iters)) {
            throw_if_signal();
            out = unmix_coefficients(x_ops, false); // solve for X_c
            auto p = solve_coefficients(c_ops, normalize); // solve for C
            print_lns("X error", out, "C error", p, "C", C_f_c);
            if (p.unconverged == 0) break;
        }
        return out;
    }

    // (C_f_c, AkA_f_f, AkB_f_r, G_f_e) -> (X_c_r, A_c_c, B_c_f)
    template <class B>
    AlternatingResult<T> unmix_coefficients(Options<B> const &ops, bool increment) {
        print(increment, C_f_c);
        // solve for components
        AkA_c_c = C_f_c.t() * AkA_f_f * C_f_c;
        AkB_c_r = C_f_c.t() * AkB_f_r;
        residual_c_r = norm2_r;
        auto res = bound_solve(X_c_r, AkA_c_c, AkB_c_r, ops.first, ops.second, &residual_c_r);
        res.objective = la::dot(residual_c_r, w_r);

        // accumulate C things
        switch_c(increment, [&](auto inc) {
            auto set = if_c(inc, plus_eq, assign_eq);
            set(A_c_c, X_c_r * diagmat(w_r) * X_c_r.t());
            set(B_c_f, (X_c_r * diagmat(w_r) * I_l_r.t())/*c l*/ * diagmat(k_l) * ((S_l_e * G_f_e.t()) % R_l_f)); /*l f*/
        });

        return res;
    }

    // (G_f_e, A_c_c, B_c_f) -> C_f_c
    template <class B>
    AlternatingResult<T> solve_coefficients(Options<B> const &ops, bool normalize=false) {
        Z_l_f = R_l_f % (S_l_e * G_f_e.t());
        Z_f_f = Z_l_f.t() * diagmat(k_l) * Z_l_f;
        // here, fix so B_c_f of elements not in indices_fc is included
        la::sparse_map(indices_fc, [&](auto i, auto f, auto c) {B_fc(i) = B_c_f(c, f);});
        la::sparse_map(indices_fc, [&](auto i, auto f1, auto c1) {
            la::sparse_map(indices_fc, [&](auto j, auto f2, auto c2) {
                A_fc_fc(i, j) = A_c_c(c1, c2) * Z_f_f(f1, f2);
            });
        });

        Col<T> C_fc(indices_fc.n_cols);
        la::sparse_map(indices_fc, C_f_c, [&](auto i, auto const &c) {C_fc(i) = c;});

        auto err = bound_solve(C_fc, A_fc_fc, B_fc, ops.first, ops.second);
        la::sparse_map(indices_fc, C_f_c, [&](auto i, auto &&c) {c = C_fc(i);});
        C_f_c.sync();

        if (normalize) {
            Col<T> sums(la::sum(C_f_c, 0).t());
            for (auto it = C_f_c.begin(); it != C_f_c.end(); ++it) {
                if (sums(it.col()) > 0) *it /= sums(it.col());
                else *it = 1;
            }
        }
        return err;
    }
};

/******************************************************************************************/


template <class T>
void render(Document &doc, Type<SpectrumOptimizer<T>> t) {
    using S = SpectrumOptimizer<T>;
    doc.type(t, "image.SpectrumOptimizer");
    render_public(doc, t);

    Pack<std::uint16_t, T>::for_each([&](auto u) {
        doc.method(t, "scan_image", &S::template scan_image<decltype(*u)>);
    });

    Pack<ScalarBound>::for_each([&](auto B) {
        doc.method(t, "new", rebind::construct<Col<T>, Mat<T>, Mat<T>, Mat<T>, Mat<T> const &, la::umat>(t));
        doc.method(t, "reset_scans", &S::reset_scans);
        doc.method(t, "spectrum", &S::spectrum);
        doc.method(t, "coefficients", &S::coefficients);
        doc.method(t, "set_coefficients", &S::set_coefficients);

        doc.method(t, "unmix_gamma", &S::template unmix_gamma<decltype(*B)>);
        doc.method(t, "unmix_coefficients", &S::template unmix_coefficients<decltype(*B)>);
        doc.method(t, "joint_gamma_update", &S::template joint_gamma_update<decltype(*B)>);
        doc.method(t, "joint_coefficient_update", &S::template joint_coefficient_update<decltype(*B)>);
        doc.method(t, "solve_gamma", &S::template solve_gamma<decltype(*B)>);
        doc.method(t, "solve_coefficients", &S::template solve_coefficients<decltype(*B)>);
    });
}

/******************************************************************************************/

}
