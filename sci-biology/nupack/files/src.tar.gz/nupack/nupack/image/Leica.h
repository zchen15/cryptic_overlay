#pragma once
#include "../types/Matrix.h"
#include "../common/Random.h"

namespace nupack::image {

inline uint random_interval(uint min, uint max) {return std::round(min + (max - min) * random_float());}

// Ex, Em: l x f, the spectra of the fluorophores
// D: 2 x 3 x f: the start and end indices of the 3 detectors for each sequence
// L: the excitation for each sequence
real leica_score(Mat<real> const &Ex, Mat<real> const &Em, Cube<uint> const &D, Col<uint> const &lasers);

// return laser wavelength
uint random_laser();

typename Mat<uint>::fixed<2, 3> random_detectors(uint laser);

std::tuple<Col<uint>, Cube<uint>, real> optimize_leica(Mat<real> const &Ex, Mat<real> const &Em, uint ns, uint iters);


}