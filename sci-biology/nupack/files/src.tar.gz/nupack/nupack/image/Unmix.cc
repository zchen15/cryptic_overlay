#include "Unmix.h"
#include "Analysis.h"

namespace nupack {
    void render_unmix(Document &doc) {
        doc.function("image.shift_image", [](Cube<std::uint16_t> &m, image::ImageShift x, real y, real z) {image::shift_image(m, x, y, z);});
        doc.function("image.discrete_histogram", &image::discrete_histogram<std::uint8_t>);
        doc.function("image.discrete_histogram", &image::discrete_histogram<std::uint16_t>);
        doc.render(Type<image::SpectrumOptimizer<double>>());
        doc.render(Type<image::ImageAnalyzer<std::uint16_t, float>>());
        doc.render(Type<image::ImageAnalyzer<std::uint16_t, double>>());
        doc.render(Type<image::ImageAnalyzer<float, double>>());
        doc.render(Type<image::ImageAnalyzer<double, double>>());
        doc.render(Type<image::ImageAnalyzer<double, float>>());
    }
}
