#pragma once
#include "../types/Matrix.h"

namespace nupack::image {

/******************************************************************************************/

// Cube<T> I_l_xy_z;
template <class I, class T>
struct ImageAnalyzer {
    Cube<T> rgb_c_r_z; // color transform
    Mat<T> rgb_l_c; // input color transform weights
    Mat<I> max_l_r; // z projection
    Mat<T> sum_l_r; // norm2 over wavelength
    Mat<T> norm2_r_z; // norm2 over wavelength
    Mat<T> mean_l_z; // mean over x, y
    Mat<T> cov_l_l; // spectrum covariance
    Col<T> score_l, score_r;
    std::vector<std::pair<Col<I>, T>> sample_l_r;
    T norm2 = 0;
    usize capacity;

    NUPACK_REFLECT(ImageAnalyzer, sum_l_r, max_l_r, mean_l_z, rgb_l_c, rgb_c_r_z, norm2_r_z, cov_l_l, norm2, score_l, score_r);

    ImageAnalyzer(usize n, usize l, usize r, usize z, Col<T> score, Mat<T> rgba={}) :
        norm2_r_z(r, z), cov_l_l(l, l, la::fill::zeros), rgb_c_r_z(rgba.n_cols, r, z), rgb_l_c(std::move(rgba)),
        sum_l_r(l, r, la::fill::zeros), mean_l_z(l, z), capacity(n), score_r(r), score_l(std::move(score)), max_l_r(l, r) {score_r.fill(real(*minf));}

    std::pair<Mat<I>, Col<T>> samples() const {
        Mat<I> m(cov_l_l.n_rows, sample_l_r.size());
        Col<T> c(sample_l_r.size());
        for (auto i : range(sample_l_r.size())) c(i) = sample_l_r[i].second;
        la::uvec order = la::sort_index(c, "descend");
        izip(order, [&](auto i, auto j) {m.col(i) = sample_l_r[j].first;});
        c = c(order);
        return {std::move(m), std::move(c)};
    }

    void add(usize z, Mat<I> const &I_l_r) {
        Mat<T> T_l_r = la::conv_to<Mat<T>>::from(I_l_r);
        sum_l_r += T_l_r;
        if (rgb_l_c.n_cols) rgb_c_r_z.slice(z) = rgb_l_c.t() * T_l_r;

        mean_l_z.col(z) = la::mean(T_l_r, 1);
        norm2_r_z.col(z) = la::sum(T_l_r % T_l_r, 0).t();
        norm2 += la::accu(norm2_r_z.col(z));
        cov_l_l += T_l_r * T_l_r.t();

        auto comp = [](auto const &p, auto const &q) {return p.second > q.second;};

        // keep track of the <capacity> points with the largest norm in l
        sample_l_r.reserve(capacity);
        for (auto r : range(I_l_r.n_cols)) {
            // auto const score = norm2_r_z(r, z);
            auto const score = la::dot(T_l_r.col(r), score_l);
            if (score > score_r(r)) {
                max_l_r.col(r) = I_l_r.col(r);
                score_r(r) = score;
            }
            // instead of this, maybe do v @ cov^-1 @ v ?

            if (sample_l_r.size() < capacity) {
                sample_l_r.emplace_back(I_l_r.col(r), score);
            } else {
                std::pop_heap(sample_l_r.begin(), sample_l_r.end(), comp);
                if (score > sample_l_r.back().second) {
                    sample_l_r.back().first = I_l_r.col(r);
                    sample_l_r.back().second = score;
                }
            }
            std::push_heap(sample_l_r.begin(), sample_l_r.end(), comp);
        }
    }
};

/******************************************************************************************/

template <class I, class T>
void render(Document &doc, Type<ImageAnalyzer<I, T>> t) {
    doc.type(t, "image.ImageAnalyzer", std::make_pair(rebind::type_index<I>(), rebind::type_index<T>()));
    render_public(doc, t);
    doc.method(t, "new", rebind::construct<usize, usize, usize, usize, Col<T>, Mat<T>>(t));
    doc.method(t, "add", &ImageAnalyzer<I, T>::add);
    doc.method(t, "samples", &ImageAnalyzer<I, T>::samples);
}

/******************************************************************************************/

template <class T>
la::uvec discrete_histogram(Col<T> const &t, usize n=0) {
    if (n == 0) n = usize(std::numeric_limits<std::uint16_t>::max()) + 1;
    la::uvec out(n, la::fill::zeros);
    for (auto const &i : t) ++out[i];
    return out;
}

/******************************************************************************************/

/// Linear interpolation in 1D
template <class B, class E, class T=double>
void zero_shift_right(B b, E const end, T const shift) {
    NUPACK_REQUIRE(shift, >=, 0);
    static_assert(!std::is_integral_v<T>);
    auto const begin = b;
    T f_hi = (shift - std::floor(shift)), f_lo = 1 - f_hi;

    if (f_hi > f_lo) {f_hi = 1; f_lo = 0;}
    else {f_hi = 0; f_lo = 1;}

    auto lo = std::next(b, std::floor(shift));

    if (auto hi = std::next(lo); hi < end)
        for (; hi != end; ++b, ++lo, ++hi) {*b = f_hi * (*hi) + f_lo * (*lo);}

    if (lo < end) *b = f_lo * (*lo); ++b;

    if (b < end) {
        if constexpr(!std::is_class_v<std::decay_t<decltype(*b)>>) std::fill(b, end, 0);
        else for (; b != end; ++b) (*b).zeros();
    }
}

/// Linear interpolation in 1D
template <class B, class E, class T=double>
void zero_shift(B b, E const end, T const shift) {
    if (shift < 0) zero_shift_right(b, end, -shift);
    else if (shift > 0) zero_shift_right(std::next(reverse_iter(end)), std::next(reverse_iter(b)), shift);
}

/******************************************************************************************/

using ImageShift = std::tuple<real, int, int>;

// use pointer because armadillo is dumb and doesn't have bidirectional iterators
// use len because armadillo doesn't do size() right either
template <class M>
void shift_image(M &&m, ImageShift x) {
    if (std::get<1>(x) < std::get<2>(x)) {
        auto ptr = std::addressof(m(0));
        zero_shift(ptr + std::get<1>(x), ptr + std::get<2>(x), -std::get<0>(x));
    }
}

// shift in x, then y
template <class M>
void shift_image(M &&m, ImageShift x, real y) {
    if (std::get<0>(x)) for (auto i : range<int>(m.n_cols)) shift_image(m.col(i), x);
    auto v = indirect_view(range<int>(m.n_cols), [&](auto i) {
        return m.col(i).subvec(std::get<1>(x), std::get<2>(x)-1);
    });
    zero_shift(std::begin(v), std::end(v), -y);
}

// shift in x, then y, then z
template <class M>
void shift_image(M &&m, ImageShift x, real y, real z) {
    if (std::get<0>(x) || y) for (auto i : range<int>(m.n_slices)) shift_image(m.slice(i), x, y);
    auto v = indirect_view(range<int>(m.n_slices), [&](auto i) {
        return m.slice(i).rows(std::get<1>(x), std::get<2>(x)-1);
    });
    zero_shift(std::begin(v), std::end(v), -z);
}

// shift_image(T *t, ArrayLayout p, vec<ImageShift> &x) {
//     ImageShift s = x.back();
//     x.pop_back();
//     stride = p.strides(i);
//     for
// }

// shift_image(ArrayView v, vec<ImageShift> x) {
//     auto p = v.data.target<std::uint16_t>();

// }


/******************************************************************************************/

inline decltype(auto) split_rgba(std::uint32_t &r) {return reinterpret_cast<std::array<std::uint8_t, 4> &>(r);}
inline auto merge_rgba(std::array<std::uint8_t, 4> const &r) {return reinterpret_cast<std::uint32_t const &>(r);}

}
