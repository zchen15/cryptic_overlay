#pragma once
#include "../types/Matrix.h"

#define NUPACK_LEMON __has_include(<lemon/core.h>)
#if NUPACK_LEMON
#   include "BipartiteMatching.h"
#   include <lemon/core.h>
#endif

#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/connected_components.hpp>
#include <boost/graph/push_relabel_max_flow.hpp>
#include <boost/graph/graphviz.hpp>

#include <optional>

namespace nupack::image {

/******************************************************************************************/

template <class T>
struct BipartiteGraph {
#if NUPACK_LEMON
    using EdgeMap = lemon::SmartBpGraph::EdgeMap<T>;
    lemon::SmartBpGraph graph;
    std::optional<EdgeMap> weights;
#endif

    BipartiteGraph() = default;
    BipartiteGraph(BipartiteGraph &&o) = delete;
    BipartiteGraph(BipartiteGraph const &o) = delete;
    BipartiteGraph &operator=(BipartiteGraph const &o) = delete;
    BipartiteGraph &operator=(BipartiteGraph &&o) = delete;
};

/******************************************************************************************/

struct GraphMatching {
#if NUPACK_LEMON
    vec<lemon::SmartBpGraph::Node> nodes;
    vec<lemon::SmartBpGraph::Edge> edges;
#endif
    vec<BipartiteGraph<real>> graphs;
    small_vec<uint> sizes;
    vec<uint> vertex_labels, edge_labels;

    GraphMatching(uint nsub, uint nedges, uint m, vec<uint> vlabels);
    GraphMatching(GraphMatching &&) = delete;
    GraphMatching(GraphMatching const &) = delete;

    void set_weight(uint);
    void add_edge(uint m, uint n);
    void initialize_weights();

    /// return mask of whether each edge appears in the maximum matching
    small_vec<bool> max_matching() const;
};

/******************************************************************************************/

struct MultipartiteGraph {
    void initialize();

public:
    using Graph = boost::adjacency_list<boost::vecS, boost::vecS, boost::undirectedS>;

    Graph all_vertices;
    arma::umat all_edges;
    small_vec<uint> prefixes;

    NUPACK_REFLECT(MultipartiteGraph, all_edges);

    template <class F>
    void for_each_edge(F &&f) {
        for (auto p = boost::edges(all_vertices); p.first != p.second; ++p.first) {
            auto s = boost::source(*p.first, all_vertices);
            auto t = boost::target(*p.first, all_vertices);
            (s < t) ? f(s, t) : f(t, s);
        }
    }

    // MultipartiteGraph(arma::umat edges) : all_edges(edges)

    template <class V>
    explicit MultipartiteGraph(V const &positions_cdx, Col<real> const &threshold_d) : prefixes(1, 0) {
        for (auto const &p : positions_cdx) prefixes.emplace_back(prefixes.back() + p.n_cols);
        for (auto q = begin_of(positions_cdx); q != end_of(positions_cdx); ++q) {
            auto const q0 = prefixes[q - begin_of(positions_cdx)];
            for (auto p = begin_of(positions_cdx); p != q; ++p) {
                auto const p0 = prefixes[p - begin_of(positions_cdx)];
                for (auto i : range(p->n_cols)) for (auto j : range(q->n_cols))
                    if (arma::all(arma::abs(p->col(i) - q->col(j)) < threshold_d))
                        add_edge(p0 + i, q0 + j, all_vertices);
            }
        }
        initialize();
    }
};

/******************************************************************************************/

struct MultipartiteMatcher : MultipartiteGraph {
    std::unique_ptr<GraphMatching> matching;

    MultipartiteMatcher(MultipartiteMatcher &&) = default;
    MultipartiteMatcher(MultipartiteMatcher const &g) : MultipartiteMatcher(true, g) {}
    MultipartiteMatcher &operator=(MultipartiteMatcher &&) = default;
    MultipartiteMatcher &operator=(MultipartiteMatcher const &g) {return *this = MultipartiteMatcher(true, g);}

    MultipartiteMatcher(bool, MultipartiteGraph g) : MultipartiteGraph(std::move(g)) {
        vec<uint> labels;
        labels.resize(boost::num_vertices(all_vertices));
        auto const nsub = boost::connected_components(all_vertices, labels.data());
        matching = std::make_unique<GraphMatching>(nsub, boost::num_edges(all_vertices), prefixes[1], std::move(labels));
        for_each_edge([&](auto s, auto t) {matching->add_edge(s, t);});
        matching->initialize_weights();
    }

    // V: a list of points as a matrix (D, N) in each channel
    // t: a column of thresholds in each dimension
    template <class V>
    explicit MultipartiteMatcher(V const &positions_cdx, Col<real> const &threshold_d)
        : MultipartiteMatcher(true, MultipartiteGraph(positions_cdx, threshold_d)) {}

    /// given all of the edge weights in the graph
    /// return the indices of which of them appear in the maximum matching
    arma::uvec max_matching(Col<real> const &weights);
};

/******************************************************************************************/

}

