/**
 * @brief Equilibrium toolkit functionality
 *
 * @file Equilibrate.h
 * @author Mark Fornace
 * @date 2018-05-31
 */
#pragma once
#include "../types/Matrix.h"

namespace nupack::concentration {

enum class Init : uint {uniform=0, given=1, absls=2, nnls=3};

struct Options {
    usize max_iters = 1e4;
    real tolerance = 1.e-8;
    real delta_min = 1.e-12;
    real delta_max = 1000.0;
    bool orthogonalize = true; //< takes care of cases where # strands > # complexes
    Init init = Init::uniform; //< usually the non-uniform init is better
    NUPACK_REFLECT(Options, max_iters, tolerance, delta_min, delta_max, init, orthogonalize);
};

void render(Document &doc, Type<Options> t);

template <class V>
struct Output {
    V solution, dual_solution;
    real objective, max_rel_grad;
    usize iters;
    bool converged;
    NUPACK_REFLECT(Output, solution, dual_solution, objective, max_rel_grad, iters, converged);
};

template <class V>
void render(Document &doc, Type<Output<V>> t) {
    doc.type(t, "concentration.Output");
    render_public(doc, t);
}

/**
 * @brief Solve equilibrium concentrations
 * @param A Coefficient matrix (complexes, strands)
 * @param x0 initial concentrations
 * @param q log partition functions
 * @param ops solving options
 * @return V equilibrated concentrations
 */
template <class M, class V>
Output<V> equilibrate(M A, V x0, V const &logq, Options const &ops={});

/**
 * @brief Solve equilibrium concentrations for complexes
 * indices: list of ordered indices of strands
 * logq: list of log partition functions (distinguishable)
 * x0: strand concentrations
 */
Output<Col<real>> solve_complexes(vec<small_vec<uint>> const &indices, Col<real> logq, Col<real> x0, Options const &ops, bool rotational_correction=true);

extern template Output<Col<double>> equilibrate(Mat<double>, Col<double>, Col<double> const &, Options const &);
extern template Output<Col<float>> equilibrate(Mat<float>, Col<float>, Col<float> const &, Options const &);

rebind::Variable response(std::type_index, Options const &o);
std::optional<Options> request(Type<Options>, rebind::Variable const &, rebind::Dispatch &msg);

}
