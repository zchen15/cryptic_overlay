/**
 * @brief Equilibrium toolkit algorithms - usually it will suffice to include Equilibrate.h
 *
 * @file Concentration.h
 * @author Mark Fornace
 * @date 2018-05-31
 */
#pragma once
#include "Equilibrate.h"
#include "../math/BoundSolve.h"
#include "../iteration/Search.h"
#include <spdlog/spdlog.h>
#include <spdlog/fmt/ostr.h>

namespace nupack::concentration {

/******************************************************************************************/

/// Using linear solver, gradient, Hessian, delta, and minimum delta return the dogleg direction to go to
template <class V, class M, class T>
V find_direction(V const &grad, M const &Hess, T const delta, T min_delta) {
    // Probably could optimize the order of Newton, Cauchy evaluations below
    NUPACK_ASSERT(grad.is_finite(), delta, min_delta, grad);
    NUPACK_ASSERT(Hess.is_finite(), delta, min_delta, grad, Hess);
    // Calculate Newton step with a SPD, singular accepting solver
    V newt = -grad;
    bool const newton = la::solve(newt, Hess, newt,
#if (ARMA_VERSION_MAJOR >= 9) && (ARMA_VERSION_MINOR >= 500)
        la::solve_opts::fast + la::solve_opts::allow_ugly + la::solve_opts::likely_sympd
#else
#       warning "Armadillo 9.500 or newer is recommended."
        la::solve_opts::fast + la::solve_opts::allow_ugly
#endif
    );
    T const newt_norm = norm(newt);

    // Take Newton if we are inside the minimum trust region
    if (newton && newt_norm > 0 && (delta < min_delta || newt_norm < delta))
        return newt;

    // Calculate Cauchy step
    V cauchy = grad / norm(grad);
    cauchy = grad * (-1 / dot(cauchy, Hess * cauchy));
    T const cauchy_norm = norm(cauchy);

    // Take Cauchy if Newton failed or we are outside the trust region
    if (!newton || newt_norm == 0 || !std::isfinite(sq(newt_norm)) || cauchy_norm > delta)
        return sqrt(delta / cauchy_norm) * cauchy;

    // Dogleg - take this if we are in intermediate region
    T const newt_cauchy = dot(newt, cauchy);

    auto q = quadratic_solve<T>(sq(newt_norm) + sq(cauchy_norm) - 2 * newt_cauchy,
                                2 * (newt_cauchy - sq(cauchy_norm)),
                                sq(cauchy_norm) - sq(delta));

    auto beta = std::min(q.first, q.second, less_abs); // choose correct root for mixing coefficient
    NUPACK_REQUIRE(abs(beta), <=, 1, beta, newt_norm, cauchy_norm, newt_cauchy);

    if (beta < 0) return (beta + 1) * cauchy;
    else return (1 - beta) * cauchy + beta * newt;
}

/******************************************************************************************/

template <class V, class P, class O>
struct DualSystem {
    using gradient = V;
    using hessian = Mat<value_type_of<V>>;

    template <class V_, class P_, class O_>
    DualSystem(V_ &&v, P_ &&p, O_ &&o) : dual(fw<V_>(v)), to_primal(fw<P_>(p)), objective_function(fw<O_>(o)) {
        to_primal(primal, dual);
        objective = objective_function(primal, dual);
    }

    V primal, dual;
    real objective;

    P to_primal; // (primal, dual) -> primal
    O objective_function;  // (primal, dual) -> float

    NUPACK_REFLECT(DualSystem, primal, dual, objective, to_primal, objective_function);

    // Take another system and set self to its dual value plus a shift
    template <class T> void update(DualSystem const &s, T &&shift) {
        dual = s.dual + fw<T>(shift);
        to_primal(primal, dual);
        objective = objective_function(primal, dual);
    }

    void swap(DualSystem &x) {
        swap_all(std::tie(primal, dual, objective), std::tie(x.primal, x.dual, x.objective));
    }
};

template <class ...Ts> auto dual_system(Ts &&...ts) {return DualSystem<decay<Ts>...>(fw<Ts>(ts)...);}

/******************************************************************************************/

/// Converge a system using a trust-region method
/// Provide initial system and delta, functions to compute gradient, offset, direction, convergence, and radius adjustment
template <class Sys, class G, class H, class D, class C, class A>
Sys trust_region(Sys s, G &&gradient, H &&hessian, D &&direction, C &&condition, A &&adjust_delta, real delta) {
    auto s2 = s;
    typename Sys::gradient grad, p;
    typename Sys::hessian Hess;
    for (std::size_t iter = 0; true; ++iter) {
        throw_if_signal();
        gradient(grad, s);
        hessian(Hess, s);
        if (condition(s, grad, Hess)) break;
        p = direction(grad, Hess, delta);
        s2.update(s, p);

        // rho measures actual improvement divided by expected improvement (if exact, = 1)
        auto const expected = dot(grad, p) - dot(p, Hess * p) / 2; // should almost always be < 0
        auto const rho = (s2.objective - s.objective) / expected; // better for rho to be >0

        NUPACK_ASSERT(!std::isnan(rho) && std::isfinite(delta), "error in trust region solver",
            iter, delta, rho, p, grad, Hess, s.objective, s.primal, s.dual, s2.objective, s2.primal, s2.dual, expected);

        // Possibly accept the new values. Also, adjust the trust region size
        delta = adjust_delta(delta, rho);
        if (s2.objective <= s.objective) s.swap(s2);

        // Check validity of current solution
        NUPACK_ASSERT(s.primal.is_finite() && s.dual.is_finite() && std::isfinite(s.objective),
            "trust region solver encountered non-finite value",
            iter, delta, rho, p, grad, Hess, s.objective, s.primal, s.dual, s2.objective, s2.primal, s2.dual, expected);
    }
    return s;
}

/******************************************************************************************/

template <class M, class V>
V initial_dual_guess(Init in, M const &A, V const &x0, V const &q, V const &rhs) {
    V c(len(x0));

    // Initial guess that is used by Concentration -- uses q plus a uniform guess for x0
    switch (in) {
        case Init::uniform: c.fill(1);
        // Initial guess using input concentrations
        case Init::given: c = la::log(x0);
        // Initial guess using absolute value of least squares
        case Init::absls: c = la::log(A * la::abs(solve(A.t() * A, rhs)));
        // Initial guess using NNLS
        case Init::nnls: c = la::log(std::get<0>(bound_least_squares(la::eval(A.t()),
            static_cast<M const &>(rhs), ScalarBound(0, real(inf)), AlternatingOptions(5000))));
    }

    // Get rid of any NaN by multiplying by min^2/max, where min and max are of finite values of c
    real bump = 1;
    for (auto const x : c) if (std::isfinite(x)) bump = std::min<real>(x, bump);
    for (auto &x : c) if (!std::isfinite(x)) x = bump;

    // Weight lower free energy complexes more for a least squares initial guess
    V const weight = arma::exp(q - q.max());
    M const AwA = A.t() * la::diagmat(weight) * A;
    return la::solve(AwA, A.t() * (weight % (c - q)));
}

/******************************************************************************************/

// where x is a vector and H is symmetric, return A.T * diag(x) * A
// this is probably the rate limiting step, complexity is (# strands)^2 (# complexes)
template <class M, class V>
void symmetric_mdm(M &H, M const &A, V const &x) {
    H.set_size(A.n_cols, A.n_cols);
    for (auto i : range(H.n_rows)) for (auto j : range(i+1))
        H.at(j, i) = H.at(i, j) = accu(A.col(i) % x % A.col(j));
}


/**
 * @brief Solve equilibrium concentrations
 * The objective is O(y) = 1^T exp(A y + q) + y^T A^T x0
 * @param A Coefficient matrix (complexes, strands)
 * @param x0 initial concentrations
 * @param q log partition functions
 * @param ops solving options
 * @return V equilibrated concentrations
 */
template <class M, class V>
Output<V> equilibrate_impl(M A, V const &x0, V const &q, Options const &ops) {
    static auto logger = spdlog::get("concentration");
    NUPACK_ALL_EQUAL("Inconsistent number of complexes", x0.n_rows, q.n_rows, A.n_rows);

    if (logger) logger->info("equilibrate started.");
    if (logger) logger->info("A rows: {}, A columns: {}", A.n_rows, A.n_cols);

    if (!len(x0)) return {x0, 0, 0, true};

    M orig_A, orth_A;
    if (ops.orthogonalize) {
        orig_A = A;
        orth_A = orth(A.t());
        A = A * orth_A;
    }

    // Direction finder with minimum radius delta
    auto direction = [dmin=ops.delta_min](auto const &...ts) {
        auto p = find_direction(ts..., dmin);
        // It is unknown why this can happen, but it does in some irreproducible design cases
        for (auto &x : p) if (!std::isfinite(x)) x = 0;
        return p;
    };

    usize n = 0; // number of condition checks (= 1 + number of iterations)
    real max_rel_grad;
    bool good = false;
    // Negative total concentrations of each strand type in the chosen basis
    V const rhs = -(A.t() * x0);
    // Negative total concentrations of each strand type in the normal basis
    V const normalization = 1 / ((ops.orthogonalize ? orig_A : A).t() * x0);
    NUPACK_ASSERT(normalization.is_finite() && normalization.min() > 0, normalization);
    // Convergence criterion based on gradient norm
    auto condition = [&] (auto const &sys, auto const &grad, auto const &...) {
        if (!ops.orthogonalize) max_rel_grad = la::max(la::abs(grad) % normalization);
        else max_rel_grad = la::max(la::abs(orth_A * grad) % normalization);
        good = max_rel_grad < ops.tolerance;
        return (ops.max_iters < ++n) || good;
    };
    // Function to calculate primal vector from previous primal and dual
    auto primal = [&](auto &x, auto const &y) {x = la::exp(A * y + q);};
    // Function to calculate objective from primal and dual
    auto objective = [&](auto const &x, auto const &y) {return accu(x) + dot(y, rhs);};

    auto sys = dual_system(initial_dual_guess(ops.init, A, x0, q, rhs), primal, objective);

    // Function to calculate gradient in dual space from system
    auto gradient = [&](auto &grad, auto const &s) {grad = A.t() * s.primal + rhs;};
    // Function to calculate gradient in dual space from system
    // this is probably the rate limiting step, complexity is (# strands)^2 (# complexes)
    auto hessian = [&](auto &H, auto const &s) {symmetric_mdm(H, A, s.primal);}; // same as H = A.t() * la::diagmat(s.primal) * A;
    // Function to adjust trust region radius and return if the new values should be accepted
    auto adjust_delta = [=](auto const delta, auto const rho) {
        if (delta <= ops.delta_min) return delta;
        if (rho > 0.75) return std::min(2 * delta, ops.delta_max);
        if (rho < 0.25) return delta / 4;
        return delta;
    };
    // Run trust region with initial radius 1000
    auto ret = trust_region(std::move(sys), gradient, hessian, direction, condition, adjust_delta, ops.delta_max);

    if (!good && logger)
        logger->error("A:\n{}\northo A:\n{}\nx0:\n{}\ng:\n{}\nx:\n{}\n", orig_A, A, x0, q, ret.primal);

    if (logger) logger->info("equilibrate finished. Number of iterations: {}", n - 1);

    return {std::move(ret.primal), std::move(ret.dual), ret.objective, max_rel_grad, n - 1, good};
}


template <class M, class V>
Output<V> equilibrate(M A, V x0, V const &q, Options const &ops) {
    if (q.has_nan()) throw std::domain_error("Input log Q contains NaN");
    if (!q.has_inf()) return equilibrate_impl(std::move(A), x0, q, ops);
    if (q.max() == real(*inf)) throw std::domain_error("Input log Q contains +inf");
    auto const s = la::find_finite(q);
    auto out = equilibrate_impl<M, V>(A.rows(s), x0(s), q(s), ops);
    out.solution.swap(x0);
    out.solution.zeros();
    out.solution(s) = x0;
    return out;
}

}
