#include "Solve.h"
#include "../reflect/Dictionary.h"

namespace nupack::concentration {

template Output<Col<double>> equilibrate(Mat<double>, Col<double>, Col<double> const &, Options const &);
template Output<Col<float>> equilibrate(Mat<float>, Col<float>, Col<float> const &, Options const &);

rebind::Variable response(std::type_index, Options const &v) {return to_dictionary(v);}

std::optional<Options> request(Type<Options>, rebind::Variable const &r, rebind::Dispatch &msg) {
    if (auto z = r.request<rebind::Dictionary>()) return from_dictionary<Options>(std::move(*z), msg);
    return msg.error("Not a dictionary-like type");
}

template <class V, class T, class F=Identity>
auto maxmap(V &&v, T const &init, F &&f={}) {
    std::decay_t<decltype(f(*begin_of(v)))> out = init;
    for (auto &&x : v) {auto tmp = f(x); if (tmp > out) out = tmp;}
    return out;
}

Output<Col<real>> solve_complexes(vec<small_vec<uint>> const &indices, Col<real> logq, Col<real> x0, Options const &ops, bool rotational_correction) {
    NUPACK_ALL_EQUAL("Inconsistent number of complexes", len(indices), len(logq), len(x0));
    Mat<real> A(len(logq), maxmap(indices, 0, [](auto const &p) {return maxmap(p, 0) + 1;}), arma::fill::zeros);

    izip(indices, [&](auto c, auto const &x) {
        for (auto s : x) A(c, s) += 1;
        if (rotational_correction) logq(c) -= std::log(real(rotational_symmetry(x)));
    });

    return equilibrate(std::move(A), std::move(x0), std::move(logq), ops);
}

void render(Document &doc, Type<Options> t) {
    doc.type(t, "concentration.Options");
    doc.method(t, "new", rebind::construct(t));
    doc.method(t, "set_init", [](Options &o, uint n) {NUPACK_REQUIRE(n, <=, 3); o.init = static_cast<Init>(n);});
    render_public(doc, t);
}

}

/******************************************************************************************/

namespace nupack {
    void render_concentration(Document &doc) {
        doc.function("concentration.solve", concentration::equilibrate<Mat<real>, Col<real>>);
        doc.function("concentration.solve_complexes", &concentration::solve_complexes);
    }
}
