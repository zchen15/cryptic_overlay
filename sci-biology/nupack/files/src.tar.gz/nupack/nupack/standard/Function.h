#pragma once
//#include "../reflect/Memory.h"
//#include "../reflect/Print.h"
//#include "../reflect/Hash.h"

#include <functional>

namespace nupack {

/******************************************************************************************/

template <class R, class ...Ts>
using Function = std::function<R(Ts...)>;

// NUPACK_DEFINE_VARIADIC(is_function, Function, class);

template <class ...Ts>
struct Observer {
    Function<void(Ts...)> function;
    void operator()(Ts ...ts) const {if (function) function(static_cast<Ts>(ts)...);}
};

/******************************************************************************************/

}

namespace rebind {

template <class R, class ...Ts>
struct Renderer<std::function<R(Ts...)>> {
    using F = std::function<R(Ts...)>;
    void operator()(Document &doc) const {
        doc.render<unqualified<R>>();
        (doc.render<unqualified<Ts>>(), ...);
        doc.type("std.Function", typeid(F));
        doc.method(typeid(F), "()", &F::operator());
        doc.method(typeid(F), "bool", &F::operator bool);
    }
};

}
