#pragma once
#include "../reflect/Memory.h"
#include "../reflect/Print.h"
#include "../reflect/Hash.h"

#include <map>
#include <unordered_map>

namespace nupack {

/******************************************************************************************/

template <class ...Ts> using Map = std::map<Ts...>;

template <class Key, class T, class Hash=hash<Key>, class Equal=std::equal_to<Key>,
          class Alloc=std::allocator<std::pair<Key const, T>>>
using HashMap = std::unordered_map<Key, T, Hash, Equal, Alloc>;

NUPACK_DEFINE_VARIADIC(is_map, std::map, class);
NUPACK_EXTEND_VARIADIC(is_map, std::multimap, class);
NUPACK_EXTEND_VARIADIC(is_map, std::unordered_map, class);

template <class T>
struct hash<T, void_if<(has_hash<value_type_of<T>>) && (is_map<T>)>> : RangeHash<T> {};

/******************************************************************************************/

template <class T>
struct memory::impl<T, void_if<is_map<T>>> {
    std::size_t operator()(T const &t) const {return sum(t, memory::impl<value_type_of<T>>());}
    void erase(T &t) const {T t_; t.swap(t_);}
};

/******************************************************************************************/

template <class T> struct io::PrintAsContainer<T, void_if<is_map<T>>> : PrintAsSet {};

/******************************************************************************************/

template <class M=void, class V>
auto count_map(V const &v) {
    nonvoid<M, Map<value_type_of<V>, std::size_t>> out;
    for (auto const &t : v) out->try_emplace(t, 0).first->second += 1;
    return out;
}

/******************************************************************************************/

}

namespace rebind {

template <class It, class T>
struct Iter {
    It iter, end;
    void next() {if (iter != end) ++iter;}
    bool good() const {return iter != end;}
    T get() const {return iter != end ? *iter : throw std::out_of_range("invalid iterator");}
};

template <class It, class T>
struct Renderer<Iter<It, T>> {
    using I = Iter<It, T>;
    void operator()(Document &doc) const {
        doc.type(typeid(I), "std.Iterator");
        doc.method(typeid(I), "next", &I::next);
        doc.method(typeid(I), "good", &I::good);
        doc.method(typeid(I), "get", &I::get);
    }
};

template <class M>
struct MapRenderer {
    using K = typename M::key_type;
    using V = typename M::mapped_type;

    void operator()(Document &doc) const {
        using P = std::pair<typename M::key_type, typename M::mapped_type>;
        doc.render<P>();
        doc.type(typeid(M), "std.Map");
        doc.method(typeid(M), "__setitem__", [](M &m, K k, V p) {m.insert_or_assign(std::move(k), std::move(p));});
        doc.method(typeid(M), "[]", [](M &m, K const &t) -> decltype(m.at(t)) {return m.at(t);});
        doc.method(typeid(M), "__iter__", [](M &m) {return Iter<typename M::iterator, P>{m.begin(), m.end()};});
        doc.method(typeid(M), "__len__", [](M const &m) {return m.size();});
        doc.method(typeid(M), "value_type", [](M const &) {return std::type_index(typeid(typename M::value_type));});
        doc.method(typeid(M), "items", [](M const &m) {return std::vector<std::pair<K, V>>(std::begin(m), std::end(m));});
    }
};

template <class T, class C, class A>
struct Renderer<std::map<T, C, A>> : MapRenderer<std::map<T, C, A>> {};

}
