#pragma once
#include "../types/PairList.h"
#include "../types/Sequence.h"

#include <regex>

namespace nupack { namespace newdesign {

/** @brief A secondary structure with nicks embedded */
struct Structure : Indexable<Structure>, MemberComparable {
    PairList pairs;
    vec<uint> nicks;
    NUPACK_REFLECT(Structure, pairs, nicks);

    auto & iter() {return pairs.contents;}

    Structure() = default;

    /**
     * @brief defer to logic of string constructor after first ensuring string is dot-parens-plus (dpp)
     *
     * @param s a string in any hybrid of regular dpp or run-length-encoded dpp
     */
    Structure(string const &s) : Structure(parse_struc(s), true) {}

    Structure(string const &s, bool) :
            pairs(s),
            nicks(prefixes<vec<uint>>(false, indirect_view(split_sequence_string(s), len))) {}
    Structure(PairList pairs, vec<uint> nicks) : pairs(std::move(pairs)), nicks(std::move(nicks)) {}
    Structure(char const *s) : Structure(string(s)) {}

    string dp() const {return pairs.dp(nicks);}
    string dp_rle() const;

    bool valid() const {return len(pairs) > 0;}

    void rotate() {
        if (len(nicks) == 1) return;
        auto offset = nicks[0];
        pairs = rotated_pairing(std::move(pairs), offset);

        auto length = back(nicks);
        for (auto & n : nicks) n = n - offset;
        std::rotate(begin_of(nicks), begin_of(nicks) + 1, end_of(nicks));
        back(nicks) = length;
    }

    Structure rotated() const {
        Structure new_struc(*this);
        new_struc.rotate();
        return new_struc;
    }

    static string parse_struc(string const &s);

    auto save_repr() const {return dp_rle();}
    void load_repr(string s) {*this = Structure(s);}

    friend std::ostream & operator<<(std::ostream &os, Structure const &s) {
        return os << "Structure(\"" << s.dp_rle() << "\")";
    }
};

void render(Document &doc, Type<Structure> t);

}}
