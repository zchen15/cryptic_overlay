#include "Granularity.h"
#include "../reflect/Dump.h"

namespace nupack { namespace newdesign {

LevelSpecification EnsembleLevelSpecification::default_spec {};


void render(Document &doc, Type<EnsemblePartition> t) {
    doc.type(t, "design.results.Partition");

    doc.method(t, "{}", dumpable(t));
    render_public(doc, t);
}

}}
