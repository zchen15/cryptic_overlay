#pragma once
#include "QuadraticRatio.h"
#include "Matrices.h"

namespace nupack::trace {

/******************************************************************************************/

// O(M N^2 + O(M^3)) complexity
template <bool Debug=false, class M, class T>
auto decompose_trace(M const &X, la::Mat<T> const &A, la::Mat<T> const &B) {
    if (Debug) { // probably involves more recalculations
        la::Mat<T> Q = la::inv_sympd(X.t() * B * X); // O(M^3)
        la::Mat<T> Bp = B - B * X * Q * X.t() * B;  // O(M N^2)
        la::Mat<T> Ap = A + B * X * Q * X.t() * A * X * Q * X.t() * B // (n, n)
                    - A * X * Q * X.t() * B
                    - B * X * Q * X.t() * A;
        return std::make_tuple(std::move(Q), std::move(Ap), std::move(Bp));
    } else {
        la::Mat<T> AX = A * X, BX = B * X; // O(M N^2)
        la::Mat<T> Q, XBX = X.t() * BX;    // O(M^2 N)
        if (!la::inv_sympd(Q, XBX)) NUPACK_ASSERT(la::inv(Q, XBX), XBX, X); // O(M^3)
        la::Mat<T> QXB = Q * BX.t(); // O(M^2 N)
        la::Mat<T> Bp = B - BX*QXB;  // O(M N^2)
        la::Mat<T> Ap = A + QXB.t()*X.t()*AX*QXB - AX*QXB - QXB.t()*AX.t(); // O(M N^2)
        return std::make_tuple(std::move(Q), std::move(Ap), std::move(Bp));
    }
}

/******************************************************************************************/

// O(M N^2) complexity
template <class V, class M0, class M1, class M2, class M3, class M4>
auto decomposed_objective(V const &x, M0 const &A, M1 const &Q, M2 const &Ap, M3 const &Bp, M4 const &Z) {
    return la::dot(x, Ap, x) / la::dot(x, Bp, x)
         + la::accu(Q % (Z.t() * A * Z)); // <- this is M N^2, it may not be needed in some cases
}

/******************************************************************************************/

template <class T>
struct Optimizer {
    // Input arrays
    la::Mat<T> const &A;
    la::Mat<T> const &B;
    la::Mat<T> &X;

    // Primary arrays
    la::Mat<T> Ap, Bp, Q, QYB;

    Optimizer(la::Mat<T> &X, la::Mat<T> const &A, la::Mat<T> const &B)
        : perm(vec<la::uword>(range(X.n_cols))), X(X), A(A), B(B) {
    }

    // Work arrays
    la::Col<T> u, z, h, r, j, w, y, bdel;
    la::Mat<T> V, Q2, AB, Y;
    typename la::Mat<T>::template fixed<4, 4> M{la::fill::zeros};
    la::uvec perm;

    /// Evaluate all necessary matrices for a given solution X, and return the current objective
    void calculate_inverses() {
        Y = X.tail_cols(X.n_cols - 1);
        NUPACK_ASSERT(Y.is_finite(), Y);
        std::tie(Q, Ap, Bp) = decompose_trace(Y, A, B);
        NUPACK_ASSERT(Ap.is_finite());
        QYB = Q * Y.t() * B;
    }

    T objective() const {return decomposed_objective(column(), A, Q, Ap, Bp, Y);}

    auto column() {return X.col(perm(0));}
    auto column() const {return X.col(perm(0));}

    void update_inverses(bool debug=false) {
        NUPACK_ASSERT(X.is_finite(), X);
        auto const m = X.n_cols;
        auto const xn = X.col(perm(0)); // to put in
        auto const xo = X.col(perm(1)); // to take out
        bdel = B * (xn - xo);
        // All columns that are not being removed or put in
        auto const Z = Y.tail_cols(m-2);
        auto const s = la::span(1, Q.n_cols-1);

        // Update for Q = inv(Y^T B Y)
        T c = 1;
        if (m != 2) c += la::dot(Q(s, 0), Z.t(), bdel);
        T const q = -Q(0, 0);

        T d = la::dot(xo, B, xo) - la::dot(xn, B, xn) + sq(c) / q;
        if (m != 2) d += la::dot(bdel, Z, Q(s, s), Z.t(), bdel);
        // print(d, la::as_scalar(xo.t() * B * xo),  la::as_scalar(xn.t() * B * xn), sq(c) / q, la::as_scalar(bdel.t() * Z * Q(s, s) * Z.t() * bdel));
        if (d == 0) {BEEP("short circuit"); return;}
        d = -1 / d;

        u = c / q * Q.col(0);
        if (m != 2) u += Q.tail_cols(m-2) * Z.t() * bdel;
        Q2 = Q + la::outer(Q.col(0), Q.col(0)) / q + d * la::outer(u, u);
        NUPACK_ASSERT(Q2.is_finite(), q, d, Q, Q2, X, xo, xn, Z);

        // Update for the constraint: B Y Q
        QYB += la::outer(Q2.col(0), bdel) + (1/q) * la::outer(Q.col(0), B * Y * Q.col(0)) + d * la::outer(u, B * Y * u);
        NUPACK_ASSERT(QYB.is_finite());

        // Update for the B remainder: B Y Q Y^T B
        r = -xn;
        if (m != 2) r += Z * u.tail(m-2);
        z = -xo;
        if (m != 2) z += Z * Q(s, 0) / q;
        j = B * r;
        h = B * z;

        Bp += -d * j * j.t() + -q * h * h.t();
        NUPACK_ASSERT(Bp.is_finite());

        // Update for a piece of the A remainder: A Y Q Y^T B and its transpose
        AB = -d * (A * r) * j.t() + -q * (A * z) * h.t();
        Ap += AB + AB.t();

        // Update for the A remainder: B Y Q Y^T A Y Q Y^T B
        w = B * Y * Q * Y.t() * A * r;
        y = B * Y * Q * Y.t() * A * z;

        M(0, 0) = sq(q) * la::dot(z, A, z);
        M(0, 1) = M(1, 0) = d * q * la::dot(z, A, r);
        M(0, 3) = M(3, 0) = q;
        M(1, 1) = sq(d) * la::dot(r, A, r);
        M(1, 2) = M(2, 1) = d;
        V = la::join_rows(h, j, w, y);
        Ap += V * M * V.t();
        NUPACK_ASSERT(Ap.is_finite());

        // Rotate the permutation and necessary columns of Q
        Q.swap(Q2);
        std::rotate(perm.begin(), perm.begin()+1, perm.end());

        for (auto i : range(Q.n_cols)) std::rotate(Q.begin_col(i), std::next(Q.begin_col(i)), Q.end_col(i));
        for (auto i : range(Q.n_rows)) std::rotate(Q.begin_row(i), std::next(Q.begin_row(i)), Q.end_row(i));
        for (auto i : range(QYB.n_cols)) std::rotate(QYB.begin_col(i), std::next(QYB.begin_col(i)), QYB.end_col(i));

        // All columns except the next one to be being modified
        Y = X.cols(perm.tail(m-1));

        if (debug) {
            auto [Q2, Ap2, Bp2] = decompose_trace(Y, A, B);
            la::Mat<T> QYB2 = Q * Y.t() * B;
            BEEP(Y, Ap, Ap2, Bp, Bp2, Q, la::inv_sympd(Y.t() * B * Y), QYB, Q * Y.t() * B);
            // NUPACK_ASSERT(la::close_matrices(Q, Q2), Q, Q2);
            // NUPACK_ASSERT(la::close_matrices(Ap, Ap2), Ap, Ap2);
            // NUPACK_ASSERT(la::close_matrices(Bp, Bp2), Bp, Bp2);
            // NUPACK_ASSERT(la::close_matrices(QYB, QYB2), QYB, QYB2);
        }
    }
};

/******************************************************************************************/

}
