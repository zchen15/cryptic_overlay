#pragma once
#include "Inversion.h"
#include "RatioSolve.h"
#include "ConstraintSolve.h"

namespace nupack::trace {

/******************************************************************************************/

template <class M, class V>
auto stationary_objective(M const &X, M const &A, M const &B, V const &pi, bool pinv=true) {
    M Q;
    if (pinv) Q = la::pinv(X.t() * B * X);
    else Q = la::inv_sympd(X.t() * B * X);

    return la::accu((X.t() * A * X) % Q)
         - (1 + la::dot(pi, X, Q, X.t(), A, X, Q, X.t(), pi))
         / la::dot(pi, X, Q, X.t(), pi);
}

/******************************************************************************************/

template <class T>
struct StationaryOptimizer : Optimizer<T> {
    using base_type = Optimizer<T>;
    using base_type::QYB;
    using base_type::Y;
    using base_type::Q;
    using base_type::Ap;
    using base_type::Bp;
    using base_type::A;
    using base_type::B;

    Col<T> const &p;

    la::Mat<T> C, Aq, Bq;
    la::Col<T> c1, c2, v, w, s;

    StationaryOptimizer(la::Mat<T> &X, la::Mat<T> const &A, la::Mat<T> const &B, la::Col<T> const &pi) :
        base_type(X, A, B), p(pi) {}

    void update_constraints() {
        auto const m = QYB.n_rows, n = QYB.n_cols;
        C.set_size(4 * m, n);

        // First order, known occupancy
        C.rows(0, m-1) = -QYB; // M x N array

        c1 = Q * Y.t() * p;
        c2 = p - B * Y * c1;
        c1 *= 1 / la::dot(p, Y, c1);

        // First order, unknown occupancy
        C.rows(m, 2*m-1) = QYB + la::outer(c1, c2);

        // Second order, known occupancy
        C.rows(2*m, 3*m-1) = Q * Y.t() * A * (Y * QYB - la::eye(n, n));

        // Intermediate quantities
        v = Y * Q * Y.t() * p;
        w = p - B * v;
        T t = la::dot(p, v);
        s = A * v; s -= QYB.t() * Y.t() * s;

        // Second order, unknown occupancy
        {
            la::Mat<T> W = A - A * Y * QYB;
            C.rows(3*m, 4*m-1) = t * Q * Y.t() * W
                               - la::outer(Q * Y.t() * A * v, w)
                               + la::outer(Q * Y.t() * p, (1 + la::dot(v, A, v)) / t * w - s);
        }

        if (false) {
            la::Mat<T> Bm = B + 1e5 * la::outer(p, p),
                    Am = A + 1e10 * la::outer(p, p);

            la::Mat<T> C4 = (la::eye(n, n) - Bm * Y * la::inv(Y.t() * Bm * Y) * Y.t()) * Am * Y * la::inv(Y.t() * Bm * Y);
            BEEP(t * C4.t(), C.rows(3*m, 4*m-1));
        }

        Bq = t * Bp + la::outer(w, w);
        Aq = t * Ap - (1 + la::dot(v, A, v)) * Bp - la::outer(s, w) - la::outer(w, s);
    }

    void calculate_inverses() {
        base_type::calculate_inverses();
        update_constraints();
    }

    T objective() const {
        auto x = base_type::column();
        return la::accu((Y.t() * A * Y) % Q) + la::dot(x, Aq, x) / la::dot(x, Bq, x);
    }

    void update_inverses(bool debug=false) {
        base_type::update_inverses(debug);
        update_constraints();

        if (debug) {
            auto const m = QYB.n_rows;
            auto x = base_type::column();
            la::Mat<T> C1 = -Q * Y.t() * B;
            la::Mat<T> C2 = la::outer(Q * Y.t() * p, p - B * Y * Q * Y.t() * p) / la::dot(p, Y, Q, Y.t(), p)  + Q * Y.t() * B;
            BEEP(C.head_rows(m) * x, -Q * Y.t() * B * x, -la::inv(Y.t() * B * Y) * Y.t() * B * x);
            BEEP(C1 * x, C2 * x, C * x);
            // NUPACK_ASSERT(close_matrices(C.head_rows(m), C1), C, C1);
            // NUPACK_ASSERT(close_matrices(C.tail_rows(m), C2), C, C2);
        }
    }
};

/******************************************************************************************/

/*
Maximize $\frac{a x^2 + b x + c}{d x^2 + e x + f}$
subject to $x0 <= x <= x1$
Both polynomials are assumed to be positive semidefinite, i.e. $a \geq 0, c \geq 0, 4 a c \geq b^2$
*/

template <bool Debug=false, class X, class M, class T>
std::pair<T, bool> constrained_solve(X &&x, M const &A, M const &B, M const &C, ConstraintOptions<T> const &ops) {
    NUPACK_ASSERT(x.is_finite(), x);
    auto [r1, r2, satisfied] = maximize_constrained_column(x, A, B, C, ops);
    NUPACK_ASSERT(x.is_finite(), x);
    // print(r1, r2, satisfied);
    return {r2 - r1, satisfied};
}

/******************************************************************************************/

/*
Maximize $\mathrm{Tr} C^T A C (C^T B C)^{-1}$ subject to $C \geq 0$
A, B is assumed symmetric positive semi-definite
*/
template <class T>
Output<T> maximize_stationary(la::Mat<T> X, la::Mat<T> const &A, la::Mat<T> const &B, la::Col<T> const &pi,
                              ConstraintOptions<T> const &cops={}, Options<T> const &ops={}) {
    NUPACK_REQUIRE(X.n_cols, >=, 2);

    Output<T> out;
    StationaryOptimizer<T> o(X, A, B, pi);

    o.calculate_inverses();
    out.objective = o.objective();

    for (; out.iters != ops.iters; ++out.iters) {
        out.satisfied = true;
        T improvement = 0;
        for (uint i = 0; i != X.n_cols; ++i) {
            auto p = constrained_solve(o.column(), o.Aq, o.Bq, o.C, cops); // O(N^2)

            o.update_inverses(false);
            out.satisfied &= p.second;
            improvement += p.first;
        }
        if (ops.refresh) {
            o.calculate_inverses();
            auto old = improvement;
            improvement = o.objective() - out.objective;
            print(out.iters, old, improvement);
        }

        out.objective += improvement;

        // print(int(out.satisfied), improvement, out.objective);
        // if (out.iters > 1000)
        if (out.satisfied && !(improvement > ops.tolerance * out.objective)) {out.converged = true; break;}
    }

    out.solution = std::move(X);
    return out;
}

/******************************************************************************************/

template <class T>
Output<T> stationary_maximum(usize m, la::Mat<T> const A, la::Mat<T> const B, la::Col<T> const &pi,
                             Init init, ConstraintOptions<T> const &cops={}, Options<T> const &ops={}) {
    return maximize_stationary(initial_guess(A, B, m, init), A, B, pi, cops, ops);
}

/******************************************************************************************/
}
