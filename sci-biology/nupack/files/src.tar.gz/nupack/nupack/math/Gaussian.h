#pragma once
#include "../types/Matrix.h"
#include "../common/Constants.h"
#include "BoundSolve.h"

namespace nupack {

struct GaussianOptions {
    AlternatingOptions solver;
    real regularize;
    real truncate;
    NUPACK_REFLECT(GaussianOptions, solver, regularize, truncate);

    GaussianOptions(AlternatingOptions const &ops, real reg=0, real trunc=5) : solver(ops), regularize(reg), truncate(trunc) {
        NUPACK_REQUIRE(truncate, >, 0);
    }
};

void render(Document & doc, Type<GaussianOptions> t);

/******************************************************************************************/

/// Positions in a 1D array that have non-negligible contributions from a Gaussian(mu, sigma)
template <class T, class X>
auto gaussian_domain(X const &x, T const &mu, T const &sigma, T const &truncate) {
    NUPACK_REQUIRE(len(x), >, 0);
    if (len(x) == 1) return arma::span(0, 0);
    auto const rbox = 1 / (x(1) - x(0));
    auto const lim = len(x) - 1;
    T const min = floor((mu - truncate * sigma) * rbox);
    T const max = ceil((mu + truncate * sigma) * rbox);
    return arma::span(std::clamp<T>(min, 0, lim), std::clamp<T>(max, 0, lim));
}

/******************************************************************************************/

/// Positions in an ND array that have non-negligible contributions from a Gaussian(mu, sigma)
template <class H, class F, std::size_t ...Is, class ...Ts>
auto eval_gaussian_base(H const &h, F const &f, std::index_sequence<Is...>, Ts const &...ts) {
    return fold(times, h(ts...), f[Is](ts)...);
}

/// Positions in an ND array that have non-negligible contributions from a Gaussian(mu, sigma)
template <class T, uint N, uint, class G, class M, class F, class H, class X, class ...Ts, NUPACK_IF(N == sizeof...(Ts))>
T eval_gaussian(G const &, M const &, F const &f, H const &h, X const &, Ts const &...ts) {
    return eval_gaussian_base(h, f, std::make_index_sequence<sizeof...(Ts)>(), ts...);
}

template <class T, uint N, uint D, class G, class M, class F, class H, class X, class ...Ts, NUPACK_IF(N != sizeof...(Ts))>
T eval_gaussian(G &g, M const &m, F const &f, H const &h, X const &x, Ts const &...ts) {
    constexpr uint I = N - 1 - sizeof...(Ts);
    T const s2 = pow(m(1, I), -2), s3 = pow(m(1, I), -3);
    T const mm = -m(0, I), ms1 = mm + m(1, I), ms2 = mm - m(1, I);
    auto const &xi = x[I];
    T sum = 0;
    for (auto const t : indices(xi)) {
        auto const pdf = eval_gaussian<T, N, D>(g, m, f, h, x, t, ts...);
        sum += pdf;
        if constexpr(D != 0) {
            g(0, I) += pdf * s2 * (xi(t) + mm); // \partial x
            g(1, I) += pdf * s3 * (xi(t) + ms1) * (xi(t) + ms2); // \partial \sigma
        }
    }
    return sum;
}

/******************************************************************************************/

/// Gradient and value of one Gaussian on a grid with a constant image
template <class T, uint N, uint D, class G, class H, class M, class X, std::size_t ...Is>
auto one_gaussian(G &grad, M const &m, H const &h, X const &grid, T const &truncate, std::index_sequence<Is...>) {
    // h - Tensor(x, y ...)
    // m - Matrix(2, # dimensions) of mean and sigma
    // grid - Matrix(# points, # dimensions)
    // Calculate \sum_{x,y,...} Normal(m)(x, y, ...) I(x, y, ...)
    // as well as its derivative w.r.t. m
    std::array<arma::span, N> domains = {gaussian_domain<T>(grid[Is], m(0, Is), m(1, Is), truncate)...};
    std::array<decltype(grid[0](domains[0])), N> views = {grid[Is](domains[Is])...};
    std::array<Col<T>, N> f;
    for (auto const d : range(N)) {
        f[d] = views[d] - m(0, d);
        f[d] = arma::exp((-T(0.5) / sq(m(1, d))) * (f[d] % f[d])) / sqrt(2 * T(Pi) * sq(m(1, d)));
    }
    auto out = eval_gaussian<T, N, D>(grad, m, std::move(f), h(domains[Is]...), std::move(views));
    NUPACK_ASSERT(is_finite(out));
    return out;
}

/// Gradient and value of one Gaussian on a grid with a constant image
template <class T, uint N, uint D, class G, class H, class M, class X>
auto one_gaussian(G &grad, M const &m, H const &h, X const &grid, T truncate) {
    return one_gaussian<T, N, D>(grad, m, h, grid, truncate, std::make_index_sequence<la::depth<H>>());
}

/******************************************************************************************/

/// Gradient and value of all two Gaussian products on a grid
// grad: (2, # dimensions = N)
// m: 2, # dimensions
template <class T, uint N, uint D, class G, class M, class X>
auto squared_gaussian(G &grad, M const &m, X const &grid, T const &truncate) {
    std::array<T, N> factors;
    NUPACK_DREQUIRE(len(grid), ==, N);
    NUPACK_DREQUIRE(grad.n_cols, ==, N);
    NUPACK_DREQUIRE(m.n_cols, ==, N);
    for (auto const d : indices(grid)) {
        T const mm = -m(0, d), s = m(1, d);
        T const c = 1 / (2 * Pi * sq(s));
        T const a = -1 / sq(s);
        T const s2 = 2 * pow(s, -2), s3 = 2 * pow(s, -3);
        T const m1 = mm - s, m2 = mm + s;

        factors[d] = 0;
        for (auto const x : grid[d](gaussian_domain<T>(grid[d], m(0, d), m(1, d) / sqrt(T(2)), truncate))) {
            auto const pdf = c * std::exp(a * sq(x + mm));
            factors[d] += pdf;
            if constexpr(D != 0) {
                grad(0, d) += pdf * s2 * (x + mm); // \partial x
                grad(1, d) += pdf * s3 * (x + m1) * (x + m2); // \partial \sigma
            }
        }
    }
    T out = product(factors);
    if (out == 0) grad.zeros();
    else for (auto d : indices(grid)) grad.col(d) *= out / factors[d];
    return out;
}

/******************************************************************************************/

/// Gradient and value of selected two Gaussian products on a grid
template <class T, uint N, uint D, class G, class M, class X>
auto two_gaussian(G &grad, M const &mi, M const &mj, X const &grid, T const &truncate) {
    std::array<T, N> factors;
    for (auto const d : range(N)) {
        T const si = mi(1, d), sj = mj(1, d), ui = mi(0, d), uj = mj(0, d);
        T const vi = sq(si), vj = sq(sj);
        T const c = std::exp(-sq(ui - uj) / 2 / (vi + vj)) / (2 * Pi * si * sj);
        T const s = sqrt((vi * vj) / (vi + vj));
        T const a = -0.5 / sq(s);
        T const mu = (vi * uj + vj * ui) / (vi + vj);

        T const ui1 = -ui - si, ui2 = -ui + si;
        T const uj1 = -uj - sj, uj2 = -uj + sj;
        T const si2 = pow(si, -2), si3 = pow(si, -3);
        T const sj2 = pow(sj, -2), sj3 = pow(sj, -3);

        factors[d] = 0;

        for (auto const x : grid[d](gaussian_domain<T>(grid[d], mu, s, truncate))) {
            auto const pdf = c * std::exp(a * sq(x - mu));
            factors[d] += pdf;

            if constexpr(D != 0) {
                grad(0, d)     += pdf * (x - ui) * si2;
                grad(0, d + N) += pdf * (x - uj) * sj2;

                grad(1, d)     += pdf * (x + ui1) * (x + ui2) * si3;
                grad(1, d + N) += pdf * (x + uj1) * (x + uj2) * sj3;
            }
        }
    }
    T out = product(factors);
    if (out == 0) grad.zeros();
    else if (D) for (auto d : indices(grid)) {
        grad.col(d) *= out / factors[d];
        grad.col(d + N) *= out / factors[d];
    }
    return out;
}

/******************************************************************************************/

template <class T, uint N, uint D, class M, class G1, class G2, class ...Ts>
SpMat<T> gmm_operator(std::size_t z, T regularize, M const &m, G1 &diag_grad, G2 &off_grad, arma::umat const &pairs, Ts const &...ts) {
    NUPACK_REQUIRE(pairs.n_rows, ==, 2);
    auto const np = pairs.n_cols;
    arma::umat locs(2, z + 2 * np);
    for (auto n : range(z)) // diagonal indices
        locs(0, n) = locs(1, n) = n;

    if (np) {
        locs.cols(z, z + np-1) = pairs;
        locs.tail_cols(np).row(1) = pairs.row(0);
        locs.tail_cols(np).row(0) = pairs.row(1);
    }

    Col<T> vals(locs.n_cols);
    for (auto const i : range(z)) // diagonal
        vals(i) = regularize + squared_gaussian<T, N, D>(diag_grad.slice(i), m.slice(i), ts...);
    for (auto const n : range(np)) // symmetric offdiagonal
        vals(z + n + np) = vals(z + n) = two_gaussian<T, N, D>(off_grad.slice(n), m.slice(pairs(0, n)), m.slice(pairs(1, n)), ts...);

    return {locs, std::move(vals), z, z};
}

/******************************************************************************************/

template <class T, uint N, uint D, class M, class G, class ...Ts>
Col<T> gmm_rhs(G &grad, M const &m, Ts const &...ts) {
    Col<T> b(m.n_slices);
    for (auto const i : range(m.n_slices))
        b(i) = one_gaussian<T, N, D>(grad.slice(i), m.slice(i), ts...);
    NUPACK_ASSERT(all_of(b, is_finite));
    return b;
}

/******************************************************************************************/

/// Returns solution, solved weight vector, gradient vector for position and sigma
/// h: the image
/// m: the positions and sigmas (2, dimension, N)
/// returns the objective value, the solved weights, and the gradient (2, dimension, N)
template <bool dXS, class T, class H, class M, class X, class L>
auto gmm_gradient(H const &image, M const &m, X const &grid, L const &pairs, GaussianOptions const &ops, ScalarBound const &bound) {
    // H(...), M(2, dimension, N)
    auto const z = m.n_slices, npairs = pairs.n_cols;
    constexpr auto N = la::depth<H>;
    constexpr auto D = 2 * uint(dXS);

    // Calculate right hand side and its grqdient
    Cube<T> grad(D, N, z, arma::fill::zeros);
    auto const b = gmm_rhs<T, N, D>(grad, m, image, grid, ops.truncate);

    // Calculate sparse A operator
    Cube<T> diag_grad(D, N, z, arma::fill::zeros); // (x/s, dimension, point)
    Cube<T> off_grad(D, 2 * N, npairs, arma::fill::zeros); // (x/s, dimension and left/right index, point)
    auto const A = gmm_operator<T, N, D>(z, ops.regularize, m, diag_grad, off_grad, pairs, grid, ops.truncate);

    // Solve for weights
    Col<T> x(b.n_rows, arma::fill::zeros);
    auto conv = bound_solve(x, A, b, bound, ops.solver);
    NUPACK_REQUIRE(conv.unconverged, ==, 0, "NNLS did not converge");

    // Get objective = x^T A x - 2 x^T b -- (b^T b is constant and not included)
    NUPACK_ASSERT(all_of(x, is_finite));
    T const objective = dot(x, A * x) - 2 * dot(x, b);

    if (D != 0) {
        // Add the gradient stuff coming from A into the gradient
        for (auto const i : range(z)) {
            grad.slice(i) *= -2 * x(i);
            grad.slice(i) += sq(x(i)) * diag_grad.slice(i);
        }
        NUPACK_ASSERT(all_of(grad, is_finite));

        for (auto const n : range(npairs)) {
            auto const xx = 2 * x(pairs(0, n)) * x(pairs(1, n));
            grad.slice(pairs(0, n)) += xx * off_grad.slice(n).head_cols(N);
            grad.slice(pairs(1, n)) += xx * off_grad.slice(n).tail_cols(N);
        }
        NUPACK_ASSERT(all_of(grad, is_finite));
    }

    return std::make_tuple(objective, std::move(x), std::move(grad));
}

template <class T, class H, class M, class X, class L>
auto gmm_squared_loss(H const &image, M const &m, X const &grid, L const &pairs,
                      bool grad, GaussianOptions const &ops, ScalarBound const &bound={}) {
    return switch_c(grad, [&](auto B) {
        return gmm_gradient<decltype(B)::value, T>(image, m, grid, pairs, ops, bound);
    });
}

/******************************************************************************************/



}
