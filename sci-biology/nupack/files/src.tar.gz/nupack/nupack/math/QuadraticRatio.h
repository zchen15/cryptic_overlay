#pragma once
#include "../types/Matrix.h"

namespace nupack::trace {

/******************************************************************************************/

template <class T>
T quadratic_ratio(T const &x, T const &a, T const &b, T const &c,
                              T const &e, T const &f, T const &g) {
    return (a * x * x + b * x + c) / (e * x * x + f * x + g);
}

/******************************************************************************************/

template <class T>
bool quadratic_positive_definite(T const &a, T const &b, T const &c, T tol=1e-10) {
    return a > 0 && c > 0 && b * b < (4 - tol) * a * c;
}

/******************************************************************************************/

template <class T>
struct Ratio {
    T a=0, b=0, c=0, e=0, f=0, g=0;

    NUPACK_REFLECT(Ratio, a, b, c, e, f, g);

    bool positive_definite() const {
        return quadratic_positive_definite(e, f, g);
    }

    T value(T const &x) const {
        return (a * x * x + b * x + c) / (e * x * x + f * x + g);
    }

    void check() const {
        NUPACK_DASSERT(quadratic_positive_definite(e, f, g), e, f, g);
    }

    T finite_point() const {
        return (sqrt(g * (a*a*g - a*b*f+b*b*e) + a*c*(f*f-2*e*g) - b*c*e*f + c*c * e*e) + a*g - c*e) / (b*e - a*f);
    }

    std::pair<T, T> unbounded_solution(T const inf) const {
        check();
        // 0
        T x = 0, p = c / g;
        // inf (-inf is equivalent so we'll ignore that possibility)
        if (a / e > p) {x = inf; p = value(x);}
        // general solution
        T const x2 = finite_point(), p2 = value(x2);
        if (p2 > p) {p = p2; x = x2;}
        // On analysis, these are just edge cases for the linear term equal to 0
        // Pretty sure they are therefore not needed
        // possibility 4: edge case 1
        // test(x, p, (c*e - a*g - sqrt(a*a*g*g + a*c*(f*f - 2*e*g) + c*c*e*e)) / (a*f));
        // possibility 5: edge case 2
        // test(x, p, b*g / (sqrt(a*a + g*g + e*g*(b*b - 2*a*c) + c*c*e*e) - a*g + c*e));
        NUPACK_ASSERT(!std::isnan(x));
        return {x, p};
    }

    std::pair<T, T> nonnegative_solution(T const inf) const {
        check();
        // 0
        T x = 0, p = c / g;
        // inf
        if (a / e > p) {x = inf; p = value(x);}
        // general solution
        if (auto const x1 = finite_point(); 0 < x1)
            if (auto const p1 = value(x1); p1 > p) {p = p1; x = x1;}
        // edge case
        if (auto const x1 = (c * f - b * g) / (a * g - c * e); 0 < x1)
            if (auto const p1 = value(x1); p1 > p) {p = p1; x = x1;}

        NUPACK_ASSERT(x >= 0, x);
        return {x, p};
    }

    std::pair<T, T> bounded_solution(T const xmin, T const xmax) const {
        // the possibilities are xmin, xmax, general solution, 0
        // xmin
        T x = xmin, p = value(xmin);
        // xmax
        if (auto const p1 = value(xmax); p1 > p) {x = xmax; p = p1;}
        // 0
        if (xmin < 0 && 0 < xmax)
            if (auto const p1 = c / g; p1 > p) {x = 0; p = p1;}
        // general
        if (auto const x1 = finite_point(); xmin < x1 && x1 < xmax)
            if (auto const p1 = value(x1); p1 > p) {x = x1; p = p1;}
        // edge case
        if (auto const x1 = (c * f - b * g) / (a * g - c * e); xmin < x1 && x1 < xmax)
            if (auto const p1 = value(x1); p1 > p) {p = p1; x = x1;}
        NUPACK_ASSERT(xmin <= x && x <= xmax, x, xmin, xmax);
        return {x, p};
    }
};


/******************************************************************************************/

/// O(n) calculation of polynomial terms
template <class T, class C>
std::array<T, 3> polynomial_terms(la::Mat<T> const &A, C const &x, T const xax, uint i) {
    T a = A(i, i), xi = x(i);
    T b = 2 * (la::dot(x, A.col(i)) - a * xi);
    T c = xax - a * xi * xi - b * xi; // total minus the parts coming from x(i)
    NUPACK_ASSERT(std::isfinite(a) && std::isfinite(b) && std::isfinite(c), a, b, c, xi);
    return {a, b, c};
}


/******************************************************************************************/

template <class T>
struct MatrixRatio {
    T xax=0, xbx=0;

    MatrixRatio() = default;
    NUPACK_REFLECT(MatrixRatio, xax, xbx);

    template <class X, class A, class B>
    MatrixRatio(X &&x, A const &a, B const &b) {
        xax = la::dot(x, a, x);
        xbx = la::dot(x, b, x);
        NUPACK_ASSERT(std::isfinite(xax) && std::isfinite(xbx) && xbx != 0, xax, xbx, x, a, b);
    }

    template <class X>
    T value(X const &x) const {
        NUPACK_ASSERT(x.is_finite() && std::isfinite(xax) && std::isfinite(xbx) && xbx != 0, xax, xbx, x);
        return xax / xbx;
    }

    template <class X, class A, class B>
    Ratio<T> scalar_ratio(X &&x, A const &a, B const &b, uint i) const {
        auto const abc = polynomial_terms(a, x, xax, i);
        auto const efg = polynomial_terms(b, x, xbx, i);
        return {abc[0], abc[1], abc[2], efg[0], efg[1], efg[2]};
    }

    template <class X>
    void normalize(X &&x, T const t) {
        if (t != 0) {x *= 1 / t; xax /= sq(t); xbx /= sq(t);}
        else NUPACK_ERROR("Vector norm is non-finite", x, t);
    }

    void reset(Ratio<T> const &q, T const x) {
        xax = q.a*x*x + q.b*x + q.c;
        xbx = q.e*x*x + q.f*x + q.g;

        NUPACK_ASSERT(std::isfinite(xax) && std::isfinite(xbx), q, x, xax, xbx);
    }
};

/******************************************************************************************/

}
