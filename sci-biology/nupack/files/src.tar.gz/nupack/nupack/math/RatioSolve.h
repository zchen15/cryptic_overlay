#pragma once
#include "QuadraticRatio.h"
#include "Inversion.h"
#include <variant>

namespace nupack::trace {

/******************************************************************************************/

template <class T>
struct Options {
    T minimum = 0, maximum = 0, tolerance = 0;
    usize iters = 0;
    bool refresh = true;

    Options() = default;
    Options(T min, T max=1e10, T tol=1e-6, uint i=1e4, bool r=true)
        : minimum(min), maximum(max), tolerance(tol), iters(i), refresh(r) {}

    NUPACK_REFLECT(Options, minimum, maximum, tolerance, iters, refresh);
};

/******************************************************************************************/

template <class T>
struct Output {
    la::Mat<T> solution;
    T objective = 0;
    usize iters = 0;
    bool satisfied = true, converged = false;
    NUPACK_REFLECT(Output, solution, objective, iters, satisfied, converged);
};

/******************************************************************************************/

template <class A, class B, class X>
real trace_objective(X const &x, A const &a, B const &b, bool pinv=true) {
    if (pinv) return la::accu((x.t() * a * x) % la::pinv(x.t() * b * x));
    else return la::accu((x.t() * a * x) % la::inv(x.t() * b * x));
}

/******************************************************************************************/

/*
Maximize $\frac{x^T A^2 x}{\frac{x^T A x}}$ subject to scalar constraints on $x$
A is assumed symmetric positive semi-definite
Total complexity is O(N^2)
*/
template <class S, class T, class X>
std::pair<T, T> maximize_column(S const &solve, X &&x, la::Mat<T> const &A, la::Mat<T> const &B, uint norm) {
    MatrixRatio<T> ratio(x, A, B);
    T const r1 = ratio.value(x);

    izip(x, [&](auto const &i, auto &xi) { // N iterations -> O(N^2)
        auto const q = ratio.scalar_ratio(x, A, B, i); // costs O(N)

        if (q.positive_definite()) {
            xi = solve(q).first;
            ratio.reset(q, xi);
        }
    });

    ratio.normalize(x, la::norm(x, norm));

    T const r2 = ratio.value(x);
    return {r1, r2};
}

/******************************************************************************************/

template <class T>
struct ConstraintOptions {
    T minimum=0, maximum=1e10, tolerance=1e-10;
    uint norm=1, iters=4;

    NUPACK_REFLECT(ConstraintOptions, minimum, maximum, tolerance, norm, iters);
};

/******************************************************************************************/

/*
Maximize $\frac{x^T A^2 x}{\frac{x^T A x}}$ subject to $C x \geq 0$, $x \geq 0$
A is assumed symmetric positive semi-definite
Total complexity is O(N^2)
Returns:
    1. Initial objective value
    2. Final objective value
    3. Whether the constraints were satisfied at every iteration
*/
template <class T, class X>
std::tuple<T, T, bool> maximize_constrained_column(X &&x, la::Mat<T> const &A, la::Mat<T> const &B,
                                                   la::Mat<T> const &C, ConstraintOptions<T> const &ops={}) {
    MatrixRatio<T> ratio(x, A, B); // O(N^2)
    // handling these separately is expected to be better for numerical precision
    la::Col<T> v, Cx = C * x;
    T const r1 = ratio.value(x);
    bool satisfied = true;
    // print("A", x.min(), (C * x).min(), r1);

    for (uint iter = 0; iter != ops.iters; ++iter) {
        izip(x, [&](auto const i, auto &xi) { // O(N^2)
            auto const q = ratio.scalar_ratio(x, A, B, i); // O(N)
            auto const x0 = xi;
            v = Cx + C.col(i) * -x0; // O(M)

            satisfied = satisfied && (x0 >= ops.minimum) && (x0 <= ops.maximum);

            T xmin = ops.minimum, xmax = ops.maximum;
            zip(v, C.col(i), [&](auto const &v, auto const &c) { // O(M)
                // to satisfy the constraints, all  v >= -C.col(i) * x0
                satisfied = satisfied && (x0 * c + v >= -ops.tolerance * std::abs(v));

                if (c != 0) {
                    T const t = (v - ops.tolerance * std::abs(v)) / -c;
                    if (c < 0) xmax = std::min(t, xmax);
                    else xmin = std::max(t, xmin);
                    NUPACK_REQUIRE(c * t + v, >=, 0);
                }
            });

            // if (xmax <= xmin) return;
            // if (xmax <= xmin) xi = std::clamp(xi, ops.minimum, ops.maximum);
            if (xmax <= xmin) xi = std::clamp(0.5 * (xmin + xmax), ops.minimum, ops.maximum); // or 0?
            // if (xmax <= xmin) xi = 0.5 * (xmin + xmax); // or 0?
            else if (q.positive_definite()) xi = q.bounded_solution(xmin, xmax).first;

            ratio.reset(q, xi);
            Cx += C.col(i) * (xi - x0);
        });
    }

    // 0 is a nasty solution that can sometimes happen.
    // To bail out, use the maximum delta function for x
    if (la::all(x == 0)) {
        x.randu();
        ratio = MatrixRatio<T>(x, A, B);
        // auto const i = (la::clamp(A.diag(), 0, real(*inf)) / (B.diag().replace(0, 1))).index_max();
        // print(i, A.n_cols);
        // x(i) = 1;
        // ratio.xax = A(i, i);
        // ratio.xbx = B(i, i);
        // NUPACK_REQUIRE(B(i, i), >, 0);
        satisfied = false;
    }

    // ratio.normalize(x, la::norm(x, ops.norm));
    ratio.normalize(x, la::accu(x));
    return {r1, ratio.value(x), satisfied};
}

/******************************************************************************************/

enum class Init {random, identity, eigenvectors};

template <class T>
la::Mat<T> initial_guess(la::Mat<T> const &A, la::Mat<T> const &B, usize m, Init init) {
    la::Mat<T> C(A.n_rows, m);
    switch (init) {
        case Init::random: {
            print("random");
            C.randu();
            return C;
        }
        case Init::eigenvectors: {
            print("eigen");
            la::Col<T> eigval;
            la::Mat<T> eigvec, Bh;

            // Try generalized eigenvector approach. If it doesn't work just take the maximum eigenvectors of B
            if (la::sqrtmat_sympd(Bh, B) && la::inv_sympd(Bh, Bh)) {
                NUPACK_ASSERT(la::eig_sym(eigval, eigvec, Bh * A * Bh));
                C = Bh * eigvec.tail_cols(m);
            } else {
                NUPACK_ASSERT(la::eig_sym(eigval, eigvec, B));
                C = eigvec.tail_cols(m);
            }
            return C;
        }
        case Init::identity: {
            print("identity");
            C.zeros();
            C.head_rows(m).diag() += 1;
            return C;
        }
    }
    NUPACK_ERROR("Invalid init", init);
}

/******************************************************************************************/

}
