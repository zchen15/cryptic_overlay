#pragma once
#include "../types/Matrix.h"
#include "BoundSolve.h"

namespace nupack {

/******************************************************************************/

template <class T>
struct ReferenceDIIS {
    std::deque<Mat<T>> history;
    std::size_t max_history;

    explicit ReferenceDIIS(std::size_t max) : max_history(max) {
        if (max == 0) throw std::invalid_argument("History length cannot be 0");
    }

    std::pair<Mat<T>, Mat<T>> matrices() const {
        if (!history.size()) return {};
        Mat<T> E(history[0].n_rows, history.size()), X(history[0].n_rows, history.size());
        izip(history, [&](auto i, auto const &h) {
            X.col(i) = h.col(0);
            E.col(i) = h.col(1);
        });
        return {std::move(X), std::move(E)};
    }

    // return fit coefficients, fit vector, predicted error
    std::tuple<Col<T>, Col<T>, Col<T>> fit(Col<T> const &x) const {
        auto [X, E] = matrices();
        for (auto i : range(X.n_cols)) X.col(i) -= x; // the error is just the residual in x
        Col<T> c = la::solve(X.t() * X, Col<T>(history.size(), la::fill::ones));
        c /= la::accu(c);
        return {c, X * c, E * c};
    }

    // Given an observed vector, guess what the corresponding error vector would be
    Col<T> error_prediction(Col<T> const &x) const {return std::get<2>(fit(x));}

    void emplace(Col<T> const &x, Col<T> const &err) {
        history.emplace_back(x.n_rows, 2);
        history.back().col(0) = x;
        history.back().col(1) = err;
        while (history.size() > max_history) history.pop_front();
    }

    Col<T> next_guess() const {
        if (history.empty()) return {};
        auto const [X, E] = matrices();
        // Col<T> c = la::sum(la::pinv(E.t() * E)).t();
        Col<T> c = la::solve(E.t() * E, Col<T>(history.size(), la::fill::ones));
        c /= la::accu(c);
        return X * std::move(c);
    }

    // Given observed vector and error vector, generate the DIIS-decided next vector
    Col<T> operator()(Col<T> const &x, Col<T> const &err) {
        emplace(x, err);
        return next_guess();
    }
};

/******************************************************************************/

/// In addition to keeping input and error history matrices X, E, FastDIIS also holds
/// an updated version of the inverse of E^T E as A to achieve a lower (m * n) complexity
template <class T>
struct FastDIIS {
    Mat<T> X, E, A;
    Col<T> c;
    std::size_t max_history, index = 0;

    explicit FastDIIS(std::size_t max) : max_history(max), A(max, max), c(max) {
        if (max == 0) throw std::invalid_argument("History length cannot be 0");
    }

    Col<T> operator()(Col<T> const &x, Col<T> const &err) {
        auto i = index++;
        if (i == 0) {
            A(0, 0) = 1 / dot(err, err);
            X.set_size(x.n_rows, max_history);
            E.set_size(x.n_rows, max_history);
            X.col(0) = x;
            E.col(0) = err;
            c = {1};
            return x;
        }
        if (i < max_history) {
            X.col(i) = x;
            E.col(i) = err;
            auto const s = la::span(0, i-1);
            auto const Ai = A(s, s);
            c = E.head_cols(i).t() * err;
            Col<T> Aic = Ai * c;
            T const d = sq(la::norm(err));
            T const scale = 1 / (d - dot(c, Aic));
            c = scale * Aic;
            A(i, i) = scale;
            A(i, s) = -c.t();
            A(s, i) = -c;
            A(s, s) += Aic * c.t();
            c = la::sum(A(la::span(0, i), la::span(0, i))).t();
            c *= 1 / la::accu(c);
            return X.head_cols(i+1) * c;
        } else {
            i = i % max_history;
            c = E.t() * -E.col(i); // (n * m)
            X.col(i) = x; // (n)
            E.col(i) = err; // (n)
            c += E.t() * E.col(i); // (n * m)
            c(i) /= 2;
            Col<T> const w = A * c; // (n * m)
            T const a = w(i), b = dot(c, w), d = A(i, i);
            c = A.col(i);
            T const rec = b * d - 1 - 2 * a - sq(a);
            A += la::outer(((1 + a) / rec) * c + (-d / rec) * w, w); // (m * m)
            A += la::outer(((1 + a) / rec) * w + (-b / rec) * c, c); // (m * m)
            c = la::sum(A).t(); // (m * m)
            c *= 1 / la::accu(c); // (m)
            return X * c; // (n * m)
        }
    }
};

/******************************************************************************/

template <class T>
struct NonnegativeDIIS : FastDIIS<T> {
    using base_type = FastDIIS<T>;
    using base_type::c;
    using base_type::E;
    using base_type::X;

    std::size_t iters;
    T tol;

    explicit NonnegativeDIIS(std::size_t max, std::size_t it=5000, T t=1e-12)
        : base_type(max), iters(it), tol(t) {}

    Col<T> operator()(Col<T> const &x, Col<T> const &err) {
        Col<T> u = base_type::operator()(x, err);
        if (u.min() >= 0) return u;
        std::size_t const l = min(base_type::index+1, c.n_rows);
        Mat<T> A = E.head_cols(l).t() * E.head_cols(l);

        // Rescale back so A c is all 1s
        T const scale = 1 / dot(A.col(0), c);
        c *= scale;
        u *= scale;
        // the residual m starts at 0 because we already solved least squares
        // Col<T> diag(A.diag()), m(c.n_rows, la::fill::zeros), y = u;
        // c.zeros();
        for (auto &e : c) if (e < 0) e = 0;
        // Col<T> diag(A.diag()), m(c.n_rows, la::fill::ones), y(u.n_rows, la::fill::zeros);
        Col<T> diag(A.diag()), m = 1 - A * c, y = X.head_cols(l) * c;
        std::size_t z = 0;

        for (; z < iters && (z == 0 || la::max(la::abs(c - u)) > tol * la::accu(c)); ++z) {
            u = c;
            for (std::size_t k = 0; k != A.n_cols; ++k) {
                T t = c(k) + m(k) / diag(k);
                y += (t - c(k)) * X.col(k);

                T const limit = -tol * la::norm(y, 1);
                T bump = 0;
                for (auto i : range(y.n_rows))
                    if (y(i) < limit && X(i, k) > 0) max_eq(bump, -y(i) / X(i, k));
                if (bump != 0) {
                    y += bump * X.col(k);
                    t += bump;
                }
                if (Debug) NUPACK_REQUIRE(y.min(), >, -tol * la::norm(y, 1));
                if (t != c(k)) m += (c(k) - t) * A.col(k);
                c(k) = t;
            }
        }
        c /= la::accu(c);
        u = X.head_cols(l) * c;
        NUPACK_REQUIRE(u.min(), >=, -tol * la::norm(u, 1));
        for (auto &e : u) if (e < 0) e = 0;
        return u;
    }
};

/******************************************************************************/

template <class T>
void render(Document &doc, Type<ReferenceDIIS<T>> t) {
    doc.type(t, "numeric.ReferenceDIIS");
    doc.method(t, "new", rebind::construct<std::size_t>(t));
    doc.method(t, "()", &ReferenceDIIS<T>::operator());
    doc.method(t, "error_prediction", &ReferenceDIIS<T>::error_prediction);
    doc.method(t, "matrices", &ReferenceDIIS<T>::matrices);
}

template <class T>
void render(Document &doc, Type<FastDIIS<T>> t) {
    doc.type(t, "numeric.FastDIIS");
    doc.method(t, "new", rebind::construct<std::size_t>(t));
    doc.method(t, "()", &FastDIIS<T>::operator());
}

template <class T>
void render(Document &doc, Type<NonnegativeDIIS<T>> t) {
    doc.type(t, "numeric.NonnegativeDIIS");
    doc.method(t, "new", rebind::construct<std::size_t, std::size_t, T>(t));
    doc.method(t, "()", &NonnegativeDIIS<T>::operator());
}

}
