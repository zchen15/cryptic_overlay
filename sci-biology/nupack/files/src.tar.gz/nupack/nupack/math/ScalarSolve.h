#pragma once
#include "RatioSolve.h"
#include "Inversion.h"
#include <variant>

namespace nupack::trace {

/******************************************************************************************/

/*
Maximize $\frac{a x^2 + b x + c}{d x^2 + e x + f}$
Both polynomials are assumed to be positive semidefinite, i.e. $a \geq 0, c \geq 0, 4 a c \geq b^2$
*/
template <class T>
struct UnboundedColumnSolver {
    T inf = 1e10;

    template <class X, class A, class B>
    std::pair<T, T> operator()(X &&x, A const &a, B const &b) const {
        return maximize_column([&](Ratio<T> const &q) {
            return q.unbounded_solution(inf);
        }, x, a, b, 2);
    }
};

/******************************************************************************************/

/*
Maximize $\frac{a x^2 + b x + c}{d x^2 + e x + f}$
subject to $x \geq 0$
Both polynomials are assumed to be positive semidefinite, i.e. $a \geq 0, c \geq 0, 4 a c \geq b^2$
*/
template <class T>
struct NonNegativeColumnSolver {
    T inf = 1e10;

    template <class X, class A, class B>
    std::pair<T, T> operator()(X &&x, A const &a, B const &b) const {
        return maximize_column([&](Ratio<T> const &q) {
            return q.nonnegative_solution(inf);
        }, x, a, b, 1);
    }
};

/******************************************************************************************/

/*
Maximize $\frac{a x^2 + b x + c}{d x^2 + e x + f}$
subject to $x0 <= x <= x1$
Both polynomials are assumed to be positive semidefinite, i.e. $a \geq 0, c \geq 0, 4 a c \geq b^2$
*/
template <class T>
struct BoundedColumnSolver {
    T xmin = 0, xmax = 0;

    template <class X, class A, class B>
    std::pair<T, T> operator()(X &&x, A const &a, B const &b) const {
        return maximize_column([&](Ratio<T> const &q) {
            return q.bounded_solution(xmin, xmax);
        }, x, a, b, 2);
    }
};

/******************************************************************************************/

template <bool Debug=false, class S, class T>
void maximize_init(S const &solver, Output<T> &out, la::Mat<T> const &A, la::Mat<T> const &B, Options<T> const &ops) {
    auto const m = out.solution.n_cols;
    if (m == 0) {
        out.converged = true;
        out.objective = 0;
    } else if (m == 1) {
        for (; out.iters != ops.iters; ++out.iters) {
            auto const [r1, r2] = solver(out.solution.col(0), A, B);
            out.objective = r2;
            if (!(r2 - r1 > r2 * ops.tolerance)) {out.converged = true; break;}
        }
    } else {
        Optimizer<T> o(out.solution, A, B);

        o.calculate_inverses();
        out.objective = o.objective();

        for (; out.iters != ops.iters; ++out.iters) {
            T improvement = 0;
            for (uint i = 0; i != m; ++i) {
                auto p = solver(o.column(), o.Ap, o.Bp); // O(N^2)
                o.update_inverses();
                improvement += p.second - p.first;
            }
            if (ops.refresh) {
                o.calculate_inverses();
                improvement = o.objective() - out.objective;
            }

            out.objective += improvement;

            // print(improvement, out.objective);
            // if (out.iters > 1000)
            if (!(improvement > ops.tolerance * out.objective)) {out.converged = true; break;}
        }
    }
}

/******************************************************************************************/

/*
Maximize $\mathrm{Tr} C^T A C (C^T B C)^{-1}$ subject to $C \geq 0$
A, B is assumed symmetric positive semi-definite
*/
template <bool Debug=false, class T>
Output<T> maximize_trace(la::Mat<T> X, la::Mat<T> const &A, la::Mat<T> const &B, Options<T> const &ops={}) {
    Output<T> out;
    out.solution = std::move(X);
    if (ops.minimum == 0) maximize_init(NonNegativeColumnSolver<T>{ops.maximum}, out, A, B, ops);
    if (ops.maximum == -ops.minimum) maximize_init(UnboundedColumnSolver<T>{ops.maximum}, out, A, B, ops);
    else maximize_init(BoundedColumnSolver<T>{ops.minimum, ops.maximum}, out, A, B, ops);
    return out;
}

/******************************************************************************************/

template <class T>
Output<T> trace_maximum(usize m, la::Mat<T> const A, la::Mat<T> const B, Init init, Options<T> const &ops={}) {
    return maximize_trace(initial_guess(A, B, m, init), A, B, ops);
}

/******************************************************************************************/

}
