#include "ScalarSolve.h"
#include "StationarySolve.h"

namespace nupack::trace {

void render(Document &doc, Type<Output<real>> t) {
    doc.type(t, "trace.Output");
    render_public(doc, t);
}

void render(Document &doc, Type<Options<real>> t) {
    doc.type(t, "trace.Options");
    render_public(doc, t);
    doc.method(t, "new", rebind::construct<real, real, real, uint, bool>(t));
}

void render(Document &doc, Type<ConstraintOptions<real>> t) {
    doc.type(t, "trace.ConstraintOptions");
    render_public(doc, t);
    doc.method(t, "new", rebind::construct<real, real, real, uint, uint>(t));
}

}

namespace nupack {
    void render_trace(Document &doc) {
        doc.function("trace.stationary_maximum", trace::stationary_maximum<real>);
        doc.function("trace.trace_maximum", trace::trace_maximum<real>);
    }
}
