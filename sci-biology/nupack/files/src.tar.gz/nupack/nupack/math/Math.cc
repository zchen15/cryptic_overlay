#include "BoundSolve.h"
#include "DIIS.h"
#include "Gaussian.h"
#include "Matrices.h"

namespace nupack {

/**************************************************************************************/

void render(Document &doc, Type<GaussianOptions> t) {
  doc.type(t, "numeric.GaussianOptions");
  render_public(doc, t);
  doc.method(t, "new", rebind::construct<AlternatingOptions, real, real>(t));
}

/**************************************************************************************/

template <class T>
void mask_to_zero(Col<T> &c, rebind::ArrayView const &mask) {
    NUPACK_REQUIRE(mask.layout.depth(), ==, 1);
    NUPACK_ASSERT(mask.layout.column_major());
    auto b = mask.data.target<bool>();
    NUPACK_ASSERT(b, "array does not contain type bool");
    for (auto it = c.begin(); it != c.end(); ++b, ++it) if (*b) *it = 0;
}

/**************************************************************************************/

void render(Document &doc, Type<AlternatingOptions> t) {
    doc.type(t, "numeric.AlternatingOptions");
    render_public(doc, t);
    doc.method(t, "new", rebind::construct<std::size_t, double, bool>(t));
}

void render(Document &doc, Type<ScalarBound> t) {
    doc.type(t, "numeric.ScalarBound");
    render_public(doc, t);
    doc.method(t, "new", rebind::construct<real, real, real>(t));
}

/**************************************************************************************/

void render_math(Document &doc) {
    doc.function("numeric.ref_test", [](arma::Col<double> &m) {m.fill(5);});
    doc.function("numeric.mask_to_zero", mask_to_zero<float>);
    doc.function("numeric.mask_to_zero", mask_to_zero<double>);

    doc.function("numeric.als", als<Mat<double>, double>);
    doc.function("numeric.ntf", als<Mat<double>, double>);

    doc.function("numeric.sparse_pair_matrix", la::sparse_pair_matrix<real>);

    doc.render<FastDIIS<real>>();
    doc.render<ReferenceDIIS<real>>();
    doc.render<NonnegativeDIIS<real>>();

    rebind::Pack<float, double>::for_each([&](auto t) {
        using T = decltype(*t);

        rebind::Pack<ScalarBound, VectorBound<T>>::for_each([&](auto b) {
            doc.function("numeric.bound_solve", bound_solve<decltype(*b), arma::Mat<T>, T>);
            doc.function("numeric.bound_solve", bound_solve<decltype(*b), arma::SpMat<T>, T>);
        });

        doc.function("numeric.gmm_squared_loss", gmm_squared_loss<
            T, arma::Cube<T>, arma::Cube<T>, std::array<arma::Col<T>, 3>, arma::umat
        >);

        doc.function("numeric.gmm_squared_loss", gmm_squared_loss<
            T, arma::Mat<T>, arma::Cube<T>, std::array<arma::Col<T>, 2>, arma::umat
        >);
    });
}

/**************************************************************************************/

}
