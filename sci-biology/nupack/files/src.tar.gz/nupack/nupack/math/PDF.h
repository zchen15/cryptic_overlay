
#pragma once
#include "../common/Random.h"
#include "../common/Constants.h"
#include "../common/Error.h"
#include <boost/math/special_functions/binomial.hpp>
#include <boost/math/special_functions/gamma.hpp>

namespace nupack {

/******************************************************************************************/

template <class Distribution, class Out=double>
struct PDF;

/// Poisson distribution defined in terms of its mean
template <class T, class Out>
struct PDF<std::poisson_distribution<T>, Out> {
    using D = std::poisson_distribution<T>;
    D dist;
    Out scale;

    PDF(D d) : dist(d), scale(std::exp(-dist.mean())) {}
    explicit PDF(Out mean) : PDF(D(mean)) {NUPACK_REQUIRE(mean, >=, 0);}

    NUPACK_REFLECT(PDF, dist, scale);

    Out operator()(T i) const {
        return scale * std::pow(dist.mean(), i) / std::tgamma(i + 1);
    }

    std::array<Out, 1> parameters() const {return {dist.mean()};}

    friend std::ostream &operator<<(std::ostream &os, PDF const &p) {
        return os << "Poisson(" << p.dist.mean() << ")";
    }
};

/******************************************************************************************/

template <class T, class Out>
struct GatedPoisson {
    std::poisson_distribution<T> poisson;
    Out gate;

    NUPACK_REFLECT(GatedPoisson, poisson, gate);
    GatedPoisson(Out g, Out m) : poisson(m), gate(g) {}

    template <class RNG>
    T operator()(RNG &rng) {return (random_float(rng) < gate) ? poisson(rng) : T(0);}
};

template <class T, class Out>
struct PDF<GatedPoisson<T, Out>> {
    GatedPoisson<T, Out> dist;
    Out scale;

    PDF(Out gate, Out mean) : dist(gate, mean), scale(gate * std::exp(-mean)) {}
    NUPACK_REFLECT(PDF, dist, scale);

    Out operator()(T i) const {
        if (!i) return (1 - dist.gate) + scale;
        return scale * std::pow(dist.poisson.mean(), i) / std::tgamma(i + 1);
    }

    std::array<Out, 2> parameters() const {return {dist.gate, dist.poisson.mean()};}

    friend std::ostream &operator<<(std::ostream &os, PDF const &p) {
        return os << "GatedPoisson(" << p.dist.gate << ", " << p.dist.poisson.mean() << ")";
    }
};

/******************************************************************************************/

/// Gamma distribution defined in terms of its shape and scale
template <class T, class Out>
struct PDF<std::gamma_distribution<T>, Out> {
    using D = std::gamma_distribution<T>;
    D dist;
    T constant;

    NUPACK_REFLECT(PDF, dist, constant);

    explicit PDF(D d) : dist(d), constant(-dist.alpha() * std::log(dist.beta()) - std::lgamma(dist.alpha())) {
        NUPACK_REQUIRE(dist.alpha(), >=, 0);
        NUPACK_REQUIRE(dist.beta(), >, 0);
        NUPACK_ASSERT(std::isfinite(constant));
    }
    explicit PDF(T alpha, T beta) : PDF(D(alpha, beta)) {}

    // log pdf = -(x/b) - a Log[b] + (a - 1) Log[x] - Log[Gamma[a]]
    Out log_pdf(T x) const {return constant + (dist.alpha() - 1) * std::log(x) - x / dist.beta();}

    Out cumulative(T x) const {return boost::math::gamma_p(dist.alpha(), x / dist.beta());}

    Out operator()(T x) const {return std::exp(log_pdf(x));}

    Out mean() const {return dist.alpha() * dist.beta();}
    static PDF from_mean(T mean, T beta) {return PDF(mean / beta, beta);}

    std::array<Out, 2> parameters() const {return {dist.alpha(), dist.beta()};}

    friend std::ostream &operator<<(std::ostream &os, PDF const &p) {
        return os << "Gamma(" << p.dist.alpha() << ", " << p.dist.beta() << ")";
    }
};

/******************************************************************************************/

/// Normal distribution defined in terms of its mean and std deviation
template <class T, class Out>
struct PDF<std::normal_distribution<T>, Out> {
    using D = std::normal_distribution<T>;
    D dist;
    T denom, scale;

    NUPACK_REFLECT(PDF, dist, denom, scale);

    explicit PDF(D d) : dist(d), denom(-1 / (2 * dist.stddev() * dist.stddev())),
        scale(1 / std::sqrt(2 * Pi * dist.stddev() * dist.stddev())) {}
    explicit PDF(T mean, T stddev) : PDF(D(mean, std::abs(stddev))) {}

    Out operator()(T x) const {
        auto xm = x - dist.mean();
        return scale * std::exp(xm * xm * denom);
    }
};

/******************************************************************************************/

/// Isotropic normal distribution about 0 in any number of dimensions, in terms of the radial coordinate
template <class T>
struct RadialDistribution {
    std::normal_distribution<T> normal;
    uint dimension;

    RadialDistribution(T std, uint d) : normal(0, std), dimension(d) {}

    template <class RNG>
    T operator()(RNG &rng) {
        T r2 = 0;
        for (uint i = 0; i != dimension; ++i) r2 += sq(normal(rng));
        return std::sqrt(r2);
    }
};

/******************************************************************************************/

template <class T, class Out>
struct PDF<RadialDistribution<T>, Out> {
    using D = RadialDistribution<T>;
    D dist;
    T scale, denom;

    explicit PDF(T s, uint d) : dist{s = std::abs(s), d} {
        // \frac{2^{1-\frac{n}{2}} \left| s\right| ^{-n}}{\Gamma \left(\frac{n}{2}\right)}
        denom = -1 / (2 * s * s);
        scale = std::pow(2.0, 1 - 0.5 * dist.dimension)
              / std::tgamma(0.5 * dist.dimension) / std::pow(s, dist.dimension);
    }

    Out operator()(T x) const {
        // same as normal distribution but multiply by volume element (and scale)
        return scale * std::pow(x, dist.dimension-1) * std::exp(x * x * denom);
    }
};

/******************************************************************************************/

/// Gamma distribution defined in terms of its maximum and its success probability
template <class T, class Out>
struct PDF<std::binomial_distribution<T>, Out> {
    using D = std::binomial_distribution<T>;
    D dist;
    explicit PDF(T max, Out p) : dist(max, p) {NUPACK_REQUIRE(p, >=, 0); NUPACK_REQUIRE(p, <=, 1); NUPACK_REQUIRE(max, >=, 0);}

    NUPACK_REFLECT(PDF, dist);

    Out operator()(T i) const {
        if (i > dist.t()) return 0;
        return boost::math::binomial_coefficient<Out>(dist.t(), i)
            * std::pow(dist.p(), i) * std::pow(1 - dist.p(), dist.t() - i);
    }
};

/******************************************************************************************/

template <class T>
void render(Document &doc, Type<PDF<std::normal_distribution<T>>> t) {
    doc.type(t, "numeric.Normal");
    doc.method(t, "new", rebind::construct<real, real>(t));
}

template <class T>
void render(Document &doc, Type<PDF<std::gamma_distribution<T>>> t) {
    doc.type(t, "numeric.Gamma");
    doc.method(t, "new", rebind::construct<real, real>(t));
    doc.method(t, "()", &decltype(*t)::operator());
}

template <class T>
void render(Document &doc, Type<PDF<RadialDistribution<T>>> t) {
    doc.type(t, "numeric.Radial");
    doc.method(t, "new", rebind::construct<real, int>(t));
}

template <class T, class Out>
void render(Document &doc, Type<PDF<GatedPoisson<T, Out>>> t) {
    doc.type(t, "numeric.GatedPoisson");
    doc.method(t, "new", rebind::construct<real, real>(t));
    doc.method(t, "()", &decltype(*t)::operator());
}

template <class T>
void render(Document &doc, Type<PDF<std::poisson_distribution<T>>> t) {
    doc.type(t, "numeric.Poisson");
    doc.method(t, "new", rebind::construct<real>(t));
    doc.method(t, "()", &decltype(*t)::operator());
}

/******************************************************************************************/

}
