#pragma once
#include "../types/Matrix.h"

namespace nupack {

/******************************************************************************************/

template <class T>
real sparsity(T const &t) {return 1 - std::count(begin_of(t), end_of(t), 0) / real(len(t));}

/******************************************************************************************/

/// Make a matrix from a list of tuples where it is nonzero (x, y, value)
template <class Mat, class Tuples, NUPACK_IF(la::is_dense<Mat>)>
Mat matrix_from_tuples(usize n_rows, usize n_cols, Tuples const &tups) {
    Mat ret(n_rows, n_cols); la::fill_zero(ret);
    for (auto const &t : tups) ret(first_of(t), second_of(t)) += third_of(t);
    return ret;
};

/******************************************************************************************/

template <class Mat, class Tuples, NUPACK_IF(la::is_sparse<Mat>)>
Mat matrix_from_tuples(usize const n_rows, usize const n_cols, Tuples const &tups) {
    la::vec values(len(tups));
    la::umat locs(2, len(tups));
    for (auto i : indices(tups)) {
        locs(0, i) = first_of(tups[i]);
        locs(1, i) = second_of(tups[i]);
        values(i) = third_of(tups[i]);
    }
    return {locs, values, n_rows, n_cols};
}

/******************************************************************************************/

/// Take square matrix of probabilities
/// Return diagonal entries, off-diagonal entries, rows, columns
/// if n is 0, return all entries, else return the n highest non-diagonal entries in each row
// complexity is N^2 log(n) + N n log(n N) \approx N^2 log(n) + N n log(N)
template <class T>
auto sparse_pair_matrix(Mat<T> const &m, std::size_t n=0) {
    NUPACK_REQUIRE(m.n_rows, ==, m.n_cols);
    Col<T> values;
    Col<la::uword> rows, cols;

    if (n == 0) n = m.n_rows - 1;
    else n = min(n, m.n_rows-1);

    if (m.n_rows <= 1) {
        // no off diagonal
    } else if (m.n_rows - 1 == n) {
        for_each(std::tie(values, rows, cols), [&](auto &x) {x.set_size(m.n_rows * n / 2);});
        la::uword p = 0;
        for (auto j : range(m.n_rows)) for (auto i : range(0, j)) {
            rows(p) = i;
            cols(p) = j;
            values(p) = m(i, j);
            ++p;
        }
    } else {
        std::vector<la::uword> idx;
        std::vector<std::pair<la::uword, la::uword>> v;
        v.reserve(m.n_rows * n);

        for (auto const j : range(m.n_rows)) {
            // all possible column indices
            idx.assign(range(m.n_rows).begin(), range(m.n_rows).end());
            // partially sort to get the n biggest column indices
            std::nth_element(idx.begin(), idx.begin() + n, idx.end(), [j, c=m.col(j)](auto i1, auto i2) {
                if (i1 == j) return false; // don't include on-diagonal elements
                if (i2 == j) return true;
                return c(i1) > c(i2);
            });
            // only include nonzero elements
            for (auto it = idx.begin(); it != idx.begin() + n; ++it)
                if (m(*it, j) != 0) v.emplace_back(std::minmax(*it, j));
        }
        v = unique_sorted(std::move(v));
        for_each(std::tie(values, rows, cols), [&](auto &x) {x.set_size(v.size());});
        zip(v, values, rows, cols, [&m](auto const &p, auto &x, auto &r, auto &c) {
            r = p.first; c = p.second; x = m(r, c);
        });
    }

    return std::make_tuple(Col<T>(m.diag()), std::move(values), std::move(rows), std::move(cols));
}

}
