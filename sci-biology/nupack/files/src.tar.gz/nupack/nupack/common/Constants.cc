/**
 * @brief Defines default random number generator and other constants
 *
 * @file Constants.cc
 * @author Mark Fornace
 * @date 2018-05-31
 */
#include "Threading.h"
#include "Constants.h"
#include "Random.h"
#include "Error.h"
#include "Costs.h"

#include "../reflect/Print.h"
#include "../reflect/Serialize.h"
#include "../execution/Local.h"
#include "../types/IO.h"
#include "../types/Sequence.h"
#include "../reflect/Serialize.h"
#include "../math/Sparse.h"

#include <nupack/Version.h>

namespace nupack {

thread_local SharedMode GlobalSharedMode = SharedMode::copy;
thread_local std::vector<std::pair<void const *, nlohmann::json>> GlobalSharedState;

/// This may be used to turn knobs in development code without recompiling completely
string HackHelper = "";

/******************************************************************************************/

std::random_device Static_RD;

#ifndef NUPACK_RANDOM_DEVICE
#   error("NUPACK_RANDOM_DEVICE should be defined")
#elif NUPACK_RANDOM_DEVICE
    bool const RandomDevice = (arma::arma_rng::set_seed_random(), true);
    thread_local std::mt19937 StaticRNG{Static_RD()};
#else
    bool const RandomDevice = false;
    thread_local std::mt19937 StaticRNG{};
#endif

/******************************************************************************************/

// In Kelvin, Tanaka M., Girard, G. et al, Metrologia, 2001 38, 301-309.
real water_molarity(real T) {
   constexpr real const a1 = -3.983035 - ZeroCinK, a2 = 301.797 - ZeroCinK,
                        a3 = 522528.9, a4 = 69.34881 - ZeroCinK, a5 = 999.974950;
   return a5 * (1 - (T + a1) * (T + a1) * (T + a2) / a3 / (T + a4)) / 18.0152;
};

// No correction for RNA since we don't have parameters
real dna_salt_correction(real t, real na, real mg, bool long_helix) {
  // Ignore magnesium for long helix mode (not cited why, for consistency with Mfold)
  NUPACK_REQUIRE(na, >=, 0.05); NUPACK_REQUIRE(na, <=, 1.1);
  NUPACK_REQUIRE(mg, >=, 0);    NUPACK_REQUIRE(mg, <=, 0.2);
  if (long_helix) return -(0.2 + 0.175 * std::log(na)) * t / DefaultTemperature;
  return -0.114 * std::log(na + 3.3 * std::sqrt(mg)) * t / DefaultTemperature;
}

/******************************************************************************************/

std::string ReferenceSequence = "TTCCGTAGCGGAGGTCTATGTCCTCAATGTTTCGCGTCGTATTTATTTGCAAACAGATACGCATTCCCCCCCTGCCTTCCGAGCTGTTGCTACTTCACCAACTCGCGCTTAATGCATGAAACTCTAGTTCACTCACCGATTAGTTATCGATTAAGAAGAGACCAGTTGGGAATTAGCTAACCGCAACAAGAACGACCATATAGAGTTGTCTCCTAGTCTCAGCATTTGGCGAGGTTCAGTCCTTATTGCACGCTGGACCAAACGTCTCCTTGTCTACTAAAAATTCAATGGACTATGAGGAGCTCGTATAGAAGCTCGAATGGGTGCTCTATCCTCCGACTGTTTGAAAACATATGAAGACCAACGGTAATACACACGGTATCTACTTCAAGAAGCTGTGTTTGCCGAGCTCGACGATGTCACTGGCCGGTCCGGTGTGTACACCTATAGGGGGATTTGGTGTCCCCTTGTAGAAGCTAAGTTACCTGTTTGGCTATTAGCGTCGTGTGTAATGTTAATCTGCGATACTTATGAAATCGCATTGGTTTGCAGTTTCTCTACGCTGGTGTAGGACCGAGATAAAGTCGTGCGATAGTTATATAAGTACGAGAGTCAGAGCGCCGTTCAATAAGGTCCCGTGCCGTCCCCCCGTTGTTGCTGTCTCCTTGCGAAATGGATGATGACCAGGTTGGATAGAGAGCGCGACTTCTCGCTGGCTCGGTGATCGCTCGAGACTAGGACAACGGGGGCTATTGAGTGGACCTGACTACTATCCTATTGTCAGAAATGGCCACCTACACGCCTAACTGACTGGACGTTCGTAGTTGATCTGTTAAAACGAGAACTAGCACACTCAACGGCGTGGGGGCTAGTCTTAGGAAAAGTTTGGAGAAGAAAGAAGACCAACGGAACCCATCGATTTGAATTGACGTTGGTGTCTTTTCGTACAAGACAGAGGCAAAATTATTTTGCTTACTTCGTCATACAAAATCATTATCCCTTGACCTGCGGCCCCGCGTAACACCACCTCTCTGATAAGTAGGTTGACTATTCAGGGGGTCCACGAGCTACACGATCGTGCTCAAGAATTCCTTCCGGAATTGACGCGTAATCAACAAAAACCGATATTAGGACGGGCCTGAGTAAGATAGTTGTAGGTGTCCACGGTCTAGTTAGGGTGGTGGGTCCGAGTTCGCGTTACTTTGTTCTGTCAAACTCGGCCTGTGTGCCGAGATAAAGGCCACGATCGTTATATCATGCCAAGCGTCGACAGTCGGAAGGAACGCAATCCGACCGTTCGACCCGTGACCCGTGCCATAAGGACAAACATCGAACATTATTTGCGGGAAAATTCCTACGAAGCGTCGCGCTTCGCAGGAGTGTACTAACTATGTAAGGGAAACCTTACCACAGCTCGCATAGCTGTTTTCAGCTGGTGTGTTCATTTCAAGCGGTAGGTGATTTTCAGATAGTGGCGCGGCCCTGCGGATGCGTTGGTGCTAACACCCTCTATCGACGGGTATGGGTAGGATTGAAACCCTGCTGTATGTGTTAGATATCGATGCCGACTGGAGCTCGGCCATGCTTCGTATAAATTGTTCGATTCGTCACGGGGGGCCCAAGAAATATGGCAAATACACAAATCGGGGTTATCGTGTTTGATTCGACCATCTCCTACCGGCACAATACACATTTTTACGGTTACATTACTCACTGCGTGAACTGACTGGAATCGTCTCTTGTTGGCCCATCACAAAAGCTTTGCGTAAGGCTGTATGAATGCTTTACGTTTCTGGCTGATACTGCTTAGGGGCCGATTATCTAGAGGAATTAACACCCACCGTGTTGTCCGGAGGGTGCGCCGAGTTCCGATTAGACTAAGAAAGCGTGGTCGGATATAGGCAATATCGGTGCCCAGTTCACCTGCTGGATCTCTTGCCCGTGCGCAACGCGGTGATACTTTGATTGATCCTTGATCGTAATCCGTGACCTGGAAGATGTACTCTTACAAACACGCACTGAACCCGGCGTCGCTCTCGAGCGGTGTAGGAAATCTCTATTTCCCCTGTGCTTGTGTCTGTAGATTACCTTACACGTTTTACTGTATGATGCGCATGCCTTTTCGAGGTACCCCGGGCTTGGAACGTAGTGGGGAGCGGGTTGACTTTTCATCTAATCAACCGCTAGGTATTACCACTAAAGGATCATCCAATTAACATCATTTCGGCATTCACCAAATTGTTTGGGTGAGTGATCTCTAGACTAATGTACTGACTAAATCAATCTACATGGGTCTCCAAAAGTGTTCCGTGGTACCCCTACTACCACCCTCCGACCTTGATGGAATAGTAGCGGGAGTCTGGAGTTGATGGGACACAGCATTCCTGGATGGAACAAAATCCGGTCGAACTGGCACGAGCTTAACAATCATACGCATCGACGCGGATAATCGCGGGTTGTTCGTACCAACTAATGCCTTATAAAGAAGCCACGGCAGATGTGACTAGACAGCAACTAGTGAGGTGTGCAGCAGAGCGCCAACACGTTACCAGAGCGAACGTATTAATATAATTATTCATGCTATAACAGTCGCCAACTAGTCTACACATGGAGGCACCTGTGGTGGGGCCATTTAATGCACATGTGGCCGATTGCACAAAGATGGGGCAGACTATCTCAAGTCGGATCGCTATTTATTCTCCTTCACTAAGCCGACAAGCTTATATTAAATCGCCACACTACAACGTAACTGTGGAATACAGCCTGGGTCACTACAGTAGTTGTCTCTTCAGCGGCGATACATAGAGGCATGAGCAATGTAGACGTTGCAAGCCTCAGCATGAAAGACGCTGATTATAAATCTCCCAGAAATTTTCAAGCTTAGTTGCCACATAGCTCGGCTTTTCTAATTATCTCCTCTCCGGCTTCACGTGTGCCGCCCCCAGCATTAAGTTCTTACCCCCATTGAAACGATCCGTCATGTCAATTTGAGTTATCGGC";

string reference_dna(std::size_t length) {
    if (length > ReferenceSequence.size()) throw std::out_of_range("reference_dna");
    return ReferenceSequence.substr(0, length);
}

void render(Document &doc, Type<Local> t) {
    doc.type(t, "core.Local");
    doc.method<0>(t, "new", rebind::construct<usize>(t));
    doc.method(t, "n_workers", &Local::n_workers);
}

void render_constants(Document &doc) {
    doc.function("constants.ldexp", [](float f, std::int32_t i) {
        print(bool(i));
    });

    doc.function("constants.read_lines", [](std::string_view path) {
        std::ifstream ifs{path.data()};
        if (!ifs.good()) NUPACK_ERROR("File does not exist", path);
        vec<std::string> lines;
        for (std::string s; std::getline(ifs, s);) lines.emplace_back(s);
        std::cout << lines.front() << std::endl;
        return lines;
    });

    doc.function("core.sparse_pair_matrix", sparse_pair_matrix<real>);

    /// Utility functions
    doc.function("constants.dp_to_pairs", [](std::string_view s) {return io::to_pairs(s);});

    doc.function("constants.unit_evaluation_cost_table", unit_evaluation_cost_table);
    doc.function("constants.unit_evaluation_costs", unit_evaluation_costs);
    doc.function("constants.unit_subblock_cost", unit_subblock_cost);
    doc.function("constants.subblock_cost", subblock_cost<small_vec<std::size_t>>);

    doc.function("constants.trim_cxx", [](std::string s) {return trim_type_name(std::move(s), 10000);});
    doc.function("constants.rotational_symmetry", &rotational_symmetry<small_vec<uint>>);
    doc.function("constants.compute_necklaces", [](rebind::AnnotatedCallback<void, small_vec<uint>> f, uint size, uint n) {
        return compute_necklaces(small_vec<uint>(size), n, std::move(f));
    });

    // doc.function("numeric.nnls", nnls<float, std::uint16_t, float>);
    // doc.function("numeric.nnls", nnls<float, float, float>);
    // doc.function("numeric.nnls", nnls<double, double, double>);
    doc.function("constants.water_molarity", water_molarity);
    doc.function("constants.dna_salt_correction", dna_salt_correction);
    doc.object("constants.ZeroCinK", ZeroCinK);
    doc.object("constants.DefaultTemperature", DefaultTemperature);
    doc.object("constants.BoltzmannConstant", Kb);
    doc.object("constants.GitBranch", GitBranch);
    doc.object("constants.GitRevision", GitRevision);
    doc.object("constants.Version", Version);

#   define NUPACK_TMP(scope, name, val)         \
        doc.function(scope name, [] {return val;}); \
        doc.function(scope "set_" name, [](decltype(val) const &v) {val = v;})
        NUPACK_TMP("constants.", "default_parameters_path", DefaultParametersPath);
        NUPACK_TMP("constants.", "total_ram", TotalRAM);
        NUPACK_TMP("constants.", "total_cpu", TotalCPU);
#   undef NUPACK_TMP
}

void render(Document &doc, Type<AlwaysTrue> t) {doc.type(t, "constants.AlwaysTrue");}

void render(Document &doc, Type<AlwaysFalse> t) {doc.type(t, "constants.AlwaysFalse");}

void render(Document &doc, Type<True> t) {doc.type(t, "constants.TrueType");} // TODO convert to bool?

void render(Document &doc, Type<False> t) {doc.type(t, "constants.FalseType");}

}

/******************************************************************************************/

namespace rebind {

void Renderer<nupack::json>::operator()(Document &doc) const {
    using J = nupack::json;
    Type<J> t;
    doc.type(t, "core.JSON");
    doc.method(t, "new", construct<>(t));
    doc.method(t, "load", [](J &j, std::string_view s) {j = J::parse(s);});
    doc.method(t, "save", [](J const &j, unsigned indent) {return indent ? j.dump(indent) : j.dump();});
}

}