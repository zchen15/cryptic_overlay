#!/bin/sh
echo "--------------------------------------------------------------------------------"
echo "Configuring NUPACK C++ code"

mkdir conda-build-cpp && cd conda-build-cpp

declare -a CMAKE_PLATFORM_FLAGS
if [[ ${HOST} =~ .*darwin.* ]]; then
  echo "Deduced a Mac OS X platform"
  export MACOSX_DEPLOYMENT_TARGET="10.14"
  CMAKE_PLATFORM_FLAGS+=(-DCMAKE_OSX_SYSROOT="${CONDA_BUILD_SYSROOT}")
  CMAKE_PLATFORM_FLAGS+=(-DNUPACK_SIMD_FLAGS="-msse;-msse2;-msse3;-msse4")
else
  echo "Deduced a Linux platform"
  CMAKE_PLATFORM_FLAGS+=(-DCMAKE_CXX_COMPILER="$PREFIX/bin/clang++")
  CMAKE_PLATFORM_FLAGS+=(-DCMAKE_TOOLCHAIN_FILE="${RECIPE_DIR}/cross-linux.cmake")
  CMAKE_PLATFORM_FLAGS+=(-DNUPACK_PIC=ON)
  CMAKE_PLATFORM_FLAGS+=(-DNUPACK_TBB_MALLOC=OFF)
  # CMAKE_PLATFORM_FLAGS+=(-DCMAKE_LINKER="$PREFIX/bin/ld")
  CMAKE_PLATFORM_FLAGS+=(-DCMAKE_POSITION_INDEPENDENT_CODE=ON)
  # CMAKE_PLATFORM_FLAGS+=(-DCMAKE_CXX_STANDARD_INCLUDE_DIRECTORIES=$PREFIX/include/c++/v1/)
  # CMAKE_PLATFORM_FLAGS+=(-DCMAKE_CXX_STANDARD_LIBRARIES="$PREFIX/lib/libc++.a $PREFIX/lib/libc++abi.a")
  CMAKE_PLATFORM_FLAGS+=(-DNUPACK_SIMD_FLAGS="-msse;-msse2;-msse3;-msse4")
fi

cmake -G Ninja \
    -DNUPACK_SHARED=ON \
    -DCMAKE_PREFIX_PATH=$PREFIX \
    -DCMAKE_INSTALL_PREFIX=$PREFIX \
    -DCMAKE_INSTALL_LIBDIR=$PREFIX/lib \
    -DCMAKE_BUILD_TYPE=Release \
    -DBoost_USE_STATIC_LIBS=ON \
    -DBoost_USE_STATIC_RUNTIME=ON \
    -DBLA_STATIC=ON \
    -DJSONCPP_WITH_TESTS=OFF \
    -DCMAKE_CXX_COMPILER=clang++ \
    ${CMAKE_PLATFORM_FLAGS[@]} \
    -DCMAKE_LIBRARY_PATH=$PREFIX/lib \
    -DCMAKE_SYSROOT=${CONDA_BUILD_SYSROOT} \
    -DBUILD_CXX=ON \
    -DBUILD_PYTHON=OFF \
    ..

echo "--------------------------------------------------------------------------------"
export JOBS="$((CPU_COUNT < 4 ? CPU_COUNT : 4))"
echo "Building NUPACK libraries using ${JOBS}/${CPU_COUNT} cores"

cmake --build . --target schema -- -v -j ${JOBS}

echo "--------------------------------------------------------------------------------"
echo "Installing NUPACK C++ libraries and include directories"

cmake --build . --target install

echo "--------------------------------------------------------------------------------"
