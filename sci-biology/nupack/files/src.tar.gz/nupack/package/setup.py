'''
NUPACK setup
'''

# Always prefer setuptools over distutils
from setuptools import setup, find_packages
from setuptools.command.install import install
# To use a consistent encoding
from codecs import open
from pathlib import Path
import platform
import subprocess as sp
from shutil import copy2
import os, site

NAME = '@NUPACK_NAME@' # configured by CMake

if '@' in NAME:
    NAME = 'nupack'

def fix_linking():
    dylib_substrings = ['boost', 'arpack', 'superlu', 'tbb', 'stdc++', 'blas', 'armadillo']
    lib_lines = sp.check_output(['ldd', NAME + '/nupack_cpp.so']).decode('utf-8').split('\n')
    toks = [x.split()[2:] for x in lib_lines]
    libs = [t[0] for t in toks if len(t) > 1 and any(y in t[0] for y in dylib_substrings)]
    Path(NAME + '/dylibs').mkdir(exist_ok=True)
    for lib in libs:
        copy2(lib, NAME + '/dylibs')

    root = site.getsitepackages()[0]
    sp.check_call(['patchelf','--set-rpath','$ORIGIN/dylibs', NAME + '/nupack_cpp.so'])
    for lib in (os.path.join(NAME + '/dylibs', x) for x in os.listdir(NAME + '/dylibs')):
        sp.check_call(['patchelf','--set-rpath','$ORIGIN',lib])
    return {NAME: ['nupack_cpp.so', 'parameters/*', 'dylibs/*', 'multitube*']}

here = Path(__file__).absolute().parent

# Get the long description from the README file
# with open(path.join(here, 'README.rst'), encoding='utf-8') as f:
#     long_description = f.read()

# https://stackoverflow.com/questions/20288711/post-install-script-with-python-setuptools
class PostInstallCommand(install):
    '''Post-installation for installation mode.'''
    def install_cxx_exes(self):
        pass

    def run(self):
        self.install_cxx_exes()
        install.run(self)

if False and platform.system() == 'Linux':
    package_data = fix_linking()
else:
    package_data = {NAME: ['nupack_cpp.so', 'parameters/*']}

setup(
    name=NAME,
    version='4.0.0',
    description='Nucleic Acid Package',
    url='www.nupack.org',
    package_data=package_data,
    packages=find_packages(include=(NAME + '**',)),
    scripts=[],
    cmdclass={'install': PostInstallCommand}
)

