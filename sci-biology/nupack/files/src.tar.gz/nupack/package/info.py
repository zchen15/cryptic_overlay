'''
File configured by CMake
Can include any CMake variables that are desired within the Python package
'''

version = '@CMAKE_PROJECT_VERSION@'
build_type = '@CMAKE_BUILD_TYPE@'
