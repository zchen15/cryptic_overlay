brew unlink armadillo
brew unlink tbb
brew unlink superlu
brew unlink arpack

cd package/cpp && \
conda-build -c conda-forge -c anaconda . && \
cd ../python && \
conda-build --python 3.7 -c conda-forge -c anaconda . -c local && \
conda-build --python 3.6 -c conda-forge -c anaconda . -c local && \
cd ../.. && \
mkdir -p ./package/conda/osx && \
mv ~/anaconda3/conda-bld/osx-64/nupack*bz2 ./package/conda/osx/

brew link superlu
brew link arpack
brew link tbb
# brew link armadillo
