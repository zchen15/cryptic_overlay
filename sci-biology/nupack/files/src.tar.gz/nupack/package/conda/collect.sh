
mkdir -p ${2}/nupack-${1}

rsync -avz --prune-empty-dirs --exclude='examples/' --exclude='external/json/benchmarks' --exclude='external/json/test/' --exclude='llvm/' --exclude='.git/' --exclude '*.bz2' --exclude ''  . ${2}/nupack-${1}-source

mkdir -p ${2}/nupack-${1}/osx-64
mkdir -p ${2}/nupack-${1}/linux-64
cp ./package/conda/osx/*${1}*.bz2 ${2}/nupack-${1}/osx-64
cp ./package/conda/linux/*${1}*.bz2 ${2}/nupack-${1}/linux-64
cp -r ./examples ${2}/examples

conda index ${2}/nupack-${1}

#tarring isnt very useful
#tar -czvf ${2}/nupack-${1}.tar.gz -C ${2} nupack-${1}
#rm -r ${2}/nupack-${1}
