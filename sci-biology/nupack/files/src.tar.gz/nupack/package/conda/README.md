## To update

1. Make necessary changes.
2. Change the version in `CMakeLists.txt`.
3. Commit the changes and run `git tag 4.0.8` or whatever.

## To build

1. Run `bash package/conda/osx.sh` locally on a Mac from the top-level directory.
2. Launch a docker container and run `bash package/conda/linux.sh` from within the VM.
3. Collect all the package files using something like this command:

```bash
bash package/conda/collect.sh 4.0.8 ~/Dropbox/NUPACK-4-prerelease/4.0.8
```
