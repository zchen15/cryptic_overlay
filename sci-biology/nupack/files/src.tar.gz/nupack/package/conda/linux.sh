cd package/cpp && \
conda-build -c conda-forge -c anaconda . && \
cd ../python && \
conda-build --python 3.7 -c conda-forge -c anaconda . && \
conda-build --python 3.6 -c conda-forge -c anaconda . && \
cd ../.. && \
mkdir -p /root/nupack/package/conda/linux && \
mv /root/miniconda3/conda-bld/linux-64/nupack*.bz2 /root/nupack/package/conda/linux/

