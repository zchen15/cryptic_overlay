#include "Test.h"
#include <nupack/math/BoundSolve.h>
#include <nupack/math/DIIS.h>
#include <nupack/common/Constants.h>

#include <nupack/thermo/Engine.h>
#include <nupack/thermo/CachedModel.h>
#include <nupack/model/Model.h>
#include <nupack/execution/Local.h>

// #include <nupack/thermo/Engine.h>
// #include <nupack/execution/Local.h>
// #include <nupack/thermo/Models.h>

namespace nupack {

/******************************************************************************************/

// UNIT_TEST("gamma") = [](Context ct) {
//     PDF<std::poisson_distribution<uint>> poisson(0.8);
//     ct.near(poisson(5), 0.001226967624682759);
//     PDF<std::gamma_distribution<double>> gamma(2, 2);
//     ct.near(gamma(4.5), 0.1185741276320974);
//     PDF<std::normal_distribution<double>> normal(2, 2);
//     ct.near(normal(4.5), 0.091324542694511);
//     PDF<std::binomial_distribution<uint>> binomial(6, 0.8);
//     ct.near(binomial(4), 0.24576);
// };

// UNIT_TEST("hmm") = [](Context ct) {
//     auto s = to_sequences("UAUUCUGAAAGGCUAAAAGCUCUU");
//     // BEEP(dynamic_program<3>(s, thermo::pf_model()));
//     auto mod = thermo::pf_model<real>(Ensemble::none);
//     BEEP(thermo::dynamic_program<4>(Local(), s, mod, {}, [](auto const &msg) {
//         print(msg.block.Q);
//         print(msg.block.B);
//     }));
//     mod.set_beta(0);
//     BEEP(thermo::dynamic_program<4>(Local(), s, mod));
// };

UNIT_TEST("hmm") = [](Context ct) {
    uint n = 20;
    Mat<real> Q(n, n);
    Q.fill(1);
    for (auto o : range(n)) {
        for (auto i : range(n)) {
            auto j = i + o;
            Q(i, j) = accu(Q(i, span(i, j-1)) * Q(span(i+2, j), j));
        }

    }
};

/******************************************************************************************/

}
