from nupack.design import Design, TimeInterval
from argparse import ArgumentParser
from nupack import Local

def output_count(prefix):
    counter = 0
    def inner(result):
        nonlocal counter

        filename = f"{prefix}-{counter}.out"
        with open(filename, 'w') as f:
            f.write(result.to_json(indent=4))
        counter += 1

    return inner

import os, time, threading
start = os.times()
print(start)

def print_cpu():
    global start
    while True:
        t = os.times()
        den = (t.elapsed - start.elapsed or 1)
        print(' '.join('%.4f' % ((getattr(t, k) - getattr(start, k)) / den)  for k in ('user', 'system', 'children_user', 'children_system')))
        time.sleep(10)
        start = t

def main():
    parser = ArgumentParser()
    parser.add_argument("filename")

    args = parser.parse_args()
    fn = args.filename

    t = threading.Thread(target=print_cpu, daemon=True)
    t.start()
    des = Design(json=open(fn).read())
    # res = des(checkpoint_condition=TimeInterval(1000), checkpoint_handler=output_count(fn))
    res = des(Local(1))

    with open(fn+".out", 'w') as f:
        f.write(res.to_json(indent=4))

    print(fn+".out")


if __name__ == "__main__":
    main()
