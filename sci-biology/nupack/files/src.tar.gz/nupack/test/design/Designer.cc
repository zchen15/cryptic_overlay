#include "../Test.h"
#include <nupack/design/ThermoWrapper.h>
#include <nupack/design/Designer.h>
#include <nupack/design/Complex.h>
#include <nupack/design/Defect.h>
#include "TestingEnvironments.h"

#include <nupack/reflect/Serialize.h>

namespace nupack { namespace newdesign {

UNIT_TEST("design/designer/fixed-design-defect-1") = [](Context ct) {
    DesignParameters in_params;
    in_params.f_stop = 1.0;
    vec<Objective> objs {Objective(MultitubeObjective())};
    Weights wts;
    wts.add_objective_weight(1);
    Designer designer(build_two_tubes(), objs, wts, in_params);

    designer.initialize(false);
    designer.optimize_tubes(Local());
    auto st_view = designer.design.sequences.get_strand("reverse domains");
    ct.equal(st_view.to_sequence(designer.best.full.sequence), Sequence("GGGGTTTTCCCCAAAA"));
    ct.equal(designer.best.full.total(), about(0.625089));
    ct.require(designer.success());
};

/* might take a while as it runs through various mutation limits, but still be correct */
UNIT_TEST("design/designer/fixed-design-defect-1pct") = [](Context ct) {
    DesignParameters in_params;
    in_params.f_stop = 0.01;
    vec<Objective> objs {Objective(MultitubeObjective())};
    Weights wts;
    wts.add_objective_weight(1);
    Designer designer(build_two_tubes(), objs, wts, in_params);

    designer.initialize(false);
    designer.optimize_tubes(Local());
    auto st_view = designer.design.sequences.get_strand("reverse domains");
    ct.equal(st_view.to_sequence(designer.best.full.sequence), Sequence("GGGGTTTTCCCCAAAA"));
    ct.equal(designer.best.full.total(), about(0.625089));
    ct.require(!designer.success());
};


PROTOTYPE("design/designer/designer.run-hcr") = [](Context ct) {
    DesignParameters in_params;
    in_params.f_stop = 0.02;
    Weights wts;
    wts.add_objective_weight(1);
    vec<Objective> objs {Objective(MultitubeObjective())};

    int N = 20;
    vec<real> times;
    for (auto i : range(N)) {
        Designer designer(build_hcr(), objs, wts, in_params);
        designer.initialize();

        BEEP(designer.max_depth);
        designer.optimize_tubes(Local());
        BEEP(designer.max_depth);

        Designer copy_des(build_hcr(), objs, wts, in_params);
        copy_des.design.set_sequence(designer.best.full.sequence);
        copy_des.design.sequences.print_components();
        BEEP(designer.best.full.total(), designer.stats, designer.known_bads);
        times.emplace_back(designer.stats.design_time);
    }

    BEEP(sum(times)/N);

    // root_designer.initialize(false);
    // BEEP(root_designer.max_depth);
    // t = time_it([&]{root_designer.optimize_tubes(Local());});
    // BEEP(t);
    // BEEP(root_designer.max_depth);

    // designer.design.set_sequence(root_designer.best.full.sequence);
    // designer.design.sequences.print_components();

    // BEEP(root_designer.best.full.total(), root_designer.stats);
};

PROTOTYPE("design/designer/designer.problem") = [](Context ct) {
    DesignParameters in_params;
    in_params.f_stop = 0.02;
    vec<Objective> objs {Objective(MultitubeObjective())};
    Weights wts;
    wts.add_objective_weight(1);
    Designer designer(build_hcr(), objs, wts, in_params);

    // designer.initialize();
    // designer.design.set_sequence(Sequence{"GGAAAGAGTGAGGTGGTTGTTGTGGTGGTTATGGGCTGGATTTTATACCTCACTCTTTCCGCCCATAACCACCACAACAACCACGTATAAAATCCA"});
    auto & design = designer.design;
    auto const &parameters = designer.parameters;

    design.set_sequence(Sequence{"TCGTAAATGTCCTGGAAGGACGGTAATTCCCCTTGGCTTCGTTAGGCTGGACATTTACGACCAAGGGGAATTACCGTCCTTCCAAGCCTAACGAAG"});
    design.initialize_decomposition();
    designer.max_depth = design.max_depth();
    design.set_sequence(Sequence("GGGGGGATGATTGGGAGGTGAGTTTTTTGGTTGAGGTGTTGTGTGGTGAATCATCCCCCCCCTCAACCAAAAAACTCACCTCCCCACCACACAACA"));

    Local env(1);
    design.sequences.print_components();
    for (auto i : ~range(designer.max_depth)) {
        BEEP(i, design.normalized_defect(i).total(), designer.parameters.f_stop * std::pow(designer.parameters.f_stringent, i));
        izip(design.complexes, [&](auto j, auto &c) {
            auto pf = c.log_pfunc(env, design.models, design.sequence(), i);
            auto defect = c.defect(env, design.models, design.sequence(), i).total();
            auto child_pf = c.log_pfunc(env, design.models, design.sequence(), i+1);
            auto child_defect = c.defect(env, design.models, design.sequence(), i+1).total();
            BEEP(j, c.name, to_nick_sequence(c.strands, design.sequence()), pf, child_pf, std::exp(child_pf - pf), defect, child_defect);
        });
    }

    auto & nine = at(design.complexes, 9);
    auto & ten = at(design.complexes, 10);

    auto t_env = nine.target.environment(design.models);
    auto beep_fractions = [&](auto &c) {
        auto calculation = c.dynamic_program(env, t_env, design.sequence(), 0, nine.params);
        auto &pp = calculation.first;
        real cumulative = 0;
        for (auto pair : key_view(c.children)) {
            uint i, j; std::tie(i, j) = pair;
            BEEP(i, j, pp(i, j));
            cumulative += pp(i, j);
        }
        if (!c.children.empty()) BEEP(cumulative);
    };

    nine.decomposition.apply_recursive(beep_fractions);
    t_env = ten.target.environment(design.models);
    ten.decomposition.apply_recursive(beep_fractions);
};


PROTOTYPE("design/designer/designer.concentration-nan") = [](Context ct) {
    DesignParameters in_params;
    in_params.f_stop = 0.02;
    vec<Objective> objs {Objective(MultitubeObjective())};
    Weights wts;
    wts.add_objective_weight(1);
    Designer designer(build_hcr(), objs, wts, in_params);

    // designer.initialize();
    // designer.design.set_sequence(Sequence{"GGAAAGAGTGAGGTGGTTGTTGTGGTGGTTATGGGCTGGATTTTATACCTCACTCTTTCCGCCCATAACCACCACAACAACCACGTATAAAATCCA"});
    auto &params = designer.parameters;
    auto &design = designer.design;
    Local env(1);
    auto run = [&] {for (auto i : range(design.max_depth() + 1)) {
        auto j = 12;
        auto &c = design.complexes[j];
        auto pf = c.log_pfunc(env, design.models, design.sequence(), i);
        BEEP(i, j, c.name, to_nick_sequence(c.strands, design.sequence()), pf);

        // izip(design.complexes, [&](auto j, auto &c) {
        //     auto pf = c.log_pfunc(design.models, design.sequence(), i);
        //     BEEP(i, j, c.name, to_nick_sequence(c.strands, design.sequence()), pf);
        // });
    }};
    design.set_sequence(Sequence("TGAATCATCCACGTGCATGTCCGTTCATATAAAGATACTGGCGGACGTGTGGATGATTCAATCTTTATATGAACGGACATGCACACGTCCGCCAGT"));
    design.initialize_decomposition();
    run();
    design.set_sequence(Sequence("CATTTTAGTTTCGGGGTTGTTGTTTGGTTTTAAGGGGTGGGAGGGGTGGAAACTAAAATGCCCTTAAAACCAAACAACAACCCCCACCCCTCCCAC"));
    run();
};

UNIT_TEST("design/designer/designer.no-inf") = [](Context ct) {
    DesignParameters in_params;
    in_params.f_stop = 0.02;
    vec<Objective> objs {Objective(MultitubeObjective())};
    Weights wts;
    wts.add_objective_weight(1);
    Designer designer(build_hcr(), objs, wts, in_params);

    designer.initialize();
    designer.design.set_sequence(Sequence("GGGGCGTAAAAAGGAGTAGGAGAAAAAGTGAATGCGAGAAAGAATGACTTTTTACGCCCCCGCATTCACTTTTTCTCCTACTCCGTCATTCTTTCT"));
    designer.redecompose_active(Local(), 0);

    auto & design = designer.design;
    for (auto i : ~range(designer.max_depth))
        ct.require(std::isfinite(design.normalized_defect(i).total()));
};

/*
JSON doesnt work for gecode constraint solver
UNIT_TEST("design/designer/designer.serialize-design-json") = [](Context ct) {
    auto t = build_hcr();

    std::ostringstream os;
    os << json(t) << std::endl;
    auto str1 = os.str();

    json j;
    std::istringstream is(str1);
    is >> j;
    Design u = j.get<Design>();

    std::ostringstream os2;
    os2 << json(u) << std::endl;
    auto str2 = os2.str();
    ct.equal(str1, str2);
};
*/

PROTOTYPE("design/designer/save-and-continue") = [](Context ct) {
    // create design and designer and serialize
    DesignParameters in_params;
    in_params.f_stop = 0.1;
    vec<Objective> objs {Objective(MultitubeObjective())};
    Weights wts;
    wts.add_objective_weight(1);
    Designer des(build_hcr(), objs, wts, in_params);
    // std::ofstream("initial.json") << std::setw(4) << json(des) << std::endl;

    // design to 10% and serialize
    des.initialize();
    des.optimize_tubes(Local());
    // std::ofstream("intermediate.json") << std::setw(4) << json(des) << std::endl;

    // print 10% result
    des.design.sequences.print_components();
    BEEP(des.best.full.total());
/*
    JSON broken, see above
    // load 10% result into new designer, set stop condition to 5%, design, serialize
    json j;
    std::ifstream("intermediate.json") >> j;
    Designer restart = j.get<Designer>();
    restart.parameters.f_stop = 0.05;
    restart.optimize_tubes(Local());
    // std::ofstream("final.json") << std::setw(4) << json(restart) << std::endl;

    // print 5% result
    restart.design.sequences.print_components();
    BEEP(restart.best.full.total());
*/
};

}
}
