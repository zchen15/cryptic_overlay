#include "../Test.h"
#include <nupack/design/Split.h>
#include <nupack/olddesign/split_set.h>
#include <nupack/design/ThermoWrapper.h>
#include "TestingEnvironments.h"

namespace nupack { namespace newdesign {

UNIT_TEST("design/split/check-valid-splits") = [](Context ct) {
    Structure str("(7+)7");
    auto splits = valid_split_points(str, 0, 3);

    ct.equal(len(splits), 1);
    ct.equal(splits[0], SplitPoint(3, 10));

    vec<SplitPoint> expected {{3, 10}, {2, 11}, {4,9}};
    splits = valid_split_points(str, 0, 2);
    ct.equal(len(expected), len(splits));
    for_each(expected, [&](auto const &e) {
        ct.require(contains(splits, e));
    });
};

UNIT_TEST("design/split/check-split-sorting") = [](Context ct) {
    Structure str("(7+)7");
    auto splits = valid_split_points(str, 0, 2);
    splits = ascending_cost_splits(splits, len(str));

    ct.equal(splits.at(0), SplitPoint(3, 10));
};

UNIT_TEST("design/split/check-split-crossing") = [](Context ct) {
    SplitPoint ref(1, 10);
    ct.require(crosses(ref, {0, 9}));
    ct.require(crosses({0, 9}, ref));
    ct.require(crosses(ref, {1, 9}));
    ct.require(crosses({1, 9}, ref));
    ct.require(crosses(ref, {0, 10}));
    ct.require(crosses({0, 10}, ref));
    ct.require(crosses(ref, {10, 15}));
    ct.require(crosses({10, 15}, ref));
    ct.require(crosses(ref, {0, 1}));
    ct.require(crosses({0, 1}, ref));
    ct.require(!crosses(ref, {1, 10}));
    ct.require(!crosses({5, 18}, {4, 19}));
};

UNIT_TEST("design/split/check-is-padded") = [](Context ct) {
    vec<uint> bounds {0, 10, 12, 22};
    uint h_split = 3;

    vec<uint> expected_true {3,4,5,6,15,16,17,18};
    auto expected_false = vec<uint>(span(0, 23));
    erase_if(expected_false, [&](auto const &e) {return contains(expected_true, e);});

    for (auto e : expected_true) {
        ct.info(e);
        ct.require(is_padded(e, bounds, h_split));
    }
    for (auto e : expected_false) {
        ct.info(e);
        ct.require(!is_padded(e, bounds, h_split));
    }
};

UNIT_TEST("design/split/check-is-large-enough") = [](Context ct) {
    uint n = 21;
    uint min_size = 12;
    for (auto i : range(n)) for (auto j : range(i+1, n)) {
        ct.info(i); ct.info(j);
        ct.require(!is_large_enough({i, j}, n, min_size));
        ct.require(is_large_enough({i, j}, n, 0));
    }

    // TODO: test checking that splits which are large enough for non-zero parameters work
    n = 12;
    min_size = 6;
    vec<SplitPoint> allowed {{0, 7}};
};

UNIT_TEST("design/split/check-empty-for-nondecomposable") = [](Context ct) {
    auto seq = to_sequences({"GGGGGGGGGGGGAAACCCCCC"});
    ModelKey key("RNA", "min", DefaultTemperature);
    ModelMap map;

    Local env(1);
    auto probs = sparsify(pair_probability(env, seq, double_models(map.get_model(key))).first, 0.00001);
    Structure struc(".6(6.3)6");

    // BEEP(valid_split_points(struc, 12, 2));
    // BEEP(possible_splits(probs, 12, 2, struc));
    auto splits = minimal_splits(probs, 0.99, 12, 2, struc);
    ct.equal(len(splits), 0);
};

UNIT_TEST("design/split/split-structure") = [](Context ct) {
    Structure orig("(8+)8");
    SplitPoint sp(3, 12);
    Structure left, right;
    std::tie(left, right) = split(sp, orig);
    {
        Structure comp("(4+)4");
        ct.equal(left, comp);
    }
    {
        Structure comp("(5+)5");
        ct.equal(right,  comp);
    }

    Structure no_pairs({}, {5, 10, 20});
    sp = {7, 17};
    std::tie(left, right) = split(sp, no_pairs);
    {
        Structure comp({}, {5, 8, 11});
        ct.equal(left, comp);
    }
    {
        Structure comp({}, {3, 11});
        ct.equal(right, comp);
    }
};

UNIT_TEST("design/split/split-sequence") = [](Context ct) {
    auto state = example_state();
    vec<StrandView> strands(3, state.get_strand("reverse domains"));

    auto s_view = [&](auto const &x) {return indirect_view(x, [&](auto s) {return s.to_sequence(state.nucleotides);});};
    auto full_view = s_view(strands);
    ct.equal(full_view, vec<Sequence>(full_view));
    ct.equal(full_view, to_sequences({"GGGGTTTTCCCCAAAA", "GGGGTTTTCCCCAAAA", "GGGGTTTTCCCCAAAA"}));

    SplitPoint sp(17, 35);
    vec<StrandView> left, right; std::tie(left, right) = split(sp, strands);
    ct.equal(s_view(left), to_sequences({"GGGGTTTTCCCCAAAA", "GG", "GTTTTCCCCAAAA"}));
    ct.equal(s_view(right), to_sequences({"GGGTTTTCCCCAAAA", "GGGG"}));
    ct.not_equal(s_view(right), to_sequences({"GGGTTTTCCCCAAAA", "GGGGT"}));

    sp = {0, 15};
    std::tie(left, right) = split(sp, strands);
    ct.equal(s_view(left), to_sequences({"G", "A", "GGGGTTTTCCCCAAAA", "GGGGTTTTCCCCAAAA"}));
    ct.equal(s_view(right), to_sequences({"GGGGTTTTCCCCAAAA"}));

    sp = {15, 16};
    std::tie(left, right) = split(sp, strands);
    ct.equal(s_view(left), full_view);
    ct.equal(s_view(right), to_sequences({"A", "G"}));

    sp = {15, 32};
    std::tie(left, right) = split(sp, strands);
    ct.equal(s_view(left), to_sequences({"GGGGTTTTCCCCAAAA", "GGGGTTTTCCCCAAAA"}));
    ct.equal(s_view(right), to_sequences({"A", "GGGGTTTTCCCCAAAA", "G"}));
};


PROTOTYPE("design/split/check-splittable") = [](Context ct) {
    auto seq = to_sequences({"CAGCUGUAGCUGACUGACUGCCGACUGCGUACGUCAGUCAUGCA", "GUCAUGACUGCAUGAUCGACGCUGCGCGCGCGGCCGAUGCA"});
    // auto seq = to_sequences({"GCCAUGGCCAUGAAACAUGGC"});
    // auto seq = to_sequences({"CCAAACAAAACCCACCUCCCACCAUUACACUCCUCCUUCCCCCUCACCAU"});
    // auto seq = to_sequences({"ACCCUUAACCUUCUUUCUAUCCCUCUGCCUCCUCUUUCUUCUUCCUCUUCCCCCCUCCUCUCCACCCUUCCCCUAAUAUUCCCCCUCCAUUCCUCCCUCU"});
    // auto seq = to_sequences({"GGAGGAGGAGGAGGAGGAGG", "CCACCACCACCACCACCACC"});
    ModelKey key("RNA", "min", 23 + ZeroCinK);
    ModelMap map;

    Local env(1);
    auto dense_probs = pair_probability(env, seq, double_models(map.get_model(key))).first;
    // Structure struc("((((((.........))))))");
    Structure struc;
    struc.nicks = {len(dense_probs)};
    auto probs = sparsify(dense_probs, 0.00001);

    // BEEP(valid_split_points(struc, 12, 2));
    int i = 47, j = 56;
    for (auto r : range(-2, 3)) BEEP(i-r, j+r, probs(i-r, j+r));
    BEEP(possible_splits(probs, 5, 2, struc));
    auto splits = minimal_splits(probs, 0.99, 5, 2, struc);
    BEEP(splits);
    BEEP(std::pow(len(probs), 3));
    BEEP(sum(splits, [&](auto s) {return children_cost(s, len(probs));}));
};

UNIT_TEST("design/split/divide-splitpoints") = [](Context ct) {
    SplitPoint divider(5,15);
    vec<SplitPoint> pairs {{0, 25}, {1,4}, {6, 10}, {11, 14}};
    auto child_pairs = split(divider, pairs);
    decltype(child_pairs) expected = {{{0, 16}, {1, 4}, {5,6}},  {{1, 5}, {6, 9}, {0, 10}}};
    ct.equal(child_pairs, expected);
};

} // end namespace newdesign

namespace design {
UNIT_TEST("design/split/check-old-splitset") = [](Context ct) {
    SplitSet s;
    s.push_back(1, 10, 0.5);
    ct.require(s.crosses_all(0, 9));
    ct.require(s.crosses_all(1, 9));
    ct.require(s.crosses_all(0, 10));
    ct.require(s.crosses_all(0, 1));
    ct.require(s.crosses_all(10, 15));
    ct.require(!s.crosses_all(1, 10));
};

}

}
