#pragma once
#include <nupack/design/SequenceAdapter.h>
#include <nupack/design/Designer.h>

namespace nupack { namespace newdesign {

DesignSequence example_state();
Design build_one_tube();
Design build_two_tubes();
Design build_hcr();


}}
