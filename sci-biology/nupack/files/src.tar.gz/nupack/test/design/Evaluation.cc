#include "../Test.h"
#include "TestingEnvironments.h"

#include <nupack/design/Designer.h>
#include <nupack/design/ThermoWrapper.h>
#include <nupack/design/Complex.h>
#include <nupack/design/Defect.h>
#include <nupack/olddesign/wrapper.h>
#include <nupack/design/custom_csp/sequence_utils.h>

namespace nupack { namespace newdesign {

UNIT_TEST("design/evaluation/least_squares") = [](Context ct) {
    vec<real> x {0.67457587, 0.01486412, 0.0607121 , 0.46637409, 0.06321503,
       0.1407605 , 0.79244138, 0.29141082, 0.27996684, 0.14117646,
       0.04762288, 0.70831641, 0.83142267, 0.25709194, 0.62539088,
       0.35682418, 0.64561523, 0.35759091, 0.63964856, 0.58505252,
       0.82534429, 0.92803562, 0.65833442, 0.63976741, 0.49248242};
    vec<real> y {5.28417003, 2.58274219, 1.0271474 , 1.96276613, 3.70436517,
       4.85517914, 7.69607953, 4.69136186, 8.57823325, 9.95543863,
       9.28057535, 4.34425079, 4.14813693, 5.97160151, 1.54816916,
       5.14606258, 5.38560464, 4.49331765, 8.69753779, 4.39962905,
       7.1709868 , 3.08533174, 4.09833515, 7.41530369, 5.54536714};
    vec<real> mb {5.281995334906239, -0.08522968046227757};

    auto res = ord_lin_lsq(x, y);
    ct.equal(at(mb, 0), about(at(res, 0)));
    ct.equal(at(mb, 1), about(at(res, 1)));
};


UNIT_TEST("design/evaluation/log_sum_exp") = [](Context ct) {
    double inf = std::numeric_limits<double>::infinity();
    ct.equal(0, log_sum_exp(-inf, 0));
    ct.equal(-inf, log_sum_exp(-inf));
    ct.equal(-inf, log_sum_exp(-inf, -inf));
    ct.equal(inf, log_sum_exp(-inf, inf));
    ct.equal(inf, log_sum_exp(inf));
    ct.equal(inf, log_sum_exp(0, inf));
};


UNIT_TEST("design/evaluation/adding-models") = [](Context ct) {
    ModelMap map;
    ct.info("No models yet.");
    ct.equal(len(map), 0);

    ct.info("One model added via request.");
    auto const &mods1 = map.get_model(ModelKey());
    ct.equal(len(map), 1);

    Local env(1);
    auto res1 = partition_function(env, to_sequences({"AAAACCCCTTTTGGGG"}), double_models(mods1));

    ct.info("Request same model; no new models should be added.");
    auto const &mods2 = map.get_model(ModelKey());
    ct.equal(len(map), 1);

    auto res2 = partition_function(env, to_sequences({"AAAACCCCTTTTGGGG"}), double_models(mods2));
    ct.info("dynamic_program was run with same models, on same sequence, so it should produce the same result.");
    ct.equal(res1, about(res2));

    ModelKey dna_key("DNA");
    auto const &mods3 = map.get_model(dna_key);
    ct.info("new model requested, size should increase.");
    ct.equal(len(map), 2);

    auto res3 = partition_function(env, to_sequences({"AAAACCCCTTTTGGGG"}), double_models(mods3));
    ct.info("running same sequence with different material, result should be different.");
    ct.not_equal(res1, res3);
};

UNIT_TEST("design/evaluation/evaluating-complex-test") = [](Context ct) {
    // create sequences
    DesignSequence state = example_state();
    state.initialize_sequence();

    // create model
    ModelMap map;
    ModelKey key;

    // create complex from sequences and model and unstructure target
    Complex single {{state.get_strand("reverse domains")}, key};
    Complex doubled {vec<StrandView>(2, state.get_strand("reverse domains")), key};
    Complex three {{state.get_strand("reverse domains"), state.get_strand("reverse domains"), state.get_strand("all As")}, key};

    // compare reference value
    Local env(1);
    auto const &models = map.get_model(key);
    ct.equal(single.log_pfunc(env, map, state.nucleotides), about(std::get<0>(models).as_log(1.87288768568603e3)));
    ct.equal(doubled.log_pfunc(env, map, state.nucleotides), about(std::get<0>(models).as_log(1.5252096227370975e10)));
    ct.equal(three.log_pfunc(env, map, state.nucleotides), about(std::get<0>(models).as_log(3.186763630027916e+7)));
};

UNIT_TEST("design/evaluation/structure-specification") = [](Context ct) {
    auto s = Structure("(((+)))...");
    ct.equal(s.dp(), "(((+)))...");

    ct.throw_as<std::invalid_argument>([] {return Structure("blah");});
    ct.throw_as<std::invalid_argument>([] {return Structure("(8+2)8");});
    ct.no_throw([] {return Structure("(8+)8");});
    ct.equal(Structure("(8+)8"), Structure("((((((((+))))))))"));

    ct.equal(Structure("(((..+)...)).+((..))").dp_rle(), "(3.2+).3)2.+(2.2)2");
};


UNIT_TEST("design/evaluation/structure-rotation") = [](Context ct) {
    auto s = PairList("((..))..");
    ct.equal(rotated_pairing(s, 2).dp(), "..((..))");
    ct.equal(rotated_pairing(s, 4).dp(), s.dp());
    ct.equal(rotated_pairing(s, -2).dp(), "..((..))");

    auto str = Structure("(((+)))((.+.))....");
    auto copied = str;
    copied.rotate();
    ct.equal(copied.dp(), "(((((.+.))....+)))");
    copied.rotate();
    ct.equal(copied.dp(), ".((....+(((+))))).");
    copied.rotate();
    ct.equal(copied, str);
};

UNIT_TEST("design/evaluation/evaluating-complex-defect") = [](Context ct) {
    // create sequences
    DesignSequence state = example_state();
    state.initialize_sequence();

    // create model
    ModelMap map;
    ModelKey key;

    // create complex
    Complex single {{state.get_strand("reverse domains")}, Target(key, "((((....))))....")};
    Complex alternate {{state.get_strand("reverse domains")}, Target(key, "....((((....))))")};
    Complex doubled {vec<StrandView>(2, state.get_strand("reverse domains")), Target(key, "((((....((((....+))))....))))....")};

    // evaluate
    Local env(1);
    ct.equal(doubled.defect(env, map, state.nucleotides).total(), about(1.296287151212507));
    ct.equal(single.defect(env, map, state.nucleotides).total(), about(1.4870242245330836));
    ct.equal(alternate.defect(env, map, state.nucleotides).total(), about(15.654300757820433));
};

UNIT_TEST("design/evaluation/example-design-build") = [](Context ct) {
    Design design = build_one_tube();

    ct.equal(len(design.complexes), 2);
    ct.equal(len(design.tubes), 1);
};


UNIT_TEST("design/evaluation/evaluate-concs") = [](Context ct) {
    Design design = build_one_tube();
    auto const &tube = design.tubes[0];

    Local env(1);
    auto log_pfuncs = design.log_pfuncs(env);
    auto concs = tube.concentrations(log_pfuncs, {});
    ct.equal(concs[0], about(134784/1e6));
    ct.equal(concs[1], about(1432608/1e6));

    concs = tube.concentrations(log_pfuncs);
    ct.equal(concs[0], about(134784/1e6));
    ct.equal(concs[1], about(1432608/1e6));
};

UNIT_TEST("design/evaluation/evaluate-tube-defect") = [](Context ct) {
    Local env(1);
    auto design = build_one_tube();
    auto const &tube = design.tubes[0];

    auto log_pfuncs = design.log_pfuncs(env);
    auto comp_defs = design.complex_defects(env);

    auto defect = tube.defect(log_pfuncs, comp_defs);
    auto norm_defect = tube.normalized_defect(log_pfuncs, comp_defs);

    ct.equal(defect.total(), about(1.534017e+01));
    ct.equal(norm_defect.total(), about(0.319587));
    ct.equal(design.normalized_defect(env).total(), about(0.319587));
};

UNIT_TEST("design/evaluation/evaluate-multi-defect") = [](Context ct) {
    Local env(1);
    auto design = build_two_tubes();
    auto log_pfuncs = design.log_pfuncs(env);
    auto comp_defs = design.complex_defects(env);

    ct.equal(design.tubes[0].normalized_defect(log_pfuncs, comp_defs).total(), about(0.319587));
    ct.equal(design.tubes[1].normalized_defect(log_pfuncs, comp_defs).total(), about(0.930592));
    ct.equal(design.normalized_defect(env).total(), about(0.625089));
};


UNIT_TEST("design/evaluation/check-sampling") = [](Context ct) {
    auto design = build_two_tubes();

    Local env(1);
    auto defect = design.normalized_defect(env);
    ct.equal(len(defect.sample_nucleotides()), 1);
    ct.equal(len(defect.sample_nucleotides(16)), 16);
    ct.equal(len(defect.sample_nucleotides(50)), 16);
};


PROTOTYPE("design/evaluation/beep-sampling") = [](Context ct) {
    auto design = build_two_tubes();

    Local env(1);
    auto defect = design.normalized_defect(env);
    BEEP(defect);
    for (auto i : range(10)) BEEP(defect.sample_nucleotides(i));

    BEEP(design.sequence());
    design.sequences.mutate_sequence(defect.sample_nucleotides(10));
    BEEP(design.sequence());
};


UNIT_TEST("design/evaluation/evaluate-hcr") = [](Context ct) {
    auto hcr = build_hcr();

    // domains concatenated in order a b c a* b* c*
    vec<std::pair<string, real>> reference {
            {"GGGGGGAGGTGGGTGGTTGAATGAGTATGAAAGAGCTGGAGTAAATTGCCACCTCCCCCCGCTCTTTCATACTCATTCAACCACCAATTTACTCCA", 0.018631},
            {"GCGGGTTATTATGGGGTTGGTTGTGTTGGTTTGTTCTATATATTCGGGATAATAACCCGCGAACAAACCAACACAACCAACCCCCCCGAATATATA", 0.016764},
            {"AGAAAAAAGAGGGGGGAAAAGATAGAAGAAGAAGCGTGGAGTTGAATTCCTCTTTTTTCTCGCTTCTTCTTCTATCTTTTCCCCAATTCAACTCCA", 0.017023}
            };

    Local env(1);
    for (auto const &r : reference) {
        ct.info(r.first);
        hcr.set_sequence(Sequence(r.first));
        ct.equal(hcr.normalized_defect(env).total(), about(r.second));
    }
};


PROTOTYPE("design/evaluation/time-thermo-functions") = [](Context ct) {
    vec<int> lengths {50, 100, 200, 400};
    constexpr int trials {10};

    ModelMap map;
    auto mods = double_models(map.get_model({}));
    Local env(1);

    vec<real> times;
    vec<real> bonus_times;
    for (auto l : lengths) {
        times.emplace_back(time_it(trials, [&]{
            NickSequence seq(random_sequences(1, l));
            newdesign::pair_probability(env, seq, mods);
        }));
        bonus_times.emplace_back(time_it(trials, [&]{
            NickSequence seq(random_sequences(1, l));
            newdesign::pair_probability(env, seq, mods, {}, -20);
        }));
    }

    vec<real> fractions;
    zip(times, bonus_times, [&] (auto x, auto y) {fractions.emplace_back(x / y);});

    BEEP(lengths, times, bonus_times, fractions);
};


PROTOTYPE("design/evaluation/constrained-pair-probabilities") = [](Context ct) {
    auto seqs = to_sequences({"GGGGGGG", "CCCCCCC"});
    ModelMap map;
    auto mods = double_models(map.get_model({}));
    Local env(1);

    auto normal = newdesign::pair_probability(env, seqs, mods);
    BEEP(normal.first, normal.second);

    vec<SplitPoint> fpairs = {{0, 13}, {6, 7}};
    auto enforced = newdesign::pair_probability(env, seqs, mods, fpairs, -20);
    BEEP(enforced.first, enforced.second);

};

using namespace design;

PROTOTYPE("design/evaluation/compare-old-constrained-pprobs") = [](Context ct) {
    auto seqs = custom_csp::SequenceUtils::str_to_nuc("GGGGGGGCCCCCCC");
    seqs.insert(seqs.begin() + 7, custom_csp::STRAND_PLUS);
    seqs.insert(seqs.end(), custom_csp::STRAND_PLUS);
    BEEP(seqs);
    auto n = 14;
    vec<real> pp(n * (n+1), 0.0);
    vec<real> bonuses(n * n, 1.0);
    NupackInvariants invars;
    invars.ensemble = Ensemble::nostacking;

    /* normal evaluation */
    auto pfunc = pfuncFullWithBonuses(seqs, invars, bonuses, pp);
    thermo::Tensor<real, 2> tens(n, n+1);
    tens.assign(pp);
    BEEP(pfunc, tens);

    /* add bonuses */
    auto bonus = ::nupack::Model(Ensemble::none).boltz(invars.dG_clamp);
    bonuses[0 * n + 13] = bonus;
    bonuses[6 * n + 7] = bonus;

    /* bonused evaluation */
    pfunc = pfuncFullWithBonuses(seqs, invars, bonuses, pp);
    tens.assign(pp);
    BEEP(pfunc, tens);
    BEEP(pfunc - 2 * std::log(bonus));
};

UNIT_TEST("design/evaluation/concentration-failing") = [](Context ct) {
// A =
//    1.0000   1.0000        0        0
//         0        0   1.0000   1.0000
//         0        0   2.0000   2.0000

// dG =
//   -4.6637e+01
//   -4.8639e+01
//   -1.0393e+02

// x0 =
//    1.8134e-08
//    1.8134e-08
//             0
    vec<real> A {1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 2, 2};
    vec<real> dG {
-33.8916,
-43.3948,
-93.5957
        };
    vec<real> x0 {1.8134e-08, 1.8134e-08, 0};

    real_mat mat_A(A);
    mat_A.reshape(4, 3);
    inplace_trans(mat_A);

    real_col col_x0(x0);
    real_col col_dG(dG), col_logq = -col_dG;

    concentration::equilibrate(mat_A, col_x0, col_logq);
};

template <class S>
void compare_pp(Context &ct, S const &seqs, vec<SplitPoint> const &pairs) {
    /* construct components */
    auto nickseq = NickSequence(seqs);
    auto strs = vmap(seqs, [](auto const &s) {return s.str();});
    vec<int> old_seqs;
    for_each(strs, [&](auto const &s) {
        auto seq = custom_csp::SequenceUtils::str_to_nuc(s);
        cat(old_seqs, seq);
        old_seqs.emplace_back(custom_csp::STRAND_PLUS);
    });

    auto n = len(nickseq);

    ModelMap map;
    NupackInvariants invars;
    auto mods = double_models(map.get_model({}));
    auto const & mod = std::get<1>(mods).energy_model;
    invars.temperature = mod.conditions.temperature;
    invars.ensemble = mod.ensemble;
    real bonus = invars.dG_clamp;
    real exp_bonus = mod.boltz(bonus);

    vec<real> bonuses(n * n, 1.0);
    vec<real> pp(n * (n + 1));

    auto compare = [&] (auto const &newstuff, auto old_pf, auto &old_pp) {
        thermo::Tensor<real, 2> tens(n, n+1);
        tens.assign(old_pp);
        auto const &new_pp = newstuff.first;
        for (auto i : indices(nickseq)) *tens(i, i) = *tens(i, n);

        vec<bool> checked;
        for (auto i : indices(nickseq)) for (auto j : indices(nickseq))
            checked.emplace_back(*new_pp(i, j) == about(*tens(i, j)));
        auto flag = all_of(checked, [](auto c) {return c;});

        ct.require(flag);
        if (!flag) BEEP(nickseq, strs, old_seqs, newstuff.first, tens);
        ct.require(newstuff.second == about(old_pf));
    };

    Local env(1);

    /* compare default */
    auto new_default = newdesign::pair_probability(env, nickseq, mods);
    auto old_default_pfunc = pfuncFullWithBonuses(old_seqs, invars, bonuses, pp);
    compare(new_default, old_default_pfunc, pp);

    /* compare forced */
    pp = vec<real>(n * (n + 1));
    for (auto const &sp : pairs) {
        uint i, j; std::tie(i, j) = sp;
        bonuses[i * n + j] = exp_bonus;
    }
    auto new_forced = newdesign::pair_probability(env, nickseq, mods, pairs, bonus);
    auto join = -mod.beta * (nickseq.n_sequences() - 1) * mod.join_penalty();
    new_forced.second += join;
    auto old_forced_pfunc = pfuncFullWithBonuses(old_seqs, invars, bonuses, pp);
    old_forced_pfunc -= len(pairs) * std::log(exp_bonus);
    compare(new_forced, old_forced_pfunc, pp);
};

#define NUPACK_TEST(name, seqs, pairs) \
        UNIT_TEST("design/evaluation/pprobs-" name "") = [](Context ct) {compare_pp(ct, seqs, pairs);};
NUPACK_TEST("gc-duplex", to_sequences({"GGGGGGG", "CCCCCCC"}), (vec<SplitPoint>{{0, 13}, {6, 7}}));
NUPACK_TEST("at-capped-gc-duplex", to_sequences({"AGGGGGGGA", "TCCCCCCCT"}), (vec<SplitPoint>{{0, 17}, {8, 9}}));
NUPACK_TEST("triplex", to_sequences({"GGGCCC", "GGGCCC", "GGGCCC"}), (vec<SplitPoint>{{0, 17}, {5, 6}, {11, 12}}));
NUPACK_TEST("triplex-non-sym", to_sequences({"GGGCCC", "GGGTTT", "AAACCC"}), (vec<SplitPoint>{{0, 17}, {5, 6}, {11, 12}}));
#undef NUPACK_TEST

}
}
