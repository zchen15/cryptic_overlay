#include "TestingEnvironments.h"

namespace nupack { namespace newdesign {

DesignSequence example_state() {
    DesignSequence state;

    state.add_domain(DomainSpec("a", {{"A", 4}}));
    state.add_domain(DomainSpec("c", {{"C", 4}}));
    state.add_domain(DomainSpec("t", {{"T", 4}}));
    state.add_domain(DomainSpec("g", {{"G", 4}}));

    state.add_strand({"all As", {"a", "a", "a", "a"}});
    state.add_strand({"reverse domains", {"g", "t", "c", "a"}});
    // GGGGTTTTCCCCAAAA

    state.add_domain_complements();
    state.make_sequence();
    return state;
}


Design build_one_tube() {
    /* use example sequences*/
    Design design;
    design.sequences = example_state();
    design.sequences.initialize_sequence();

    /* */
    design.add_complex(std::vector<string>(1, "reverse domains"), ModelKey(), "single_strand", Structure("((((....))))...."));
    design.add_complex(std::vector<string>(2, "reverse domains"), ModelKey(), "double_strand", Structure("((((....((((....+))))....))))...."));

    design.add_tube({0, 1}, {1.0, 1.0}, "the_tube");

    return design;
}

Design build_two_tubes() {
    auto design = build_one_tube();
    design.add_tube({0, 1}, {1.0, 0.0}, "other_tube");
    return design;
}

Design build_hcr() {
    /* build sequence components */
    DesignSequence seqs;
    seqs.add_domain(DomainSpec("a", {{"N", 12}}));
    seqs.add_domain(DomainSpec("b", {{"N", 24}}));
    seqs.add_domain(DomainSpec("c", {{"N", 12}}));

    seqs.add_strand({"i1", {"b*", "a*"}});
    seqs.add_strand({"h2", {"b*", "a*", "b", "c"}});
    seqs.add_strand({"i2", {"c*", "b*"}});
    seqs.add_strand({"h1", {"a", "b", "c*", "b*"}});

    seqs.add_domain_complements();
    seqs.make_sequence();

    Design design(std::move(seqs));

    ModelKey key("DNA", "min", ZeroCinK + 25);

    /* add complexes */
    /* on-targets */
    /* 0*/ design.add_complex({"h1"}, key, "A", "............((((((((((((((((((((((((............))))))))))))))))))))))))");
    /* 1*/ design.add_complex({"h2"}, key, "B", "((((((((((((((((((((((((............))))))))))))))))))))))))............");
    /* 2*/ design.add_complex({"i1"}, key, "X", "....................................");
    /* 3*/ design.add_complex({"h1", "i1"}, key, "X__A", "((((((((((((((((((((((((((((((((((((....................................+))))))))))))))))))))))))))))))))))))");
    /* 4*/ design.add_complex({"h1", "h2", "i1"}, key, "X__A__B", "((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((+....................................))))))))))))))))))))))))))))))))))))+))))))))))))))))))))))))))))))))))))");
    /* 5*/ design.add_complex({"h1", "h1", "h2", "i1"}, key, "X__A__A__B", "((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((+((((((((((((((((((((((((((((((((((((....................................+))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))+))))))))))))))))))))))))))))))))))))");
    /* 6*/ design.add_complex({"i2"}, key, "A_out", "....................................");

    /* explicitly add off-targets complexes for now */
    /* 7*/ design.add_complex({"h1", "h2"}, key);
    /* 8*/ design.add_complex({"i1", "i1"}, key);
    /* 9*/ design.add_complex({"h1", "h1"}, key);
    /*10*/ design.add_complex({"h2", "h2"}, key);
    /*11*/ design.add_complex({"h2", "i1"}, key);
    /*12*/ design.add_complex({"i2", "i2"}, key);
    /*13*/ design.add_complex({"i1", "i2"}, key);
    /*14*/ design.add_complex({"h1", "i2"}, key);
    /*15*/ design.add_complex({"h2", "i2"}, key);

    DecompositionParameters decomp_params;
    for (auto &c : design.complexes) c.params = decomp_params;

    // add complementarity constraints implied by target structures -- later, already captured by domain complementarity for now

    /* add tubes */
    design.add_tube(
            {/*on*/ 0, 1, 2, /*off*/ 7, 8, 9, 10, 11},
            {/*on*/ 1e-8, 1e-8, 1e-8, /*off*/ 0, 0, 0, 0, 0},
            "Step_0");
    design.add_tube(
            {/*on*/ 3, /*off*/ 0, 2, 8, 9},
            {/*on*/ 1e-8, /*off*/ 0, 0, 0, 0},
            "Step_1");
    design.add_tube(
            {/*on*/ 4, /*off*/ 0, 1, 2, 3, 7, 8, 9, 10, 11},
            {/*on*/ 1e-8, /*off*/ 0, 0, 0, 0, 0, 0, 0, 0, 0},
            "Step_2");
    design.add_tube(
            {/*on*/ 5, /*off*/ 0, 1, 2, 3, 4, 7, 8, 9, 10, 11},
            {/*on*/ 1e-8, /*off*/ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            "Step_3");
    design.add_tube(
            {0, 1, 2, 6, /*on*/ 7, 8, 9, 10, 11, 12, 13, 14 /*off*/},
            {1e-8, 1e-8, 1e-8, 1e-8, /*on*/ 0, 0, 0, 0, 0, 0, 0, 0 /*off*/},
            "Crosstalk");

    return design;
}

}}
