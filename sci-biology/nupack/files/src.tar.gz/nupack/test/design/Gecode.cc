#include "../Test.h"
#include "Gecode.h"
#include <nupack/design/Specification.h>
#include <nupack/design/Constraints.h>
#include <nupack/design/constraint_handler.h>
#include <cmath>

namespace nupack { namespace newdesign {


uint n = 200;
uint mut = 0;

PROTOTYPE("design/gecode/build_model") = [](Context ct) {
    vec<int> ref(n, 2);

    Example ex(n);
    ex.add_reference(ref);
    ex.disallow({0,0});

    ex.print();
    // (void) ex.status();
    // ex.print();
    Example * blah = nullptr;
    auto time = time_it(1, [&] {
        Search::Options opts;
        // opts.stop = Search::Stop::time(1000);
        BAB<Example> e(&ex, opts);
        uint max_sols = 100, sols = 0;
        // while (bool(blah = e.next()) && sols < max_sols) {
        decltype(blah) temp;
        while (bool(temp = e.next())) {
            delete blah;
            blah = temp;
            // blah->print();
            // BEEP(blah->cost().val());
            // vec<int> goof(indirect_view(blah->nucs, [](auto const &i) {return i.val();}));
            // BEEP(goof);
            ++sols;
        }
    });
    blah->print();
    BEEP(time);
};


UNIT_TEST("design/gecode/attempt_mutation") = [](Context ct) {
    auto print_status = [](auto blah) {
        switch (blah) {
            case SpaceStatus::SS_FAILED: BEEP("SS_FAILED"); break;
            case SpaceStatus::SS_SOLVED: BEEP("SS_SOLVED"); break;
            case SpaceStatus::SS_BRANCH: BEEP("SS_BRANCH"); break;
        }
    };

    uint length = 30;
    vec<int> ids;
    for (auto i : range(length)) ids.emplace_back(i);

    vec<int> ref;
    Example ex(n);
    print_status(ex.status());
    std::unique_ptr<Example> ex2_ptr(ex.cast_clone());
    Example &ex2 = *ex2_ptr;

    // ex.word_constraint(ids, {vec<int>(length, 0), vec<int>(length, 2), vec<int>(length, 1)});
    // ex.word_constraint(ids, {vec<int>(length, 0), vec<int>(length, 2)});
    ex.default_brancher();
    print_status(ex.status());

    DFS<Example> e(&ex);
    auto orig = e.next();
    if (orig) {
        for (auto i : range(orig->nucs.size()))
            ref.emplace_back(orig->nucs[i].val());
    } else {
        throw;
    }

    auto orig_seq = vmap<Sequence>(orig->nucs, [](auto i) {return Base::from_index(i.val());});
    BEEP(orig_seq);
    // Example ex2(n);
    // ex2.force({mut, 3 - at(ref, mut)});

    // ex2.word_constraint(ids, {vec<int>(length, 0), vec<int>(length, 2), vec<int>(length, 1)});
    // ex2.word_constraint(ids, {vec<int>(length, 0), vec<int>(length, 2)});
    // ex2.disallow({mut, at(ref, mut)});
    // ex2.add_reference(ref);
    print_status(ex2.status());

    decltype(orig) mutated = nullptr, temp = nullptr;
    auto time = time_it(5, [&] {
        std::unique_ptr<Example> ex3_ptr(ex2.cast_clone());
        Example &ex3 = *ex3_ptr;
        ex3.force({mut, 3 - at(ref, mut)});
        ex3.add_reference(ref);

        Search::Options opts;
        opts.c_d = 2 * n;
        DFS<Example> e2(&ex3, opts);
        if (mutated) delete mutated;
        mutated = e2.next();

        // while (bool(temp = e2.next())) {
        //     delete mutated;
        //     mutated = temp;
        //     BEEP(mutated->cost().val());
        // }
    });

    Sequence mut_seq;
    if (mutated) {
        // BEEP(mutated->cost().val());
        mut_seq = vmap<Sequence>(mutated->nucs, [](auto i) {return Base::from_index(i.val());});
        BEEP(mut_seq);
        BEEP(hamming_distance(orig_seq, mut_seq));
    }
    BEEP(time);
    if (orig) delete orig;
    if (mutated) delete mutated;
};


UNIT_TEST("design/gecode/old_mutation") = [](Context ct) {
    DesignSequence seqs;
    uint length = 30;
    seqs.add_domain(DomainSpec("short", {{"N", length}}));
    seqs.add_domain(DomainSpec("dom", {{"N", n-length}}));
    seqs.add_strand(StrandSpec("str", {"short", "dom"}));
    seqs.make_sequence();

    /* GC content constraint */
    // vec<string> ref_seqs {"S", "C"};
    vec<string> ref_seqs {"S"};
    for (auto r : ref_seqs) {
        SimilaritySpec gc;
        gc.name = "str";
        gc.reference = multiply_substrings({{r, n}});
        gc.range = {0.55, 0.65};
        gc.add_constraint(seqs);
    }

    /* word constraint */
    WordSpec word;
    word.domains = {"short"};
    // word.comparisons = {{multiply_substrings({{"G", length}}), multiply_substrings({{"C", length}}), multiply_substrings({{"A", length}})}};
    word.comparisons = {{multiply_substrings({{"G", length}}), multiply_substrings({{"A", length}})}};
    word.add_constraint(seqs);

    // /* pattern constraints */
    // vec<PatternSpec> pats {{"str", "AAAA"}, {"str", "CCCC"}, {"str", "GGGG"}, {"str", "UUUU"}};
    // for (auto const &p : pats) p.add_constraint(seqs);

    seqs.initialize_sequence();

    auto sequence = seqs.nucleotides;
    BEEP(sequence);

    auto time = time_it(5, [&] {
        seqs.set_sequence(sequence);
        seqs.mutate_sequence({mut});
    });
    BEEP(seqs.nucleotides);
    BEEP(time);
};

using nupack::design::ConstraintHandler;
using nupack::design::CompConstraint;
using nupack::design::WordConstraint;
using nupack::design::PatternConstraint;
using nupack::design::MatchConstraint;
using nupack::design::trinary;
using nupack::design::NUPACK_CS_STRONG;

PROTOTYPE("design/gecode/ConstraintHandler_mutation_scaling-complementarity") = [](Context ct) {
    for (auto i : range(4, 19)) {
        auto n = int(std::pow(10, real(i)/4));
        // uint window_length = 50;
        // if (n < window_length) continue;
        // if (n>3200) continue;

        ConstraintHandler constraints;
        for (auto i : range(2 * n)) constraints.add_nucleotide_variable(Base('N'));

        /* complementarity */
        for (auto i : range(n)) {
            int j = 2 * n - int(i) - 1;
            constraints.add_constraint(CompConstraint(i, j, NUPACK_CS_STRONG));
        }

        auto vars = constraints.init_random();

        auto time = time_it(5, [&] {
            constraints.make_mutation({0}, vars);
        });
        // BEEP(seqs.nucleotides);
        // BEEP(time);
        print<io::comma>(n, time, "Old", "complementarity");
    }
};

PROTOTYPE("design/gecode/ConstraintHandler_mutation_scaling-gccontent") = [](Context ct) {
    for (auto i : range(4, 19)) {
        auto n = int(std::pow(10, real(i)/4));
        // uint window_length = 50;
        // if (n < window_length) continue;
        // if (n>3200) continue;

        vec<int> all(n);
        std::iota(begin_of(all), end_of(all), 0);

        ConstraintHandler constraints;
        for (auto i : range(2 * n)) constraints.add_nucleotide_variable(Base('N'));

        /* complementarity */
        for (auto i : range(n)) {
            int j = 2 * n - int(i) - 1;
            constraints.add_constraint(CompConstraint(i, j, NUPACK_CS_STRONG));
        }

        /* GC content constraint */
        vec<string> ref_seqs {"S"};
        for (auto r : ref_seqs) {
            constraints.add_constraint(MatchConstraint(all, multiply_substrings({{r, n}}), {0.45}, {0.55}));
        }

        auto vars = constraints.init_random();

        auto time = time_it(5, [&] {
            constraints.make_mutation({0}, vars);
        });
        // BEEP(seqs.nucleotides);
        // BEEP(time);
        print<io::comma>(n, time, "Old", "composition");
    }
};


PROTOTYPE("design/gecode/ConstraintHandler_mutation_scaling-pattern") = [](Context ct) {
    for (auto i : range(4, 19)) {
        auto n = int(std::pow(10, real(i)/4));
        // uint window_length = 50;
        // if (n < window_length) continue;
        // if (n>3200) continue;

        vec<int> all(n);
        std::iota(begin_of(all), end_of(all), 0);

        ConstraintHandler constraints;
        for (auto i : range(2 * n)) constraints.add_nucleotide_variable(Base('N'));

        /* complementarity */
        for (auto i : range(n)) {
            int j = 2 * n - int(i) - 1;
            constraints.add_constraint(CompConstraint(i, j, NUPACK_CS_STRONG));
        }

        // DesignSequence seqs;
        // seqs.add_domain(DomainSpec("short", {{"N", window_length}}));
        // seqs.add_domain(DomainSpec("dom", {{"N", n-window_length}}));
        // seqs.add_strand(StrandSpec("str", {"short", "dom"}));
        // // seqs.add_strand(StrandSpec("str", {"dom"}));
        // seqs.make_sequence();

        // /* GC content constraint */
        // vec<string> ref_seqs {"S"};
        // for (auto r : ref_seqs) {
        //     constraints.add_constraint(MatchConstraint(all, multiply_substrings({{r, n}}), {0.45}, {0.55}));
        // }

        /* word constraint */
        // Sequence mRNA {"CATTTACACAGCGTACAAACCCAACAGGCCCAGTCATGAGCACGAAATATTCAGCCTCCGCCGAGTCGGCGTCCTCTTACCGCCGCACCTTTGGCTCAGGTTTGGGCTCCTCTATTTTCGCCGGCCACGGTTCCTCAGGTTCCTCTGGCTCCTCAAGACTGACCTCCAGAGTTTACGAGGTGACCAAGAGCTCCGCTTCTCCCCATTTTTCCAGCCACCGTGCGTCCGGCTCTTTCGGAGGTGGCTCGGTGGTCCGTTCCTACGCTGGCCTTGGTGAGAAGCTGGATTTCAATCTGGCTGATGCCATAAACCAGGACTTCCTCAACACGCGTACTAATGAGAAGGCCGAGCTCCAGCACCTCAATGACCGCTTCGCCAGCTACATCGAGAAGGTGCGCTTCCTCGAGCAGCAGAACTCTGCCCTGACGGTGGAGATTGAGCGTCTGCGGGGTCGCGAGCCCACCCGTATTGCAGAGCTGTACGAGGAGGAGATGAGAGAGCTGCGCGGACAGGTGGAGGCACTGACCAATCAGAGATCCCGTGTGGAGATCGAGAGGGACAACCTAGTCGATGACCTACAGAAACTAAAGCTCAGACTTCAAGAGGAGATCCACCAGAAAGAGGAAGCTGAAAACAACCTTTCTGCTTTCAGAGCTGATGTCGATGCTGCCACTCTGGCCAGGCTGGACCTGGAAAGACGTATCGAGGGTCTTCACGAAGAGATTGCATTCCTCAGGAAGATTCATGAGGAGGAGATCCGTGAGCTGCAGAACCAGATGCAGGAGAGTCAGGTGCAGATCCAAATGGACATGTCCAAACCAGACCTGACTGCGGCCCTCAGAGACATTCGCCTGCAGTACGAGGCTATCGCTGCCAAGAATATCAGCGAGGCCGAGGACTGGTATAAGTCTAAGGTTTCAGATTTGAACCAGGCAGTGAACAAGAATAACGAGGCTCTCAGAGAAGCCAAGCAGGAGACCATGCAGTTCCGTCACCAGCTCCAGTCCTACACCTGCGAGATTGACTCTCTCAAGGGCACCAATGAGTCTCTGAGGAGGCAAATGAGTGAGATGGAGGAGCGGCTGGGACGTGAGGCCGGTGGTTATCAGGACACTATCGCCCGTCTCGAGGCTGAGATCGCAAAAATGAAAGACGAGATGGCCCGCCACCTCCGCGAGTACCAGGATCTGCTGAATGTGAAGATGGCTCTGGATGTGGAGATCGCCACCTACAGGAAGCTTTTGGAAGGAGAGGAGAGCAGGATCTCGCTGCCCGTGCAGTCCTTTTCATCCCTGAGTTTCAGAGAGAGCAGTCCAGAGCAGCACCACCACCAGCAGCAGCAACCACAACGCTCATCTGAAGTCCACTCCAAGAAAACAGTCCTGATCAAGACCATCGAGACCCGCGATGGCGAGGTCGTCAGCGAGTCCACACAGCACCAGCAGGACGTCATGTAAAGCTTGAGAAACAGATCGAGTTTCACAGAATGCCTTGCATTTTCACTGATGGCCTCAGGCTTTTTTAAGCACACACCCAGTATTGCCGTGACCCATTACCGCATGTGGATGACGCATGGAGACAAAAGGAAAGTGAGCTGAAAAACCAGAGGGAGGAAAAGTGGAATGGTGTGATGCTGAGCGTTCAGAAAGTGGCCAGATGAGCTCAGAGTTTCTGATTTAATGAATGTATGTGTGCGTGTGTGTGTGGTTGGGTCATATCTGAGACACTGTTCCACAGCAACAAAAACAATAAAATTCACTGTATTTTCTCCTAAAAAAAAAAAAAAAAAAAAAAAAAA"};
        // vec<string> words;
        // vec<int> window(window_length);
        // std::iota(begin_of(window), end_of(window), 0);
        // for (auto i : range(len(mRNA) - window_length + 1)) {
        //     Sequence word(vmap<Sequence>(range(i, i+window_length), [&](auto c){return at(mRNA, c);}));
        //     words.emplace_back(string(word));
        // }
        // auto supp_var = constraints.add_variable(vec<trinary>(len(words), true));
        // constraints.add_constraint(WordConstraint(window, words, supp_var));

        // /* pattern constraints */
        vec<PatternSpec> pats {{"str", "AAAA"}, {"str", "CCCC"}, {"str", "GGGG"}, {"str", "UUUU"},
            {"str", "WWWWWW"}, {"str", "SSSSSS"}, {"str", "MMMMMM"}, {"str", "KKKKKK"}, {"str", "YYYYYY"}, {"str", "RRRRRR"}};
        for (auto const &p : pats) constraints.add_constraint(PatternConstraint(all, p.pattern, constraints.get_possible_nucleotides()));

        auto vars = constraints.init_random();

        auto time = time_it(5, [&] {
            constraints.make_mutation({0}, vars);
        });
        // BEEP(seqs.nucleotides);
        // BEEP(time);
        print<io::comma>(n, time, "Old", "pattern");
    }
};

PROTOTYPE("design/gecode/ConstraintHandler_mutation_scaling-window") = [](Context ct) {
    for (auto i : range(4, 19)) {
        auto n = int(std::pow(10, real(i)/4));
        uint window_length = 50;
        if (n < window_length) continue;
        // if (n>3200) continue;

        vec<int> all(n);
        std::iota(begin_of(all), end_of(all), 0);

        ConstraintHandler constraints;
        for (auto i : range(2 * n)) constraints.add_nucleotide_variable(Base('N'));

        /* complementarity */
        for (auto i : range(n)) {
            int j = 2 * n - int(i) - 1;
            constraints.add_constraint(CompConstraint(i, j, NUPACK_CS_STRONG));
        }

        /* word constraint */
        Sequence mRNA {"CATTTACACAGCGTACAAACCCAACAGGCCCAGTCATGAGCACGAAATATTCAGCCTCCGCCGAGTCGGCGTCCTCTTACCGCCGCACCTTTGGCTCAGGTTTGGGCTCCTCTATTTTCGCCGGCCACGGTTCCTCAGGTTCCTCTGGCTCCTCAAGACTGACCTCCAGAGTTTACGAGGTGACCAAGAGCTCCGCTTCTCCCCATTTTTCCAGCCACCGTGCGTCCGGCTCTTTCGGAGGTGGCTCGGTGGTCCGTTCCTACGCTGGCCTTGGTGAGAAGCTGGATTTCAATCTGGCTGATGCCATAAACCAGGACTTCCTCAACACGCGTACTAATGAGAAGGCCGAGCTCCAGCACCTCAATGACCGCTTCGCCAGCTACATCGAGAAGGTGCGCTTCCTCGAGCAGCAGAACTCTGCCCTGACGGTGGAGATTGAGCGTCTGCGGGGTCGCGAGCCCACCCGTATTGCAGAGCTGTACGAGGAGGAGATGAGAGAGCTGCGCGGACAGGTGGAGGCACTGACCAATCAGAGATCCCGTGTGGAGATCGAGAGGGACAACCTAGTCGATGACCTACAGAAACTAAAGCTCAGACTTCAAGAGGAGATCCACCAGAAAGAGGAAGCTGAAAACAACCTTTCTGCTTTCAGAGCTGATGTCGATGCTGCCACTCTGGCCAGGCTGGACCTGGAAAGACGTATCGAGGGTCTTCACGAAGAGATTGCATTCCTCAGGAAGATTCATGAGGAGGAGATCCGTGAGCTGCAGAACCAGATGCAGGAGAGTCAGGTGCAGATCCAAATGGACATGTCCAAACCAGACCTGACTGCGGCCCTCAGAGACATTCGCCTGCAGTACGAGGCTATCGCTGCCAAGAATATCAGCGAGGCCGAGGACTGGTATAAGTCTAAGGTTTCAGATTTGAACCAGGCAGTGAACAAGAATAACGAGGCTCTCAGAGAAGCCAAGCAGGAGACCATGCAGTTCCGTCACCAGCTCCAGTCCTACACCTGCGAGATTGACTCTCTCAAGGGCACCAATGAGTCTCTGAGGAGGCAAATGAGTGAGATGGAGGAGCGGCTGGGACGTGAGGCCGGTGGTTATCAGGACACTATCGCCCGTCTCGAGGCTGAGATCGCAAAAATGAAAGACGAGATGGCCCGCCACCTCCGCGAGTACCAGGATCTGCTGAATGTGAAGATGGCTCTGGATGTGGAGATCGCCACCTACAGGAAGCTTTTGGAAGGAGAGGAGAGCAGGATCTCGCTGCCCGTGCAGTCCTTTTCATCCCTGAGTTTCAGAGAGAGCAGTCCAGAGCAGCACCACCACCAGCAGCAGCAACCACAACGCTCATCTGAAGTCCACTCCAAGAAAACAGTCCTGATCAAGACCATCGAGACCCGCGATGGCGAGGTCGTCAGCGAGTCCACACAGCACCAGCAGGACGTCATGTAAAGCTTGAGAAACAGATCGAGTTTCACAGAATGCCTTGCATTTTCACTGATGGCCTCAGGCTTTTTTAAGCACACACCCAGTATTGCCGTGACCCATTACCGCATGTGGATGACGCATGGAGACAAAAGGAAAGTGAGCTGAAAAACCAGAGGGAGGAAAAGTGGAATGGTGTGATGCTGAGCGTTCAGAAAGTGGCCAGATGAGCTCAGAGTTTCTGATTTAATGAATGTATGTGTGCGTGTGTGTGTGGTTGGGTCATATCTGAGACACTGTTCCACAGCAACAAAAACAATAAAATTCACTGTATTTTCTCCTAAAAAAAAAAAAAAAAAAAAAAAAAA"};
        vec<string> words;
        vec<int> window(window_length);
        std::iota(begin_of(window), end_of(window), 0);
        for (auto i : range(len(mRNA) - window_length + 1)) {
            Sequence word(vmap<Sequence>(range(i, i+window_length), [&](auto c){return at(mRNA, c);}));
            words.emplace_back(string(word));
        }
        auto supp_var = constraints.add_variable(vec<trinary>(len(words), true));
        constraints.add_constraint(WordConstraint(window, words, supp_var));


        auto vars = constraints.init_random();

        auto time = time_it(5, [&] {
            constraints.make_mutation({0}, vars);
        });
        // BEEP(seqs.nucleotides);
        // BEEP(time);
        print<io::comma>(n, time, "Old", "window");
    }
};


// PROTOTYPE("design/gecode/ConstraintHandler_mutation_scaling-pattern") = [](Context ct) {
//     for (auto i : range(4, 19)) {
//         auto n = int(std::pow(10, real(i)/4));
//         uint window_length = 50;
//         // if (n < window_length) continue;
//         // if (n>3200) continue;

//         vec<int> all(n);
//         std::iota(begin_of(all), end_of(all), 0);

//         ConstraintHandler constraints;
//         for (auto i : range(2 * n)) constraints.add_nucleotide_variable(Base('N'));

//         /* complementarity */
//         for (auto i : range(n)) {
//             int j = 2 * n - int(i) - 1;
//             constraints.add_constraint(CompConstraint(i, j, NUPACK_CS_STRONG));
//         }

//         // DesignSequence seqs;
//         // seqs.add_domain(DomainSpec("short", {{"N", window_length}}));
//         // seqs.add_domain(DomainSpec("dom", {{"N", n-window_length}}));
//         // seqs.add_strand(StrandSpec("str", {"short", "dom"}));
//         // // seqs.add_strand(StrandSpec("str", {"dom"}));
//         // seqs.make_sequence();

//         // /* GC content constraint */
//         // vec<string> ref_seqs {"S"};
//         // for (auto r : ref_seqs) {
//         //     constraints.add_constraint(MatchConstraint(all, multiply_substrings({{r, n}}), {0.45}, {0.55}));
//         // }

//         /* word constraint */
//         Sequence mRNA {"CATTTACACAGCGTACAAACCCAACAGGCCCAGTCATGAGCACGAAATATTCAGCCTCCGCCGAGTCGGCGTCCTCTTACCGCCGCACCTTTGGCTCAGGTTTGGGCTCCTCTATTTTCGCCGGCCACGGTTCCTCAGGTTCCTCTGGCTCCTCAAGACTGACCTCCAGAGTTTACGAGGTGACCAAGAGCTCCGCTTCTCCCCATTTTTCCAGCCACCGTGCGTCCGGCTCTTTCGGAGGTGGCTCGGTGGTCCGTTCCTACGCTGGCCTTGGTGAGAAGCTGGATTTCAATCTGGCTGATGCCATAAACCAGGACTTCCTCAACACGCGTACTAATGAGAAGGCCGAGCTCCAGCACCTCAATGACCGCTTCGCCAGCTACATCGAGAAGGTGCGCTTCCTCGAGCAGCAGAACTCTGCCCTGACGGTGGAGATTGAGCGTCTGCGGGGTCGCGAGCCCACCCGTATTGCAGAGCTGTACGAGGAGGAGATGAGAGAGCTGCGCGGACAGGTGGAGGCACTGACCAATCAGAGATCCCGTGTGGAGATCGAGAGGGACAACCTAGTCGATGACCTACAGAAACTAAAGCTCAGACTTCAAGAGGAGATCCACCAGAAAGAGGAAGCTGAAAACAACCTTTCTGCTTTCAGAGCTGATGTCGATGCTGCCACTCTGGCCAGGCTGGACCTGGAAAGACGTATCGAGGGTCTTCACGAAGAGATTGCATTCCTCAGGAAGATTCATGAGGAGGAGATCCGTGAGCTGCAGAACCAGATGCAGGAGAGTCAGGTGCAGATCCAAATGGACATGTCCAAACCAGACCTGACTGCGGCCCTCAGAGACATTCGCCTGCAGTACGAGGCTATCGCTGCCAAGAATATCAGCGAGGCCGAGGACTGGTATAAGTCTAAGGTTTCAGATTTGAACCAGGCAGTGAACAAGAATAACGAGGCTCTCAGAGAAGCCAAGCAGGAGACCATGCAGTTCCGTCACCAGCTCCAGTCCTACACCTGCGAGATTGACTCTCTCAAGGGCACCAATGAGTCTCTGAGGAGGCAAATGAGTGAGATGGAGGAGCGGCTGGGACGTGAGGCCGGTGGTTATCAGGACACTATCGCCCGTCTCGAGGCTGAGATCGCAAAAATGAAAGACGAGATGGCCCGCCACCTCCGCGAGTACCAGGATCTGCTGAATGTGAAGATGGCTCTGGATGTGGAGATCGCCACCTACAGGAAGCTTTTGGAAGGAGAGGAGAGCAGGATCTCGCTGCCCGTGCAGTCCTTTTCATCCCTGAGTTTCAGAGAGAGCAGTCCAGAGCAGCACCACCACCAGCAGCAGCAACCACAACGCTCATCTGAAGTCCACTCCAAGAAAACAGTCCTGATCAAGACCATCGAGACCCGCGATGGCGAGGTCGTCAGCGAGTCCACACAGCACCAGCAGGACGTCATGTAAAGCTTGAGAAACAGATCGAGTTTCACAGAATGCCTTGCATTTTCACTGATGGCCTCAGGCTTTTTTAAGCACACACCCAGTATTGCCGTGACCCATTACCGCATGTGGATGACGCATGGAGACAAAAGGAAAGTGAGCTGAAAAACCAGAGGGAGGAAAAGTGGAATGGTGTGATGCTGAGCGTTCAGAAAGTGGCCAGATGAGCTCAGAGTTTCTGATTTAATGAATGTATGTGTGCGTGTGTGTGTGGTTGGGTCATATCTGAGACACTGTTCCACAGCAACAAAAACAATAAAATTCACTGTATTTTCTCCTAAAAAAAAAAAAAAAAAAAAAAAAAA"};
//         vec<string> words;
//         vec<int> window(window_length);
//         std::iota(begin_of(window), end_of(window), 0);
//         for (auto i : range(len(mRNA) - window_length + 1)) {
//             Sequence word(vmap<Sequence>(range(i, i+window_length), [&](auto c){return at(mRNA, c);}));
//             words.emplace_back(string(word));
//         }
//         auto supp_var = constraints.add_variable(vec<trinary>(len(words), true));
//         constraints.add_constraint(WordConstraint(window, words, supp_var));

//         // /* pattern constraints */
//         vec<PatternSpec> pats {{"str", "AAAA"}, {"str", "CCCC"}, {"str", "GGGG"}, {"str", "UUUU"},
//             {"str", "WWWWWW"}, {"str", "SSSSSS"}, {"str", "MMMMMM"}, {"str", "KKKKKK"}, {"str", "YYYYYY"}, {"str", "RRRRRR"}};
//         for (auto const &p : pats) constraints.add_constraint(PatternConstraint(all, p.pattern, constraints.get_possible_nucleotides()));

//         auto vars = constraints.init_random();

//         auto time = time_it(5, [&] {
//             constraints.make_mutation({0}, vars);
//         });
//         // BEEP(seqs.nucleotides);
//         // BEEP(time);
//         print<io::comma>(n, time, "Old", "pattern");
//     }
// };

PROTOTYPE("design/gecode/Constraints_mutation_scaling-complementarity") = [](Context ct) {
    ConstraintHandler();
    for (auto i : range(4, 19)) {
        auto n = int(std::pow(10, real(i)/4));

        // if (n>3200) continue;
        Constraints constraints(Sequence(multiply_substrings({{"N", 2*n}})));
        constraints.msec_cutoff = 1e7;

        /* complementarity */
        for (auto i : range(n)) constraints.complementarity_constraint(i, 2*n-i-1);

        vec<int> all(n);
        std::iota(begin_of(all), end_of(all), 0);


        auto seq = constraints.initial_sequence().value();
        auto time = time_it(5, [&]{
            constraints.make_mutation(seq, {0});
        });

        print<io::comma>(n, time, "New", "complementarity");
    }
};

PROTOTYPE("design/gecode/Constraints_mutation_scaling-gccontent") = [](Context ct) {
    ConstraintHandler();
    for (auto i : range(4, 19)) {
        auto n = int(std::pow(10, real(i)/4));

        /* word constraint */
        // int window_length = 50;
        // if (n < window_length) continue;

        // if (n>3200) continue;
        Constraints constraints(Sequence(multiply_substrings({{"N", 2*n}})));
        constraints.msec_cutoff = 1e7;

        /* complementarity */
        for (auto i : range(n)) constraints.complementarity_constraint(i, 2*n-i-1);

        vec<int> all(n);
        std::iota(begin_of(all), end_of(all), 0);

        /* GC Content */
        std::pair<real, real> limits {0.45, 0.55};
        constraints.similarity_constraint(all, Sequence(multiply_substrings({{"S", n}})), limits);

        auto seq = constraints.initial_sequence().value();
        auto time = time_it(5, [&]{
            constraints.make_mutation(seq, {0});
        });

        print<io::comma>(n, time, "New", "composition");
    }
};

PROTOTYPE("design/gecode/Constraints_mutation_scaling-pattern") = [](Context ct) {
    ConstraintHandler();
    for (auto i : range(4, 19)) {
        auto n = int(std::pow(10, real(i)/4));

        // if (n>3200) continue;
        Constraints constraints(Sequence(multiply_substrings({{"N", 2*n}})));
        constraints.msec_cutoff = 1e7;

        /* complementarity */
        for (auto i : range(n)) constraints.complementarity_constraint(i, 2*n-i-1);

        vec<int> all(n);
        std::iota(begin_of(all), end_of(all), 0);

        /* pattern constraints */
        vec<std::pair<string, int>> patterns {{"A", 4}, {"C", 4}, {"G", 4}, {"T", 4}
        ,
        {"W", 6}, {"S", 6}, {"M", 6}, {"K", 6}, {"Y", 6}, {"R", 6}
        };
        for (auto p : patterns) constraints.pattern_constraint(all, Sequence(multiply_substrings({p})));

        auto seq = constraints.initial_sequence().value();
        auto time = time_it(5, [&]{
            constraints.make_mutation(seq, {0});
        });

        print<io::comma>(n, time, "New", "pattern");
    }
};

PROTOTYPE("design/gecode/Constraints_mutation_scaling-diversity") = [](Context ct) {
    ConstraintHandler();
    for (auto i : range(4, 19)) {
        auto n = int(std::pow(10, real(i)/4));

        // if (n>3200) continue;
        Constraints constraints(Sequence(multiply_substrings({{"N", 2*n}})));
        constraints.msec_cutoff = 1e7;

        /* complementarity */
        for (auto i : range(n)) constraints.complementarity_constraint(i, 2*n-i-1);

        vec<int> all(n);
        std::iota(begin_of(all), end_of(all), 0);

        /* diversity constraints */
        constraints.diversity_constraint(all, 4, 2);
        constraints.diversity_constraint(all, 6, 3);

        auto seq = constraints.initial_sequence().value();
        auto time = time_it(5, [&]{
            constraints.make_mutation(seq, {0});
        });

        print<io::comma>(n, time, "New", "diversity");
    }
};

PROTOTYPE("design/gecode/Constraints_mutation_scaling-window") = [](Context ct) {
    ConstraintHandler();
    for (auto i : range(4, 19)) {
        auto n = int(std::pow(10, real(i)/4));

        /* word constraint */
        int window_length = 50;
        if (n < window_length) continue;

        // if (n>3200) continue;
        Constraints constraints(Sequence(multiply_substrings({{"N", 2*n}})));
        constraints.msec_cutoff = 1e7;

        /* complementarity */
        for (auto i : range(n)) constraints.complementarity_constraint(i, 2*n-i-1);

        vec<int> all(n);
        std::iota(begin_of(all), end_of(all), 0);

        /* window constraint */
        vec<int> window(window_length);
        std::iota(begin_of(window), end_of(window), 0);
        Sequence mRNA {"CATTTACACAGCGTACAAACCCAACAGGCCCAGTCATGAGCACGAAATATTCAGCCTCCGCCGAGTCGGCGTCCTCTTACCGCCGCACCTTTGGCTCAGGTTTGGGCTCCTCTATTTTCGCCGGCCACGGTTCCTCAGGTTCCTCTGGCTCCTCAAGACTGACCTCCAGAGTTTACGAGGTGACCAAGAGCTCCGCTTCTCCCCATTTTTCCAGCCACCGTGCGTCCGGCTCTTTCGGAGGTGGCTCGGTGGTCCGTTCCTACGCTGGCCTTGGTGAGAAGCTGGATTTCAATCTGGCTGATGCCATAAACCAGGACTTCCTCAACACGCGTACTAATGAGAAGGCCGAGCTCCAGCACCTCAATGACCGCTTCGCCAGCTACATCGAGAAGGTGCGCTTCCTCGAGCAGCAGAACTCTGCCCTGACGGTGGAGATTGAGCGTCTGCGGGGTCGCGAGCCCACCCGTATTGCAGAGCTGTACGAGGAGGAGATGAGAGAGCTGCGCGGACAGGTGGAGGCACTGACCAATCAGAGATCCCGTGTGGAGATCGAGAGGGACAACCTAGTCGATGACCTACAGAAACTAAAGCTCAGACTTCAAGAGGAGATCCACCAGAAAGAGGAAGCTGAAAACAACCTTTCTGCTTTCAGAGCTGATGTCGATGCTGCCACTCTGGCCAGGCTGGACCTGGAAAGACGTATCGAGGGTCTTCACGAAGAGATTGCATTCCTCAGGAAGATTCATGAGGAGGAGATCCGTGAGCTGCAGAACCAGATGCAGGAGAGTCAGGTGCAGATCCAAATGGACATGTCCAAACCAGACCTGACTGCGGCCCTCAGAGACATTCGCCTGCAGTACGAGGCTATCGCTGCCAAGAATATCAGCGAGGCCGAGGACTGGTATAAGTCTAAGGTTTCAGATTTGAACCAGGCAGTGAACAAGAATAACGAGGCTCTCAGAGAAGCCAAGCAGGAGACCATGCAGTTCCGTCACCAGCTCCAGTCCTACACCTGCGAGATTGACTCTCTCAAGGGCACCAATGAGTCTCTGAGGAGGCAAATGAGTGAGATGGAGGAGCGGCTGGGACGTGAGGCCGGTGGTTATCAGGACACTATCGCCCGTCTCGAGGCTGAGATCGCAAAAATGAAAGACGAGATGGCCCGCCACCTCCGCGAGTACCAGGATCTGCTGAATGTGAAGATGGCTCTGGATGTGGAGATCGCCACCTACAGGAAGCTTTTGGAAGGAGAGGAGAGCAGGATCTCGCTGCCCGTGCAGTCCTTTTCATCCCTGAGTTTCAGAGAGAGCAGTCCAGAGCAGCACCACCACCAGCAGCAGCAACCACAACGCTCATCTGAAGTCCACTCCAAGAAAACAGTCCTGATCAAGACCATCGAGACCCGCGATGGCGAGGTCGTCAGCGAGTCCACACAGCACCAGCAGGACGTCATGTAAAGCTTGAGAAACAGATCGAGTTTCACAGAATGCCTTGCATTTTCACTGATGGCCTCAGGCTTTTTTAAGCACACACCCAGTATTGCCGTGACCCATTACCGCATGTGGATGACGCATGGAGACAAAAGGAAAGTGAGCTGAAAAACCAGAGGGAGGAAAAGTGGAATGGTGTGATGCTGAGCGTTCAGAAAGTGGCCAGATGAGCTCAGAGTTTCTGATTTAATGAATGTATGTGTGCGTGTGTGTGTGGTTGGGTCATATCTGAGACACTGTTCCACAGCAACAAAAACAATAAAATTCACTGTATTTTCTCCTAAAAAAAAAAAAAAAAAAAAAAAAAA"};
        vec<Sequence> words;
        for (auto i : range(len(mRNA) - window_length + 1)) {
            Sequence word(vmap<Sequence>(range(i, i+window_length), [&](auto c){return at(mRNA, c);}));
            words.emplace_back(word);
        }
        constraints.word_constraint(window, words);

        auto seq = constraints.initial_sequence().value();
        auto time = time_it(5, [&]{
            constraints.make_mutation(seq, {0});
        });

        print<io::comma>(n, time, "New", "window");
    }
};


UNIT_TEST("design/gecode/NucSpace_basic") = [](Context ct) {
    Constraints constraints(Sequence("NNNN"));
    print(constraints.initial_sequence());

    Constraints gc(Sequence("SSSS"));
    print(gc.initial_sequence());
};


UNIT_TEST("design/gecode/fail_to_create") = [](Context ct) {
    ct.throw_as<Gecode::Int::VariableEmptyDomain>([]{Constraints(Sequence("NNNNNN_"));});
};


UNIT_TEST("design/gecode/NucSpace_mutation") = [](Context ct) {
    Constraints constraints(Sequence("NNNN"));
    auto seq = constraints.initial_sequence();
    auto mutated = constraints.make_mutation(seq.value(), {0});
    BEEP(seq, mutated);
};


UNIT_TEST("design/gecode/no_mutation") = [](Context ct) {
    Constraints constraints(Sequence("ANNN"));
    auto seq = constraints.initial_sequence();
    auto mutated = constraints.make_mutation(seq.value(), {0});
    ct.require(!bool(mutated));

    mutated = constraints.make_mutation(seq.value(), {1});
    ct.require(bool(mutated));
};


UNIT_TEST("design/gecode/NucSpace_match") = [](Context ct) {
    Constraints constraints(Sequence("NNNNNNNN"));
    for (auto i : range(4)) constraints.match_constraint(i, i+4);
    auto seq = constraints.initial_sequence();
    BEEP(seq);
    for (auto i : range(4)) ct.require(seq.value()[i] == seq.value()[i+4]);

    auto mut = constraints.make_mutation(seq.value(), {0});
    BEEP(mut);
    for (auto i : range(4)) ct.require(mut.value()[i] == mut.value()[i+4]);
};

UNIT_TEST("design/gecode/NucSpace_complementarity") = [](Context ct) {
    Constraints constraints(Sequence("NNNNNNNN"));
    for (auto i : range(4)) constraints.complementarity_constraint(i, i+4);
    auto seq = constraints.initial_sequence();
    BEEP(seq);
    for (auto i : range(4)) ct.require(seq.value()[i] == complement(seq.value()[i+4]));

    auto mut = constraints.make_mutation(seq.value(), {0});
    BEEP(mut);
    for (auto i : range(4)) ct.require(mut.value()[i] == complement(mut.value()[i+4]));
};


UNIT_TEST("design/gecode/NucSpace_complementarity2") = [](Context ct) {
    Pairable can_pair(WobblePairing::off, WobbleClosing::off);
    uint n = 6400;
    Constraints constraints(Sequence(multiply_substrings({{"N", n}})));

    for (auto i : range(n/2)) constraints.complementarity_constraint(i, n-i-1, false);
    Sequence seq;
    auto time = time_it([&] {
        seq = constraints.initial_sequence().value();
    });
    BEEP(seq);
    BEEP(time);

    for (auto i : range(n/2)) ct.require(can_pair(seq[i], seq[n-i-1]));

    Sequence mut;
    time = time_it([&]{mut = constraints.make_mutation(seq, {0}).value();});
    BEEP(mut);
    BEEP(time);

    for (auto i : range(n/2)) ct.require(can_pair(mut[i], mut[n-i-1]));

    time = time_it(5, [&] {
        constraints.initial_sequence();
    });
    BEEP(time);

    time = time_it(5, [&] {
        constraints.make_mutation(seq, {0});
    });
    BEEP(time);
};


UNIT_TEST("design/gecode/NucSpace_wobble") = [](Context ct) {
    Pairable gu_pair(WobblePairing::on);
    Pairable can_pair(WobblePairing::off);
    uint n = 6400;
    Constraints constraints(Sequence(multiply_substrings({{"N", n}})));

    for (auto i : range(n/2)) constraints.complementarity_constraint(i, n-i-1, true);
    Sequence seq;
    auto time = time_it([&] {
        seq = constraints.initial_sequence().value();
    });
    BEEP(seq);
    BEEP(time);

    for (auto i : range(n/2)) ct.require(gu_pair(seq[i], seq[n-i-1]));
    uint count {0};
    for (auto i : range(n/2)) count += can_pair(seq[i], seq[n-i-1]);
    BEEP(real(n/2 - count)/real(n/2));

    Sequence mut;
    time = time_it([&]{mut = constraints.make_mutation(seq, {0}).value();});
    BEEP(mut);
    BEEP(time);

    for (auto i : range(n/2)) ct.require(gu_pair(mut[i], mut[n-i-1]));

    time = time_it(5, [&] {
        constraints.initial_sequence();
    });
    BEEP(time);

    time = time_it(5, [&] {
        constraints.make_mutation(seq, {0});
    });
    BEEP(time);
};

UNIT_TEST("design/gecode/NucSpace_pattern_fail_to_initialize") = [](Context ct) {
    Constraints constraints(Sequence("GGGG"));

    constraints.pattern_constraint({0,1,2,3}, Sequence("SSSS"));

    ct.throw_as<Gecode::SpaceFailed>([&]{constraints.initial_sequence();});
};

UNIT_TEST("design/gecode/NucSpace_patterns") = [](Context ct) {
    Pairable can_pair(WobblePairing::on);
    uint n = 3200;
    vec<int> all(n);
    std::iota(begin_of(all), end_of(all), 0);
    Constraints constraints(Sequence(multiply_substrings({{"N", 2*n}})));
    vec<std::pair<string, int>> patterns {{"A", 4}, {"C", 4}, {"G", 4}, {"T", 4},
            {"W", 6}, {"S", 6}, {"M", 6}, {"K", 6}, {"Y", 6}, {"R", 6}};
    for (auto p : patterns) constraints.pattern_constraint(all, Sequence(multiply_substrings({p})));
    for (auto i : range(n)) constraints.complementarity_constraint(i, 2*n-i-1, false);


    auto check = [&] (auto const &seq) {
        for (auto i : range(n-3)) {
            std::set<Base> counter;
            for (auto j : range(i, i+4)) counter.emplace(at(seq, j));
            ct.require(len(counter) > 1);
        }
        for (auto i : range(n-5)) {
            std::set<Base> counter;
            for (auto j : range(i, i+6)) counter.emplace(at(seq, j));
            ct.require(len(counter) > 2);
        }
    };

    auto seq = constraints.initial_sequence().value();
    BEEP(seq);
    check(seq);

    auto mut = constraints.make_mutation(seq, {0}).value();
    BEEP(mut);
    check(mut);

    BEEP(hamming_distance(seq, mut));

    auto time = time_it(5, [&] {
        constraints.initial_sequence();
    });
    BEEP(time);

    time = time_it(5, [&] {
        constraints.make_mutation(seq, {0});
    });
    BEEP(time);
};


UNIT_TEST("design/gecode/NucSpace_diversity") = [](Context ct) {
    Pairable can_pair(WobblePairing::on);
    uint n = 3200;
    vec<int> all(n);
    std::iota(begin_of(all), end_of(all), 0);
    Constraints constraints(Sequence(multiply_substrings({{"N", 2*n}})));
    // vec<std::pair<string, int>> patterns {{"A", 4}, {"C", 4}, {"G", 4}, {"T", 4},
    //         {"W", 6}, {"S", 6}, {"M", 6}, {"K", 6}, {"Y", 6}, {"R", 6}};
    // for (auto p : patterns) constraints.pattern_constraint(all, Sequence(multiply_substrings({p})));
    constraints.diversity_constraint(all, 4, 2);
    constraints.diversity_constraint(all, 6, 3);
    for (auto i : range(n)) constraints.complementarity_constraint(i, 2*n-i-1, false);


    auto check = [&] (auto const &seq) {
        for (auto i : range(n-3)) {
            std::set<Base> counter;
            for (auto j : range(i, i+4)) counter.emplace(at(seq, j));
            ct.require(len(counter) > 1);
        }
        for (auto i : range(n-5)) {
            std::set<Base> counter;
            for (auto j : range(i, i+6)) counter.emplace(at(seq, j));
            ct.require(len(counter) > 2);
        }
    };

    auto seq = constraints.initial_sequence().value();
    BEEP(seq);
    check(seq);

    auto mut = constraints.make_mutation(seq, {0}).value();
    BEEP(mut);
    check(mut);

    BEEP(hamming_distance(seq, mut));

    auto time = time_it(5, [&] {
        constraints.initial_sequence();
    });
    BEEP(time);

    time = time_it(5, [&] {
        constraints.make_mutation(seq, {0});
    });
    BEEP(time);
};

UNIT_TEST("design/gecode/NucSpace_gc_content") = [](Context ct) {
    std::pair<real, real> limits {0.65, 0.75};
    uint n = 1000;

    vec<int> all(n);
    std::iota(begin_of(all), end_of(all), 0);

    Constraints constraints(Sequence(multiply_substrings({{"N", n}})));
    constraints.similarity_constraint(all, Sequence(multiply_substrings({{"S", n}})), limits);
    for (auto i : range(n/2)) constraints.complementarity_constraint(i, n-i-1, false);

    auto check = [&] (auto const &seq) {
        uint counter {0};
        for (auto base: seq) if (base == Base('G') || base == Base('C')) ++counter;
        auto frac = real(counter) / n;
        ct.require(frac <= limits.second);
        ct.require(frac >= limits.first);
    };

    auto seq = constraints.initial_sequence().value();
    BEEP(seq);
    check(seq);

    auto mut = constraints.make_mutation(seq, {0}).value();
    BEEP(mut);
    check(mut);

    auto time = time_it(5, [&] {
        constraints.initial_sequence();
    });
    BEEP(time);

    time = time_it(5, [&] {
        constraints.make_mutation(seq, {0});
    });
    BEEP(time);
};


PROTOTYPE("design/gecode/NucSpace_mutate_all") = [](Context ct) {
    Pairable can_pair(WobblePairing::on);
    uint n = 1000;
    vec<int> all(n);
    std::iota(begin_of(all), end_of(all), 0);
    Constraints constraints(Sequence(multiply_substrings({{"N", n}})));
    vec<std::pair<string, int>> patterns {{"A", 4}, {"C", 4}, {"G", 4}, {"T", 4},
            {"W", 6}, {"S", 6}, {"M", 6}, {"K", 6}, {"Y", 6}, {"R", 6}};
    for (auto p : patterns) constraints.pattern_constraint(all, Sequence(multiply_substrings({p})));

    auto seq = constraints.initial_sequence().value();
    BEEP(seq);

    auto mutation_locations = all;
    random_shuffle(mutation_locations);
    decltype(seq) mut;
    auto time = time_it([&]{ mut = constraints.make_mutation(seq, mutation_locations).value(); });
    BEEP(mut);

    BEEP(time, time / n);

    auto dist = hamming_distance(seq, mut);
    BEEP(dist, real(dist)/n);
};


UNIT_TEST("design/gecode/NucSpace_window_constraint") = [](Context ct) {
    Sequence mRNA {"CATTTACACAGCGTACAAACCCAACAGGCCCAGTCATGAGCACGAAATATTCAGCCTCCGCCGAGTCGGCGTCCTCTTACCGCCGCACCTTTGGCTCAGGTTTGGGCTCCTCTATTTTCGCCGGCCACGGTTCCTCAGGTTCCTCTGGCTCCTCAAGACTGACCTCCAGAGTTTACGAGGTGACCAAGAGCTCCGCTTCTCCCCATTTTTCCAGCCACCGTGCGTCCGGCTCTTTCGGAGGTGGCTCGGTGGTCCGTTCCTACGCTGGCCTTGGTGAGAAGCTGGATTTCAATCTGGCTGATGCCATAAACCAGGACTTCCTCAACACGCGTACTAATGAGAAGGCCGAGCTCCAGCACCTCAATGACCGCTTCGCCAGCTACATCGAGAAGGTGCGCTTCCTCGAGCAGCAGAACTCTGCCCTGACGGTGGAGATTGAGCGTCTGCGGGGTCGCGAGCCCACCCGTATTGCAGAGCTGTACGAGGAGGAGATGAGAGAGCTGCGCGGACAGGTGGAGGCACTGACCAATCAGAGATCCCGTGTGGAGATCGAGAGGGACAACCTAGTCGATGACCTACAGAAACTAAAGCTCAGACTTCAAGAGGAGATCCACCAGAAAGAGGAAGCTGAAAACAACCTTTCTGCTTTCAGAGCTGATGTCGATGCTGCCACTCTGGCCAGGCTGGACCTGGAAAGACGTATCGAGGGTCTTCACGAAGAGATTGCATTCCTCAGGAAGATTCATGAGGAGGAGATCCGTGAGCTGCAGAACCAGATGCAGGAGAGTCAGGTGCAGATCCAAATGGACATGTCCAAACCAGACCTGACTGCGGCCCTCAGAGACATTCGCCTGCAGTACGAGGCTATCGCTGCCAAGAATATCAGCGAGGCCGAGGACTGGTATAAGTCTAAGGTTTCAGATTTGAACCAGGCAGTGAACAAGAATAACGAGGCTCTCAGAGAAGCCAAGCAGGAGACCATGCAGTTCCGTCACCAGCTCCAGTCCTACACCTGCGAGATTGACTCTCTCAAGGGCACCAATGAGTCTCTGAGGAGGCAAATGAGTGAGATGGAGGAGCGGCTGGGACGTGAGGCCGGTGGTTATCAGGACACTATCGCCCGTCTCGAGGCTGAGATCGCAAAAATGAAAGACGAGATGGCCCGCCACCTCCGCGAGTACCAGGATCTGCTGAATGTGAAGATGGCTCTGGATGTGGAGATCGCCACCTACAGGAAGCTTTTGGAAGGAGAGGAGAGCAGGATCTCGCTGCCCGTGCAGTCCTTTTCATCCCTGAGTTTCAGAGAGAGCAGTCCAGAGCAGCACCACCACCAGCAGCAGCAACCACAACGCTCATCTGAAGTCCACTCCAAGAAAACAGTCCTGATCAAGACCATCGAGACCCGCGATGGCGAGGTCGTCAGCGAGTCCACACAGCACCAGCAGGACGTCATGTAAAGCTTGAGAAACAGATCGAGTTTCACAGAATGCCTTGCATTTTCACTGATGGCCTCAGGCTTTTTTAAGCACACACCCAGTATTGCCGTGACCCATTACCGCATGTGGATGACGCATGGAGACAAAAGGAAAGTGAGCTGAAAAACCAGAGGGAGGAAAAGTGGAATGGTGTGATGCTGAGCGTTCAGAAAGTGGCCAGATGAGCTCAGAGTTTCTGATTTAATGAATGTATGTGTGCGTGTGTGTGTGGTTGGGTCATATCTGAGACACTGTTCCACAGCAACAAAAACAATAAAATTCACTGTATTTTCTCCTAAAAAAAAAAAAAAAAAAAAAAAAAA"};
    uint n = 1000;
    Constraints constraints(Sequence(multiply_substrings({{"N", n}})));
    for (auto i : range(n/2)) constraints.complementarity_constraint(i, n-i-1, false);

    uint window_length = 50;
    vec<int> window(window_length);
    std::iota(begin_of(window), end_of(window), 0);

    vec<Sequence> words;
    for (auto i : range(len(mRNA) - window_length + 1)) {
        Sequence word(vmap<Sequence>(range(i, i+window_length), [&](auto c){return at(mRNA, c);}));
        words.emplace_back(word);
    }
    constraints.word_constraint(window, words);

    auto seq = constraints.initial_sequence().value();
    BEEP(seq);

    auto mut = constraints.make_mutation(seq, {0}).value();
    BEEP(mut);

    BEEP(hamming_distance(seq, mut));

    auto time = time_it(5, [&] {
        constraints.initial_sequence();
    });
    BEEP(time);

    time = time_it(5, [&] {
        constraints.make_mutation(seq, {0});
    });
    BEEP(time);
};


UNIT_TEST("design/gecode/NucSpace_all_constraints") = [](Context ct) {
    uint n = 3200;
    Constraints constraints(Sequence(multiply_substrings({{"N", n*2}})));
    for (auto i : range(n)) constraints.complementarity_constraint(i, 2*n-i-1, false);

    vec<std::pair<string, int>> patterns {{"A", 4}, {"C", 4}, {"G", 4}, {"T", 4}
            // ,
            // {"W", 6}, {"S", 6}, {"M", 6}, {"K", 6}, {"Y", 6}, {"R", 6}
            };

    std::pair<real, real> limits {0.45, 0.55};
    vec<int> all(n);
    std::iota(begin_of(all), end_of(all), 0);

    constraints.similarity_constraint(all, Sequence(multiply_substrings({{"S", n}})), limits);
    // for (auto p : patterns) constraints.pattern_constraint(all, Sequence(multiply_substrings({p})));
    constraints.diversity_constraint(all, 4, 2);
    constraints.diversity_constraint(all, 6, 3);


    uint window_length = 50;
    vec<int> window(window_length);
    std::iota(begin_of(window), end_of(window), 0);

    Sequence mRNA {"CATTTACACAGCGTACAAACCCAACAGGCCCAGTCATGAGCACGAAATATTCAGCCTCCGCCGAGTCGGCGTCCTCTTACCGCCGCACCTTTGGCTCAGGTTTGGGCTCCTCTATTTTCGCCGGCCACGGTTCCTCAGGTTCCTCTGGCTCCTCAAGACTGACCTCCAGAGTTTACGAGGTGACCAAGAGCTCCGCTTCTCCCCATTTTTCCAGCCACCGTGCGTCCGGCTCTTTCGGAGGTGGCTCGGTGGTCCGTTCCTACGCTGGCCTTGGTGAGAAGCTGGATTTCAATCTGGCTGATGCCATAAACCAGGACTTCCTCAACACGCGTACTAATGAGAAGGCCGAGCTCCAGCACCTCAATGACCGCTTCGCCAGCTACATCGAGAAGGTGCGCTTCCTCGAGCAGCAGAACTCTGCCCTGACGGTGGAGATTGAGCGTCTGCGGGGTCGCGAGCCCACCCGTATTGCAGAGCTGTACGAGGAGGAGATGAGAGAGCTGCGCGGACAGGTGGAGGCACTGACCAATCAGAGATCCCGTGTGGAGATCGAGAGGGACAACCTAGTCGATGACCTACAGAAACTAAAGCTCAGACTTCAAGAGGAGATCCACCAGAAAGAGGAAGCTGAAAACAACCTTTCTGCTTTCAGAGCTGATGTCGATGCTGCCACTCTGGCCAGGCTGGACCTGGAAAGACGTATCGAGGGTCTTCACGAAGAGATTGCATTCCTCAGGAAGATTCATGAGGAGGAGATCCGTGAGCTGCAGAACCAGATGCAGGAGAGTCAGGTGCAGATCCAAATGGACATGTCCAAACCAGACCTGACTGCGGCCCTCAGAGACATTCGCCTGCAGTACGAGGCTATCGCTGCCAAGAATATCAGCGAGGCCGAGGACTGGTATAAGTCTAAGGTTTCAGATTTGAACCAGGCAGTGAACAAGAATAACGAGGCTCTCAGAGAAGCCAAGCAGGAGACCATGCAGTTCCGTCACCAGCTCCAGTCCTACACCTGCGAGATTGACTCTCTCAAGGGCACCAATGAGTCTCTGAGGAGGCAAATGAGTGAGATGGAGGAGCGGCTGGGACGTGAGGCCGGTGGTTATCAGGACACTATCGCCCGTCTCGAGGCTGAGATCGCAAAAATGAAAGACGAGATGGCCCGCCACCTCCGCGAGTACCAGGATCTGCTGAATGTGAAGATGGCTCTGGATGTGGAGATCGCCACCTACAGGAAGCTTTTGGAAGGAGAGGAGAGCAGGATCTCGCTGCCCGTGCAGTCCTTTTCATCCCTGAGTTTCAGAGAGAGCAGTCCAGAGCAGCACCACCACCAGCAGCAGCAACCACAACGCTCATCTGAAGTCCACTCCAAGAAAACAGTCCTGATCAAGACCATCGAGACCCGCGATGGCGAGGTCGTCAGCGAGTCCACACAGCACCAGCAGGACGTCATGTAAAGCTTGAGAAACAGATCGAGTTTCACAGAATGCCTTGCATTTTCACTGATGGCCTCAGGCTTTTTTAAGCACACACCCAGTATTGCCGTGACCCATTACCGCATGTGGATGACGCATGGAGACAAAAGGAAAGTGAGCTGAAAAACCAGAGGGAGGAAAAGTGGAATGGTGTGATGCTGAGCGTTCAGAAAGTGGCCAGATGAGCTCAGAGTTTCTGATTTAATGAATGTATGTGTGCGTGTGTGTGTGGTTGGGTCATATCTGAGACACTGTTCCACAGCAACAAAAACAATAAAATTCACTGTATTTTCTCCTAAAAAAAAAAAAAAAAAAAAAAAAAA"};
    vec<Sequence> words;
    for (auto i : range(len(mRNA) - window_length + 1)) {
        Sequence word(vmap<Sequence>(range(i, i+window_length), [&](auto c){return at(mRNA, c);}));
        words.emplace_back(word);
    }
    constraints.word_constraint(window, words);


    auto check_pattern = [&] (auto const &seq) {
        for (auto i : range(n-3)) {
            std::set<Base> counter;
            for (auto j : range(i, i+4)) counter.emplace(at(seq, j));
            ct.require(len(counter) > 1);
        }
        for (auto i : range(n-5)) {
            std::set<Base> counter;
            for (auto j : range(i, i+6)) counter.emplace(at(seq, j));
            ct.require(len(counter) > 2);
        }
    };


    auto seq = constraints.initial_sequence().value();
    BEEP(seq);
    check_pattern(seq);

    auto mut = constraints.make_mutation(seq, {0}).value();
    BEEP(mut);
    check_pattern(mut);

    BEEP(hamming_distance(seq, mut));

    auto time = time_it(10, [&] {
        constraints.initial_sequence();
    });
    BEEP(time);

    time = time_it(10, [&] {
        constraints.make_mutation(seq, {0});
    });
    BEEP(time);
};


UNIT_TEST("design/gecode/ConstraintHandler_all_constraints") = [](Context ct) {
    DesignSequence seqs;
    uint n = 3200;
    uint length = 50;
    seqs.add_domain(DomainSpec("short", {{"N", length}}));
    seqs.add_domain(DomainSpec("dom", {{"N", n-length}}));
    seqs.add_strand(StrandSpec("str", {"short", "dom"}));
    seqs.make_sequence();

    /* GC content constraint */
    vec<string> ref_seqs {"S"};
    for (auto r : ref_seqs) {
        SimilaritySpec gc;
        gc.name = "str";
        gc.reference = multiply_substrings({{r, n}});
        gc.range = {0.45, 0.55};
        gc.add_constraint(seqs);
    }

    /* word constraint */
    WordSpec word;
    word.domains = {"short"};
    Sequence mRNA {"CATTTACACAGCGTACAAACCCAACAGGCCCAGTCATGAGCACGAAATATTCAGCCTCCGCCGAGTCGGCGTCCTCTTACCGCCGCACCTTTGGCTCAGGTTTGGGCTCCTCTATTTTCGCCGGCCACGGTTCCTCAGGTTCCTCTGGCTCCTCAAGACTGACCTCCAGAGTTTACGAGGTGACCAAGAGCTCCGCTTCTCCCCATTTTTCCAGCCACCGTGCGTCCGGCTCTTTCGGAGGTGGCTCGGTGGTCCGTTCCTACGCTGGCCTTGGTGAGAAGCTGGATTTCAATCTGGCTGATGCCATAAACCAGGACTTCCTCAACACGCGTACTAATGAGAAGGCCGAGCTCCAGCACCTCAATGACCGCTTCGCCAGCTACATCGAGAAGGTGCGCTTCCTCGAGCAGCAGAACTCTGCCCTGACGGTGGAGATTGAGCGTCTGCGGGGTCGCGAGCCCACCCGTATTGCAGAGCTGTACGAGGAGGAGATGAGAGAGCTGCGCGGACAGGTGGAGGCACTGACCAATCAGAGATCCCGTGTGGAGATCGAGAGGGACAACCTAGTCGATGACCTACAGAAACTAAAGCTCAGACTTCAAGAGGAGATCCACCAGAAAGAGGAAGCTGAAAACAACCTTTCTGCTTTCAGAGCTGATGTCGATGCTGCCACTCTGGCCAGGCTGGACCTGGAAAGACGTATCGAGGGTCTTCACGAAGAGATTGCATTCCTCAGGAAGATTCATGAGGAGGAGATCCGTGAGCTGCAGAACCAGATGCAGGAGAGTCAGGTGCAGATCCAAATGGACATGTCCAAACCAGACCTGACTGCGGCCCTCAGAGACATTCGCCTGCAGTACGAGGCTATCGCTGCCAAGAATATCAGCGAGGCCGAGGACTGGTATAAGTCTAAGGTTTCAGATTTGAACCAGGCAGTGAACAAGAATAACGAGGCTCTCAGAGAAGCCAAGCAGGAGACCATGCAGTTCCGTCACCAGCTCCAGTCCTACACCTGCGAGATTGACTCTCTCAAGGGCACCAATGAGTCTCTGAGGAGGCAAATGAGTGAGATGGAGGAGCGGCTGGGACGTGAGGCCGGTGGTTATCAGGACACTATCGCCCGTCTCGAGGCTGAGATCGCAAAAATGAAAGACGAGATGGCCCGCCACCTCCGCGAGTACCAGGATCTGCTGAATGTGAAGATGGCTCTGGATGTGGAGATCGCCACCTACAGGAAGCTTTTGGAAGGAGAGGAGAGCAGGATCTCGCTGCCCGTGCAGTCCTTTTCATCCCTGAGTTTCAGAGAGAGCAGTCCAGAGCAGCACCACCACCAGCAGCAGCAACCACAACGCTCATCTGAAGTCCACTCCAAGAAAACAGTCCTGATCAAGACCATCGAGACCCGCGATGGCGAGGTCGTCAGCGAGTCCACACAGCACCAGCAGGACGTCATGTAAAGCTTGAGAAACAGATCGAGTTTCACAGAATGCCTTGCATTTTCACTGATGGCCTCAGGCTTTTTTAAGCACACACCCAGTATTGCCGTGACCCATTACCGCATGTGGATGACGCATGGAGACAAAAGGAAAGTGAGCTGAAAAACCAGAGGGAGGAAAAGTGGAATGGTGTGATGCTGAGCGTTCAGAAAGTGGCCAGATGAGCTCAGAGTTTCTGATTTAATGAATGTATGTGTGCGTGTGTGTGTGGTTGGGTCATATCTGAGACACTGTTCCACAGCAACAAAAACAATAAAATTCACTGTATTTTCTCCTAAAAAAAAAAAAAAAAAAAAAAAAAA"};
    vec<string> words;
    for (auto i : range(len(mRNA) - length + 1)) {
        auto w = vmap<Sequence>(range(i, i+length), [&](auto c){return at(mRNA, c);});
        words.emplace_back(w.str());
    }
    word.comparisons = {words};
    word.add_constraint(seqs);


    /* pattern constraints */
    vec<PatternSpec> pats {{"str", "AAAA"}, {"str", "CCCC"}, {"str", "GGGG"}, {"str", "UUUU"},
             {"str", "WWWWWW"}, {"str", "SSSSSS"}, {"str", "MMMMMM"}, {"str", "KKKKKK"}, {"str", "YYYYYY"}, {"str", "RRRRRR"}
    };
    for (auto const &p : pats) p.add_constraint(seqs);

    auto init_time = time_it(10, [&] {
        seqs.initialize_sequence();
    });

    auto sequence = seqs.nucleotides;
    BEEP(sequence);

    auto time = time_it(10, [&] {
        seqs.set_sequence(sequence);
        seqs.mutate_sequence({mut});
    });
    BEEP(seqs.nucleotides);

    BEEP(hamming_distance(sequence, seqs.nucleotides));

    BEEP(init_time);
    BEEP(time);
};

UNIT_TEST("design/gecode/ConstraintHandler_pattern_constraint") = [](Context ct) {
    DesignSequence seqs;
    uint n = 3200;
    uint length = 50;
    // seqs.add_domain(DomainSpec("short", {{"N", length}}));
    seqs.add_domain(DomainSpec("dom", {{"N", n}}));
    seqs.add_strand(StrandSpec("str", {"dom"}));
    // seqs.add_strand(StrandSpec("str", {"short", "dom"}));
    seqs.make_sequence();

    /* pattern constraints */
    vec<PatternSpec> pats {{"str", "AAAA"}, {"str", "CCCC"}, {"str", "GGGG"}, {"str", "UUUU"},
             {"str", "WWWWWW"}, {"str", "SSSSSS"}, {"str", "MMMMMM"}, {"str", "KKKKKK"}, {"str", "YYYYYY"}, {"str", "RRRRRR"}
    };
    for (auto const &p : pats) p.add_constraint(seqs);

    auto init_time = time_it(5, [&] {
        seqs.initialize_sequence();
    });

    auto sequence = seqs.nucleotides;
    BEEP(sequence);

    auto time = time_it(5, [&] {
        seqs.set_sequence(sequence);
        seqs.mutate_sequence({mut});
    });
    BEEP(seqs.nucleotides);

    BEEP(hamming_distance(sequence, seqs.nucleotides));

    BEEP(init_time);
    BEEP(time);
};

}}
