#include "../Test.h"

#include <nupack/design/Designer.h>
#include <nupack/design/ThermoWrapper.h>
#include <nupack/design/Complex.h>
#include <nupack/design/Defect.h>
#include <nupack/design/Specification.h>

namespace nupack::newdesign {


using Condition = cpy::Callback<bool>;
using Handler = cpy::Callback<void>;

struct DesignRunner {
    auto operator()(Specification const &spec, Local const &env, Condition condition, Handler handler) const {
        SignalRuntime l;

        if (bool(condition.function) ^ bool(handler.function)) {
            string msg = "If using checkpointing with designer, "
            "you must have both a checkpoint condition and a checkpoint handler";
            NUPACK_ERROR(msg);
        }

        Designer d(spec);
        d.initialize();

        // if (bool(_restart)) {
        //     auto const &restart = _restart.value();
        //     auto const &res = restart.results[0];
        //     auto mapping = ensure_compatibility(spec, res); // throw useful errors where there are mismatches
        //     auto &seqs = d.design.sequences;

        //     for (auto const &domain: res.domains) seqs.set_domain(domain.first, domain.second);

        //     d.Psi.mask = vmap<decltype(d.Psi.mask)>(mapping, [&](auto i) {return restart.stats.final_Psi.active(i);});
        //     d.stats = restart.stats;
        //     d.redecompose_active(env, 0);
        // }

        if (condition.function) {
            auto real_condition = [c=std::move(condition)] (Designer const &des) {return c(des.stats, des.timer);};
            auto real_handler = [&, h=std::move(handler)] (Designer &des) {
                des.stats.design_time += des.timer.stop();
                des.stats.final_Psi = des.Psi;
                auto sequence = des.best_sequence(env);
                auto result = DesignResult(des);
                h(std::move(result));
                des.timer.start();
            };
            d.checkpoint = [handler=std::move(real_handler),
                    condition=std::move(real_condition)] (Designer &des) {if (condition(des)) handler(des);};
        }

        d.optimize_tubes(env);

        // d.design.set_sequence(d.best.full.sequence);
        return DesignResult(d);
    }
};

PROTOTYPE("design/runner/run_json") = [](Context ct, std::string in, std::string out) {
    std::ifstream ifs(in);
    json input;
    ifs >> input;

    Specification spec = input.get<Specification>();
    auto runner = DesignRunner();
    auto result = runner(spec, {}, Condition({}, {}), Handler({}, {}));

    json output(result);

    std::ofstream ofs(out);
    ofs << std::setw(4) << output << std::endl;
};

}
