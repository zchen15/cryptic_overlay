#include "../Test.h"
#include <nupack/execution/Local.h>
#include <nupack/design/ThermoWrapper.h>
#include <nupack/iteration/View.h>
#include <nupack/types/Sequence.h>
#include <nupack/design/SequenceAdapter.h>
#include "TestingEnvironments.h"

namespace nupack { namespace newdesign {

PROTOTYPE("design/sequences/view-sequence") = [](Context ct) {
    Sequence seq = Sequence("AAAACCCCTTTTGGGG");
    BEEP(seq);
    BEEP(view(seq));

    vec<decltype(view(seq, 0, 0))> views {view(seq, 0, 4), view(seq, 8, 12)};
    BEEP(views);
    NickSequence multi(views);
    seq[2] = Base('T');
    BEEP(seq);
    BEEP(views);

    BEEP(multi);
};

void transfer_seq(Sequence & seq, string input) {
    transform(input, seq, [] (auto a) {return Base(a);});
};

PROTOTYPE("design/sequences/run-views") = [](Context ct) {
    CachedModel m32(PF(), Model<real32>(Ensemble::none, {}, {}, {}, WobblePairing::on));
    m32.reserve(10000);
    CachedModel m64(PF(), Model<real64>(Ensemble::none, {}, {}, {}, WobblePairing::on));
    m64.reserve(10000);

    Local env;
    auto run = [&] (auto const &m_seq) {
        auto models = std::tie(m32, m64, m32, m64);
        BEEP(m_seq);
        auto ret_val = partition_function(env, m_seq, models);
        BEEP(ret_val);
    };

    Sequence seq = Sequence("AAAACCCCTTTTGGGG");
    BEEP(seq);
    vec<decltype(view(seq, 0, 0))> views {view(seq, 0, 4), view(seq, 8, 12)};
    run(views);

    transfer_seq(seq, "ACTGACTGACTGACTG");
    BEEP(seq);
    run(views);
};

UNIT_TEST("design/sequences/iterator-vector") = [](Context ct) {
    DesignSequence state = example_state();
    auto inds = state.get_strand("all As").to_indices();

    ct.equal(len(inds), 16);
    for (auto i : inds) ct.equal(state.nucleotides[i], Base('A'));
};

UNIT_TEST("design/sequences/seq-test") = [](Context ct) {
    DesignSequence state = example_state();
    auto strand = state.get_strand("all As");
    ct.equal(strand, state.get_strand("all As"));
    auto domain = state.get_domain("g");
    ct.equal(strand.to_sequence(state.nucleotides), Sequence("AAAAAAAAAAAAAAAA"));
    ct.equal(domain.to_sequence(state.nucleotides), Sequence("GGGG"));

    state.nucleotides[0] = Base('C');
    ct.equal(strand.to_sequence(state.nucleotides), Sequence("CAAACAAACAAACAAA"));

    // should revert back to constrained sequence
    state.initialize_sequence();
    ct.equal(strand.to_sequence(state.nucleotides), Sequence("AAAAAAAAAAAAAAAA"));
};


PROTOTYPE("design/sequences/random-seqs") = [](Context ct) {
    DesignSequence state;

    state.add_domain(DomainSpec("any", {{"N", 5}}));
    state.add_domain(DomainSpec("weak", {{"W", 5}}));
    state.add_domain(DomainSpec("strong", {{"S", 5}}));

    BEEP(state);
    state.make_sequence();
    BEEP(state);
    state.initialize_sequence();
    BEEP(state);
};

UNIT_TEST("design/sequences/views-are-same") = [](Context ct) {
    DesignSequence state = example_state();
    auto g1 = state.get_domain("g");
    auto g2 = state.get_domain("g");
    auto a = state.get_domain("a");

    ct.equal(g1, g2);
    ct.not_equal(a, g1);
    ct.equal(state.get_strand("reverse domains"), state.get_strand("reverse domains"));
    ct.not_equal(state.get_strand("reverse domains"), state.get_strand("all As"));
};

UNIT_TEST("design/sequences/slice-strand") = [](Context ct) {
    DesignSequence state = example_state();
    auto strand = state.get_strand("reverse domains");

    ct.equal(strand.to_sequence(state.nucleotides), Sequence("GGGGTTTTCCCCAAAA"));

    ct.info("make sure the Sequence comparison is working correctly.");
    ct.not_equal(strand.to_sequence(state.nucleotides), Sequence("A"));
    ct.throw_as<std::runtime_error>([&] {strand.slice(4, 3);});

    auto ref_seq = Sequence("GGGGTTTTCCCCAAAA");
    for (auto i : range(len(strand))) {
        for (auto j : range(i, len(strand))) {
            auto left = strand.slice(i, j).to_sequence(state.nucleotides);
            auto right = view(ref_seq, i, j+1);
            // BEEP(i, j, j-i, left, right);
            ct.equal(len(left), len(right));
            ct.equal(left, right);
        }
    }
};

UNIT_TEST("design/sequences/domain-complements") = [](Context ct) {
    auto state = example_state();
};

PROTOTYPE("design/sequences/print-add-complement") = [](Context ct) {
    auto state = example_state();
    state.initialize_sequence();
    state.print_components();
};

UNIT_TEST("design/sequences/check-complementarity") = [](Context ct) {
    vec<string> comp_dom_names {"a*", "t*", "c*", "g*"};
    vec<string> expected_seqs {"TTTT", "AAAA", "GGGG", "CCCC"};

    auto state = example_state();
    state.initialize_sequence();
    auto comp_doms = indirect_view(comp_dom_names, [&](auto const &n) {return state.get_domain(n);});
    zip(comp_doms, expected_seqs, [&](auto const &d, auto const &s) {
        ct.equal(d.to_sequence(state.nucleotides), Sequence(s));
    });
};


UNIT_TEST("design/sequences/assign-domain") = [](Context ct) {
    DesignSequence state;
    state.add_domain("a", "AAAA");
    state.add_domain("s", "SSSS");
    state.add_domain("n", "NNNN");
    state.add_strand({"san", {"s", "a", "n"}});

    state.add_domain_complements();
    state.make_sequence();

    ct.throw_as<Error>([&]{state.set_domain("a", Sequence("ATAT"));});
    state.set_domain("s", Sequence("GGCC"));
    state.set_domain("n", Sequence("ATCG"));
    ct.equal(Sequence("GGCCAAAAATCG"), state.get_strand("san").to_sequence(state.nucleotides));
};

}
}
