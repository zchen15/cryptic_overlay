// #pragma once

#include <nupack/design/SequenceAdapter.h>
#include <gecode/int.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <gecode/search.hh>
#include <gecode/gist.hh>

namespace nupack { namespace newdesign {

using namespace Gecode;

void hamming_distance(Space& space,
                      IntVarArray a,
                      IntVarArray b,
                      int n,
                      IntVar diffs) {

  BoolVarArgs d;
  for(int i = 0; i < n; i++) {
    d << expr(space, a[i] != b[i]);
  }
  rel(space, diffs == sum(d));
}

inline void gist_printer(const Space &home, const Brancher &b, unsigned int a, IntVar x, int i, const int &n, std::ostream& o) {
    print_os<io::comma>(o, i, x, a, n);
}

struct Example : public Space {
    IntVarArray nucs;
    // IntVar _cost;
    IntVarArray ref;

    Example(uint n) :
            nucs(*this, n*2, 0, 3)
            // _cost(*this, 0, n*2)
            {


        // for (auto i : range(n-1)) {
        // for (auto i : range(n-3)) {
        //     rel(*this, nucs[i], IRT_NQ, nucs[i+1]);
        //     rel(*this, nucs[i], IRT_NQ, nucs[i+2]);
        //     rel(*this, nucs[i], IRT_NQ, nucs[i+3]);
        // }

        /* complementarity */
        for (auto i : range(n)) {
            rel(*this, nucs[i] == 3 - nucs[n+i]);
        }


        // uint length = 4;
        // for (auto i : range(n-length)) {
        //     for (auto j : range(4)) {
        //         IntArgs comp(vec<int>(length, j));
        //         count(*this, nucs.slice(i, 1, length), comp, IRT_LE, length);
        //     }
        // }

        // /* global cardinality */
        // if (n >= 8) {
        //     // count(*this, nucs.slice(0, 1, 4), IntArgs({0, 1, 2, 3}), IRT_EQ, 4);
        //     count(*this, nucs.slice(0, 1, 4), IntArgs({0, 1, 2, 3}), IRT_EQ, 4);
        // }
    }

    Example(Example &other) : Space(other) {
        nucs.update(*this, other.nucs);
        // _cost.update(*this, other._cost);
        ref.update(*this, other.ref);
    }

    Example * copy() {
        return new Example(*this);
    }

    void disallow(std::pair<int, int> dis) {
        /* knockout */
        rel(*this, nucs[dis.first], IRT_NQ, dis.second);
    }

    void force(std::pair<int, int> force) {
        rel(*this, nucs[force.first], IRT_EQ, force.second);
    }

    void add_reference(vec<int> _ref) {
        IntVarArgs temp;
        for (auto i: _ref) temp << IntVar(*this, IntSet({i}));
        ref = IntVarArray(*this, temp);

        /* set up cost variable */
        // IntVar counter(*this, 0, n);
        // count(*this, nucs.slice(0, 1, n), IntArgs(ref), IRT_EQ, counter);
        // rel(*this, _cost == n - counter);
        // hamming_distance(*this, nucs, ref, ref.size(), _cost);
        // rel(*this, _cost == 0);

        // Rnd rnd(random_range(1,1e10));
        branch(*this, nucs, INT_VAR_NONE(), INT_VAL([&](auto const &home, auto x, auto i) {
            int ret {-1};
            if (i < ref.size()) {
                auto r = ref[i].val();
                if (x.in(r)) ret = r;
            }
            if (ret == -1) ret = x.min();
            return ret;
        }), {}, &gist_printer);
        // default_brancher();
    }

    void default_brancher() {
        Rnd r(1U);

        // branch(*this, nucs, INT_VAR_AFC_SIZE_MAX(0.5), INT_VAL_RND(r));
        // branch(*this, nucs, INT_VAR_NONE(), INT_VAL_MIN());
        branch(*this, nucs, INT_VAR_RND(r), INT_VAL_RND(r), {}, &gist_printer);
        // branch(*this, _cost, INT_VAR_RND(r), INT_VAL_RND(r));
        // branch(*this, ref, INT_VAR_RND(r), INT_VAL_RND(r));
    }

    void add_gc_content() {
        uint n = nucs.size() / 2;
        IntSet gc({1,2});

        /* GC content constraint on basic variables */
        count(*this, nucs.slice(0, 1, n), gc, IRT_GQ, int(0.55 * n));
        count(*this, nucs.slice(0, 1, n), gc, IRT_LQ, int(0.65 * n));

        // BoolVarArgs d;
        // for(int i = 0; i < n; i++) {
        //     d << expr(*this, singleton(nucs[i]) <= gc);
        // }
        // rel(*this, sum(d) <= int(0.65 * n));
        // rel(*this, sum(d) >= int(0.55 * n));
    }

    void word_constraint(vec<int> vars, vec<vec<int>> words) {
        uint n = len(vars);
        IntVarArgs variables;
        for (auto v : vars) { variables << nucs[v]; }

        BoolVarArgs per_word;
        for (auto const &word : words) {
            IntArgs intword(word);
            BoolVarArgs d;
            for (auto i : range(n)) d << expr(*this, variables[i] == intword[i]);
            per_word << expr(*this, sum(d) == n);
        }
        rel(*this, BOT_OR, per_word, 1);
    }

    Example * cast_clone() {
        status();
        return static_cast<Example *>(this->clone());
    }


    // virtual IntVar cost() const { return _cost;}

    void print(std::ostream &os=std::cout) const {
        os << nucs << std::endl;
    }

};

}
}
