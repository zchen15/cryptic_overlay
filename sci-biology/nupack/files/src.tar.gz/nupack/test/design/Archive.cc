#include "../Test.h"

#include <nupack/design/Archive.h>

namespace nupack { namespace newdesign {

Result make_result(vec<real> defects) {
    return {Sequence(), vmap(defects, [](auto d) {
        defect_vec temp;
        temp.emplace_back(std::make_pair(0u, d));
        return Defect(std::move(temp));
    })};
}

UNIT_TEST("design/archive/dont-add-any") = [](Context ct) {
    Archive arch;
    auto a = make_result({0});
    auto b = make_result({1});

    ct.require(!arch.attempt_add(a));
    ct.require(!arch.attempt_add(b));
};

UNIT_TEST("design/archive/dont-add-worse") = [](Context ct) {
    Archive arch(2);
    auto a = make_result({0});
    auto b = make_result({1});

    ct.require(arch.attempt_add(a));
    ct.require(!arch.attempt_add(b));
};

UNIT_TEST("design/archive/kick-out-worse") = [](Context ct) {
    Archive arch(2);
    auto a = make_result({0});
    auto b = make_result({1});

    ct.info("add bad defect");
    ct.require(arch.attempt_add(b));
    ct.info("remove bad defect");
    ct.require(arch.remove_dominated_by(a));
};

UNIT_TEST("design/archive/kick-out-worse-following-add") = [](Context ct) {
    Archive arch(2);
    auto a = make_result({0});
    auto b = make_result({1});

    ct.info("add bad defect");
    ct.require(arch.attempt_add(b));
    ct.info("remove bad defect");
    ct.require(arch.attempt_add(a));
    ct.equal(len(arch), 1);
    ct.equal(arch.results.at(0).totals(), a.totals());
};

UNIT_TEST("design/archive/kick-out-worse-following-add-pareto") = [](Context ct) {
    Archive arch(2);
    auto a = make_result({0,1});
    auto b = make_result({1,2});

    ct.info("add bad defect");
    ct.require(arch.attempt_add(b));
    ct.info("remove bad defect");
    ct.require(arch.attempt_add(a));
    ct.equal(len(arch), 1);
    ct.equal(arch.results.at(0).totals(), a.totals());
};

UNIT_TEST("design/archive/add-non-dominated") = [](Context ct) {
    Archive arch(2);
    auto a = make_result({0,1});
    auto b = make_result({1,0});

    ct.info("add first");
    ct.require(arch.attempt_add(a));
    ct.info("add second");
    ct.require(arch.attempt_add(b));
    ct.equal(len(arch), 2);
};

UNIT_TEST("design/archive/no-add-twice") = [](Context ct) {
    Archive arch(2);
    auto a = make_result({0,1});

    ct.info("add first");
    ct.require(arch.attempt_add(a));
    ct.info("add second");
    ct.require(!arch.attempt_add(a));
    ct.equal(len(arch), 1);
};

UNIT_TEST("design/archive/replace-with-more-diverse") = [](Context ct) {
    Archive arch(2);
    auto a = make_result({0,1});
    auto b = make_result({0.1,0.9});
    auto c = make_result({1,0});

    ct.info("add first");
    ct.require(arch.attempt_add(a));
    ct.info("add second");
    ct.require(arch.attempt_add(b));
    ct.info("add third");
    ct.require(arch.attempt_add(c));
    ct.info("still only two components");
    ct.equal(len(arch), 2);
    ct.info("contains exactly one of a and b (distances should be symmetric for two elements inititally)");
    ct.require(contains(arch.results, a) ^ contains(arch.results, b));
    ct.info("has the more diverse element");
    ct.require(contains(arch.results, c));
};

PROTOTYPE("design/archive/default-construction") = [](Context ct) {
    BEEP(Archive());
};


}}
