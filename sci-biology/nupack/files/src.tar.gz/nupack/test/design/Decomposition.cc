#include "../Test.h"
#include <nupack/design/Decomposition.h>
#include <nupack/design/Complex.h>
#include <nupack/olddesign/split_set.h>
#include <nupack/design/ThermoWrapper.h>
#include "TestingEnvironments.h"

#include <nupack/reflect/Serialize.h>

namespace nupack { namespace newdesign {

UNIT_TEST("design/decomposition/decomposition-invariant-maintained") = [](Context ct) {
    int H_split {2};
    int N_split {12};
    real f_split {0.99};

    uint num_trials {100};
    uint length {200};
    ModelMap models;
    auto &t_env = models.get(ModelKey("RNA", "min"));
    Local env;

    DecompositionParameters params;

    repeat_test(ct, range(num_trials), [&](auto i) {
        // build the decomposition tree
        auto seq = random_sequence(length);
        seq = Sequence(string(seq) + string(reverse_complement(seq)));
        vec<DomainView> domains = {{0, length}, {length, 2*length}};
        vec<StrandView> strands = vmap(domains, [](auto const &d) { return StrandView({d}); });
        std::stringstream strstream;
        strstream << "(" << length << "+" << ")" << length;
        Structure structure(strstream.str());
        ComplexNode root(strands, structure, {});
        root.probability_decompose(params, seq, t_env);
        ct("depth", root.depth());

        auto check_invariant = [&] (auto const &node) {
            if (len(node.children) > 0) {
                auto parent_log_pf = node.dynamic_program(env, t_env, seq, 0, params).second;
                auto child_log_pf = node.dynamic_program(env, t_env, seq, 1, params).second;
                ct("sequence", seq);
                ct("child_log_pf", child_log_pf);
                ct("parent_log_pf", parent_log_pf);
                ct(HERE).require(std::exp(child_log_pf - parent_log_pf) > f_split);
            }
        };

        root.apply_recursive(check_invariant);
    });
};


UNIT_TEST("design/decomposition/compare-with-complex") = [](Context ct) {
    auto design = build_hcr();
    auto seq = Sequence("GGGGGGAGGTGGGTGGTTGAATGAGTATGAAAGAGCTGGAGTAAATTGCCACCTCCCCCCGCTCTTTCATACTCATTCAACCACCAATTTACTCCA");
    design.set_sequence(seq);

    auto const &complex = design.complexes[0];

    Local env(1);
    ct.equal(complex.log_pfunc(env, design.models, design.sequence()), complex.log_pfunc(env, design.models, design.sequence(), 0));
    auto pprobs_c = complex.pair_probabilities(env, design.models, design.sequence());
    auto pprobs_d = complex.pair_probabilities(env, design.models, design.sequence(), 0);
    uint N = len(complex);
    for (auto i : range(N))
        for (auto j : range(N))
            ct.equal(*pprobs_c(i, j), about(pprobs_d(i, j)));
    // zip(pprobs_d, pprobs_c, [&](auto a, auto b) {
    //     ct.equal(a, about(b));
    // });
};


UNIT_TEST("design/decomposition/should-not-be-NaN") = [](Context ct) {
    DesignSequence seqs;
    seqs.add_domain("a", "CCGCCACTGCTCAGGATACTATCCCGACGACACGCTTTGTTTACCGTCCCCAAGCCCGACTGTATTGACCTAGATACCTGAAGGTCTTGGTCCAATCGCCATAGACGATCAAAATCTCCAATAATTCCTCAGCCGACTTTCCATCTTGTCGGCTAGGAATTATTGGAGATTTTGAGAAGCCATTTGCCACTCGCCGCGAGTGGCAAATGGCAAGTCTATGAGGGTGACACATGAAGAGACAGATGTCCGCGAGTCTCTCTACCTATCATCGATGCCTGAACTCCTCCCTCACACCAAACTTAATCCCCCCCTGAGGAGTTCAGGGCCCGGTCGGTTGTAAGCTAGGAGGGTTTCCTAAACTTCCCCCCCTCATCCAGTCCTATCAAAAAGAAGTTTAGGAAACGCTTACAACCGACGTAGAAGCCAACTCTCCTGCTCTGTTGGCTTGAGACCATCGATGAAGACTCGCGGACATCTGTCTGTTCATGTGTCACCCGACCAAGACCTTCAGCAATACAGTCGGGCTAAGTTCGGAGGGGACGGTAAACAAAGCGATCGTCGGGATAGTATCCTGAGCAGTGGCGGGAACAGGTCAGAAACATCCTTCCCGGGCGGACGAAAGGCTATAGCATCTCTGCACAGGCCGCCCATCCGGTTTTTAGTTCTCGTTCGTAGGATGGGCGGCCTGACCGGCAGAGATGCTATAGCCTTTCGTCCGCCGGTGTTGACAGCATGATTCCATTGCTACCCCCTACAGAGAATGGGGGTAGCAATGGAATCATGCTGTCCTTGGACCCTCCCCGGCCTTAAGTCCACGGGGATACTATCCAGAAGACAACAATTCTGGATAGTTCCCCGTGGACTTGGAGGGCGGGAAGGATGTTTCTGGGCTTCCTAACAGTCCTGGAAGCGGTGAATTACTGTTCGCGCAAGGCTACAGGAGCACACTGTTGGGTAAACTATGGGCCTGAATCGTGGGTTAAGTAGGCGACCCGACCATTACAACTTAAGGCCTACTTAACAGGGCTTGACGCCAAAAGCTGCAACAACCCAATAACAGTGTTTGCGGGGACTGCTCCCGGAGGATAATTGCTTCTTATACGCTTGGGTATCCTCCGCCCCGCAAACGGTTGTTGCCCTTTTGGCGTCAAGCCCGGTAATCGCCGCGTATGTTTCGAGACGAAGCCCCACTATGACAACTGCTTCGTCTCCGCGGCGATTACCAGATTCAGGCCCATAGGCACCCAACAGTGTGCTCCTGAGCCTTGCGCCGCGCTAAAGTGGTTTGCGAGACCGGTCGAGTACTGGACTGTGAATCCCCAGTACTCGACCGGGAAGAGGCTCGCAAACCACTTTAGCCCAACGCCCTAAGTATTCGCCATGTTTGTAACCACATGGCCTCCGATCTTTTCATCTGAGGGTGTTAAAAGATGAAAAGATCTTGCCATGTGGTTACAAACAGCTCTACCGAATACTTAGGGCGTTGGCCGATACCGGGTGCCTCAACGCAGGACTTTAGATCGTCCTGCGGATGAGGCACGTATCGGGCATTGCTCGATGATCAGGGCCTCATGGGTTTATCTGTGCGACGTTGTCTCCAAGTGATCTACAAGTACTATGGCAAGAGTTTCATTGTGGAATGGAAATCCCCTCGGATTTCCTGTACTGAAATATTAATACTATCGGAAAAATAGCGGACGATAGTATTAATATTTCAGTACTATGGGCGAGCGACAGGGGCCGACGCGACTGGGAACGAATATGCCCAGTCGCGTCGGCCCCTGTCGCTCGCCGGAATCACAATGAAACTCTTGCAACGGGCACCTCCTGATCAGCTCCACCGGTATAGGTCCGGTGGAGCGGTGCCAGGCGTGTACCATACACACCGTATTGAAGGTCCTAGACTAGTCAGGGTGGGTCACTAAAAGCTCCCCGACCCACCCTGACTAGTCTAGGACCCGGGGGACGCCTTCAGGCAGAGTACCCGCGCATACGCTACCTTCCCCATCACACCACCGCGTATGCGCGGGTACTCTGCGGCGTCGGTGTGTATGGTACACGCCCATAGTACGATCACTTGGAGACCCGTCGCACAGATAAACGAGGCCCGTCCTCATCGAGCAATGACTCTGATGCATGAGGTATCGTTAAGCACCGAGGTCGCTACGCCTTTCTTTACAACCTCTACGCGTAGCGACCTCCGGTCAGCGCCAATAAAATGTGCTCCCCGGGCGGGCTAAATCGTCTGACGAATGGCAGGGTCAGACGATTTAGCCCGCCCGGTCCAATGAGCACATTTTATTGGCGCTGACCTCCACCCCCTTAACGATACCTCAGCATCAGAGGATCTTAATAGAGCTTCAATATCCCAGAAGCTCTATTAAGAGGTAAAAGTACATTCTCTGCCCTTTTACCCCCTTTATAAGAGAATGTACGGATAGCGTTAAGTTTACAATTATGGGTCGTACGTCGAGTACGTGATTCTCATTCTTTCCTCGTCTTACTTCTCTTATCACGTACTCGACGTACGACCCATAATTGGCTGGCCTTGGAGTAGGTGGAAAGAATACTTTTAAAACTCCCTACTAACTTTCCACCTACTCCAAGAGGGGTAGAAGCGCTGGCTCACGTTCTCTGGTCCAACCCGCCGGTTGTCTGTCGCCGGAATAGCTGGCCTGAGCTATTCGTCTCCGTTGTTCCTCCGGGTTCTATGCAAAAGCATAGAAGAGGAACAACAGACGAGAATCCCTTCGTCAGTTGACGCCAATTAATCCCGCGTCAACTGACGAAGGGCAACAGGCCAGCTATTCCGGCTTCCCAGACAACCGGCGGGTTGGAGCAGAGAACGTGAGCCAGCGCTTCTACCCCCTTAACGCTATCCGGCCCCACGGGCAAATCCGCTCCAGTCTAACGAAATAGTCTAATGCCCCTTACACATACGGCAATGACACATGTGTCGTTTGAACAGCAAACTGTTCAGAGATCTCACGAGCTCGAGGGGCGCGCACTCAATATCCAATCTTACCAAAGCCCCTCGAGAGAGATCTCTGAACAGTTTGCTGTTCTCACATGTGTCATTGCAAGGGGCATTAGACCGGCGTTAGACTAGCGGACGTGGGGCCCAATTGGACTGATATAGGTACCCCCTACAACCCCTATATACACAACAAAACCATGGGGTACCTATATCAGTCCAATTG");
    seqs.add_strand({"A", {"a"}});
    seqs.add_domain_complements();
    seqs.make_sequence();

    vec<string> strands {"A"};
    auto seq = vmap<vec<StrandView>>(strands, [&](auto const &s) {return seqs.get_strand(s);});

    ModelKey key("rna06", "min", DefaultTemperature, 1.0, 0.0);

    DecompositionParameters params;
    params.H_split = 2;
    params.N_split = 12;

    Complex c(seq, Target(key, "(30.2(19.(15.10(15.7(7.2(21.(7.10)28.3(15.3)15.2)7.(14.(20.9(21.26)12.5(13.7(14.26)27.4(8.11)8.5)29.)44.9)19.)30(6.2(45.(14.21)14.4)28.6(26.10)26.6(6.8(13.(11.8)47.(6.10)6.9)6(10.(19.3(15.4(11.22)11.(17.2(9.10(10.8(9.21)28.)17(13.8(10.15)23.)15.2)29.3(18.(15.11)15.7)18(19.3(18.4(13.12)13.2)18.7)19(7.3(8.(8.8)8.2)15.(13.3(7.4(16.2(14.5(25.4(8.4)8.(23.13)23.4(29.10)29.5)17.4(6.9(10.7)16.(19.8(25.14)25.5(6.5(21.21)68.)23.4)13.(9.(15.4(13.19)13.(24.(23.10)23.6)24.8)24.2(15.9)15.7(11.20)11(13.4(30.29)30.6(18.24)18.(29.(20.2(18.6(6.2(10.4(8.4)24.4(18.11)18.3)18.4)20.)42(9.6(6.2(9.5(14.9(15.6(25.5(10.27)10.)25.)29.3)24(24.30)24"), "", params);
    ModelMap mods;
    auto &ms = c.target.environment(mods);

    c.structure_decompose();
    c.index_nodes();

    Local env;
    auto s = seqs.nucleotides;

    try {
        c.log_pfunc(env, mods, s, 6);
    } catch (Error const &e) {
        BEEP(e.what());

        auto indices = c.get_node_indices(6);
        BEEP(indices);
        auto f = [&] (auto x) {
            if (contains(indices, x.index)) {
                auto nickseq = to_nick_sequence(x.sequence, s);
                auto result = x.dynamic_program(env, ms, s, 0, params).second;
                if (std::isnan(result))
                    BEEP(x.index, x.enforced_pairs, x.sequence, x.structure, nickseq, result, newdesign::partition_function(env, nickseq, ms));
            }
        };

        c.decomposition.apply_recursive(f);
        throw(e);
    }
};


PROTOTYPE("design/decomposition/structure-based") = [](Context ct) {
    auto design = build_hcr();
    auto seq = Sequence("GGGGGGAGGTGGGTGGTTGAATGAGTATGAAAGAGCTGGAGTAAATTGCCACCTCCCCCCGCTCTTTCATACTCATTCAACCACCAATTTACTCCA");
    design.set_sequence(seq);

    Local env(1);
    for (auto &c : subview(design.complexes, range(7))) {
        c.structure_decompose();
        BEEP(c.target.structure.dp_rle());
        for (auto i : range(5)) BEEP(c.log_pfunc(env, design.models, design.sequence(), i));
    }

    // auto decomp = Decomposition(at(design.complexes, 0));
    // BEEP(decomp.pair_probabilities(design.models, design.sequence(), 0));
    // BEEP(decomp.pair_probabilities(design.models, design.sequence(), 1));
    // BEEP(decomp.pair_probabilities(design.models, design.sequence(), 2));
};


PROTOTYPE("design/decomposition/probability-based") = [](Context ct) {
    auto design = build_hcr();
    auto seq = Sequence("GGGGGGAGGTGGGTGGTTGAATGAGTATGAAAGAGCTGGAGTAAATTGCCACCTCCCCCCGCTCTTTCATACTCATTCAACCACCAATTTACTCCA");
    design.set_sequence(seq);
    real fsplit = 0.99;

    Local env(1);
    for (auto &c : design.complexes) {
        c.probability_decompose(design.sequence(), design.models);
        c.index_nodes();
        // BEEP(c);
        BEEP(c.depth());
        for (auto i : range(c.depth() + 1)) BEEP(i, c.get_node_indices(i));
        auto log_pfs = vmap<vec<real>>(range(c.depth() + 1), [&](auto i) {return c.log_pfunc(env, design.models, design.sequence(), i);});
        for (auto i : range(c.depth())) BEEP(i, std::exp(log_pfs[i+1] - log_pfs[i]));
    }

    // auto decomp = Decomposition(at(design.complexes, 0));
    // BEEP(decomp.pair_probabilities(design.models, design.sequence(), 0));
    // BEEP(decomp.pair_probabilities(design.models, design.sequence(), 1));
    // BEEP(decomp.pair_probabilities(design.models, design.sequence(), 2));
};


// PROTOTYPE("design/decomposition/valid-decomposition") {
//     auto design = build_hcr();
//     design.initialize_sequence();
//     real fsplit = 0.99;
//     izip(design.complexes, [&](auto i, auto &c) {
//         c.probability_decompose(12, 2, fsplit, design.sequence(), design.models);
//         c.index_nodes();
//         auto log_pfs = vmap<vec<real>>(range(c.depth() + 1), [&](auto x) {return c.log_pfunc(env, design.models, design.sequence(), x);});
//         for (auto j : range(c.depth())) {
//             INFO(i);
//             INFO(j);
//             INFO(design.sequence());
//             CHECK(std::exp(log_pfs[j+1] - log_pfs[j]) > fsplit);
//         }
//     });
// }


}}
