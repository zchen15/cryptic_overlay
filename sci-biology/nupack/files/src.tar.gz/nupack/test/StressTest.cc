#include <chrono>
#include <nupack/common/Runtime.h>
#include <nupack/execution/Local.h>

int main(int argc, char *argv[]) {
    using namespace nupack;
    if (argc < 2) NUPACK_ERROR("Need 1 argument");
    uint n = std::stoi(argv[1]);
    auto t = time_it(1, [n] {
        Local(n).spread(
            range(n), 1,
            [](Ignore, Ignore, Ignore) {spin_processor(std::chrono::duration<double>(10));}
        );
    });
    print(t);
}
