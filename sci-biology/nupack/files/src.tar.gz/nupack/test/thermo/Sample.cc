#include "../Test.h"
#include <nupack/thermo/Engine.h>
#include <nupack/thermo/CachedModel.h>
#include <nupack/execution/Local.h>
#include <nupack/state/State.h>
#include <nupack/types/Database.h>

#include <boost/math/distributions/chi_squared.hpp>

#include <nupack/state/StaticState.h>

namespace nupack { namespace thermo {

template <class T>
Mat<T> to_arma(Tensor<T, 2> const &t) {
    return Mat<T>(&(*t.data()), t.shape()[1], t.shape()[0]).t();
}

auto sampled_pair_probs(vec<PairList> const & samples) {
    auto size = len(samples[0]);
    auto mat = la::zeros<real_mat>(size, size);
    for (auto const &s : samples) for (auto i : indices(s)) mat(i, s[i]) += 1;
    mat /= len(samples);
    return mat;
}

// model.boltz(StaticState<>(seq, struc).calculate_energy(model))

auto compare_sample_structures(SequenceList v, usize num_samples) {

    CachedModel model{PF(), Model(Ensemble::none, {}, {}, {}, WobblePairing::on)};
    auto samples = first_of(sample(Local(), num_samples, 1, v, std::tie(model)));

    // (dot parens structure : (frequency : observed))
    std::map<PairList, std::pair<real, int>> structures;
    auto pfunc = std::exp(dynamic_program(Local(), v, std::tie(model)));

    real included_boltz = 0.0;
    for (auto const & s : samples) {
        auto p = structures.try_emplace(s);
        if (p.second) {
            real boltz = model.boltz(StaticState<>(v, s).calculate_energy(model.energy_model));
            included_boltz += boltz;
            p.first->second = std::make_pair(boltz / pfunc, 1);
        } else {
            ++p.first->second.second;
        }
    }
    int dof = len(structures);
    structures[PairList()] = std::make_pair(1.0 - included_boltz / pfunc, 0);

    real chi2 = 0, rmse = 0;
    for (auto const & s : structures) {
        auto expected = s.second.first * num_samples;
        auto observed = s.second.second;
        chi2 += sq(observed - expected) / expected;
        rmse += sq((observed - expected) / num_samples);
    }
    rmse = std::sqrt(rmse / len(structures));

    auto dist = boost::math::chi_squared(dof);
    std::map<std::string, real> out;
    out["dof"] = dof;
    out["rmse"] = rmse;
    out["p_different"] = boost::math::cdf(dist, chi2); // 0 is good
    out["chi2"] = chi2;
    out["n_samples"] = num_samples;
    return out;
}

auto compare_sample_pairs(SequenceList v, usize num_samples, bool print_mat=false) {
    CachedModel model{PF(), Model(Ensemble::none, {}, {}, {}, WobblePairing::on)};
    Local env;

    auto samples = first_of(sample(env, num_samples, 1, v, std::tie(model)));

    auto pair_probs = to_arma(pair_probability(env, v, std::tie(model)).first);
    auto sample_probs = sampled_pair_probs(samples);
    auto const n = pair_probs.n_rows;

    if (print_mat) print(pair_probs);
    if (print_mat) print(sample_probs);

    real_mat chis = ((sample_probs - pair_probs) % (sample_probs - pair_probs) / pair_probs) * num_samples;
    chis.replace(arma::datum::nan, 0);

    std::map<std::string, real> out;
    out["n_samples"] = num_samples;
    out["rmse"] = arma::norm(pair_probs - sample_probs, "fro") / n / n;
    // Using a chi square with assumed sample length = # steps
    auto const chi2 = accu(chis);
    out["chi2"] = chi2;

    int const dof = n * (n - 1) / 2;
    out["dof"] = dof;

    auto dist = boost::math::chi_squared(dof);
    out["p_different"] = boost::math::cdf(dist, chi2); // 0 is good
    return out;
}

PROTOTYPE("thermo/sample-pairs") = [](Context ct) {
    for (auto m : {1, 2, 3}) for (auto s : {10, 20, 40, 80, 160}) {
        auto v = random_sequences(m, s);;
        for (auto n : {1e0, 1e1, 1e2, 1e3, 1e4, 1e5, 1e6})
            print(m, n, compare_sample_pairs(v, n));
    }
};

PROTOTYPE("thermo/sample-structures") = [](Context ct) {
    for (auto m : {1, 2, 3}) for (auto s : {10, 20, 40, 80, 160}) {
        auto v = random_sequences(m, s);
        for (auto n : {1e0, 1e1, 1e2, 1e3, 1e4, 1e5, 1e6})
            print(m, n, compare_sample_structures(v, n));
    }
};

TIME_TEST("sample-timing") = [](Context ct) {
    CachedModel model(PF(), Model(Ensemble::none, {}, {}, {}, WobblePairing::on));
    Local env;

    auto test = [&] (string seq) {
        auto n_samples = 1;
        NickSequence sequence = to_sequences(seq);
        auto blk = block(env, NoStacking(), sequence, model).first;
        echo | time_it(5000, [&] {sample_block(blk, sequence, model, n_samples);});
        // for (auto const &s : samples) print(s.dp(sequence.nicks()));
    };

    test("GGGGGAAAAACCCCC");
    test("ACGCAGCCAGCCGACGCCAGCCGACCGCAGCGCAGCGCGGGCGCACGCGCGACGGGGGGCCAGCCCCCCCCACGCCGCCACCGACGC");
    test("GCCCAACGGCAGGGUGGAAUCGGCAAUGCCGAUAGCAUUACGUCAGCUGAGGUCCAAGACCUCUCCACCGGGUGGUUACACGGUAACCACGCCGUUGGU");
    test("UACGUCUUAUCGCCUCUCACAUCCCCCUAAAUGACGUAUAAAACUCACAGCGGACCUCCCUUUCUUUUGGAUCCGACUGACAGGGUGCAGCCCAGGCCCCUUACAGCCCACGCAGUAUCAGUUGUCUCGUCCCUGAUAGGUGAUGUCCCUCGCUGGUUAAUGUAAGUGUGUCGCGUGCGCGGUGCGAUGUACGGUUCAACGACACUAACGAUCCUCUUAAUGGGAUCCGGUAAAACACGAGGGCGAUAGUAUAGACGUUAGAGACGUCGCUUCUGAUCCAGCGAUGUUCAUAAUAUGGGGUUGUAUAACUAUUUAUGACCGAUGGAGGGGUAUCUUGGAUAUCACCAGAACCAACAAGGGGCUAUUUUACGGAGUGUAGAACGAUGGUGGAUAUCAAACCAAUCUUGGCCCCCUUGAGUGGCCAUAACGCUGUUUUUGGUAUCUCCAAGAAUCUUAGCAGGCUUUCCCGUUAUACUUGUAUUUCUCUCAGGACACCUUAAAGCUACCAGAAGGUACAUUCAGUAGUCUUCCCGCCUCUUGUCACAAGCAGGUAAGGCACUCUUUAUCGUAAUACCGUAACUCCACGACCAAAAUCGAGCAAGUUCUAAUGUUUCGCACCGCUUAUAAGCCGCGGGCGGGGUAUCCAACAUCAGUGCAAUAUUAGUUUAAGCUAUUAAUUCUGUUUUGGCAUCAAAAGCGGUUUUUUCUCAAACCAUCGGUAUAGAACGGAUUAAAUUUCUCGGGUGGUUGGCGGGGUGUGAGGAAAACGAUUAGCCAAGCAUGUAGCUAUCAUCUCGUAUCUCCGGGUACAUCCAGUAAUUAGGUUAGCCCUGGAGUACACGGAUAGGACACCAUACAUCUAUUCCGAGGAGCCAGAAAUCAGUCCGUCCUCGGUAUUUCAGAGUACUGUGGUCGGUAUCCUCUUCCUCCCGCCAUCAUCUCAAACCAAAAGCGUCCCCAUCUGACUUCGUUCUUCCCAGACAACUAACGCGGAGCGGGA");
};

template <class E=NoStacking>
void sample_sequences(Context &ct, Ensemble ens, string filename, vec<std::pair<Sequence, int>> &sequences, bool multi=true) {
    std::ofstream out(filename);
    print_os<io::comma, io::endl>(out, "size", "samples", "time", "sequence");

    CachedModel model_32{PF(), Model<float>(ens, {}, {}, {}, WobblePairing::on)};
    CachedModel model_64{PF(), Model<real>(ens, {}, {}, {}, WobblePairing::on)};
    auto models = std::tie(model_64, model_32);
    auto const n = maximum(indirect_view(sequences, [](auto const &p) {return len(p.first);}));
    for_each(models, [n](auto &m) {m.reserve(n);});

    auto lrucache = thermo::Cache<3, E, real, overflow<float>>(TotalRAM / 2);
    usize length = 0;

    Local env;
    for (auto const & s: sequences) {
        NickSequence seq{s.first};
        int samples = s.second;

        if (len(seq) > length) {
            length = len(seq);
            print("length: ", length);
        }

        real sample_time = 0;

        auto body = [&, multi](auto &stat, auto &Q, auto const &model, auto &&cache) {
            False no_cache;
            run_program(env, stat, seq, model, Q, no_cache, NoOp(), DefaultAction());
            ct.require(!stat.bad());
            if (multi) {
                sample_time = time_it(1, [&] {sample_block(Q, seq, model, samples);});
            } else {
                sample_time = time_it(1, [&] {
                    for (auto i : range(samples)) sample_block(Q, seq, model, 1);
                });
            }
        };

        dispatch_type_and_dangle<3>(seq, DataTypes<decltype(models), 0, 1>(), models, lrucache, body);

        print_os<io::comma, io::endl>(out, length, samples, sample_time, make_string(s.first));
    }
}

TIME_TEST("thermo/sample/designed-timing-csv") = [](Context ct) {
    std::ifstream in("deep_MFE_sequences.csv");
    string tok;
    std::getline(in, tok); // burn header line

    vec<string> sequences;
    while (in.good()) {
        std::getline(in, tok, ',');
        std::getline(in, tok, ',');
        if (len(tok) > 0)
            sequences.push_back(tok);
        std::getline(in, tok);
    }

    vec<int> samples = {1, 3, 10, 30, 100, 300, 1000, 3000, 10000, 30000, 100000, 300000, 1000000};

    vec<std::pair<Sequence, int>> inputs;
    for (auto const &s : sequences) for (auto samp : samples)
        inputs.emplace_back(Sequence(s), samp);

    sort(inputs, [](auto const & a, auto const & b) {
        return std::make_tuple(len(a.first), a.first, a.second)
             < std::make_tuple(len(b.first), b.first, b.second);
    });

    sample_sequences<MinDangles>(ct, Ensemble::min, "sample_designed_timings.csv", inputs);
    sample_sequences<MinDangles>(ct, Ensemble::min, "sample_designed_timings_naive.csv", inputs, false);
};


TIME_TEST("thermo/sample/csv") = [](Context ct) {
    vec<int> lengths = {10, 30, 100, 300, 1000, 3000, 10000};
    vec<int> samples = {1, 3, 10, 30, 100, 300, 1000, 3000, 10000, 30000, 100000, 300000, 1000000};

    vec<std::pair<Sequence, int>> multi_inputs;
    vec<std::pair<Sequence, int>> naive_inputs;
    for (auto length : lengths) for (auto samp : samples)
        for (auto id : range(10)) {
            multi_inputs.emplace_back(random_sequence(length), samp);
            naive_inputs.emplace_back(random_sequence(length), samp);
        }

    auto sorter = [](auto const & a, auto const & b) {
        return std::make_tuple(len(a.first), a.second, a.first)
             < std::make_tuple(len(b.first), b.second, b.first);
    };

    sort(multi_inputs, sorter);
    sort(naive_inputs, sorter);

    sample_sequences<NoStacking>(ct, Ensemble::nostacking, "sample_timings.csv", multi_inputs);
    sample_sequences<NoStacking>(ct, Ensemble::nostacking, "sample_timings_naive.csv", naive_inputs, false);
};

PROTOTYPE("thermo/sample/ss") = [](Context ct) {
    CachedModel model{PF(), Model(Ensemble::none, {}, {}, {}, WobblePairing::on)};
    auto env = Local();
    auto test = [&] (string seq, string mfe="") {
        auto num_samples = 1000000;
        auto sequence = to_sequences(seq);
        NickSequence mult = sequence;
        auto samples = first_of(sample(env, num_samples, 1, sequence, model));
        for (auto const &s : samples) print(s.dp(mult.nicks()));
        if (mfe.empty()) return;
        auto pfunc = std::exp(dynamic_program(env, sequence, model));
        auto prob = model.boltz(structure_energy(sequence, mfe, model.energy_model)) / pfunc;
        int count = 0;
        for (auto const &s : samples) {
            if (s.dp(mult.nicks()) == mfe) ++count;
        }
        BEEP(count / real(num_samples), prob);
    };

    test("GGGGGAAAAACCCCC",
         "(((((.....)))))");
    test("ACGCAGCCAGCCGACGCCAGCCGACCGCAGCGCAGCGCGGGCGCACGCGCGACGGGGGGCCAGCCCCCCCCACGCCGCCACCGACGC",
         "..((.(((.(((..(((..((.....)).)))..).)).)))))..(((((..((((((.....))))))..)).))).........");
    test("GCCCAACGGCAGGGUGGAAUCGGCAAUGCCGAUAGCAUUACGUCAGCUGAGGUCCAAGACCUCUCCACCGGGUGGUUACACGGUAACCACGCCGUUGGU",
         "..((((((((..((((((((((((...))))))(((.........)))((((((...))))))))))))..((((((((...)))))))))))))))).");
};

// UNIT_TEST("thermo/sample/chi-squared") = [](Context ct) {
//     test_boltzmann_consistency("GGGGGAAAAACCCCC", 100000);
//     // for (auto i : range(10)) test_boltzmann_consistency("ACGCAGCCAGCCGACGCCAGCCGACCGCAGCGCAGCGCGGGCGCACGCGCGACGGGGGGCCAGCCCCCCCCACGCCGCCACCGACGC", 1);
//     test_boltzmann_consistency("ACGCAGCCAGCCGACGCCAGCCGACCGCAGCGCAGCGCGGGCGCACGCGCGACGGGGGGCCAGCCCCCCCCACGCCGCCACCGACGC", 100000);
//     test_boltzmann_consistency("GCCCAACGGCAGGGUGGAAUCGGCAAUGCCGAUAGCAUUACGUCAGCUGAGGUCCAAGACCUCUCCACCGGGUGGUUACACGGUAACCACGCCGUUGGU", 100000);
// }

PROTOTYPE("thermo/sample/ms") = [](Context ct) {
    vec<string> seqs {"ACUGUGACGU", "ACGUAGUGC", "ACGUGAUCCCC"};

    CachedModel model{PF(), Model(Ensemble::none)};
    NickSequence sequence = to_sequences(seqs);
    auto num_samples = 1000000;

    small_vec<int> nicks = {10, 19};
    small_vec<int> first = {10};
    small_vec<int> second = {9};
    BEEP(sequence.nicks());
    NUPACK_REQUIRE(static_cast<small_vec<int>>(sequence.nicks()), ==, nicks);
    auto s = sequence.strands_included(0, 15).nicks();
    NUPACK_REQUIRE(static_cast<small_vec<int>>(s), ==, first);
    s = sequence.strands_included(0, 10).nicks();
    NUPACK_REQUIRE(static_cast<small_vec<int>>(s), ==, first);
    s = sequence.strands_included(15, 20).nicks();
    NUPACK_REQUIRE(static_cast<small_vec<int>>(s), ==, second);
    s = sequence.strands_included(3, 20).nicks();
    NUPACK_REQUIRE(static_cast<small_vec<int>>(s), ==, nicks);

    auto samples = first_of(sample(Local(), num_samples, 1, sequence, model));
    string mfe = "((.((.((((+)))).....+)))).......";
    int count = 0;
    for (auto const &s : samples) {
        print(s.dp(sequence.nicks()));
        if (s.dp(sequence.nicks()) == mfe) ++count;
    }
    BEEP(count / real(num_samples));
};



UNIT_TEST("thermo/priority-queue") = [](Context ct) {
    using Queue = Priority_Queue<Segment, vec<usize>, typename Segment::Compare>;

    Queue pq;
    vec<Segment> segs;
    vec<usize> marks {1, 2, 3};
    segs.emplace_back(Segment{1, 10, "Q", -4});
    segs.emplace_back(Segment{1, 10, "B", 0});
    segs.emplace_back(Segment{1, 9, "S", -3});
    segs.emplace_back(Segment{1, 100, "MS", -1});
    segs.emplace_back(Segment{1, 11, "M", -2});
    for (auto &s : segs) pq.push(s, marks);

    ct.equal(pq.pop().first, segs[3]);
    ct.equal(pq.pop().first, segs[4]);
    ct.equal(pq.pop().first, segs[0]);
    ct.equal(pq.pop().first, segs[1]);
    ct.equal(pq.pop().first, segs[2]);
    ct.require(pq.empty());
};


PROTOTYPE("coax-single-strand-Sampler") = [](Context ct) {
    CachedModel model{PF(), Model(Ensemble::stacking)};

    auto test = [&] (string seq, string mfe="") {
        auto num_samples = 1000000;
        NickSequence sequence = to_sequences(seq);
        auto samples = first_of(sample(Local(), num_samples, 1, sequence, model));
        for (auto const &s : samples) print(s.dp(sequence.nicks()));
        if (mfe.empty()) return;
        int count = 0;
        for (auto const &s : samples) {
            print(s.dp(sequence.nicks()));
            if (s.dp(sequence.nicks()) == mfe) ++count;
        }
        BEEP(count / real(num_samples));
    };

    test("GGGGGAAAAACCCCC");
    test("ACGCAGCCAGCCGACGCCAGCCGACCGCAGCGCAGCGCGGGCGCACGCGCGACGGGGGGCCAGCCCCCCCCACGCCGCCACCGACGC");

    test("GCCCAACGGCAGGGUGGAAUCGGCAAUGCCGAUAGCAUUACGUCAGCUGAGGUCCAAGACCUCUCCACCGGGUGGUUACACGGUAACCACGCCGUUGGU",
         "..((((((((..((((((((((((...))))))(((.........)))((((((...))))))))))))..((((((((...)))))))))))))))).");

};

PROTOTYPE("coax-multi-strand-Sampler") = [](Context ct) {
    vec<string> seqs {"ACUGUGACGU", "ACGUAGUGC", "ACGUGAUCCCC"};

    CachedModel model{PF(), Model(Ensemble::stacking)};

    NickSequence sequence = to_sequences(seqs);
    auto num_samples = 1000000;

    small_vec<int> nicks = {10, 19};
    small_vec<int> first = {10};
    small_vec<int> second = {9};
    BEEP(sequence.nicks());
    NUPACK_REQUIRE(static_cast<small_vec<int>>(sequence.nicks()), ==, nicks);
    auto s = sequence.strands_included(0, 15).nicks();
    NUPACK_REQUIRE(static_cast<small_vec<int>>(s), ==, first);
    s = sequence.strands_included(0, 10).nicks();
    NUPACK_REQUIRE(static_cast<small_vec<int>>(s), ==, first);
    s = sequence.strands_included(15, 20).nicks();
    NUPACK_REQUIRE(static_cast<small_vec<int>>(s), ==, second);
    s = sequence.strands_included(3, 20).nicks();
    NUPACK_REQUIRE(static_cast<small_vec<int>>(s), ==, nicks);

    auto samples = first_of(sample(Local(), num_samples, 1, sequence, model));
    string mfe = "((.((.((((+)))).....+)))).......";
    int count = 0;
    for (auto const &s : samples) {
        print(s.dp(sequence.nicks()));
        if (s.dp(sequence.nicks()) == mfe) ++count;
    }
    BEEP(count / real(num_samples));
};


}}
