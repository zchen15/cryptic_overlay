#include "../Test.h"
#include <nupack/model/Model.h>
#include <nupack/thermo/Engine.h>
#include <nupack/thermo/CachedModel.h>
#include <nupack/execution/Local.h>
#include <nupack/types/Database.h>

namespace nupack { namespace thermo {

/******************************************************************************************/

void test_mfe(Context &ct, string fn, WobblePairing gt, string material) {
    CachedModel model{MFE(), Model<double>(Ensemble::none, material, {}, {}, gt)};
    repeat_test(ct, EnergyDatabase(fn), [&](auto const &p) {
        auto mfe = dynamic_program(Local(), to_sequences(p.first), model);
        auto exact = p.second.energy;
        ct.within(mfe, exact, 1e-3);
    });
}

#define NUPACK_TEST(name, gt, mat) UNIT_TEST("thermo/mfe/" name "") = [](Context ct) {test_mfe(ct, "mfe-" name ".json", gt, mat);};
NUPACK_TEST("rna95-none-ss",    WobblePairing::off, "RNA")
NUPACK_TEST("rna95-none-ms",    WobblePairing::off, "RNA")
NUPACK_TEST("rna95-none-gu-ss", WobblePairing::on,  "RNA")
NUPACK_TEST("rna95-none-gu-ms", WobblePairing::on,  "RNA")
NUPACK_TEST("dna98-none-gt-ss", WobblePairing::on,  "DNA")
NUPACK_TEST("dna98-none-gt-ms", WobblePairing::on,  "DNA")
#undef NUPACK_TEST

/******************************************************************************************/

PROTOTYPE("mfe/ms") = [](Context ct) {
    auto v = random_sequences(10, 100);
    v.clear();

    //auto pf64  =  pf_model<real64>(Ensemble::none);
    //echo | time_it(4, [&] {dynamic_program(Local(), v, pf64);});
    //auto mfe64 = mfe_model<real64>(Ensemble::none);
    //echo | time_it(4, [&] {dynamic_program(Local(), v, mfe64);});
    CachedModel mfe32{MFE(), Model<real32>(Ensemble::none)};
    print(real(mfe32.zero()));
    print(real(mfe32.as_log(mfe32.zero())));
    echo | time_it(4, [&] {dynamic_program(Local(), v, mfe32);});
    echo | dynamic_program(Local(), v, mfe32);
};

/******************************************************************************************/

PROTOTYPE("mfe/ms/short") = [](Context ct) {
    // auto v = to_sequences({"AA", "T"});
    auto v = to_sequences({"CCC", "GGG", "ACGATCGTAGCTAGCTGATCGATCGTACGTACGTACGTACGATCGATCGATTCGAA", "CC", "ACGATCGTAGCTCCCAGCTGATCGATCGTACGTACGTACGTACGATCGATCGATTCGAA", "ACGATCGTAGCTAGCTGATCGATCCGTACGTACGTACGTACGATCGATCGATTCGAA"});
    for (auto n : {4e9, 0.0}) {
        {
            Cache<3, NoStacking, real32> cache(n);
            CachedModel model{MFE(), Model<real32>(Ensemble::none)};
            auto log = dynamic_program(Local(), v, model, cache, [&](auto const &m) {print(cache.limit, m);});
            ct.require(std::isfinite(log), log);
            auto p = pair_probability(Local(), v, model, cache, [&](auto const &m) {print(cache.limit, m);});
            ct.require(std::isfinite(p.second), p.second);
            p = pair_probability(Local(), duplicate(v), model, cache, [&](auto const &m) {print(cache.limit, m);});
            ct.require(std::isfinite(p.second), p.second);
        }
        {
            Cache<3, NoStacking, real32> cache(n);
            CachedModel model{MFE(), Model<real32>(Ensemble::none)};
            auto p = pair_probability(Local(), v, model, cache, [&](auto const &m) {print(cache.limit, m);});
            ct.require(std::isfinite(p.second), p.second);
            auto log = dynamic_program(Local(), duplicate(v), model, cache, [&](auto const &m) {print(cache.limit, m);});
            ct.require(std::isfinite(log), log);
            p = pair_probability(Local(), duplicate(v), model, cache, [&](auto const &m) {print(cache.limit, m);});
            ct.require(std::isfinite(p.second), p.second);
        }
    }
};

/******************************************************************************************/

PROTOTYPE("coaxial/mfe/write") = [](Context ct) {
    JsonDatabase<std::map<string, real>> test;
    test.write("coaxial-mfe.json");
};

PROTOTYPE("coaxial/mfe") = [](Context ct) {
    CachedModel model{MFE(), Model<real>(Ensemble::stacking)};
    repeat_test(ct, JsonDatabase<std::map<string, real>>("coaxial-mfe.json"), [&](auto const &p) {
        ct.near(dynamic_program(Local(), to_sequences(p.first), model), p.second);
    });
};

/******************************************************************************************/

PROTOTYPE("ms/coax/mfe") = [](Context ct) {
    auto v = random_sequences(10, 100);
    CachedModel model{MFE(), Model<real>(Ensemble::stacking)};

    dynamic_program(Local(), v, model, False(), [](auto m){print(m.result, delimited_string(m.sequences, "+"));});
};

/******************************************************************************************/

}}
