#include "../Test.h"
#include <nupack/thermo/Engine.h>
#include <nupack/thermo/CachedModel.h>
#include <nupack/state/State.h>
#include <nupack/execution/Local.h>
#include <nupack/types/Database.h>

namespace nupack::thermo {

/******************************************************************************************/

void test_pf_params(Context &ct, string fn) {
    Local env;
    repeat_test(ct, JsonDatabase<std::map<string, PfuncDatum>>(fn), [&](auto p) {
        ct.info(p.first);
        auto const & data = p.second;
        ct.info(data.material);
        ct.info(data.T);
        ct.info(data.sodium);
        ct.info(data.magnesium);

        string material = (data.material == "dna1998") ? "DNA" : "RNA";
        CachedModel model(PF(), Model(Ensemble::none, material, ModelConditions{data.T + ZeroCinK, data.sodium, data.magnesium}, {}, WobblePairing::on));
        ct(HERE).within(dynamic_program(env, to_sequences(p.first), model), model.as_log(data.result), 5e-5);
    });
}

#define NUPACK_TEST(name) UNIT_TEST("thermo/pf/" name "") = [](Context ct) {test_pf_params(ct, "pf-" name ".json");};
NUPACK_TEST("random-parameters-ss")
NUPACK_TEST("random-temp-material-ss")
NUPACK_TEST("random-parameters-ms")
NUPACK_TEST("random-temp-material-ms")
#undef NUPACK_TEST

void test_pf(Context &ct, string fn, WobblePairing gt, Ensemble ensemble, string material, bool count) {
    Local env;
    CachedModel model(PF(), Model(ensemble, material, {}, {}, gt));
    if (count) model.set_beta(0);
    repeat_test(ct, JsonDatabase<std::map<string, real>>(fn), [&](auto const &p) {
        double logpf = dynamic_program(env, to_sequences(p.first), model);
        ct(HERE).within(logpf, model.as_log(p.second), 5e-5);
    });
}

#define NUPACK_TEST(name, gu, dang, mat) UNIT_TEST("thermo/pf/" name "") = [](Context ct) {test_pf(ct, "pf-" name ".json", gu, dang, mat, false);};
NUPACK_TEST("rna95-none",       WobblePairing::off, Ensemble::none, "RNA")
NUPACK_TEST("rna95-none-ss",    WobblePairing::off, Ensemble::none, "RNA")
NUPACK_TEST("rna95-none-ms",    WobblePairing::off, Ensemble::none, "RNA")
NUPACK_TEST("rna95-none-gu-ss", WobblePairing::on,  Ensemble::none, "RNA")
NUPACK_TEST("rna95-none-gu-ms", WobblePairing::on,  Ensemble::none, "RNA")
NUPACK_TEST("dna98-none-gt-ss", WobblePairing::on,  Ensemble::none, "DNA")
NUPACK_TEST("dna98-none-gt-ms", WobblePairing::on,  Ensemble::none, "DNA")

NUPACK_TEST("dna98-all-ms", WobblePairing::on, Ensemble::all, "DNA")
NUPACK_TEST("dna98-min-ms", WobblePairing::on, Ensemble::min, "DNA")
NUPACK_TEST("dna98-all-ss", WobblePairing::on, Ensemble::all, "DNA")
NUPACK_TEST("dna98-min-ss", WobblePairing::on, Ensemble::min, "DNA")
NUPACK_TEST("rna95-all-ms", WobblePairing::on, Ensemble::all, "RNA")
NUPACK_TEST("rna95-min-ms", WobblePairing::on, Ensemble::min, "RNA")
NUPACK_TEST("rna95-all-ss", WobblePairing::on, Ensemble::all, "RNA")
NUPACK_TEST("rna95-min-ss", WobblePairing::on, Ensemble::min, "RNA")
#undef NUPACK_TEST

#define NUPACK_TEST(name, gu, dang, mat) UNIT_TEST("thermo/count/" name "") = [](Context ct) {test_pf(ct, "count-" name ".json", gu, dang, mat, true);};
NUPACK_TEST("rna95-none-ss",    WobblePairing::off, Ensemble::none, "RNA")
NUPACK_TEST("rna95-none-ms",    WobblePairing::off, Ensemble::none, "RNA")
NUPACK_TEST("rna95-none-gu-ss", WobblePairing::on,  Ensemble::none, "RNA")
NUPACK_TEST("rna95-none-gu-ms", WobblePairing::on,  Ensemble::none, "RNA")
NUPACK_TEST("dna98-none-gt-ss", WobblePairing::on,  Ensemble::none, "DNA")
NUPACK_TEST("dna98-none-gt-ms", WobblePairing::on,  Ensemble::none, "DNA")
#undef NUPACK_TEST

/******************************************************************************************/

TIME_TEST("pf/ss/dangles") = [](Context ct) {
    Local env;
    auto v = to_sequences({reference_dna(666)});
    for (auto d : AllEnsembles) {
        CachedModel model(PF(), Model(d, {}, {}, {}, WobblePairing::off));
        echo | exp(dynamic_program(env, v, model));
        echo | time_it(8, [&] {dynamic_program(env, v, model);});
    }
};

TIME_TEST("pf/ms/dangles") = [](Context ct) {
    Local env;
    auto const seqs = vmap(range(1, 41), [](auto n) {return random_sequence(25 * n);});
    for (auto d : AllEnsembles) {
        CachedModel model(PF(), Model(d, {}, {}, {}, WobblePairing::on));
        fork(d, echo);
        for (auto seq : seqs) {
            vec<Sequence> v = {seq};
            print(len(seq), time_it(10, [&] {dynamic_program(env, v, model);}));
        }
    }
};

/******************************************************************************************/

TIME_TEST("pf/dangles/csv") = [](Context ct) {
    Local env;

    std::ofstream out("dangles_timings.csv");
    out << "size,EnsembleType,time,sequence" << std::endl;
    vec<Sequence> seqs;
    for (double len_exp : range(0,5)) {
        int length = std::pow(10, len_exp);
        for (auto id : range(10)) {
            auto seq = random_sequence(length);
            seqs.emplace_back(seq);
        }
    }

    for (auto d : AllEnsembles) {
        CachedModel model(PF(), Model<float>(d, {}, {}, {}, WobblePairing::on));
        fork(d, echo);
        int length = -1;
        for (auto seq : seqs) {
            if (len(seq) != length) {
                length = len(seq);
                print("length:", length);
            }
            auto pf_time = time_it(1, [&] {dynamic_program<3, 1>(env, NickSequence{seq}, model);});
            out << length << ", " << EnsembleNames[uint(d)] << ", " << pf_time << ", " << make_string(seq) << "\n";
        }
    }
};

/******************************************************************************************/

TIME_TEST("pf/overflow/csv") = [](Context ct) {
    std::ofstream out("version_timings.csv");
    out << "size,version_type,time,sequence" << std::endl;
    vec<NickSequence> seqs;
    for (int length : vec<int>{10, 30, 100, 300, 1000, 3000, 10000}) {
        for (auto id : range(10)) {
            auto seq = random_sequences(3, length / 3);
            seqs.emplace_back(seq);
        }
    }

    auto run_seqs = [&] (string version, auto f) {
        int length = -1;
        for (auto seq : seqs) {
            if (len(seq.catenated) != length) {
                length = len(seq);
                print("length:", length);
            }
            auto pf_time = time_it(1, [&] {return f(seq);});

            // ACTG+GTCA version of string
            std::stringstream ss;
            for (auto const &s : seq.sequences()) ss << make_string(s) << "+";
            auto seq_str = ss.str();
            seq_str.pop_back();

            print_os<io::comma, io::endl>(out, length, version, pf_time, seq_str);
        }
    };

    CachedModel m32(PF(), Model<real32>(Ensemble::none, {}, {}, {}, WobblePairing::on));
    m32.reserve(10000);
    CachedModel m64(PF(), Model<real64>(Ensemble::none, {}, {}, {}, WobblePairing::on));
    m64.reserve(10000);

    run_seqs("nupack", [&](auto const &v) {return dynamic_program<3, 0, 0, 1, 1>(Local(), v, std::tie(m32, m64, m32, m64));});
};

/******************************************************************************************/

TIME_TEST("pf/double-vs-float") = [](Context ct) {
    Local env;
    auto v = random_sequences(1, 400);
    pack<float, double>::for_each([&](auto t) {
        CachedModel model(PF(), Model<decltype(*t)>(Ensemble::none, {}, {}, {}, WobblePairing::off));
        echo | time_it(8, [&] {dynamic_program(env, v, model);});
    });
};

TIME_TEST("pf/parallel") = [](Context ct) {
    for (auto m : range(1, 8)) powers(1.5, 10, 17, [m](usize n) {
        auto const v = random_sequences(m, n);
        for (auto p : range(1, 17)) {
            CachedModel model(PF(), Model(Ensemble::none, {}, {}, {}, WobblePairing::off));
            Local env(p);
            if (p == 1) print(n, 0, time_it(4, [&] {dynamic_program(Local(), v, model);}));
            print(n, p, time_it(4, [&] {dynamic_program(env, v, model);}));
        }
    });
};

template <class M>
void test_n3_vs_n4(Context &ct, bool count) {
    for (auto d : AllEnsembles) ct.section(EnsembleNames.at(uint(d)), [&](auto ct) {
        auto mod = CachedModel{PF(), M(d, {}, {}, {}, WobblePairing::off)};
        if (count) mod.set_beta(0);
        repeat_test(ct, 500, [&](auto i) {
            Local env;
            auto v1 = random_sequences(1, 50), v2 = random_sequences(3, 20);
            ct.near(dynamic_program<3>(env, v1, mod), dynamic_program<4>(env, v1, mod), "single strand");
            ct.near(dynamic_program<3>(env, v2, mod), dynamic_program<4>(env, v2, mod), "multi strand");
        });
    });
};

UNIT_TEST("thermo/count/n3-vs-n4") = [](Context ct) {test_n3_vs_n4<Model<real>>(ct, true);};

UNIT_TEST("thermo/pf/n3-vs-n4") = [](Context ct) {test_n3_vs_n4<Model<real>>(ct, false);};

UNIT_TEST("thermo/real-vs-overflow") = [](Context ct) {
    //auto obs = [](auto const &msg) {print(msg.result, msg.raw_result);};
    for (auto d : AllEnsembles) ct.section(EnsembleNames.at(uint(d)), [d](auto ct) {
        CachedModel mod_32{PF(), Model<real32>(d)};
        CachedModel mod_64{PF(), Model<real64>(d)};
        auto m32_32 = std::tie(mod_32, mod_32);

        auto check = [&](auto const &v) {
            auto d = dynamic_program<3, 0>(Local(), v, mod_64);
            auto test = [&](auto s, auto x) {ct.within(x, d, 5e-5, s);};

            test("3 f32    ", dynamic_program<3, 0>   (Local(), v, mod_32));
            test("3 o32    ", dynamic_program<3, 1>   (Local(), v, mod_32));
            test("3 o64    ", dynamic_program<3, 1>   (Local(), v, mod_64));
            test("3 f32 o32", dynamic_program<3, 0, 1>(Local(), v, m32_32));
            test("4 f32    ", dynamic_program<4, 0>   (Local(), v, mod_32));
            test("4 f64    ", dynamic_program<4, 0>   (Local(), v, mod_64));
            test("4 o32    ", dynamic_program<4, 1>   (Local(), v, mod_32));
            test("4 o64    ", dynamic_program<4, 1>   (Local(), v, mod_64));
            test("4 f32 o32", dynamic_program<4, 0, 1>(Local(), v, m32_32));
        };

        repeat_test(ct, 500, [&](auto i) {
            check(random_sequences(1, 70));
            check(random_sequences(2, 20));
        });
    });
};

/******************************************************************************************/

UNIT_TEST("thermo/pf/blowup") = [](Context ct) {
    Local env;
    CachedModel m64{PF(), Model<real64>(Ensemble::none)};
    m64.reserve(1000);
    CachedModel m32{PF(), Model<real32>(Ensemble::none)};
    m32.reserve(1000);

    repeat_test(ct, 100, [&](auto n) {
        for (auto m : range(1, 4)) {
            auto v = random_sequences(m, n * 4 / m, 1.0);
            auto exact = dynamic_program<3, 1>(env, v, m64);
            auto check = [=, &ct](auto i, auto c) {
                auto n = sum(v, len);
                ct.require(!std::isnan(c) && (c != double(*inf)), c, i, n, "overflow result should be finite");
                if (std::isfinite(exact)) ct.within(c, exact, 5e-4);
            };

            check("4 fF ", dynamic_program<4, 0, 1>   (env, v, std::tie(m32, m32)));
            check("4 fD ", dynamic_program<4, 0, 1>   (env, v, std::tie(m32, m64)));
            check("4 dF ", dynamic_program<4, 0, 1>   (env, v, std::tie(m64, m32)));
            check("4 fdF", dynamic_program<4, 0, 0, 1>(env, v, std::tie(m32, m64, m32)));

            check("3 fF ", dynamic_program<3, 0, 1>   (env, v, std::tie(m32, m32)));
            check("3 fD ", dynamic_program<3, 0, 1>   (env, v, std::tie(m32, m64)));
            check("3 dF ", dynamic_program<3, 0, 1>   (env, v, std::tie(m64, m32)));
            check("3 fdF", dynamic_program<3, 0, 0, 1>(env, v, std::tie(m32, m64, m32)));
        }
    });
};


PROTOTYPE("pf/cache-size") = [](Context ct) {
    NickSequence seq = to_sequences({string(500, 'A')});

    auto cache = thermo::Cache<3, NoStacking, real>(TotalRAM / 2);
    CachedModel mod_64{PF(), Model<real64>(Ensemble::none)};

    dynamic_program(Local(), seq, mod_64, cache);

    int seq_length = len(seq);
    // number of stored double matrices for no dangles
    ct.near(cache.limit.length / (seq_length * seq_length) / 8, 10.0);
};

/******************************************************************************************/

UNIT_TEST("thermo/pf/coaxial/rna95") = [](Context ct) {
    CachedModel model{PF(), Model(Ensemble::stacking, {}, {}, {}, WobblePairing::off)};
    repeat_test(ct, JsonDatabase<std::map<string, real>>("pf-rna95-coaxial.json"), [&](auto const &p) {
        ct.info(p.first);
        auto v = to_sequences(p.first);
        ct.near(dynamic_program(Local(), v, model), model.as_log(p.second));
    });
};

/******************************************************************************************/

UNIT_TEST("thermo/pf/coaxial/ss") = [](Context ct) {
    CachedModel model{PF(), Model(Ensemble::stacking, {}, {}, {}, WobblePairing::off)};
    ct.require(model.energy_model.ensemble == Ensemble::stacking);
    ct.equal(dynamic_program(Local(), to_sequences({"G"}), model), model.as_log(1.0));
};

/******************************************************************************************/

UNIT_TEST("thermo/count/coaxial/rna95") = [](Context ct) {
    CachedModel model{PF(), Model(Ensemble::stacking, {}, {}, {}, WobblePairing::off)};
    model.set_beta(0);

    repeat_test(ct, JsonDatabase<std::map<string, real>>("count-rna95-coaxial.json"), [&](auto const &p) {
        ct.info(p.first);
        auto v = to_sequences(p.first);
        if (all_of(v, [](auto const & s) {return len(s) > 1;}))
            ct.near(dynamic_program(Local(), v, model), model.as_log(p.second));
    });
};

/******************************************************************************************/

UNIT_TEST("thermo/count/coaxial/multi") = [](Context ct) {
    CachedModel model{PF(), Model(Ensemble::stacking)};
    model.set_beta(0);

    ct.require(dynamic_program(Local(), to_sequences({"C", "G"}), model) == model.as_log(1.0));
};

/******************************************************************************************/

UNIT_TEST("thermo/pp/cache") = [](Context ct) {
    NickSequence s = to_sequences("CATGTACGATCGTA+CATGCTAGCTAGCTAAA+CATGTACGATCGTA+CATGCTAGCTAGCTAAA");
    repeat_test(ct, 100, [&](auto i) {
        if (i) s = random_sequences(4, 50);
        for (auto n : {1,2,3,4}) {
            auto cache = thermo::Cache<3, NoStacking, real32, real64, overflow<real32>>(TotalRAM / 4);
            CachedModel mod_32{PF(), Model<real32>(Ensemble::none)};
            CachedModel mod_64{PF(), Model<real64>(Ensemble::none)};

            auto p0 = pair_probability<3, 0, 0, 1>(Local(n), s, std::tie(mod_32, mod_64, mod_32), False());
            auto p1 = pair_probability<3, 0, 0, 1>(Local(n), s, std::tie(mod_32, mod_64, mod_32), cache);
            auto p2 = pair_probability<3, 0, 0, 1>(Local(n), s, std::tie(mod_32, mod_64, mod_32), cache, [&](auto const &m) {
                if (n == 1) ct(HERE).equal(m.calculation_type, 'C', "calculation should be cached");
            });
            ct(HERE, n).near(p1.second, p0.second, "fresh result does not agree with reference");
            ct(HERE, n).near(p2.second, p1.second, "cached result does not agree with fresh result");

            zip(p0.first, p1.first, p2.first, [&](auto p0, auto p1, auto p2) {
                ct(HERE, n).within(p1, p0, 1e-6, "fresh probability does not agree with reference");
                ct(HERE, n).within(p2, p1, 1e-6, "cached probability does not agree with fresh probability");
            });
        }
    });
};

UNIT_TEST("thermo/pf/cache") = [](Context ct) {
    NickSequence s = to_sequences("CATGTACGATCGTA+CATGCTAGCTAGCTAAA+CATGTACGATCGTA+CATGCTAGCTAGCTAAA+CATGTACGATCGTA+CATGCTAGCTAGCTAAA+CATGTACGATCGTA+CATGCTAGCTAGCTAAA");
    repeat_test(ct, 100, [&](auto i) {
        if (i) s = NickSequence(random_sequences(4, 50)).duplicated();
        for (auto n : {1,2,3,4}) {
            auto cache = thermo::Cache<3, NoStacking, real32, real64, overflow<real32>>(TotalRAM / 4);
            CachedModel mod_32{PF(), Model<real32>(Ensemble::none)};
            CachedModel mod_64{PF(), Model<real64>(Ensemble::none)};

            auto p0 = dynamic_program<3, 0, 0, 1>(Local(n), s, std::tie(mod_32, mod_64, mod_32), False());
            auto p1 = dynamic_program<3, 0, 0, 1>(Local(n), s, std::tie(mod_32, mod_64, mod_32), cache);
            auto p2 = dynamic_program<3, 0, 0, 1>(Local(n), s, std::tie(mod_32, mod_64, mod_32), cache, [&](auto const &m) {
                if (n == 1) ct(HERE).equal(m.calculation_type, 'C', GLUE(n), "calculation should be cached");
            });

            // ct.within(len(s) * len(s) * 10 * 8.0 / cache.limit.length, 1, 0.1, GLUE(cache.limit.length), GLUE(len(s)));
            ct(HERE).near(p1, p0, p1-p0, GLUE(n), "fresh result does not agree with reference");
            ct(HERE).near(p2, p1, p2-p1, GLUE(n), "cached result does not agree with fresh result");
        }
    });
};

template <std::size_t N, class ...Ts>
void test_cache_overflow(Context &ct) {
    // auto v = to_sequences({"AA", "T"});
    auto v = to_sequences({"CCC", "GGG", "ACGATCGTAGCTAGCTGATCGATCGTACGTACGTACGTACGATCGATCGATTCGAA", "CC", "ACGATCGTAGCTCCCAGCTGATCGATCGTACGTACGTACGTACGATCGATCGATTCGAA", "ACGATCGTAGCTAGCTGATCGATCCGTACGTACGTACGTACGATCGATCGATTCGAA"});
    for (auto n : {4.e9, 0.0}) {
        auto models = std::make_tuple(CachedModel{PF(), Model<Ts>(Ensemble::none)}...);
        std::map<NickSequence, real> results;
        dynamic_program<N>(Local(), duplicate(v), models, False(), [&](auto const &m) {
            results.emplace(m.sequences, m.raw_result);
        });

        print("START", N, TypeName<Ts>()...);
        Cache<N, NoStacking, Ts...> cache(n);
        auto observe = [&](auto const &m) {
            ct.info("limit", cache.limit);
            ct.info("result", m.result);
            ct.info("type", m.calculation_type);
            if (std::isfinite(m.raw_result) && results.count(m.sequences))
                ct(HERE).within(m.raw_result, results.at(m.sequences), 1.e-5);
        };


        auto single_log = dynamic_program<N>(Local(), v, models, cache, observe);
        ct(HERE).require(std::isfinite(single_log), single_log);
        auto single_p = pair_probability<N>(Local(), v, models, cache, observe);
        ct(HERE).require(std::isfinite(single_p.second), single_p.second);
        ct(HERE).near(single_log, single_p.second, "PF result should agree with PP one");

        auto double_p = pair_probability<N>(Local(), duplicate(v), models, cache, observe);
        ct(HERE).require(std::isfinite(double_p.second), double_p.second);
        auto double_pf = dynamic_program<N>(Local(), duplicate(v), models, cache, observe);
        ct(HERE).near(double_pf, double_p.second);
        auto double_log = dynamic_program<N>(Local(), duplicate(v), models, False(), observe);
        ct(HERE).require(std::isfinite(double_log), double_log);
        ct(HERE).near(double_log, double_p.second, "fresh result should agree with cached one");
    }
}

UNIT_TEST("thermo/improper-cache-3") = [](Context ct) {test_cache_overflow<3, real64>(ct);};
UNIT_TEST("thermo/improper-cache-4") = [](Context ct) {test_cache_overflow<4, real64>(ct);};
UNIT_TEST("thermo/improper-cache-overflow-3") = [](Context ct) {test_cache_overflow<3, real32, real64>(ct);};
UNIT_TEST("thermo/improper-cache-overflow-4") = [](Context ct) {test_cache_overflow<4, real32, real64>(ct);};

}
