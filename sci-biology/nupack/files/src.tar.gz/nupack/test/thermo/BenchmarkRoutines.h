#pragma once
#include <nupack/model/ModelVariants.h>
#include <nupack/reflect/Serialize.h>
#include <nupack/reflect/SerializeMatrix.h>

namespace nupack::thermo {

/******************************************************************************/

std::pair<real, real> version_time(uint n, Ensemble ensemble, NickSequence);

vec<std::tuple<real, real, std::size_t>>
subopt_count(NickSequence s, Ensemble ensemble, std::size_t max);

std::map<std::string, real> quantity_time(Ensemble ensemble, NickSequence);

real blocking_time(SequenceList, uint procs, uint lmax, std::size_t bytes);

vec<std::array<std::pair<real, std::size_t>, 2>>
sampling_time(Ensemble ensemble, NickSequence, vec<std::size_t> n_samples);

vec<std::tuple<std::size_t, real, real, uint>>
contour_time(SequenceList, real, Ensemble ensemble, std::size_t bytes);

// coax structure mfe, vector of lowest sample mfes for given number
using RandomMFE = std::tuple<real, std::tuple<std::string, real, real, real>, vec<std::tuple<std::string, real, real>>>;

RandomMFE random_mfe(SequenceList s, Ensemble ensemble, vec<std::size_t> n_samples);

template <class V> void save_json(std::string name, V const &v) {
  std::ofstream ofs(name);
  ofs << json{v};
}

template <class V> V load_json(std::string name) {
  std::ifstream ifs(path_join(DefaultDataPath, name));
  json j;
  ifs >> j;
  return j.get<V>();
}

}