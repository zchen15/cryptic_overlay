#include "../Test.h"
#include <nupack/model/Model.h>
#include <nupack/thermo/Engine.h>
#include <nupack/thermo/CachedModel.h>
#include <nupack/types/Database.h>
#include <nupack/execution/Local.h>

namespace nupack::thermo {

/******************************************************************************************/

TIME_TEST("thermo/pp/dangles") = [](Context ct) {
    for (auto d : AllEnsembles)
        echo | pair_probability(Local(), to_sequences({"ACGTCCGTAGCTA"}), CachedModel(PF(), Model(d)));
};

TIME_TEST("thermo/pp/pf-vs-pp") = [](Context ct) {
    auto v = random_sequences(1, 600);
    CachedModel model(PF(), Model(Ensemble::none, {}, {}, {}, WobblePairing::off));
    echo | time_it([&]{pair_probability(Local(), v, model);});
    echo | time_it([&]{dynamic_program(Local(), v, model);});
};

void test_pairs(Context &ct, string fn, WobblePairing gt, string material) {
    CachedModel model(PF(), Model(Ensemble::none, material, {}, {}, gt));
    repeat_test(ct, PairsDatabase(fn), [&](auto const &p) {
        ct.info(p.first);
        auto ret = pair_probability(Local(), to_sequences(p.first), model);
        int bad = 0;
        auto const &info = p.second;
        for (auto const ind : indices(info.i))
            bad += !(*ret.first(info.i[ind], info.j[ind]) == about(info.prob[ind]));
        ct.equal(bad, 0);
    });
};

#define NUPACK_TEST(name, gu, mat) UNIT_TEST("thermo/pp/" name "") = [](Context ct) {test_pairs(ct, "pairs-" name ".json", gu, mat);};
NUPACK_TEST("rna95-none-ms", WobblePairing::on, "RNA")
NUPACK_TEST("dna98-none-ms", WobblePairing::on, "DNA")
NUPACK_TEST("rna95-none-ss", WobblePairing::on, "RNA")
NUPACK_TEST("dna98-none-ss", WobblePairing::on, "DNA")
#undef NUPACK_TEST


/******************************************************************************************/

UNIT_TEST("thermo/pp/overflow-negative-number") = [](Context ct) {
    // auto seq = to_sequences("TAGGTCGGTCGCCATCCACTCTGGCCCGACGCCCTGGCGCTCGCAACACCGGACTCGGGAATCAGCTGTCGGGTTGCGCACGCCCGGCGGCCTGGGTAGGGGGGCTTGGCGCGCCGAGCGCGGGTGGGCGCCCCCTACAGCCAGGCGCTGGCGCGAGGCGGGGCTGGGCGGGCAGGCGACCGCCCGGGGCAACGCCGAGCACGGGGCGCCCGCTTGCGGGCCTCGCCCGCGGCGGCCTCGGCCGTATCATGCCGGACGGCGCCTATAGCGCGCACCCTCCCCCCCGGACCCGTGCGCCGCGGCGGTATGCGCCGCCGTCAGGAGCGACGATGCGGTCGCGCCGCCCGCCGGGGGCGGGGCCTCCCACGCTTGGGCACCGCAGCCGACGAGGTAGGGGTCGCACAGTGCCGCTCCAGCGAGGCCCCTTACGCCGGGTCCCCTTTGAGAACCTGGCGCCGCGGCGCTCGGCCAGCGTGTCGAAACCCCGCGTCCCCGACCGGGCCCCGCCTGACGGCACAGGTACCGAACTGGCCCTGGGCTCGCCAGGTGATGCTCCGACGGCGGCAGGGCGCCATTCAGATCGATGCGCACAGGTGACCGTCGGGGCGGGCGCAGCACATGGGCGCTGCTGGTAACTGCGTGCCCAGGCCCTGTCCACGGAGCCCCCTGGCAGGAGTGCGGCGCGCGGGGTCCCGGCGGGCGGGCACCCAGCGAATCGCGGGCCCCGCGTCGGGCTAAGGCGTGGAGGCTGCAAGCCAAATCGACCCAGCCCGTGGGCAGACCGACGGCTGGCCCGGCCGGGCCGCACTCACTCACCGACCCCCAGCGTGCGTACGCACGCTGGGTTGAGGGCTACTGCCGCGCTGTGTCCCTGCACGGTCCCGCGCGCATGGGGTCAGCCTTAAGACAAGCGCTCCACGGGCGCGTGGGGGCTAGTCGCGGCCAGCGTCGCGGGAGGGCCATGGTAGACACAGGACCTCGTCCGCCGCCCTGTCTACGCAGTACGCGCAGTCGGTGACCCGCGTGCCCCGTGACACACGAACCCATGAGGGCTCCATACAGGCCGGCGGGATGCGTCGAGCTGGAGAGAACCGGGGCTGTATAGTCGTGGTGTCGCGGGACCCGGAGACCCGCCCTGCGACGTGCGCCGCGACAGACACAGCCGGTTGCCCCTGACGTGCCGCACCCCCCCCGACCTGCCCGATTACGGGGCCGCTGTCGATGGAAGGTGCCGGCAGACTGTCCAGTGCCGCATAGCCGGGACCGAGACCCCTGGTGACCGCGGCGCACAGTCGGTCATCTGGTGGCCGCGCGGAGGTATACAGCGCCCGCTGGGCGGAGGGGGGGCGGCCCTTCCCCCGCGCCGGCGGTAGGGGGGCTGCCCGGGCCAATAGCAAGCAGCGAGGGATCGGCTGCGTCTCGCAGCCTGGCGGCCCGACATGGGGTCTCCCTGGGCGCGGCCGCCCACGGGGGGCGCGGACTGGCATGCCATCGGACGGCTTAATCAAGGGGCTGCAGCAGGGGGGGGGTGGCAGGCTCCCGGGCGCTGTGGCGCTCGCCGCGCCGAAGGCTCGGTCCCCTCAGGGCATCGTCCCGACTC");
    auto seq = to_sequences("GAAGTGGGTTTACGCACTCGAAACGCAGGTTTATGCTTGGTGGCTCCAATAGCAGTCTTGGCTCACACAACGTGACAACAATGGAACGTACATAGGCATACCAGAGGGGTACCCGTTCGCGTTATCTATATGGACCGCGACATCTATATTTGTGACCTCGGATGGTTGAGCATTTCGACGCTGAACTGCTCCCTGTGGAT+ATCCACAGGGAGCAGTTCAGCGTCGAAATGCTCAACCATCCGAGGTCACAAATATAGATGTCGCGGTCCATATAGATAACGCGAACGGGTACCCCTCTGGTATGCCTATGTACGTTCCATTGTTGTCACGTTGTGTGAGCCAAGACTGCTATTGGAGCCACCAAGCATAAACCTGCGTTTCGAGTGCGTAAACCCACTTC+GAAGTGGGTTTACGCACTCGAAACGCAGGTTTATGCTTGGTGGCTCCAATAGCAGTCTTGGCTCACACAACGTGACAACAATGGAACGTACATAGGCATACCAGAGGGGTACCCGTTCGCGTTATCTATATGGACCGCGACATCTATATTTGTGACCTCGGATGGTTGAGCATTTCGACGCTGAACTGCTCCCTGTGGAT+ATCCACAGGGAGCAGTTCAGCGTCGAAATGCTCAACCATCCGAGGTCACAAATATAGATGTCGCGGTCCATATAGATAACGCGAACGGGTACCCCTCTGGTATGCCTATGTACGTTCCATTGTTGTCACGTTGTGTGAGCCAAGACTGCTATTGGAGCCACCAAGCATAAACCTGCGTTTCGAGTGCGTAAACCCACTTC");

    CachedModel mod_64{PF(), Model<real>(Ensemble::min)};
    CachedModel mod_32{PF(), Model<real32>(Ensemble::min)};
    auto p = pair_probability<3, 0, 0, 1>(Local(), seq, std::tie(mod_32, mod_64, mod_32));
};

/******************************************************************************************/

UNIT_TEST("thermo/pp/problem-seqs") = [](Context ct) {
    auto seq = to_sequences("CAGCUGUAGCUGACUGACUGCCGACUGCGUACGUCAGUCAUGCA+GUCAUGACUGCAUGAUCGACGCUGCGCGCGCGGCCGAUGCA");
    for (auto T : {23, 37}) {
        CachedModel mod_64(PF(), Model<real>(Ensemble::min, "RNA"s, ModelConditions{T + ZeroCinK, 1.0, 0.0}, {}, WobblePairing::on));
        CachedModel mod_32(PF(), Model<real32>(Ensemble::min, "RNA"s, ModelConditions{T + ZeroCinK, 1.0, 0.0}, {}, WobblePairing::on));

        ct.info("type", "31").info("sequence", seq).info("T", T);
        auto p0 = pair_probability<3, 1>(Local(), seq, std::tie(mod_32));
        ct.info("type", "3001").info("sequence", seq).info("T", T);
        auto p = pair_probability<3, 0, 0, 1>(Local(), seq, std::tie(mod_32, mod_64, mod_32));

        ct(HERE).within(p.second, p0.second, 5e-6);
        zip(p.first, p0.first, [&](auto f, auto f0) {ct(HERE).within(f, f0, 5e-6);});
    }
};

/******************************************************************************************/

UNIT_TEST("thermo/pp/overflow-edge-case") = [](Context ct) {
    Local env;
    CachedModel m32(PF(), Model<real32>(Ensemble::stacking, {}, {}, {}, WobblePairing::on));
    CachedModel m64(PF(), Model<real64>(Ensemble::stacking, {}, {}, {}, WobblePairing::on));

    auto s = to_sequences({
        "GGTCCCCCGCCGCGGAAAATAAGAAAGCATCGGGGCGACTAACAAGCAACCTCCAGAGACGACAAAAACCCGGCCTAGCCGGGGCTCGACGGAATCTGCT",
        "AGTGACCTCTGACCGACGCGGATCGCCTCCACAGACGGAAGCAGAACCCCAAACCGGAATCGGTCTCGAGCGCAAGTCACAATTTACCGATTCGCGTCTG",
        "ACGTCCTAACCGGACAAGACCCTGAGACTGCGTCTCAGGGTCGGAAAATGGCTGATGCCTAGACGTCGTCCCCCCACACATAATCTGGTAAAGCTTGGCC"});
{
    auto p64 = pair_probability<4, 0>(env, s, std::tie(m64));
    ct.require(std::isfinite(p64.second), p64.second);
    auto p32 = pair_probability<4, 0, 0>(env, s, std::tie(m32, m64));
    ct.require(std::isfinite(p32.second), p32.second);
}
{
    auto p64 = pair_probability<3, 0>(env, s, std::tie(m64));
    ct.require(std::isfinite(p64.second), p64.second);
    auto p32 = pair_probability<3, 0, 0>(env, s, std::tie(m32, m64));
    ct.require(std::isfinite(p32.second), p32.second);
}
};

/******************************************************************************************/

}
