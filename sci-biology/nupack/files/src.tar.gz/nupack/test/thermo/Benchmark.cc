#include "../Test.h"
#include "BenchmarkRoutines.h"
#include <nupack/execution/Local.h>
#include <spdlog/spdlog.h>
#include <spdlog/sinks/stdout_sinks.h>

namespace nupack::thermo {

/******************************************************************************/

TIME_TEST("stress-test") = [](Context ct, real t) {spin_processor(std::chrono::duration<real>(t));};

TIME_TEST("benchmark/thermo/baseline") = [](Context ct, long n, long s) {
    print(version_time(n, Ensemble::none, random_sequences(1, s)));
};

/******************************************************************************/

auto benchmark_random_mfe(json const &job) {
    auto p = job.get<std::pair<SequenceList, vec<std::size_t>>>();
    return random_mfe(p.first, Ensemble::stacking, p.second);
};

auto benchmark_versions(json const &job) {
    auto const v = job.get<SequenceList>();
    auto none = version_time(1, Ensemble::none, v);
    auto coax = version_time(1, Ensemble::stacking, v);
    print(sum(v, len), none, coax);
    return std::make_pair(none, coax);
};

/******************************************************************************/

auto benchmark_subopt(json const &job) {
    return subopt_count(job.get<SequenceList>(), Ensemble::stacking, 1e6);
};

/******************************************************************************/

auto benchmark_quantities(json const &job) {
    auto const v = job.get<SequenceList>();
    // if (v[0].size() != 3000) return std::make_pair(json(), json());
    auto none = quantity_time(Ensemble::none, v);
    auto coax = quantity_time(Ensemble::stacking, v);
    print(sum(v, len), none, coax);
    return std::make_pair(none, coax);
};

/******************************************************************************/

auto benchmark_sampling(json const &job) {
    auto const p = job.get<std::pair<SequenceList, vec<std::size_t>>>();
    print(p);
    return sampling_time(Ensemble::stacking, p.first, p.second);
};

/******************************************************************************/

auto benchmark_blocking(json const &job, uint procs, long bytes) {
    auto const p = job.get<std::pair<SequenceList, uint>>();
    auto cached = blocking_time(p.first, procs, p.second, bytes);
    auto not_cached = blocking_time(p.first, procs, p.second, 0);
    print(cached, not_cached, p);
    return std::make_pair(cached, not_cached);
};

auto benchmark_parallel(json const &job, long bytes) {
    return vmap(vec<uint>{1,2,3,4,5,6,7,8,10,12,14,16,18,20,22,24}, [&](auto procs) {
        return std::make_pair(procs, benchmark_blocking(job, procs, bytes));
    });
};

/******************************************************************************/

auto benchmark_contours(json const &job, long bytes) {
    auto const p = job.get<std::pair<SequenceList, real>>();
    print(p);
    return contour_time(p.first, p.second, Ensemble::stacking, bytes);
};

/******************************************************************************/

TIME_TEST("benchmark/thermo/any") = [](Context ct, std::string out, std::string in, long threads, real bytes) {
    auto logger = spdlog::stdout_logger_mt("benchmark");
    logger->set_level(spdlog::level::info);
    logger->set_pattern("[%H:%M:%S] %v");

    std::ifstream ifs(in);
    json input, output;
    ifs >> input;
    spin_processor(chrono::duration<real>(20)); // warm up processor
    for (auto i : range(input.size())) {
        auto j = input.at(i);
        auto const type = j["type"].template get<std::string>();
        auto const args = j["parameters"];
        try {
            if (type == "contours")
                j["output"] = benchmark_contours(args, bytes);
            else if (type == "blocking")
                j["output"] = benchmark_blocking(args, threads, bytes);
            else if (type == "subopt")
                j["output"] = benchmark_subopt(args);
            else if (type == "versions")
                j["output"] = benchmark_versions(args);
            else if (type == "sampling")
                j["output"] = benchmark_sampling(args);
            else if (type == "quantities")
                j["output"] = benchmark_quantities(args);
            else if (type == "parallel")
                j["output"] = benchmark_parallel(args, bytes);
            else if (type == "random_mfe")
                j["output"] = benchmark_random_mfe(args);
            else NUPACK_ERROR("Unknown job type", type);
        } catch(...) {
            std::cerr << "Error while running job\n" << j << std::endl;
            throw;
        }
        output.emplace_back(std::move(j));
        std::ofstream ofs(out);
        ofs << output;
    }
};

}
