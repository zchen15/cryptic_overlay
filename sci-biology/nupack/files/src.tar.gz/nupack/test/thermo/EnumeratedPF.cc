#include "../Test.h"
#include <nupack/jump/Jump.h>
#include <nupack/execution/Local.h>
#include <nupack/types/Database.h>
#include <nupack/markov/Enumerate.h>

#include <nupack/thermo/Engine.h>
#include <nupack/thermo/CachedModel.h>
#include <nupack/thermo/CoaxialEnumeration.h>

namespace nupack { namespace thermo {

/******************************************************************************************/

void compare_stack_pf(Context &ct, SequenceList const &s, bool count) {
    Local env;
    CachedModel model(PF(), Model(Ensemble::stacking, {}, {}, {}, WobblePairing::off));
    if (count) model.set_beta(0);

    auto dynamic = dynamic_program(env, NickSequence(s), model);
    real enumerated = enumerated_stack_sum<RigPF>(s, model.energy_model);
    ct.within(dynamic, model.as_log(enumerated), 0.01, s);
};

/******************************************************************************************/

void compare_stack_mfe(Context &ct, SequenceList const &s) {
    Local env;
    CachedModel model(MFE(), Model(Ensemble::stacking, {}, {}, {}, WobblePairing::off));
    auto states = subopt(env, 0.0, NickSequence(s), model);
    auto w1 = minimum(states, second_of);
    real enumerated = enumerated_stack_sum<RigMFE>(s, model.energy_model);

    ct(HERE).within(w1.second, enumerated, 0.01, s);
    auto state_energy = stacking_state_partition_function<RigMFE>(jump_state(s, w1.first, moves::full), model.energy_model);
    ct(HERE).within(w1.second, state_energy, 0.01, s);
};

/******************************************************************************************/

UNIT_TEST("thermo/coaxial/count/enumerated") = [](Context ct) {
    repeat_test(ct, JsonDatabase<vec<string>>("enumeration_seqs.json"), [&](auto &&s) {compare_stack_pf(ct, to_sequences(s), true);});
};


UNIT_TEST("thermo/coaxial/pf/enumerated") = [](Context ct) {
    repeat_test(ct, JsonDatabase<vec<string>>("enumeration_seqs.json"), [&](auto &&s) {compare_stack_pf(ct, to_sequences(s), false);});
};


UNIT_TEST("thermo/coaxial/mfe/enumerated") = [](Context ct) {
    repeat_test(ct, JsonDatabase<vec<string>>("enumeration_seqs.json"), [&](auto &&s) {compare_stack_mfe(ct, to_sequences(s));});
};


/******************************************************************************************/

template <class S, class Model>
real enumerated_pf(S &&s, Model const &mod, bool count) {
    real pf = 0;
    for_complex_states(jump_state(s, {}, moves::full, mod), [&](auto const &w) {
        auto energy = w.calculate_energy(mod);
        if (!count) pf += mod.boltz(energy);
        else pf += (energy != decltype(energy)(*inf));
    });
    return pf;
}

/******************************************************************************************/

void compare_pf(Context &ct, string fn, Ensemble ensemble, WobblePairing gt, string material, bool count) {
    JsonDatabase<vec<string>> const db(fn);
    Local env;
    CachedModel model(PF(), Model<real64>(ensemble, material, {}, {}, gt));
    auto mod = model.energy_model;
    if (count) model.set_beta(0);

    repeat_test(ct, db, [&](auto const &seq) {
        ct.info(seq);
        auto g = (gt == WobblePairing::on);
        ct.info(g);
        ct.info(material);
        auto s = to_sequences(seq);
        auto dynamic = dynamic_program(env, NickSequence(s), model);
        real enumerated = enumerated_pf(seq, mod, count);
        ct.within(dynamic, model.as_log(enumerated), 0.01);
    });
}

/******************************************************************************************/

UNIT_TEST("enum/pf/basic/nogu/rna/none"   ) = [](Context ct) {compare_pf(ct, "enumeration_seqs.json", Ensemble::none, WobblePairing::off, "RNA", false);};
UNIT_TEST("enum/pf/basic/nogu/rna/min"    ) = [](Context ct) {compare_pf(ct, "enumeration_seqs.json", Ensemble::min,  WobblePairing::off, "RNA", false);};
UNIT_TEST("enum/pf/basic/nogu/rna/all"    ) = [](Context ct) {compare_pf(ct, "enumeration_seqs.json", Ensemble::all,  WobblePairing::off, "RNA", false);};
UNIT_TEST("enum/pf/basic/nogu/dna/none"   ) = [](Context ct) {compare_pf(ct, "enumeration_seqs.json", Ensemble::none, WobblePairing::off, "DNA", false);};
UNIT_TEST("enum/pf/basic/nogu/dna/min"    ) = [](Context ct) {compare_pf(ct, "enumeration_seqs.json", Ensemble::min,  WobblePairing::off, "DNA", false);};
UNIT_TEST("enum/pf/basic/nogu/dna/all"    ) = [](Context ct) {compare_pf(ct, "enumeration_seqs.json", Ensemble::all,  WobblePairing::off, "DNA", false);};
UNIT_TEST("enum/pf/basic/gt/rna/none"     ) = [](Context ct) {compare_pf(ct, "enumeration_seqs.json", Ensemble::none, WobblePairing::on,  "RNA", false);};
UNIT_TEST("enum/pf/basic/gt/rna/min"      ) = [](Context ct) {compare_pf(ct, "enumeration_seqs.json", Ensemble::min,  WobblePairing::on,  "RNA", false);};
UNIT_TEST("enum/pf/basic/gt/rna/all"      ) = [](Context ct) {compare_pf(ct, "enumeration_seqs.json", Ensemble::all,  WobblePairing::on,  "RNA", false);};
UNIT_TEST("enum/pf/basic/gt/dna/none"     ) = [](Context ct) {compare_pf(ct, "enumeration_seqs.json", Ensemble::none, WobblePairing::on,  "DNA", false);};
UNIT_TEST("enum/pf/basic/gt/dna/min"      ) = [](Context ct) {compare_pf(ct, "enumeration_seqs.json", Ensemble::min,  WobblePairing::on,  "DNA", false);};
UNIT_TEST("enum/pf/basic/gt/dna/all"      ) = [](Context ct) {compare_pf(ct, "enumeration_seqs.json", Ensemble::all,  WobblePairing::on,  "DNA", false);};
UNIT_TEST("enum/count/basic/nogu/rna/none") = [](Context ct) {compare_pf(ct, "enumeration_seqs.json", Ensemble::none, WobblePairing::off, "RNA", true);};
UNIT_TEST("enum/count/basic/nogu/rna/min" ) = [](Context ct) {compare_pf(ct, "enumeration_seqs.json", Ensemble::min,  WobblePairing::off, "RNA", true);};
UNIT_TEST("enum/count/basic/nogu/rna/all" ) = [](Context ct) {compare_pf(ct, "enumeration_seqs.json", Ensemble::all,  WobblePairing::off, "RNA", true);};
UNIT_TEST("enum/count/basic/nogu/dna/none") = [](Context ct) {compare_pf(ct, "enumeration_seqs.json", Ensemble::none, WobblePairing::off, "DNA", true);};
UNIT_TEST("enum/count/basic/nogu/dna/min" ) = [](Context ct) {compare_pf(ct, "enumeration_seqs.json", Ensemble::min,  WobblePairing::off, "DNA", true);};
UNIT_TEST("enum/count/basic/nogu/dna/all" ) = [](Context ct) {compare_pf(ct, "enumeration_seqs.json", Ensemble::all,  WobblePairing::off, "DNA", true);};
UNIT_TEST("enum/count/basic/gt/rna/none"  ) = [](Context ct) {compare_pf(ct, "enumeration_seqs.json", Ensemble::none, WobblePairing::on,  "RNA", true);};
UNIT_TEST("enum/count/basic/gt/rna/min"   ) = [](Context ct) {compare_pf(ct, "enumeration_seqs.json", Ensemble::min,  WobblePairing::on,  "RNA", true);};
UNIT_TEST("enum/count/basic/gt/rna/all"   ) = [](Context ct) {compare_pf(ct, "enumeration_seqs.json", Ensemble::all,  WobblePairing::on,  "RNA", true);};
UNIT_TEST("enum/count/basic/gt/dna/none"  ) = [](Context ct) {compare_pf(ct, "enumeration_seqs.json", Ensemble::none, WobblePairing::on,  "DNA", true);};
UNIT_TEST("enum/count/basic/gt/dna/min"   ) = [](Context ct) {compare_pf(ct, "enumeration_seqs.json", Ensemble::min,  WobblePairing::on,  "DNA", true);};
UNIT_TEST("enum/count/basic/gt/dna/all"   ) = [](Context ct) {compare_pf(ct, "enumeration_seqs.json", Ensemble::all,  WobblePairing::on,  "DNA", true);};


/******************************************************************************************/

template <class S, class Model>
auto enumerated_mfe(S &&s, Model const &mod) {
    real mfe = *inf;
    PairList pairs;
    for_complex_states(jump_state(s, {}, moves::full, mod), [&](auto const &w) {
        auto energy = w.calculate_energy(mod);
        if (energy < mfe) {pairs = w.pairs; mfe = energy;}
    });
    return std::make_pair(pairs, mfe);
}

/******************************************************************************************/

void compare_mfe(Context &ct, string fn, Ensemble ensemble, WobblePairing gt, string material) {
    JsonDatabase<vec<string>> const db(fn);
    Local env;
    CachedModel model(MFE(), Model(ensemble, material, {}, {}, gt));

    repeat_test(ct, db, [&](auto const &seq) {
        ct.info(seq);
        ct.info("gt", gt == WobblePairing::on);
        ct.info("material", material);
        auto s = to_sequences(seq);
        NickSequence ns(s);
        auto states = subopt(env, 0.0, ns, model);
        auto mfe = enumerated_mfe(seq, model.energy_model);
        auto mfe2 = minimum(states, second_of);
        ct(HERE).within(mfe2.second, structure_energy(seq, mfe2.first, model.energy_model), 0.01);
        ct(HERE).within(mfe2.second, mfe.second, 0.01);

        // ct(HERE).require(any_of(states, [&](auto const &p) {
        //     return p.first.dp(ns.nicks()) == mfe.first.dp(ns.nicks());
        // }));
    });
}

UNIT_TEST("enum/mfe/basic/nogu/rna/none"   ) = [](Context ct) {compare_mfe(ct, "enumeration_seqs.json", Ensemble::none, WobblePairing::off, "RNA");};
UNIT_TEST("enum/mfe/basic/nogu/rna/min"    ) = [](Context ct) {compare_mfe(ct, "enumeration_seqs.json", Ensemble::min,  WobblePairing::off, "RNA");};
UNIT_TEST("enum/mfe/basic/nogu/rna/all"    ) = [](Context ct) {compare_mfe(ct, "enumeration_seqs.json", Ensemble::all,  WobblePairing::off, "RNA");};
UNIT_TEST("enum/mfe/basic/nogu/dna/none"   ) = [](Context ct) {compare_mfe(ct, "enumeration_seqs.json", Ensemble::none, WobblePairing::off, "DNA");};
UNIT_TEST("enum/mfe/basic/nogu/dna/min"    ) = [](Context ct) {compare_mfe(ct, "enumeration_seqs.json", Ensemble::min,  WobblePairing::off, "DNA");};
UNIT_TEST("enum/mfe/basic/nogu/dna/all"    ) = [](Context ct) {compare_mfe(ct, "enumeration_seqs.json", Ensemble::all,  WobblePairing::off, "DNA");};
UNIT_TEST("enum/mfe/basic/gt/rna/none"     ) = [](Context ct) {compare_mfe(ct, "enumeration_seqs.json", Ensemble::none, WobblePairing::on,  "RNA");};
UNIT_TEST("enum/mfe/basic/gt/rna/min"      ) = [](Context ct) {compare_mfe(ct, "enumeration_seqs.json", Ensemble::min,  WobblePairing::on,  "RNA");};
UNIT_TEST("enum/mfe/basic/gt/rna/all"      ) = [](Context ct) {compare_mfe(ct, "enumeration_seqs.json", Ensemble::all,  WobblePairing::on,  "RNA");};
UNIT_TEST("enum/mfe/basic/gt/dna/none"     ) = [](Context ct) {compare_mfe(ct, "enumeration_seqs.json", Ensemble::none, WobblePairing::on,  "DNA");};
UNIT_TEST("enum/mfe/basic/gt/dna/min"      ) = [](Context ct) {compare_mfe(ct, "enumeration_seqs.json", Ensemble::min,  WobblePairing::on,  "DNA");};
UNIT_TEST("enum/mfe/basic/gt/dna/all"      ) = [](Context ct) {compare_mfe(ct, "enumeration_seqs.json", Ensemble::all,  WobblePairing::on,  "DNA");};

/******************************************************************************************/

// UNIT_TEST("enum.count.basic") = [](Context ct) {
//     for (auto &&gt : vec<bool>{false, true})
//         for (auto param : vec<string> {"RNA", "DNA"})
//             for (auto dangles : vec<string> {"none", "min", "all"})
//                 compare_pf("enumeration_seqs.json", gt, param, dangles(), WobblePairing::off);
// }


// UNIT_TEST("enum.pf.basic") = [](Context ct) {
//     for (auto &&gt : vec<bool>{false, true})
//         for (auto param : vec<string> {"RNA", "DNA"})
//             for (auto dangles : vec<string> {"none", "min", "all"})
//                 compare_pf("enumeration_seqs.json", gt, param, dangles);
// }



PROTOTYPE("throwaway-coaxial-energy") = [](Context ct) {
    Model<real> none{Ensemble::none};
    Model<real> coax{Ensemble::stacking};
    // _.model;
    BEEP(structure_energy("AAUUA", ".....", coax));
    BEEP(structure_energy("AAUUA", ".....", none));
    BEEP(structure_energy("GAAACGAAACGAAACGAAACGAAAC", "(...)(...)(...)(...)(...)", coax));
    BEEP(structure_energy("GAAACGAAACGAAACGAAACGAAAC", "(...)(...)(...)(...)(...)", none));
    BEEP(structure_energy("ACGUGAC+GCUGAC", "......(+).....", coax));
    BEEP(structure_energy("ACGUGAC+GCUGAC", "......(+).....", none));
    BEEP(structure_energy("UCCAAUAAAAUCGGGGGCGCACGGUUGCCAGCCCCUACAAGUACUAAAAGUACCGGAUGAGACGCCCGAAUGAUCGUUUUCUUAGAGAUCCCACCUGCAGUGCGGCCUGCCUACGGUCAUUUGCGUGGUGUUAUCGCGAUAAUUGGUAAGAAGGUUAAUAUGACAAAACCACCUUUUAUGGCUGGUCCUCGGGUUGCGUCAAGCCGUUUGCGUAUUCGGCUUUUCAUAACAAAGUCACCGCAUAACGAUGUGGGGCGUUACUACAGGGUCAGAGGCCCGGCUUCGGCUUUCAAAACCUCAAAGGCCCUUGGAGUAAGGUCUGUCGGAACUGUUCGUGAUGGAUGCCAAACCUGAGUACGAAUUAGUCACUACCCGCUUAACACGGAUGCUUCUAGGUUCAUAUCGUUUAUAGUUGAGCCAAGCUGCAGCGUGUUUAGGCGAGGGGGUCCCAGAGCGGAACCAGAAGAAGCCUGGCGAAACCGAAAUCUGACUGCGUUUACACCGAAGGAACUUCUUUUUGGCUUUGUCAAGUAAGGACUUGUUCGAAGAACUUCAUAGCUACCCUUACCGCGAGGAGACACUACUUGUAUACGUAUGAGGUAGAUAGUAUGCGAUCGACGAGCCCCAGGCGACAAUAUAAUAAUAUUGACAUAUGUCGUCCUCUCAGAUUCAUCUCGGGUCACGCUCCUCCAUUGGACAAAGGACUAACCUAUGAGCAGAAGUCUGCUUGAAUUUACUUAGGACGGGCCUUGGUUUAAUUGUACAAUUCCCGUAGACUAUUGCGCAAAGCGCGUGGGAACCAUGAUUCCUAUACUCAGGUAAGAGAUCCGCAAUGGAAUCUGUCGGGAAAUUGACAAUACUAUGAAGGGGCACGCAGCAUUCCUCUUGGGCUAGGAGCGGUACCGACUCGCCAUGUUUUACAGCACCCAUAUCUCAUCCGGGACUAGGGUUUUUUCAAGUCCCCGAGUGAGUUUUACUGAGGGUUUGUGCUAGGUUUGCU",
            ".............((((((((....)))..))))).....(((((...)))))...((((((.(.(((((((.......................((((((((((((((....(((((((..(.(((((.((.(((.(.(((((........))))).).))).)).))))).)...))))))).....))))))))).........))))))))))))).))))))......(((.((((((....))))))))).(((((..((((((.((((...(((....))).......))))...))))))...)))))..((((((((((...))).)))))))...(((((((.((((((((((..(((.(((((((((((((((..(((..((.((((((.............)))))).))..))).)))).))))))).))((((....((((((.(((.(......((((((..((..(((...((.(((((((.((.((((..(((..(((...((((..((((((((..((.((((((((..(.(((......((((((.(((.(((((.........)))))....))).).)))))..))).).)))...))))).))...))...............))))))...)))).......))))))...)))))).).((((((.((((((((.((((.((..(((((((((((....)))))))........))))...)))))).)))))(((((.(((((((((((((((((((((........(((((((......)))))))................))))))))..)))).)))))).))))))))...))).)))))))))))))))))...))..))))))..)))).))).)))...............))))(...((((((.((((((.((......)).)))))).)).))))..))).))).)))))))))))))))))..",
            none));
    BEEP(structure_energy("UCCAAUAAAAUCGGGGGCGCACGGUUGCCAGCCCCUACAAGUACUAAAAGUACCGGAUGAGACGCCCGAAUGAUCGUUUUCUUAGAGAUCCCACCUGCAGUGCGGCCUGCCUACGGUCAUUUGCGUGGUGUUAUCGCGAUAAUUGGUAAGAAGGUUAAUAUGACAAAACCACCUUUUAUGGCUGGUCCUCGGGUUGCGUCAAGCCGUUUGCGUAUUCGGCUUUUCAUAACAAAGUCACCGCAUAACGAUGUGGGGCGUUACUACAGGGUCAGAGGCCCGGCUUCGGCUUUCAAAACCUCAAAGGCCCUUGGAGUAAGGUCUGUCGGAACUGUUCGUGAUGGAUGCCAAACCUGAGUACGAAUUAGUCACUACCCGCUUAACACGGAUGCUUCUAGGUUCAUAUCGUUUAUAGUUGAGCCAAGCUGCAGCGUGUUUAGGCGAGGGGGUCCCAGAGCGGAACCAGAAGAAGCCUGGCGAAACCGAAAUCUGACUGCGUUUACACCGAAGGAACUUCUUUUUGGCUUUGUCAAGUAAGGACUUGUUCGAAGAACUUCAUAGCUACCCUUACCGCGAGGAGACACUACUUGUAUACGUAUGAGGUAGAUAGUAUGCGAUCGACGAGCCCCAGGCGACAAUAUAAUAAUAUUGACAUAUGUCGUCCUCUCAGAUUCAUCUCGGGUCACGCUCCUCCAUUGGACAAAGGACUAACCUAUGAGCAGAAGUCUGCUUGAAUUUACUUAGGACGGGCCUUGGUUUAAUUGUACAAUUCCCGUAGACUAUUGCGCAAAGCGCGUGGGAACCAUGAUUCCUAUACUCAGGUAAGAGAUCCGCAAUGGAAUCUGUCGGGAAAUUGACAAUACUAUGAAGGGGCACGCAGCAUUCCUCUUGGGCUAGGAGCGGUACCGACUCGCCAUGUUUUACAGCACCCAUAUCUCAUCCGGGACUAGGGUUUUUUCAAGUCCCCGAGUGAGUUUUACUGAGGGUUUGUGCUAGGUUUGCU",
            ".............((((((((....)))..))))).....(((((...)))))...((((((.(.(((((((.......................((((((((((((((....(((((((..(.(((((.((.(((.(.(((((........))))).).))).)).))))).)...))))))).....))))))))).........))))))))))))).))))))......(((.((((((....))))))))).(((((..((((((.((((...(((....))).......))))...))))))...)))))..((((((((((...))).)))))))...(((((((.((((((((((..(((.(((((((((((((((..(((..((.((((((.............)))))).))..))).)))).))))))).))((((....((((((.(((.(......((((((..((..(((...((.(((((((.((.((((..(((..(((...((((..((((((((..((.((((((((..(.(((......((((((.(((.(((((.........)))))....))).).)))))..))).).)))...))))).))...))...............))))))...)))).......))))))...)))))).).((((((.((((((((.((((.((..(((((((((((....)))))))........))))...)))))).)))))(((((.(((((((((((((((((((((........(((((((......)))))))................))))))))..)))).)))))).))))))))...))).)))))))))))))))))...))..))))))..)))).))).)))...............))))(...((((((.((((((.((......)).)))))).)).))))..))).))).)))))))))))))))))..",
            coax));
};



PROTOTYPE("mask-test") = [](Context ct) {
    auto masks = get_masks({2, 2, 2});
    print(masks);
    filter_masks(masks);
    print(masks);
    masks = get_masks({2, 2, 3, 2});
    print(masks);
    filter_masks(masks);
    print(masks);
    masks = get_masks({2, 2, 2, 2});
    print(masks);
    for (auto & m : masks) m.push_back(m[0]);
    filter_masks(masks);
    for (auto & m : masks) m.pop_back();
    print(masks);
};

/******************************************************************************************/

}}
