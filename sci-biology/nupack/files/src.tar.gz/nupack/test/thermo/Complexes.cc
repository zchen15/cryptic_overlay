#include "../Test.h"
#include <nupack/thermo/Engine.h>
#include <nupack/thermo/CachedModel.h>
#include <nupack/thermo/ComplexSampler.h>
#include <nupack/state/State.h>
#include <nupack/execution/Local.h>
#include <nupack/types/Database.h>

namespace nupack { namespace thermo {

/******************************************************************************************/

TIME_TEST("pf/permutations") = [](Context ct) {
    Local env(4);
    auto const v = random_sequences(10, 100);
    for (auto max : range(1, 8)) {
        auto num = 0;
        for (auto s : range(max)) num += compute_necklaces(small_vec<uint>(s+1), len(v));
        auto const num2 = compute_necklaces(small_vec<uint>(max), len(v));
        BEEP(num, num2);
        CachedModel model{PF(), Model(Ensemble::none)};
        int cached = 0, total = 0;
        auto t = time_it([&] {
            Cache<3, NoStacking, real> cache;
            auto result = permutations(env, max, v, model, cache, [&](auto const &m) {cached += m.calculation_type == 'C'; ++total;});
            ct.equal(num, len(result));
        });
        BEEP(num, num2, max, cached, total, t);
    }
};

/******************************************************************************************/

PROTOTYPE("complex-sampler") = [](Context ct) {
    auto v = to_sequences({"AACATGCTAA", "TCAGCT", "ACATGCAT", "CTAGCTGATA"});
    CachedModel model{PF(), Model(Ensemble::none)};
    auto logq = permutations(Local(), 0, v, model);
    for (auto &r : logq) {print(r.second, r.first); r.second = 0;}
    auto sampler = ComplexSampler(v, logq, 1.0);
    auto pairs = sampler(Local(), model, 50000);

    StaticState<> w(sampler.sequences, {});
    for (auto p : pairs) print(w.with_structure(p));
};

/******************************************************************************************/

TIME_TEST("parallel/permutations") = [](Context ct) {
    auto v = random_sequences(3, 40);
    CachedModel model{PF(), Model(Ensemble::none)};

    {Local env;    echo | time_it([&] {return permutations(env, 5, v, model);});}
    {Local env(1); echo | time_it([&] {return permutations(env, 5, v, model);});}
    {Local env(2); echo | time_it([&] {return permutations(env, 5, v, model);});}
    {Local env(4); echo | time_it([&] {return permutations(env, 5, v, model);});}

    v = random_sequences(2, 288);
    {Local env;    echo | time_it([&] {return permutations(env, 5, v, model);});}
    {Local env(1); echo | time_it([&] {return permutations(env, 5, v, model);});}
    {Local env(2); echo | time_it([&] {return permutations(env, 5, v, model);});}
    {Local env(4); echo | time_it([&] {return permutations(env, 5, v, model);});}
};

/******************************************************************************************/

TIME_TEST("thermo/cached-blocking-timing-csv") = [](Context ct) {
    constexpr int length = 50;
    vec<int> nums_seqs = {2, 4, 6, 8, 10};
    vec<int> max_sizes = {2, 3, 4, 5, 6};

    CachedModel mod_32{PF(), Model<real32>(Ensemble::none)};
    CachedModel mod_64{PF(), Model<real64>(Ensemble::none)};
    auto models = std::tie(mod_64, mod_32);

    std::ofstream out("cache_timing.csv");
    print_os<io::comma, io::endl>(out, "with_cache", "length", "number_of_sequences", "max_size", "number_of_complexes", "time");

    for (auto max_size : max_sizes) for (auto num_seqs : nums_seqs) for (auto procs : range<int>(1, 9)) {
        Local env(procs);
        BEEP(max_size, num_seqs);
        auto seqs = random_sequences(num_seqs, length);
        int num_complexes = 0;
        auto lrucache = thermo::Cache<3, NoStacking, real, overflow<float>>(TotalRAM / 2);

        real cached_time = time_it(1, [&]{
            auto temp = permutations<3, 0, 1>(env, max_size, seqs, models, lrucache);
            num_complexes = len(temp);
        });
        print_os<io::comma, io::endl>(out, procs, length, num_seqs, max_size, num_complexes, cached_time);

        real non_cached_time = time_it(1, [&]{
            vec<NickSequence> m_seqs;
            for (auto neck_size : range(1, max_size+1))
                compute_necklaces(small_vec<uint>(neck_size), len(seqs), [&](auto const &i) {m_seqs.emplace_back(indexed_view(i, seqs));});
            for (auto const &s : m_seqs)
                dynamic_program<3, 0, 1>(env, s, models);
        });
        print_os<io::comma, io::endl>(out, -procs, length, num_seqs, max_size, num_complexes, non_cached_time);
    }
};

/******************************************************************************************/

}}
