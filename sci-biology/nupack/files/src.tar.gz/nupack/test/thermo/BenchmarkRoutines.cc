#include <nupack/thermo/Engine.h>
#include <nupack/thermo/CachedModel.h>
#include <nupack/state/State.h>
#include <nupack/execution/Local.h>
#include <nupack/concentration/Equilibrate.h>
#include <nupack/standard/Future.h>

#include "BenchmarkRoutines.h"

#include <spdlog/spdlog.h>
#include <spdlog/fmt/ostr.h>
#include <spdlog/fmt/bundled/ostream.h>

namespace nupack::thermo {


auto benchmark_models(Ensemble ensemble, std::size_t n, bool count=false) {
    CachedModel model32{PF(), Model<real32>(ensemble)};
    if (count) model32.set_beta(0);
    model32.reserve(n);
    CachedModel model64{PF(), Model<real64>(ensemble)};
    if (count) model64.set_beta(0);
    model64.reserve(n);
    return std::make_pair(std::move(model32), std::move(model64));
}

/******************************************************************************/

// count number of structures as a function of the gap
vec<std::tuple<real, real, std::size_t>> subopt_count(NickSequence s, Ensemble ensemble, std::size_t max) {
    CachedModel model32{MFE(), Model<real32>(ensemble)};
    vec<std::tuple<real, real, std::size_t>> out;
    block_dependent<bool, 3, 0>(Local(), [&](auto const &Q, auto const &seq, auto const &model, auto pf) {
        for (real gap = 0; gap < 50; gap = std::max(1e-4, gap * sqrt(10))) {
            std::size_t n = 0;
            using Clock = std::chrono::high_resolution_clock;
            auto const start = Clock::now();
            auto it = subopt_iterator<Outer_Stack>(Q, seq, model, gap);
            for (; (Clock::now() - start < 1000s) && !it.done() && n != max; ++n, ++it) time_sink(*it);
            auto const elapsed = std::chrono::duration<real>(Clock::now() - start).count();
            out.emplace_back(gap, elapsed, n == max ? 0 : n);
            if (n == max) break;
        }
        return bool();
    }, s, std::tie(model32), False());
    return out;
}

/******************************************************************************/

RandomMFE random_mfe(SequenceList const v, Ensemble ensemble, vec<std::size_t> n_samples) {
    NickSequence s(v);
    auto logger = spdlog::get("benchmark");

    RandomMFE out;

    if (logger) logger->info("Starting MFE computation ({} nt)", len(s));

    auto energy = [&, mod=Model(ensemble)](PairList const &p){return structure_energy(v, p, mod);};
{
    CachedModel model32{MFE(), Model<real32>(ensemble)};
    auto t = time_it([&] {
        auto mfes = subopt(Local(), 0, s, model32);
        auto p = min_element(mfes, [&](auto const &p) {return energy(p.first);});
        first_of(second_of(out)) = p->first.dp(s.nicks());
        second_of(second_of(out)) = p->second;
        third_of(second_of(out)) = energy(p->first);
    });
    fourth_of(second_of(out)) = t;
}
    if (logger) logger->info("Starting sampling computation ({} nt)", len(s));
{
    auto mods = benchmark_models(ensemble, len(s));

    auto run = [&](auto const &Q, auto const &seq, auto const &model, auto pf) {
        first_of(out) = pf;
        for (auto const &m : n_samples) {
            if (logger) logger->info("Starting simultaneous samples ({}, {} nt)", m, len(s));
            auto const t = time_it(1, [&] {
                auto o = sample_block(Q, seq, model, m);
                auto p = min_element(o.first, [&](auto const &p) {return energy(p);});
                third_of(out).emplace_back(p->dp(s.nicks()), energy(*p), real());
            });
            third_of(third_of(out).back()) = t;
            if (logger) logger->info("Finished samples ({}, {} nt)", m, len(s));
        }
        return bool();
    };

    if (logger) logger->info("Starting sample block computation ({} nt)", len(s));
    if (len(s) > 3000) block_dependent<bool, 3, 1>(Local(), run, s, std::tie(mods.first), False());
    else block_dependent<bool, 3, 0, 0, 1>(Local(), run, s, std::tie(mods.first, mods.second, mods.first), False());
}
    return out;
}

/******************************************************************************/

std::pair<real, real> version_time(uint n, Ensemble ensemble, NickSequence s) {
    auto logger = spdlog::get("benchmark");
    // {
    //     auto mods = benchmark_models(Ensemble::stacking, sum(v, len));
    //     auto const b = block<3, 0, 0, 1>(Local(), Ensemble::stacking, random_sequences(1, 800, 1.0), std::tie(mods.first, mods.second, mods.first), False());
    //     print("memory of 800", memory::measure(b));
    // }
    auto mods = benchmark_models(ensemble, len(s));
    if (logger) logger->info("Starting version job ({} nt)", len(s));
    real out;
    real time = time_it(n, [&] {
        if (len(s) > 3000) out = dynamic_program<3, 1>(Local(), s, std::tie(mods.first), False());
        else out = dynamic_program<3, 0, 0, 1>(Local(), s, std::tie(mods.first, mods.second, mods.first), False());
    });
    return {out, time};
}

/******************************************************************************/

vec<std::array<std::pair<real, std::size_t>, 2>> sampling_time(Ensemble ensemble, NickSequence s, vec<std::size_t> n_samples) {
    auto logger = spdlog::get("benchmark");

    auto mods = benchmark_models(ensemble, len(s));
    vec<std::array<std::pair<real, std::size_t>, 2>> out;

    auto run = [&](auto const &Q, auto const &seq, auto const &model, auto pf) {
        for (auto const &m : n_samples) {
            std::size_t n1 = 0, n2 = 0;
            if (logger) logger->info("Starting simultaneous samples ({}, {} nt)", m, len(s));
            auto const simultaneous = time_it(1, [&] {
                auto o = sample_block(Q, seq, model, m);
                n1 = o.second;
                time_sink(o);
            });
            if (logger) logger->info("Starting sequential samples ({}, {} nt)", m, len(s));
            auto const sequential = time_it(1, [&] {
                for (auto i : range(m)) {
                    auto o = sample_block(Q, seq, model, 1);
                    n2 += o.second;
                    time_sink(o);
                }
            });
            out.push_back({std::make_pair(simultaneous, n1), std::make_pair(sequential, n2)});
            if (logger) logger->info("Finished samples ({}, {} nt)", m, len(s));
        }
        return bool();
    };
    if (logger) logger->info("Starting sample block computation ({} nt)", len(s));
    if (len(s) > 3000) block_dependent<bool, 3, 1>(Local(), run, s, std::tie(mods.first), False());
    else block_dependent<bool, 3, 0, 0, 1>(Local(), run, s, std::tie(mods.first, mods.second, mods.first), False());
    return out;
}

/******************************************************************************/

std::map<std::string, real> quantity_time(Ensemble ensemble, NickSequence s) {
    auto logger = spdlog::get("benchmark");
    auto mods = benchmark_models(ensemble, len(s));
    std::map<std::string, real> out;

    if (logger) logger->info("Starting pair probability ({} nt)", len(s));
    out["pairs"] = time_it(1, [&] {
        if (len(s) > 3000) time_sink(pair_probability<3, 1>(Local(), s, std::tie(mods.first), False()));
        else time_sink(pair_probability<3, 0, 0, 1>(Local(), s, std::tie(mods.first, mods.second, mods.first), False()));
    });

    if (logger) logger->info("Starting partition function ({} nt)", len(s));
    out["pf"] = time_it(1, [&] {
        if (len(s) > 3000) dynamic_program<3, 1>(Local(), s, std::tie(mods.first), False());
        else dynamic_program<3, 0, 0, 1>(Local(), s, std::tie(mods.first, mods.second, mods.first), False());
    });

    if (logger) logger->info("Starting partition function f32 ({} nt)", len(s));
    try {
        out["pf32"] = time_it(1, [&] {dynamic_program<3, 0>(Local(), s, std::tie(mods.first), False());});
    } catch (std::exception const &) {}

    if (logger) logger->info("Starting partition function f64 ({} nt)", len(s));
    try {
        out["pf64"] = time_it(1, [&] {dynamic_program<3, 0>(Local(), s, std::tie(mods.second), False());});
    } catch (std::exception const &) {}

    if (logger) logger->info("Starting partition function o32 ({} nt)", len(s));
    try {
        out["pf32o"] = time_it(1, [&] {dynamic_program<3, 1>(Local(), s, std::tie(mods.first), False());});
    } catch (std::exception const &) {}

    if (logger) logger->info("Starting partition function o64 ({} nt)", len(s));
    try {
        out["pf64o"] = time_it(1, [&] {dynamic_program<3, 1>(Local(), s, std::tie(mods.second), False());});
    } catch (std::exception const &) {}

    if (logger) logger->info("Starting structure count ({} nt)", len(s));
    mods = benchmark_models(ensemble, len(s), true);
    out["count"] = len(s) > 3000 ?
        dynamic_program<3, 1>(Local(), s, std::tie(mods.first), False()) :
        dynamic_program<3, 0, 0, 1>(Local(), s, std::tie(mods.first, mods.second, mods.first), False());

    CachedModel mod32{MFE(), Model<real32>(ensemble)};
    mod32.reserve(len(s));

    if (logger) logger->info("Starting MFE ({} nt)", len(s));
    out["mfe"] = time_it(1, [&]{
        time_sink(dynamic_program<3, 0>(Local(), s, std::tie(mod32), False()));
    });

    return out;
}

/******************************************************************************/

real blocking_time(SequenceList seqs, uint procs, uint lmax, std::size_t bytes) {
    auto logger = spdlog::get("benchmark");
    if (logger) logger->info("starting blocks (p={}, lmax={}, n={})", procs, lmax, sum(seqs, len));

    auto mods = benchmark_models(Ensemble::stacking, sum(seqs, len));
    Local env(procs);

    if (bytes > 0) {
        auto cache = thermo::Cache<3, Stacking, real32, real64, overflow<real32>>(bytes);

        return time_it(1, [&] {
            time_sink(permutations<3, 0, 0, 1>(env, lmax, seqs, std::tie(mods.first, mods.second, mods.first), cache));
        });
    }
    return time_it(1, [&] { // no incorporation of blocking methods now
        vec<NickSequence> perms;
        for (auto neck_size : range(1, lmax+1))
            compute_necklaces(small_vec<uint>(neck_size), len(seqs), [&](auto const &i) {
                perms.emplace_back(indexed_view(i, seqs));
                mods.first.reserve(len(perms.back()));
                mods.second.reserve(len(perms.back()));
            });

        env.spread(perms, 1, [&](auto &&env, auto const &p, auto const &) {
            time_sink(dynamic_program<3, 0, 0, 1>(env, p, std::tie(mods.first, mods.second, mods.first)));
        });
    });
}

/******************************************************************************/

vec<std::tuple<std::size_t, real, real, uint>> contour_time(SequenceList v, real time, Ensemble ensemble, std::size_t bytes) {
    auto logger = spdlog::get("benchmark");

    vec<std::tuple<std::size_t, real, real, uint>> out;
    auto const water_conc = water_molarity(DefaultTemperature);
    SequenceList const strands = sorted(std::move(v));
    auto const nt = sum(strands, len);
    auto mods = benchmark_models(Ensemble::stacking, nt);

    for (auto lmax : range(1, uint(10000 / len(strands[0])))) { // don't try memory that's too large
        if (logger) logger->info("starting contour n={} s={} l={} t={}", len(strands), len(strands[0]), lmax, time);

        auto cache = thermo::Cache<3, Stacking, real32, real64, overflow<real32>>(bytes);

        auto p = call_with_timeout(chrono::duration<real>(time), [&]{
            // check not too many necklaces
            auto number = compute_necklaces(small_vec<uint>(lmax), len(strands), [](Ignore) {throw_if_signal();});
            std::size_t n = 0;
            if (number > 1e8) return std::make_tuple(n, 0.0, 0.0, uint());
            Col<real> x0, logq;
            vec<small_vec<uint>> indices;

            auto t = time_it(1, [&] {
                auto pfs = permutations<3, 0, 0, 1>(Local(), lmax, strands, std::tie(mods.first, mods.second, mods.first), cache);
                n = len(pfs);
                throw_if_signal();

                x0 = logq = Col<real>(n);
                indices.resize(n);

                izip(pfs, [&](auto i, auto const &p) {
                    x0(i) = len(p.first) == 1 ? 1e-8 / water_conc : 0;
                    logq(i) = p.second; // log pfunc
                    for (auto const &s : p.first.views())
                        indices[i].emplace_back(binary_search_index(strands, s));
                });
            });

            throw_if_signal();

            uint iters = 0;
            auto eq = time_it(1, [&] {
                concentration::Options ops;
                ops.orthogonalize = false;
                iters = solve_complexes(indices, std::move(logq), std::move(x0), ops).iters;
            });
            return std::make_tuple(n, t, eq, iters);
        });

        if (p) {
            if (logger) logger->info("finished contour ({}, {}, {})", std::get<0>(*p), std::get<1>(*p), std::get<2>(*p));
            out.emplace_back(*p);
        } else {
            if (logger) logger->info("could not finish contour");
            break;
        }
    }
    return out;
}

/******************************************************************************/

}
