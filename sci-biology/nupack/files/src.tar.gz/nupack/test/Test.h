#pragma once
#include <lilwil/Test.h>
#include <nupack/algorithms/Traits.h>
#include <nupack/reflect/Print.h>
#include <nupack/common/Random.h>
#include <vector>

/******************************************************************************************/

/// Compile-time assert that also registers as a runtime success
#define REQUIRE_C(n, ...) static_assert((__VA_ARGS__), n);
/// For unit tests that can be run silently
#define UNIT_TEST(name) LILWIL_UNIT_TEST("test/" name)
/// For tests of execution time
#define TIME_TEST(name) LILWIL_UNIT_TEST("time/" name)
/// For tests which print stuff and are used interactively
#define PROTOTYPE(name) LILWIL_UNIT_TEST("proto/" name)
#define HERE LILWIL_HERE

#include <lilwil/Macros.h>

namespace lilwil {

template <class T>
struct ToString<T, void> {
    std::string operator()(T const &t) const {
        std::ostringstream os;
        ::nupack::dump_os(os, t);
        return os.str();
    }
};

}

namespace nupack {

/******************************************************************************************/

using Context = lilwil::Context;

/// Maximum test time (used as a guide, not a hard limit)
double max_test_time();

/// Whether to print stuff in UNIT_TESTs
int test_output();

/// Take only a subset of a vector of test inputs depending on estimated time
bool overtime(Context const &ct);

template <class T, class F, NUPACK_IF(!is_integral<T>)>
void repeat_test(Context const &ct, T const &data, F &&f) {
    auto const v = shuffled_view(data);
    for (auto it: v) {
        if (overtime(ct)) return;
        f(*it);
    }
}

template <class F>
void repeat_test(Context const &ct, std::size_t n, F &&f) {
    for (std::size_t i = 0; i != n; ++i) {
        if (overtime(ct)) return;
        f(i);
    }
}

/******************************************************************************************/

}
