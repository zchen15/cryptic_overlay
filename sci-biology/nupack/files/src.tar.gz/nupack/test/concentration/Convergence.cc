#include "../Test.h"
#include <nupack/types/Matrix.h>
#include <nupack/concentration/Equilibrate.h>
#include <nupack/types/Database.h>
#include <nupack/common/Constants.h>
#include <spdlog/spdlog.h>
#include <spdlog/sinks/basic_file_sink.h>

namespace nupack {


void test_convergence(Context &ct, string fn) {
    if (!spdlog::get("concentration")) (void) spdlog::basic_logger_mt("concentration", "log.txt");
    for (auto init : {concentration::Init::uniform, concentration::Init::given, concentration::Init::absls, concentration::Init::nnls}) {
        usize n = 0;
        JsonDatabase<std::map<string, ConcentrationDatum>> database(fn);
        auto t = time_it([&] {repeat_test(ct, database, [&](auto const &p) {
            auto const &info = p.second;
            auto A = info.matrix_A();
            real_col const logq = -real_col(info.g), ref_x = info.x;
            real_col const x0 = real_col(info.x0) / water_molarity(DefaultTemperature);
            concentration::Options ops;
            ops.tolerance = 1e-7;
            ops.init = init;
            ops.orthogonalize = true;
            auto const x = concentration::equilibrate(A, x0, logq, ops);
            n += x.iters;

            ct.info("iters", x.iters);
            ct.info("init", static_cast<uint>(init));
            ct.info("calculated complex concentrations", la::eval(x.solution * water_molarity(DefaultTemperature)));
            ct.info("final strand concentrations", la::eval(A.t() * x.solution));
            ct.info("initial strand concentrations", la::eval(A.t() * x0));
            ct.info("difference", la::eval(A.t() * x0 - A.t() * x.solution));
            ct.info("sequence", p.first);

            real_col residual = la::eval(arma::abs(x.solution * water_molarity(DefaultTemperature) - ref_x));
            ct("maximum relative residual between JSON and calculated", arma::max(residual / (x.solution * water_molarity(DefaultTemperature))));
            // ct(HERE).require(all(arma::abs(arma::log(x.solution * water_molarity(DefaultTemperature) / ref_x)) < 1e-4));

            ct(HERE).require(x.converged);
        });});
        ct(HERE).timing(t);
    }
}

UNIT_TEST("concentration/rna95-basic") = [](Context ct) {test_convergence(ct, "concentrations-rna95-basic.json");}; // 0.5s
UNIT_TEST("concentration/dna98-basic") = [](Context ct) {test_convergence(ct, "concentrations-dna98-basic.json");}; // 0.5s
UNIT_TEST("concentration/individual") = [](Context ct) {test_convergence(ct, "concentrations-individual.json");}; // 0.5s

UNIT_TEST("concentration/edge-case") = [](Context ct) {
    repeat_test(ct, range(10000), [&](auto i) {
        real_col const logq = {i ? 100 * random_float() : 27.68400525418342894568013434763998};
        real_col const x0 = {i ? std::exp(-25 * random_float()) : 0.01813618732601903968393308730356};
        real_mat const A = {{1, 1}};
        concentration::Options ops;
        ops.init = concentration::Init::uniform;
        ct.near(x0(0), concentration::equilibrate(A, x0, logq, ops).solution(0));
    });
};

}
