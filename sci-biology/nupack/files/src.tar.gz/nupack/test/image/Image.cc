#include "../Test.h"
#include <nupack/image/Leica.h>

namespace nupack::image {

PROTOTYPE("leica") = [](Context ct) {
    for (auto i : range(10)) {
        auto l = random_laser();
        print(l);
        print(random_detectors(l));
    }
};


}
