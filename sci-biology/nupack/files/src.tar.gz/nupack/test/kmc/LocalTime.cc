#include "../Test.h"
#include <nupack/jump/Jump.h>
#include <nupack/iteration/Range.h>
#include <nupack/standard/Deque.h>
#include <nupack/kmc/Pairing.h>
#include <nupack/kmc/Timer.h>
#include <nupack/kmc/LocalTime.h>
#include <nupack/kmc/Run.h>
#include <nupack/markov/RandomWalk.h>

namespace nupack::kmc {

PROTOTYPE("kmc/local-time") = [](Context ct) {
    auto w = jump_state("AAAACCCTTTT", {}, moves::full);

    kmc::HammingObserver obs({w.pairs}, {0}, 4, 0);
    kmc::CovarianceIntegrator<kmc::HammingObserver> cov(obs, 1e6, 0);

    std::mt19937 rng;
    auto run = runner(AlwaysTrue(), rng);
    deque<real_col> data;
    deque<real> times;

    run(w, Timer::with_max_time(1e-5), cov, [&](auto const &w, auto dt) {
        data.emplace_back(obs(w, dt));
        times.emplace_back(dt);
    });

    real_mat result(len(data[0])+1, len(data));
    result.fill(5555);
    izip(data, times, [&](auto i, auto const &c, auto t) {
        result(span(1, len(c)+1), i) = c;
        result(0, i) = t;
    });
    print(result);
    result = result.t();
    result.save("data.txt", arma::raw_ascii);

    print(cov);
};

PROTOTYPE("walk/local-time") = [](Context ct, uint n) {
    auto [R, pi] = markov::random_stochastic<real>(n);
    markov::RandomWalker<real> walker{R};
    auto dist = discrete_distribution(pi);
    kmc::KilledIntegrator cov(0.01);
    Col<real> basis(len(pi), la::fill::zeros);

    uint const start = dist(StaticRNG);
    walker(start, 1.0, [&](auto i, auto j, auto dt) {
        basis(i) = 1;
        cov(basis, dt);
        basis(i) = 0;
        return false;
    });

    print(cov.average_gamma());
    print(cov.average_gradient());
};

}
