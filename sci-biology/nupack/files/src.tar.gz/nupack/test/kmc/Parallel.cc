#include "../Test.h"
#include <nupack/types/Database.h>
#include <nupack/execution/Local.h>
#include <nupack/jump/Jump.h>
#include <nupack/model/Model.h>
#include <nupack/kmc/Run.h>
#include <nupack/kmc/Basics.h>
#include <nupack/kmc/Timer.h>

#ifdef NUPACK_MPI
#include <boost/mpi/communicator.hpp>
#endif

namespace nupack { namespace kmc {

/******************************************************************************************/

double TEMP = 37.0 + ZeroCinK;
double BETA = 1.0 / (TEMP * Kb);

/******************************************************************************************/

UNIT_TEST("kmc/parallel") = [](Context ct) {
    auto const c = EnergyDatabase("mfe-rna95-none-ms.json")[3];
    auto const w0 = jump_state(c.first, c.second.structure, moves::full, Model(Ensemble::min, {}, {}, {}, WobblePairing::off));

    for (auto n : range(1, 5)) {
        Local ex(n);
        print(n, time_it(1, [&] {
            auto steps1 = ex.map_reduce(24, 1, [&](auto const &...) {
                auto w = w0;
                for (auto i : range(10000)) w.step();
                // auto t = Timer::with_max_step(100);
                // runner()(w, t);
                return w.timestep();
                // return t.step;
            });
        }));
    }
};

/******************************************************************************************/

#ifdef NUPACK_MPI
// PROTOTYPE("mpi") = [](Context ct) {
//     DistributedExec ex;
//     auto km = Model(Ensemble::min, WobblePairing::off);
//     auto c = test::mfe_cases2[5];
//     jump_state w0(c.strands, c.dp, km);
//
//     auto n = std::max<int>(1, default_thread_number() / 2);
//
//     auto result = ex.map_reduce(world, n, [&] (...) {
//         auto w = w0;
//         auto t = Timer::with_max_step(10000);
//         runner()(w, t);
//         return t.step;
//     });
//
//     print_mpi(ex.rank(), result);
// }
#endif

/******************************************************************************************/
/*
PROTOTYPE("free_energy") = [](Context ct) {
    auto km = Model(Ensemble::min, WobblePairing::off);
    auto c = mfe_cases[5];
    auto y = System(c.strands);
    auto w = jump_state(y, c.dp, km);
    FE_Calc fe(w, BETA);
    AverageEnergyIntegrator ae(w);
    auto Timer = Timer(0, 1.0e-3);
    auto n = std::max<int>(1, default_thread_number() / 2);

    auto runner = until_all(fe, ae, Timer);

    runner = shared_gather(n, [r=runner, w=w0, &km](usize){return run_until(w, km, r);});

    run_until_reduce(w, km, n, std::tie(Timer, fe, ae));
    print(len(fe.counter));
    print(Timer.steps);
    print(fe.result());
}
*/
/******************************************************************************************/

}}
