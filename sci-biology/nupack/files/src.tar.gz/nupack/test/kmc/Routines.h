#pragma once
#include <nupack/jump/Jump.h>
#include <nupack/model/Model.h>
#include "../Test.h"

namespace nupack {

void check_complexes(Context &, JumpState<> const &w);
void check_update(Context &, JumpState<> const &w);
void check_del(Context &, JumpState<> w, iseq io);
void check_dels(Context &, JumpState<> w);
void check_add(Context &, JumpState<> w, iseq io, BasePairAddition mv);
void check_adds(Context &, JumpState<> w);
void check_del_chain(Context &, JumpState<> w);
void check_add_chain(Context &, JumpState<> w);
void check_steps(Context &, JumpState<> w, iseq n=1000);

}
