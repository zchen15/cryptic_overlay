#include "../Test.h"
#include <nupack/jump/Jump.h>

namespace nupack {

UNIT_TEST("state/init") = [](Context ct) {
    ct.section("1", [](Context ct) {
        auto w = jump_state({"GG", "CC"}, "..+..");
        //ct.info(w);
        ct.equal(len(w.complexes), 2);
    });
    ct.section("2", [](Context ct) {
        auto w = jump_state({"G", "C"}, ".+.");
        //ct.info(w);
        ct.equal(len(w.complexes), 2);
    });
    ct.section("3", [](Context ct) {
        auto w = jump_state({"CCGG"}, "....");
        //ct.info(w);
        ct.equal(len(w.complexes), 1);
    });
    ct.section("4", [](Context ct) {
        auto w = jump_state({"GGGGC"}, "(...)");
        //ct.info(w);
        ct.equal(len(w.complexes), 1);
    });
    ct.section("5", [](Context ct) {
        auto w = jump_state({"C", "G"}, "(+)");
        //ct.info(w);
        NUPACK_ASSERT(w.complexes.check());
        ct.equal(len(w.complexes), 1);
    });
    ct.section("6", [](Context ct) {
        auto y = System({"UGUUCACCCGACCAGCCCCUUGGGCUUGGUAGGGUUUUCUUGGUUACUCCCAAGCCUCGUUCUGAAGUUAUCCGUCACACACUAGAAGCCCAUCGCCCACACGCUAAGCCGCCUGAAGCGAAUUCCUCUCAAGGUCCGACACCAUUAGCGCCGCAUCUAGUGUCCCCCACCGAAAACACCGAAGCUUGUUUAAAUGUAUUCCUAGAUCCUUAACCCACUGUUAUAUCGCUCCCCGGGACAGCAAAGGGAUGGCACCCGCAGGCCACUGUGAUGGUCUCCAACCACGUACCGCCGCAAUGAUACGUCAGGCGCGGAGGGGGCCUGAUAAGGUUCCAUCCCUGAACGUGUCCCGGAACAUAACCUAGCACCCUACGAACCGAAAUUAGCCUCAACCGCAGGCUAAAUGCGCACUCGGCGGUUUGCCUAGUGUCGCAAACCAGUUCGUGUGCUGGUGGAGCGAUGCGCAUCUCAAGUCGCUACGACUUCAACUUUUUUUAUGAAUGCGCACUAUUGAGUAGGCUACCGCCAGCAUUGUGCUGAAGGUGGGGCGGAAUCCUCAGAUCUUCAACUGCACUCACGAUCUAUAGGCCCGCCCGCCGAACGGAUCCCGGUACCGGGCAAACCCUUCGCUUAAACCAUAGUAAGGUAACAGCGUUUCUAGCAGGGAUCGAGCCCAUCUAUUUAUAACACGCUCCUUAACGAAGAACAGCACUGCGUUCAGGACAGGCGGGUACACGCGUAACUCGAUCUUUUCACGUGAAACACUGAUAGCUCCCGAUGUAGCCCCUCUAGAUUCCCCCUCGACCAUCGGCCCUCGAGUGAGCGUGAGCGUGGCAACACCUUUUGGACUUCCGGUCGUGCGGAACAGCUCACGUGACUACUCUGGACGGAGCUAAUUCCUUUAGGUGCUAGCGACGCACGAAGGGCACGAUCCCUAGCAGCCAGUGUACGUACGGUAACACGAGGCAUUCACCCAACUCGGACGUACGACACCGGCUAA"});
        auto w = jump_state(y, ".....((((.((((((((...)))).)))).))))..(((.((.(((...(((((.(((.......(((.((.((...((((((((.((...((((...((.((......)).))..))))....(.((.(.(((.....))).).)).)..)).)))))))).....)).)).)))..))).))))).......)))..)).)))....((((.....))))..(((((((((((((((....((((((((.(((..((((((.(((((.(((...)))..)))...((((.((..(((....))).))))))))..))))))....))).)))))))).....))))))))......(((.(((((...((((((.(...(((((((.......))))))).((((((((.(((.....))).)))).))))...).)))))))))))))))))))))(((((((.((((((((...))))).............))))))))))..........(((.(((..(((((...)))))..))).((((((...(((.(((((...............)))))..))).)))))))))...(((...))).....(((....)))..((((...(((.......)))...))))......((((((((((.((((.((((....))((.(((((((.((((.((.......)).)))).))))...))).)).(((((...((((((.((..(((.(((...)))))).))...((((((.........................))))))...))))))..))))).((((.((..(((((...(((.(((((......))))).(((((.(((...........))))))))...)))...)))))...)).))))..)).)))).)))))))).)).(((.((((.((((((......((((............))))..)))))))))).)))...");
        ct.equal(len(w.complexes), 1);
    });
};

}
