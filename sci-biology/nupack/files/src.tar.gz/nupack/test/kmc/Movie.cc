#include <nupack/jump/Jump.h>
#include <nupack/model/Model.h>
#include <nupack/iteration/Transform.h>
#include <nupack/kmc/Run.h>
#include <nupack/kmc/Basics.h>
#include <nupack/kmc/Timer.h>

#include "../Test.h"
#include <nupack/types/Database.h>

namespace nupack { namespace kmc {

/******************************************************************************************/

PROTOTYPE("movie") = [](Context ct) {
    auto c = EnergyDatabase("mfe-rna95-none-ms.json")[3];
    auto w = jump_state(c.first, c.second.structure);
    print(w.dp());
    MovieMaker log("log.txt");
    auto Timer = Timer::with_max_time(0.01);
    runner()(w, Timer, log);
    //print(Timer.next());
};

/******************************************************************************************/

PROTOTYPE("vector_observer") = [](Context ct) {
    auto km = Model(Ensemble::none);
    for (auto i : range(100)) {
        auto tim = Timer();
        auto a = jump_state("CGGCGGCGCGGCGGCGAAACGCCGCCG", "((((((((...........))))))))", moves::full, km);
        auto b =  a.with_structure("........((((((((...))))))))");
        runner()(a, [&](auto const &w, auto t) {return w == b;}, tim);
        print(tim);
    }

    for (auto i : range(100)) {
        auto tim = Timer();
        auto a = jump_state("CGGCGGCGCGGCGGCGAAACGCCGCCG", "((((((((...........))))))))", moves::full, km);
        auto b =  a.with_structure("........((((((((...))))))))");
        runner()(b, [&](auto const &w, auto t) {return w == a;}, tim);
        print(tim);
    }
};

/******************************************************************************************/

PROTOTYPE("movie/hcr") = [](Context ct) {
    auto w = jump_state({"TTAACCCACGCCGAATCCTAGACTCAAAGTAGTCTAGGATTCGGCGTG+AGTCTAGGATTCGGCGTGGGTTAA"},
                         "......((((((((((((((((((......))))))))))))))))))+........................");
    runner()(w, Timer::with_max_step(40000), MovieMaker("hcr.txt", 10));
};

/******************************************************************************************/

PROTOTYPE("movie2") = [](Context ct) {
    auto c = EnergyDatabase("mfe-rna95-none-ms.json")[5];
    auto w = jump_state(c.first, c.second.structure, moves::lazy);
    runner()(w, Timer::with_max_time(1.0e-4), MovieMaker("log.txt", 10));
};

/******************************************************************************************/

PROTOTYPE("move/hcr_bigger") = [](Context ct) {
    auto y = System({"CTTTTTTCAATCTACTTTTCATCTGGTTCTCTTA", "CTTTTTTCAATCTACTTTTCATCTGGTTCTCTTAAGATGAAAAGTAGATTGAAAAAAGGGGTAGTTGT", "TAAGAGAACCAGATGAAAAGTAGATTGAAAAAAGACAACTACCCCTTTTTTCAATCTACTTTTCATCT", "CCGAAACAAAAACAAAGCCTAAACAACCCTCACC", "CCGAAACAAAAACAAAGCCTAAACAACCCTCACCGTTTAGGCTTTGTTTTTGTTTCGGGTCCACTTTT", "GGTGAGGGTTGTTTAGGCTTTGTTTTTGTTTCGGAAAAGTGGACCCGAAACAAAAACAAAGCCTAAAC", "TCCCACTCCTTCCACCTCCTATTCCCACCTCCAC", "TCCCACTCCTTCCACCTCCTATTCCCACCTCCACGAATAGGAGGTGGAAGGAGTGGGATAGACGTGAC", "GTGGAGGTGGGAATAGGAGGTGGAAGGAGTGGGAGTCACGTCTATCCCACTCCTTCCACCTCCTATTC", "CTCTCCCCTACTTCCCCCCCCATATCTCCCTTTT", "CTCTCCCCTACTTCCCCCCCCATATCTCCCTTTTTATGGGGGGGGAAGTAGGGGAGAGAGGCGTTATC", "AAAAGGGAGATATGGGGGGGGAAGTAGGGGAGAGGATAACGCCTCTCTCCCCTACTTCCCCCCCCATA", "CGATTTTGCACAGTGACGAAGAAAGCCAGCCCAT", "CGATTTTGCACAGTGACGAAGAAAGCCAGCCCATTTTCTTCGTCACTGTGCAAAATCGGCTCTCCTCA", "ATGGGCTGGCTTTCTTCGTCACTGTGCAAAATCGTGAGGAGAGCCGATTTTGCACAGTGACGAAGAAA"});
    auto w = jump_state(y, {});
    MovieMaker mm("hcr.txt", 10000);
    auto Timer = Timer::with_max_step(10000);
    runner()(w, Timer, mm);
    print(Timer.next());
};

/******************************************************************************************/

}}
