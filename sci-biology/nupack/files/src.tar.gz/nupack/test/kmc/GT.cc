#include <nupack/types/Database.h>
#include "Routines.h"
#include "../Test.h"

namespace nupack {

/******************************************************************************************/

void test_energy(Context &ct, string fn, WobblePairing gt, string material) {
    EnergyDatabase const ref(fn);
    auto const mod = Model(Ensemble::none, material, {}, {}, gt);

    for (auto const &p : ref.data) {
        // print("---------------");
        // print(p.first, p.second.structure);
        // print(PairList(p.second.structure));
        // print(to_sequences(p.first));
        auto energy = structure_energy(p.first, p.second.structure, mod);
        ct.info(p.first);
        ct.within(energy, p.second.energy, 1e-3);
    }
}

void test_energy_params(Context &ct, string fn) {
    repeat_test(ct, JsonDatabase<std::map<string, EnergyDatum<true>>>(fn), [&](auto &&p) {
        auto const & data = p.second;
        string material = "RNA";
        if (data.material == "dna1998") material = "DNA";
        auto const mod = Model(Ensemble::none, material, ModelConditions{data.T + ZeroCinK, data.sodium, data.magnesium}, {}, WobblePairing::on);
        auto energy = structure_energy(p.first, data.structure, mod);
        ct.info(p.first);
        ct.info(data.structure);
        ct.info(data.material);
        ct.info(data.T);
        ct.info(data.sodium);
        ct.info(data.magnesium);
        ct.within(energy, data.energy, 1e-3);
    });
}

UNIT_TEST("energy/rna95-none-ss") = [](Context ct) {test_energy(ct, "mfe-rna95-none-ss.json",       WobblePairing::off, "RNA");};
UNIT_TEST("energy/rna95-none-ms") = [](Context ct) {test_energy(ct, "mfe-rna95-none-ms.json",       WobblePairing::off, "RNA");};
UNIT_TEST("energy/rna95-none-gu-ss") = [](Context ct) {test_energy(ct, "mfe-rna95-none-gu-ss.json", WobblePairing::on,  "RNA");};
UNIT_TEST("energy/rna95-none-gu-ms") = [](Context ct) {test_energy(ct, "mfe-rna95-none-gu-ms.json", WobblePairing::on,  "RNA");};
UNIT_TEST("energy/dna98-none-ss") = [](Context ct) {test_energy(ct, "mfe-dna98-none-gt-ss.json",    WobblePairing::on,  "DNA");};
UNIT_TEST("energy/dna98-none-ms") = [](Context ct) {test_energy(ct, "mfe-dna98-none-gt-ms.json",    WobblePairing::on,  "DNA");};
UNIT_TEST("energy/random-temp-ss") = [](Context ct) {test_energy_params(ct, "mfe-random-temp-ss.json");};

/******************************************************************************************/

UNIT_TEST("energy/gt") = [](Context ct) {
    auto const mod = Model(Ensemble::min, {}, {}, {}, WobblePairing::on);
    auto w = jump_state({"GUCGCGUCGCGUCGCUAUGCGAC"}, "(((((((.((...)).)))))))", moves::lazy, mod);
    ct.near(w.energy, -10.5);

    w = jump_state({"AGCATGCATGCTAGCTACTCGTGCATAGTCGATTCGAT"}, "...(((((((.........)))))))..(((...))).", moves::lazy, mod);
    ct.near(w.energy, -7.4);

    w = jump_state({"AGCAUGCAUGCUAGCUACUCGUGCAUAGCGUAGCUGAUGCUAGCUAGCUAGCUGACUGAUCGUACUGAUGCUACAGCUGUCGAUUCGAU"}, "(((..((..((((((....(((.....)))........))))))..))..))).....((((.(.((((((....)).)))).).))))", moves::lazy, mod);
    ct.near(w.energy, -23.5);

    w = jump_state({"GCUAGUCGAUCGUAGCUAGCUGAUCCGAUCGUGAUCGUCUCUUGAGGAGCGCGACUAUCACUGCGCGAUGCUAUGCUGUACGGCUCAGUGUCGUGUGUGCUGAUAUUUGUCGCUCGAUGCUGUGAUGCUGGGGGGUUUUUUCGUUAUCUUACUUUCUUAUUUUUCGAUCGGGGGCUAUCUUAUAUCUACGGCGCGCGUCGUACGUGCAU"}, "((((((.(....).)))))).(((((....).))))..........((((((((.(((((.(((((((((((..(((....)))..)))))))))))...))))).))).)))))...(((((((((..(((.((((((((((..(...((......))..)..)))..))))))).)))..)))).)))))((((((...))))))..", moves::lazy, mod);
    ct.near(w.energy, -62.8);

    w = jump_state({"GGGGT"}, "(...)", moves::lazy, mod);
    ct.near(w.energy, real(*inf));

    auto const mod2 = Model(Ensemble::none, {}, {}, {}, WobblePairing::on);
    auto w2 = jump_state({"UGUACCCUAUGCGUGCU"}, ".((((.......)))).", moves::lazy, mod2); // fix this!
    ct.near(w2.energy, -1.1);

    auto const mod3 = Model(Ensemble::min, ParameterFile("DNA"), {}, {}, WobblePairing::on);
    auto w3 = jump_state({"A", "T"}, "(+)", moves::lazy, mod3);
    ct.near(w3.energy, -0.411351419);
};

/******************************************************************************************/

}
