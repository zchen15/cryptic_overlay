#include "../Test.h"
#include <nupack/types/Database.h>
#include <nupack/jump/Jump.h>
#include <nupack/kmc/Timer.h>
#include <nupack/kmc/Stopwatch.h>
#include <nupack/kmc/Run.h>
#include <nupack/model/Model.h>

namespace nupack { namespace kmc {

template <class State, class Case, class KM=typename State::model_type>
void test_time(Case c, real t, MoveMethod gen, KM const &km={}) {
    auto timer = Timer::with_max_time(t);
    auto watch = Stopwatch(20);
    //auto log = [=](auto const &w, ...) -> int {NUPACK_REQUIRE(w.energy, >=, c.energy - 0.0001); return Satisfied;};
    auto w = State(c.first, c.second.structure, gen, km);
    runner()(w, timer, watch);

    print(c.second.structure.size(), watch.seconds(), watch.seconds() / timer.step, timer.step);
}

using Fast_Iso_State = JumpState<JumpLoop<>, Model<real>>;
using Slow_Iso_State = JumpState<JumpLoop<>, Model<real>>;

TIME_TEST("ss.step") = [](Context ct) {
    print("fix these timings for Iso");
    auto km = Model(Ensemble::none);
    for (auto c : EnergyDatabase("mfe-rna95-none-ss.json"))  test_time<Slow_Iso_State>(c, 1.0e-2, moves::lazy, km);
    for (auto c : EnergyDatabase("mfe-rna95-none-ss.json"))  test_time<Fast_Iso_State>(c, 1.0e-2, moves::full, km);

    for (auto c : EnergyDatabase("mfe-rna95-none-ms.json")) test_time<JumpState<>>(c, 1.0e-2, moves::lazy, km);
    for (auto c : EnergyDatabase("mfe-rna95-none-ms.json"))  test_time<JumpState<>>(c, 1.0e-2, moves::full, km);
};

}}
