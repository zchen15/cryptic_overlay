#include "Routines.h"
#include "../Test.h"

/******************************************************************************************/

namespace nupack {

void check_complexes(Context &ct, JumpState<> const &w) {
    auto w2 = jump_state(w.sys, w.pairs, moves::full, w.model);
    ct(HERE).equal(len(w2.complexes), len(w.complexes));

    std::set<vec<iseq>> x1, x2;
    for (auto x : w.complexes.complex_indices) {
        std::rotate(begin_of(x), std::min_element(begin_of(x), end_of(x)), end_of(x));
        x1.emplace(x);
    }
    for (auto x : w2.complexes.complex_indices) {
        std::rotate(begin_of(x), std::min_element(begin_of(x), end_of(x)), end_of(x));
        x2.emplace(x);
    }
    ct(HERE).equal(x1, x2);
}

/******************************************************************************************/

void check_update(Context &ct, JumpState<> const &w) {
    auto u = w;

    u.update_rates();

    ct.near(u.energy, w.energy);

    for (auto i : indices(w)) {
        //ct.info(u[i]);
        //ct.info(w[i]);
        ct.require(w[i].edges.check());
        ct.require(u[i].edges.check());
        ct.near(w[i].del_move.dE, u[i].del_move.dE);
        ct.near(w[i].del_move.rate, w.del_rates[i]);
        ct.near(u[i].del_move.rate, u.del_rates[i]);
        ct.near(w[i].del_move.rate, u[i].del_move.rate);
        ct.near(w.add_rates[i], u.add_rates[i]);
        ct.near(w.del_rates[i], u.del_rates[i]);
    }
}

/******************************************************************************************/

void check_del(Context &ct, JumpState<> w, iseq io) {
    //ct.info(w);
    auto &o = w[io];
    //ct.info("Child: " << o);
    //ct.info("Parent: " << w[o.edges.parent]);
    //ct.info("Old structure: " << w.dp());
    auto old_energy = w.energy;
    auto old_move = o.del_move;
    //ct.info("Old energy: " << old_energy);
    o.try_merge(w, w.model, AlwaysTrue());

    //ct.info("New structure: " << w.dp());
    //ct.info("New energy: " << w.energy);
    ct(HERE).near((w.energy - old_energy), old_move.dE);

    check_update(ct, w);
}

/******************************************************************************************/

void check_dels(Context &ct, JumpState<> w) {
    for (auto io : indices(w))
        if (!w[io].edges.is_root()) check_del(ct, w, io);
}

/******************************************************************************************/

void check_add(Context &ct, JumpState<> w, iseq io, BasePairAddition mv) {
    //ct.info("Sequence : " << w.sequence());
    //ct.info("Old structure: " << w.dp());
    auto old_energy = w.energy;
    //ct.info("Old energy: " << old_energy);
    w.emplace(); w[io].split(w, w.loops.back(), mv, w.model);
    //ct.info(w.loops.back());
    //ct.info("New structure: " << w.dp());
    //ct.info("New energy: " << w.energy);
    ct.near(w.energy - old_energy, mv.dE);

    check_update(ct, w);
}

/******************************************************************************************/

void check_adds(Context &ct, JumpState<> w) {
    for (auto const &o : w.loops)
        for (auto mv : o.seqs.add_moves()) check_add(ct, w, o.index(), mv);
}

/******************************************************************************************/

void check_del_chain(Context &ct, JumpState<> w) {

    while (len(w) != len(w.complexes)) {
        auto io = floor(random_float() * len(w.loops));
        auto &o = w.loops[io];
        if (o.edges.is_root()) continue;

        //print("Child: ", o);
        //print("Parent: ", w[o.edges.parent]);

        auto old_energy = w.energy, dE = o.del_move.dE;

        //print("Old structure: ", w.dp());
        //print("Old energy: ", old_energy);

        o.try_merge(w, w.model, AlwaysTrue());
        //print(w.dp());
        ct.near((w.energy - old_energy), dE);

        check_update(ct, w);
    }
}

/******************************************************************************************/

void check_add_chain(Context &ct, JumpState<> w) {
    //ct.info(w);

    while (w.n_add_moves()) {
        auto io = floor(random_float() * len(w.loops));
        if (!w[io].n_add_moves()) continue;

        w.emplace();

        //BEEP("Adding pair in ", w[io]);
        //BEEP("parent", w[w[io].parent()]);

        auto mv = floor(random_float() * w[io].n_add_moves());

        auto old_energy = w.energy, dE = w[io].seqs.add_moves()[mv].dE;
        //BEEP("Old structure: ", w.dp());
        //BEEP("Old energy: ", old_energy);

        w[io].split(w, w.loops.back(), w[io].seqs.add_moves()[mv], w.model);

        //BEEP("Added pair in ", w.loops[io]);
        //BEEP("New structure: ", w.dp());
        //BEEP(w.dp());
        //BEEP("New energy: ", w.energy);
        //BEEP("dE: ", dE);

        ct.near((w.energy - old_energy), dE);

        check_update(ct, w);
    }
}

/******************************************************************************************/

void check_steps(Context &ct, JumpState<> w, iseq n) {
    for (auto t : range(n)) {
        // Check that loop rates add up to system rates
        for (auto o : indices(w)) {
            ct.near(w[o].seqs.total_add_rate(), w.add_rates[o]);
            ct.near(w[o].del_move.rate, w.del_rates[o]);
        }

        for (auto const &o : w.loops) if (o.seqs.exterior())
            ct(HERE).equal(w.complexes.strand_map[o.strand_index(w)].loop, o.index());

        for (auto i : indices(w)) ct(HERE).equal(w[i].index(), i);
        //ct.info(w.dp());

        check_complexes(ct, w);

        for (auto i : indices(w.loops)) {
            ct(HERE).equal(w[i].index(), i);
            ct(HERE).equal(len(w[i].edges), len(w[i].seqs.vec()));
            if (w[i].seqs.exterior()) ct.require(contains(w[i].edges, Ether));
            for (auto e : w[i].edges) if (e != Ether) ct.require(contains(w[e].edges, i));
        }

        for (auto const &o : w.loops) if (o.seqs.exterior()) {
            auto s = o.strand_index(w);
            auto loc = w.complexes.strand_map[s];
            //if (o.edges.is_root()) ct.require(loc.pos, 0);
            ct(HERE).equal(loc.loop, o.index());
            ct(HERE).equal(w.complexes.complex_indices[loc.x][loc.pos], s);
        }

        for (auto i : indices(*w.sys)) if (w.sys->total_sequence[i] == Base('_'))
            ct(HERE).equal(w.pairs[i], i);

        w.step();
    }
}

/******************************************************************************************/

}
