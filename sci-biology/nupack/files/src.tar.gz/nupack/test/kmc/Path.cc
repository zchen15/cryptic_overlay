#include <nupack/jump/Path.h>
#include <nupack/kmc/Timer.h>
#include <nupack/types/Heap.h>
#include "../Test.h"

namespace nupack::kmc {

PROTOTYPE("kmc/generate-path") = [](Context ct, real time) {
    State w(to_sequences("ACGCGATGCAACGCGATGCAACGCGATGCAACGCGATGCAACGCGATGCAACGCGATGCAACGCGATGCAACGCGATGCAACGCGATGCAACGCGATGCA"), PairList());
    auto const p = sample_path(w, model(), Timer::with_max_time(time));
    static_assert(sizeof(Step) == 16);
    print(len(p.steps) * 8 / 1.0e9, "GB");
};


PROTOTYPE("kmc/base-pairs") = [](Context ct, real time) {
    State w(to_sequences("AAAAT"), PairList());
    auto const p = sample_path(w, model(), Timer::with_max_time(time));
    auto const P = base_pair_time(p, 0, true);
    print(P);
    print(la::accu(P));
};

template <class T>
T binary_variance(T t) {
    t.transform([](auto &&x) {return x * (1 - x);});
    return std::move(t);
}

Mat<real> pair_probability(NickSequence const &, Model<> const &);

NUPACK_BINARY_FUNCTOR(first_less, (std::get<0>(t) < std::get<1>(u)));

PROTOTYPE("kmc/variable-pairs") = [](Context ct) {
    State w(to_sequences("ACGCGATGCAACGCGATGCAACGCGATGCAACGCGATGCAACGCGATGCAACGCGATGCAACGCGATGCAACGCGATGCAACGCGATGCAACGCGATGCA"), PairList());
    auto P = pair_probability(w.sys->strands);
    print(binary_variance(P));

    MaxSizeHeap<std::tuple<real, uint, uint>, vec, first_less_t> heap(10);
    for (auto j : range(P.n_cols))
        for (auto i : range(j + 1))
            heap.emplace_if(P(i, j), i, j);
    print(std::move(heap).sorted());
};

}
