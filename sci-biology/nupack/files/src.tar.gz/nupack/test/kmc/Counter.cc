#include <nupack/jump/Jump.h>
#include <nupack/model/Model.h>
#include <nupack/execution/Local.h>

#include <nupack/types/IO.h>
#include <nupack/reflect/Memory.h>
#include <nupack/kmc/LocalTime.h>
#include <nupack/kmc/Timer.h>
#include <nupack/kmc/Stopwatch.h>
#include <nupack/kmc/FreeEnergy.h>
#include <nupack/kmc/Populations.h>
#include <nupack/kmc/Run.h>

#include "../Test.h"
#include <nupack/types/Database.h>

namespace nupack { namespace kmc {

/******************************************************************************************/

PROTOTYPE("kmc/run/counters/unique_states") = [](Context ct) {
    auto c = EnergyDatabase("mfe-rna95-none-ss.json")[5];
    auto w = jump_state(c.first, c.second.structure, moves::full, Ensemble::none);
    TimeIntegrator<true> pc;
    auto timer = Timer::with_max_time(0.01);
    runner()(w, timer, pc);
    print(timer.step);
    print(pc.size());
};

/******************************************************************************************/

TIME_TEST("kmc/free-energy") = [](Context ct) {
    auto c = EnergyDatabase("mfe-rna95-none-ss.json")[7];
    auto w = jump_state(c.first, c.second.structure, moves::full, Ensemble::none);
    print(len(w.sequence()), w.sequence());

    auto fe = FreeEnergyIntegrator(1);
    auto sim1 = Timer::with_max_time(0.01);
    auto wall1 = Stopwatch();
    runner()(w, sim1, wall1, fe);
    print(wall1.seconds(), sim1.step);

    //auto sim2 = Timer::with_max_time(0.01);
    //auto wall2 = Stopwatch();
    //runner()(w, sim2, wall2);
    //print(wall2.seconds(), sim2.step);

    auto result = fe.next();
    print(len(result.exps), memory::measure(result) * 1.e-9);
    print(result.get(free_energy()));
    print(len(result.exps));
};

/******************************************************************************************/

PROTOTYPE("kmc/run/counters/unique-seqs") = [](Context ct) {
    Local ex(4);
    for (auto c : EnergyDatabase("mfe-rna95-none-ss.json")) {
        auto w0 = jump_state(c.first, c.second.structure, moves::full, Ensemble::none);

        auto counter_steps = ex.map_reduce(10, 1, [&](auto const &...) {
            auto t = Timer::with_max_time(0.001);
            auto c = sequence_counter();
            auto w = w0;
            runner()(w, t, c);
            return std::make_pair(c, t.step);
        });

        print(counter_steps.second);
        print(len(counter_steps.first));
    }
    //print(1,2);
    //for (auto const &o : lc_ref.counts) print(o.first.sequences(), o.second);
};

/******************************************************************************************/

PROTOTYPE("kmc/run/counters/complex-counter") = [](Context ct) {
    auto w0 = jump_state("GGGACGAGGC+GCCUCGUCCC", "..........+..........", moves::full, Ensemble::none);
    Local ex(4);

    auto steps_counter = ex.map_reduce(40, 1, [&](auto const &...) {
        auto c = ComplexCounter();
        auto t = Timer::with_max_time(1);
        auto w = w0;
        runner()(w, t, c);
        return std::make_pair(t.step, c);
    });
    auto steps = steps_counter.first; auto counter = steps_counter.second;

    ct.info(steps);
    //print_lns(counter.populations);
    //print_lns(counter.transitions);
    //for (auto const &t : counter.transitions)
    //    print(t.first, t.second / counter.populations[t.first.first]);
};

/******************************************************************************************/


}}
