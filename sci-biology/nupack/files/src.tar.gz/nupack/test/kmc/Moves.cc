#include "Routines.h"
#include "../Test.h"
#include <nupack/types/Database.h>

namespace nupack {

template <class T, class U>
auto get_state(T const &t, U const &u) {return jump_state(t, u, moves::full, Model(Ensemble::none, {}, {}, {}, WobblePairing::off));}

/******************************************************************************************/

UNIT_TEST("ss/small/energy") = [](Context ct) {
    repeat_test(ct, EnergyDatabase("mfe-rna95-none-ss.json"), [&](auto &&c) {
        if (len(c.first) > 100) return;
        auto w = get_state(c.first, c.second.structure);
        ct.within(w.energy, c.second.energy, 1e-3);
    });
};

UNIT_TEST("ss/small/del") = [](Context ct) {
    repeat_test(ct, EnergyDatabase("mfe-rna95-none-ss.json"), [&](auto &&c) {
        if (len(c.first) > 100) return;
        check_dels(ct, get_state(c.first, c.second.structure));
    });
};

UNIT_TEST("ss/small/step") = [](Context ct) {
    repeat_test(ct, EnergyDatabase("mfe-rna95-none-ss.json"), [&](auto &&c) {
        if (len(c.first) > 100) return;
        check_steps(ct, get_state(c.first, c.second.structure));
    });
};

UNIT_TEST("ss/small/del/chain") = [](Context ct) {
    repeat_test(ct, EnergyDatabase("mfe-rna95-none-ss.json"), [&](auto &&c) {
        if (len(c.first) > 100) return;
        check_del_chain(ct, get_state(c.first, c.second.structure));
    });
};

UNIT_TEST("ss/small/add") = [](Context ct) {
    repeat_test(ct, EnergyDatabase("mfe-rna95-none-ss.json"), [&](auto &&c) {
        if (len(c.first) > 100) return;
        check_adds(ct, get_state(c.first, c.second.structure));
    });
};

UNIT_TEST("ss/small/add-chain") = [](Context ct) {
    repeat_test(ct, EnergyDatabase("mfe-rna95-none-ss.json"), [&](auto &&c) {
        if (len(c.first) > 100) return;
        check_add_chain(ct, get_state(c.first, c.second.structure));
    });
};

/******************************************************************************************/

UNIT_TEST("ms/small/energy") = [](Context ct) {
    repeat_test(ct, EnergyDatabase("mfe-rna95-none-ms.json"), [&](auto &&c) {
        if (len(c.first) > 100) return;
        auto w = get_state(c.first, c.second.structure);
        ct.within(w.energy, c.second.energy, 1e-3);
    });
};

UNIT_TEST("ms/small/del") = [](Context ct) {
    repeat_test(ct, EnergyDatabase("mfe-rna95-none-ms.json"), [&](auto &&c) {
        if (len(c.first) > 100) return;
        check_dels(ct, get_state(c.first, c.second.structure));
    });
};

UNIT_TEST("ms/small/del-chain") = [](Context ct) {
    repeat_test(ct, EnergyDatabase("mfe-rna95-none-ms.json"), [&](auto &&c) {
        if (len(c.first) > 100) return;
        auto w = get_state(c.first, c.second.structure);
        ct.require(is_sorted(w.complexes.complex_indices), w.complexes);
        check_del_chain(ct, w);
    });
};

UNIT_TEST("ms/small/add") = [](Context ct) {
    repeat_test(ct, EnergyDatabase("mfe-rna95-none-ms.json"), [&](auto &&c) {
        if (len(c.first) > 100) return;
        check_adds(ct, get_state(c.first, c.second.structure));
    });
};

UNIT_TEST("ms/small/add-chain") = [](Context ct) {
    repeat_test(ct, EnergyDatabase("mfe-rna95-none-ms.json"), [&](auto &&c) {
        if (len(c.first) > 100) return;
        check_add_chain(ct, get_state(c.first, c.second.structure));
    });
};

UNIT_TEST("ms/small/flip") = [](Context ct) {
    repeat_test(ct, EnergyDatabase("mfe-rna95-none-ms.json"), [&](auto &&c) {
        if (len(c.first) > 100) return;
        auto w = get_state(c.first, c.second.structure);
        for (auto &o : w.loops) if (o.exterior()) {
            auto old_energy = w.energy;
            //ct.info(w);
            ct.within(w.energy, c.second.energy, 1e-3);
            w.update_rates();
            //ct.info(w);
            ct.within(w.energy, c.second.energy, 1e-3);
            o.flip(w);
            //ct.info(w);
            ct.within(w.energy, c.second.energy, 1e-3);
        }
    });
};

UNIT_TEST("ms/small/step") = [](Context ct) {
    repeat_test(ct, EnergyDatabase("mfe-rna95-none-ms.json"), [&](auto &&c) {
        if (len(c.first) > 100) return;
        check_steps(ct, get_state(c.first, c.second.structure));
    });
};

/******************************************************************************************/

UNIT_TEST("ms/step/join-iteration") = [](Context ct) {
    //auto w = jump_state({"GGGACGAGGC", "GCCUCGUCCC"}, "..........+..........", moves::full, Ensemble::none);
    auto w = get_state("GGGGGGGGGG+CCCCCCCCCC", "..........+..........");
    //print(w.sequence());

    auto r = 0.0;
    auto n = 0;
    for_all_joins(w, [&](auto m) {
        r += m.rate(w.model);
        ++n;
        auto w2 = w;
        w2.associate(m);
        check_update(ct, w2);
        //print(w.energy, w2.energy, w2.complexes);
        //print(w.dp(), w2.dp());
    });
    //print(n, r, w.complexes.join_rate(w.model));
};

}
