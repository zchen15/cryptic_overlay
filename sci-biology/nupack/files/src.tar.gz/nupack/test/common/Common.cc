#include <nupack/algorithms/Partition.h>
#include <nupack/common/Runtime.h>
#include <nupack/common/Random.h>
#include <nupack/math/PDF.h>
#include <nupack/types/IO.h>
#include <nupack/iteration/Range.h>
#include <nupack/standard/Vec.h>
#include <spdlog/logger.h>
#include <nupack/iteration/Spreadsort.h>

#include "../Test.h"

namespace nupack {

template <class V>
void test_container_traits() {
    REQUIRE_C("reserve", has_reserve<V>);
    REQUIRE_C("has_member_swap", has_member_swap<V>);
    REQUIRE_C("has_begin", has_begin<V>);
    REQUIRE_C("has_data", has_data<V>);
    REQUIRE_C("has_end", has_end<V>);
    REQUIRE_C("is_random_access", is_random_access<V>);
    REQUIRE_C("has_size", has_size<V>);
    REQUIRE_C("is_iterable", is_iterable<V>);
};

UNIT_TEST("common/traits") = [](Context ct) {
    test_container_traits<vec<int>>();
    test_container_traits<small_vec<int>>();
    test_container_traits<std::string>();
};

template <class U, class T>
void test_forward(T &&t) {REQUIRE_C("forward", is_same<T &&, U>);}

template <class U, class T>
auto test_const_forward(T const &&t) {REQUIRE_C("forward", is_same<T const &&, U>); return static_cast<T>(t);}

UNIT_TEST("common/forwarding") = [](Context ct) {
    test_forward<int &&>(int());
    {int i; test_forward<int &>(i);}
    {int const i=0; test_forward<int const &>(i);}
    {test_forward<int const &&>(static_cast<int const &&>(int()));}

    test_const_forward<int const &&>(int());
    // {int i; test_const_forward<int &>(i);}
    // {int const i=0; test_const_forward<int const &>(i);}
    {test_const_forward<int const &&>(static_cast<int const &&>(int()));}
};

UNIT_TEST("common/binary_sort") = [](Context ct) {
    auto const u = vmap(range(8), [](auto) -> double {return random_float();});
    auto v = u;
    binary_sort_ms(begin_of(v), end_of(v));
    ct.require(is_sorted(v));
    v = u;
    binary_sort_ms2(begin_of(v), end_of(v));
    ct.require(is_sorted(v));
    v = u;
    binary_sort_ls(begin_of(v), end_of(v));
    ct.require(is_sorted(v));
};

TIME_TEST("common/sort") = [](Context ct) {
    for (auto n : range(28)) {
        auto const m = std::size_t(1) << n;
        auto const u = vmap(range(m), [](auto) -> double {return random_float();});
        auto cast = [](double &f) {return reinterpret_cast<std::uint64_t *>(&f);};
        print(m);
        print("std float  ", time_it(4, [&] {auto v = u; std::sort(begin_of(v), end_of(v));}));
        print("std int    ", time_it(4, [&] {auto v = u; std::sort(cast(v.front()), cast(v.back()));}));
        print("boost float", time_it(4, [&] {auto v = u; spreadsort(v);}));
        print("boost int  ", time_it(4, [&] {auto v = u; spreadsort(view(cast(v.front()), cast(v.back())));}));
        print("binary     ", time_it(4, [&] {auto v = u; binary_sort_ms(begin_of(v), end_of(v));}));
        print("binary2    ", time_it(4, [&] {auto v = u; binary_sort_ms2(begin_of(v), end_of(v));}));
        print("binary3    ", time_it(4, [&] {auto v = u; binary_sort_ls(begin_of(v), end_of(v));}));
    }
};

UNIT_TEST("common/spreadsort-struct") = [](Context ct) {
    for (auto x : range(80)) {
        auto n = int(pow(1.2, x));
        auto w = vmap(range(n), [=](auto m) {return std::make_pair(random_float(), "something");});
        clobber_memory();
        auto t2 = time_it([&] {sort(w);});
        ct.require(is_sorted(w));
        random_shuffle(w);
        clobber_memory();
        auto t1 = time_it([&] {spreadsort_float(w, first_of, [](auto x, auto y) {return x.first < y.first;});});
        ct.require(is_sorted(w));
        if (test_output()) print(t2/t1, n);
    }
};

TIME_TEST("common/move-swap-copy") = [](Context ct) {
    for (auto i : range(1000)) {
        std::vector<int> t(100 * i), u(100 * i);
        auto t1 = time_it([&] {t = u;});
        auto t2 = time_it([&] {t.swap(u);});
        auto t3 = time_it([&] {t = std::move(u);});
        print(i, t1, t2, t3);
    }
    print("\ncopy, swap, move; actually move is non-trivial since one vector is destructed");
};

TIME_TEST("common/random/methods") = [](Context ct) {
    using rngs = pack<std::mt19937, std::mt19937_64, std::ranlux24, std::ranlux48, std::minstd_rand>;
    rngs::for_each([](auto t) {
        decltype(*t) rng;
        print(time_it(1000000, [&] {(void) random_float(rng);}), type_name(t));
    });
};

UNIT_TEST("common/random/device") = [](Context ct) {
    /// If run alone, should be 256 assertions, else 128
    decltype(StaticRNG) rng1, rng2;
    bool first = (rng1 == StaticRNG);
    for (auto i : range(128)) {
        auto x1 = random_float(rng1), x2 = random_float(rng2), x3 = random_float();
        ct.equal(x1, x2);
        if (RandomDevice) ct.not_equal(x3, x2);
        else if (first) ct.equal(x3, x2);
    }
};

UNIT_TEST("common/is-type") = [](Context ct) {
    REQUIRE_C("is-type", is_array<std::array<double, 4>>);
    REQUIRE_C("is-type", is_vec<vec<double>>);
    REQUIRE_C("is-type", is_small_vec<small_vec<double>>);
    REQUIRE_C("is-type", is_small_vec<small_vec<double, 4>>);
};

UNIT_TEST("common/legendre") = [](Context ct) {
    real const x = 0.78;
    vec<real> results, exact = {1, 0.78, 0.3473333333, -0.11089, -0.4335562267, -0.5275770708, -0.3926134483, -0.1125672311, 0.1831406779, 0.3727249927, 0.3885298728};
    legendres(10, x, [&](auto i, auto y) {results.push_back(y);});
    for (auto i : indices(results)) ct.near(results[i], exact[i]);
};

UNIT_TEST("common/ref-tuple") = [](Context ct) {
    auto tuple = std::make_tuple(1, string("sdkgb"), true);
    auto ref = as_tie(tuple);

    ct.equal(& first_of(tuple), & first_of(ref));
    ct.equal(& second_of(tuple), & second_of(ref));
    ct.equal(& third_of(tuple), & third_of(ref));

    static_assert(is_tuple<decltype(tuple)>, "");

    ct.equal(first_of(tuple), first_of(ref));
    ct.equal(second_of(tuple), second_of(ref));
    ct.equal(third_of(tuple), third_of(ref));
};

/******************************************************************************************/

NUPACK_LAMBDA(check1) = []{return 1;};

UNIT_TEST("common/static-lambda") = [](Context ct) {
    ct.equal(check1(), 1);
};

/******************************************************************************************/

UNIT_TEST("common/range") = [](Context ct) {
    auto f = [&](char const *s, auto r, vec<int> v) {
        ct.info(s);
        ct.require(std::equal(r.begin(), r.end(), v.begin(), v.end()));
    };

    f("0..9",    range(10),                         {0,1,2,3,4,5,6,7,8,9});
    f("7..9",    range(7, 10),                      {7,8,9});
    f("nothing", lrange(7, 3),                      {});
    f("9..0",    ~range(10),                        {9,8,7,6,5,4,3,2,1,0});
    f("9..7",    ~range(7, 10),                     {9,8,7});
    f("nothing", ~lrange(7, 3),                     {});
    f("5 5 5 5", copies(5, 4),                      {5,5,5,5});
    f("1..8",    range(10).offset(1, -1),           {1,2,3,4,5,6,7,8});
    f("8..1",    reversed(range(10).offset(1, -1)), {8,7,6,5,4,3,2,1});
    f("8..1",    reversed(range(10)).offset(1, -1), {8,7,6,5,4,3,2,1});
    f("8..1",    (~range(10)).offset(1, -1),        {8,7,6,5,4,3,2,1});
    f("7..9",    span(7, 10),                       {7,8,9});
    f("7..9",    ~span(7, 10),                      {9,8,7});
};

PROTOTYPE("bits") = [](Context ct) {
    BEEP(as_bitset(-4));
    BEEP(as_bitset(-3));
    BEEP(as_bitset(-2));
    BEEP(as_bitset(-1));
    BEEP(as_bitset(-0));
    BEEP(as_bitset(+0));
    BEEP(as_bitset(+1));
    BEEP(as_bitset(+2));
    BEEP(as_bitset(+3));
    BEEP(as_bitset(+4));
};

UNIT_TEST("parts/pairings") = [](Context ct) {
    small_vec<int> x = {0, 1, 2, 4, 10, 26, 76, 232, 764, 2620, 9496, 35696, 140152, 568504};

    for (auto i : indices(x)) {
        auto n = parts::pairings(i);
        ct.equal(n, x.at(i), i);
    }
};

UNIT_TEST("parts/partitions") = [](Context ct) {
    small_vec<int> x = {0, 1, 2, 5, 15, 52, 203, 877, 4140};

    for (auto i : indices(x)) {
        auto n = parts::partitions(false, i);
        ct.equal(n, x.at(i), i);
    }
};

UNIT_TEST("parts/subset-partitions") = [](Context ct) {
    small_vec<int> x = {1, 2, 5, 15, 52, 203, 877, 4140, 21147, 115975, 678570};

    for (auto i : indices(x)) {
        auto n = parts::partitions(true, i);
        ct.equal(n, x.at(i), i);
    }
};

UNIT_TEST("parts/subsets") = [](Context ct) {
    for (auto i : range(5)) {
        auto n = parts::subsets(i);
        ct.equal(n, 1 << i, i);
    }
};

PROTOTYPE("parts/bipartite") = [](Context ct) {
    for (auto i : range(8)) {
        auto n = parts::bipartite(i, i+1);
        print(i, n);
    }
};

PROTOTYPE("pdf/gamma") = [](Context ct) {
    PDF<std::gamma_distribution<real>, real> pdf(1, 2);
    ct.within(std::tgamma(1), 1, 1e-8);
    ct.require(is_nan(pdf(0)), pdf(0));
    ct.within(pdf(1e-16), 0.5, 0);
    ct.within(pdf(0.3), 0.4303539882, 1e-6);
    ct.within(pdf.cumulative(0), 0, 1e-6);
    ct.within(pdf.cumulative(0.3), 0.13929202, 1e-6);
    ct.within(pdf.cumulative(50.3), 1, 1e-6);

    for (auto iter : range(1000)) {
        real a = random_float() * 2, b = random_float() * 2, x = random_float() * 5;
        PDF<std::gamma_distribution<real>, real> pdf(a, b);
        auto exact = std::pow(x,-1 + a) / (std::pow(b,a) * std::exp(x/b) * std::tgamma(a));
        ct.within(exact, pdf(x), 1e-6, "check that definition agrees with Mathematica");
    }
};

namespace image {

real test_dots();

PROTOTYPE("dots") = [](Context ct) {
    auto r = test_dots();
    BEEP(r);
};

}

}
