#include "../Test.h"
#include <nupack/algorithms/Numeric.h>
#include <nupack/types/IO.h>
#include <nupack/math/DIIS.h>
#include <nupack/math/BoundSolve.h>

namespace nupack {


PROTOTYPE("common/sigfigs") = [](Context ct) {
    io::out() << std::setprecision(40);
    BEEP(sig_round(87.89347598374598347, 3));
    BEEP(sig_round(0.00000003253743658436578, 3));
};

PROTOTYPE("common/integer-types") = [](Context ct) {
    print("int8_t        ", sizeof(std::int8_t),         typeid(std::int8_t).name());
    print("int16_t       ", sizeof(std::int16_t),        typeid(std::int16_t).name());
    print("int32_t       ", sizeof(std::int32_t),        typeid(std::int32_t).name());
    print("int64_t       ", sizeof(std::int64_t),        typeid(std::int64_t).name());
    print("int_fast8_t   ", sizeof(std::int_fast8_t),    typeid(std::int_fast8_t).name());
    print("int_fast16_t  ", sizeof(std::int_fast16_t),   typeid(std::int_fast16_t).name());
    print("int_fast32_t  ", sizeof(std::int_fast32_t),   typeid(std::int_fast32_t).name());
    print("int_fast64_t  ", sizeof(std::int_fast64_t),   typeid(std::int_fast64_t).name());
    print("int_least8_t  ", sizeof(std::int_least8_t),   typeid(std::int_least8_t).name());
    print("int_least16_t ", sizeof(std::int_least16_t),  typeid(std::int_least16_t).name());
    print("int_least32_t ", sizeof(std::int_least32_t),  typeid(std::int_least32_t).name());
    print("int_least64_t ", sizeof(std::int_least64_t),  typeid(std::int_least64_t).name());
    print("intmax_t	     ", sizeof(std::intmax_t),       typeid(std::intmax_t).name());
    print("intptr_t	     ", sizeof(std::intptr_t),       typeid(std::intptr_t).name());
    print("uint8_t       ", sizeof(std::uint8_t),        typeid(std::uint8_t).name());
    print("uint16_t      ", sizeof(std::uint16_t),       typeid(std::uint16_t).name());
    print("uint32_t      ", sizeof(std::uint32_t),       typeid(std::uint32_t).name());
    print("uint64_t      ", sizeof(std::uint64_t),       typeid(std::uint64_t).name());
    print("uint_fast8_t  ", sizeof(std::uint_fast8_t),   typeid(std::uint_fast8_t).name());
    print("uint_fast16_t ", sizeof(std::uint_fast16_t),  typeid(std::uint_fast16_t).name());
    print("uint_fast32_t ", sizeof(std::uint_fast32_t),  typeid(std::uint_fast32_t).name());
    print("uint_fast64_t ", sizeof(std::uint_fast64_t),  typeid(std::uint_fast64_t).name());
    print("uint_least8_t ", sizeof(std::uint_least8_t),  typeid(std::uint_least8_t).name());
    print("uint_least16_t", sizeof(std::uint_least16_t), typeid(std::uint_least16_t).name());
    print("uint_least32_t", sizeof(std::uint_least32_t), typeid(std::uint_least32_t).name());
    print("uint_least64_t", sizeof(std::uint_least64_t), typeid(std::uint_least64_t).name());
    print("uintmax_t	 ", sizeof(std::uintmax_t),      typeid(std::uintmax_t).name());
    print("uintptr_t     ", sizeof(std::uintptr_t),      typeid(std::uintptr_t).name());
};


UNIT_TEST("common/log-sum-exp") = [](Context ct) {
    auto a = log(5.0);
    auto b = log(1000.0);

    ct.equal(1005.0, about(exp(log_sum_exp(a, b))));
};

/******************************************************************************************/

UNIT_TEST("common/nnls") = [](Context ct) {
    int n = 1e4, m = 50;
    arma::mat a(m, 3), b(m, n), x0(3, n);

    for (std::size_t t = 0; t != 10; ++t) {
        for (auto &i : a) i = random_float();
        for (auto &i : x0) i = random_float();
        b = a * x0;
        auto x = ct.timed(1, [&] {
            return bound_least_squares(a, b, ScalarBound(0, real(inf)), AlternatingOptions(1000, 1e-8));
        });
        ct.equal(x.second.unconverged, 0);
        ct.less(x.second.objective, 1e-8);
        ct.less(arma::abs(x.first - x0).max(), 1e-5, x);
    }
};

/******************************************************************************************/

UNIT_TEST("common/diis") = [](Context ct) {
    using T = real;
    uint n = 10, m = 4;
    ReferenceDIIS<T> ref(m);
    FastDIIS<T> fast(m);
    NonnegativeDIIS<T> nn(m);
    for (auto i : range(80)) {
        auto x = vmap<Col<T>>(range(n), [](auto) {return random_float();});
        auto e = vmap<Col<T>>(range(n), [](auto) {return random_float() - 0.1;});
        auto r = ref(x, e);
        auto f = fast(x, e);
        auto n = nn(x, e);
        ct.require(arma::norm(r - f) < 1e-8, i, r.t(), f.t(), n.t());
    }
};

}
