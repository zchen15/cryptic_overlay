#include "../Test.h"
#include <nupack/types/Sequence.h>
#include <nupack/types/IO.h>
#include <nupack/types/PairList.h>

namespace nupack {

constexpr int test_string_view(std::string_view c) {return c.size();}

UNIT_TEST("io/dotparens") = [](Context ct) {
    decltype(io::to_pairs("")) pairs;
    pairs = {3, 2, 1, 0};
    ct.equal(pairs, io::to_pairs("((+))"));
    ct.equal(pairs, io::to_pairs("(2+)2"));
    ct.throw_as<Error>([] {return io::to_pairs("2(2+)2");});
    pairs = {8, 1, 6, 3, 4, 5, 2, 7, 0};
    ct.equal(pairs, io::to_pairs("(.(...).)"));
    ct.equal(pairs, io::to_pairs("(.(.3).)"));

    ct.equal(test_string_view("123"), 3);
    std::string_view s = "(.(.3).)";
    PairList p{s};
    PairList p2 = "(.(.3).)";
};

UNIT_TEST("io/sequence") = [](Context ct) {
    ct.equal(Sequence("GGGGGGCCC").str(), "GGGGGGCCC");
    ct.equal(Sequence("A4T"), Sequence("AAAAT"));
    ct.equal(Sequence("A4T2"), Sequence("AAAATT"));
    ct.throw_as<Error>([] {return Sequence("4A4T");});
    ct.equal(Sequence("A10T2"), Sequence("AAAAAAAAAATT"));
};

UNIT_TEST("io/base-conversion") = [](Context ct) {
    REQUIRE_C("base-conversion", Base('A') == 0);
    REQUIRE_C("base-conversion", Base('C') == 1);
    REQUIRE_C("base-conversion", Base('G') == 2);
    REQUIRE_C("base-conversion", Base('T') == 3);
    REQUIRE_C("base-conversion", Base('U') == 3);
    REQUIRE_C("base-conversion", Base('R') == 4);
    REQUIRE_C("base-conversion", Base('M') == 5);
    REQUIRE_C("base-conversion", Base('S') == 6);
    REQUIRE_C("base-conversion", Base('W') == 7);
    REQUIRE_C("base-conversion", Base('K') == 8);
    REQUIRE_C("base-conversion", Base('Y') == 9);
    REQUIRE_C("base-conversion", Base('V') == 10);
    REQUIRE_C("base-conversion", Base('H') == 11);
    REQUIRE_C("base-conversion", Base('D') == 12);
    REQUIRE_C("base-conversion", Base('B') == 13);
    REQUIRE_C("base-conversion", Base('N') == 14);
    REQUIRE_C("base-conversion", Base('_') == 15);
};


}
