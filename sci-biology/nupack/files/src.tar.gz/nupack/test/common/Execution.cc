#include "../Test.h"
#include <nupack/execution/Local.h>
#include <nupack/execution/ThreadPool.h>

#include <thread>
#include <chrono>
// #include "/usr/local/include/folly/executors/CPUThreadPoolExecutor.h"

namespace nupack {

TIME_TEST("common/compare-executors") = [](Context ct) {
    for (auto t : {1e-4s, 1e-3s, 1e-2s, 1e-1s}) {
        auto task = [t](auto const &...){sleep(t);};

        for (auto i : range(1, 9)) {
            Local env(i);
            print("A", t, i, time_it([&]{env.spread(range(80), 1, task);}));
            ThreadPool<> env2(i);
            print("B", t, i, time_it([&]{env2.spread(range(80), 1, task);}));
            // Promise<int> p;
            // Future<int> f = p.getFuture();
            // f.isReady() == false
            // p.setValue(42);
            // folly::CPUThreadPoolExecutor env3(i);
            // print("B", t, i, time_it([&]{
            //     std::vector<folly::Func> fs(80, task);
            //     collect(fs).wait();
            //     env3.spread(range(80), 1, task);
            // }));
        }
    }
};

}
