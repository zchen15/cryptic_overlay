#include "Fortran.h"
#include "../Test.h"

#include <boost/fusion/adapted/std_tuple.hpp>

namespace nupack {
using namespace x4::literals;

template <class P> auto parse(P const &p, std::string s) {return x4::parser(p, ' '_x)(s);}

PROTOTYPE("parse-fortran") = [](Context ct) {
    std::string c;
    using namespace fortran;

    //REQUIRE_NOTHROW(parse(entity_decl,                                 "x(5, 5, *)"));
    REQUIRE_NOTHROW(parse(subroutine_stmt,                             "   \n    subroutine goof(x, y)  "));
    //REQUIRE(parse(declaration_construct,                       "    \n   integer m "));
    REQUIRE_NOTHROW(parse(x4::eol,                                     "   \n  "));
    REQUIRE_NOTHROW(parse(end_subroutine_stmt,                         "   \n end "));
    //REQUIRE(parse(subroutine_subprogram,                       "   \n    subroutine goo (x, y)   \n end "));
    //REQUIRE_NOTHROW(parse(type_spec,                                   " character * 1 "));

    REQUIRE_NOTHROW(parse(variable,                                    "  lda  "));
    //REQUIRE_NOTHROW(parse(primary,                                     "  lda  "));
    //REQUIRE(parse(expr,                                        "  lda  "));
    //REQUIRE(parse(entity_decl,                                 " a( lda, ASSUME ) "));
    //REQUIRE(parse(declaration_construct,                       "  \n  double precision   a(lda, ASSUME)  "));
    //REQUIRE(parse(subroutine_subprogram,                       "\n subroutine blah  \n  double precision   a(lda, ASSUME) \n end "));
    //REQUIRE(parse(named_constant_define % ","_x,               "  x = 1.0d0   "));
    REQUIRE_NOTHROW(parse(literal_constant,                          "  1.0d0   "));
    REQUIRE_NOTHROW(parse(literal_constant >> ')'_x,                 "  1.0d0 )  "));
    REQUIRE_THROWS(parse(name,                                       "  end  "));
    REQUIRE_NOTHROW(parse(end_subroutine_stmt,                       "   \n end "));
    //REQUIRE(parse(execution_part,                              " \n lside  = lsame( side  , 'l' ) "));

    //REQUIRE(parse(primary >> end_subroutine_stmt,              " lsame( side  , 'l' )  \n end "));
    //REQUIRE(parse(eol >> "if"_x >> paren(expr) >> action_stmt, " \n if( n ) return "));
    //REQUIRE(parse(do_block,                                    "     \n return "));
    //REQUIRE(parse(variable >> ')'_x >> expr,                   "      b ( i, j ) = zero "));
    //REQUIRE(parse(block_do_construct,                          "     \n        do 10 i = 1, m \n return \n 10 continue"));
    //REQUIRE_NOTHROW(parse(numeric_expr,                              " 1 "));
    //REQUIRE_NOTHROW(parse(numeric_expr,                              " 1.5 "));
    //REQUIRE_NOTHROW(parse(numeric_expr,                              " -1 "));
    //REQUIRE_NOTHROW(parse(numeric_expr,                              " +1 "));
    //REQUIRE_NOTHROW(parse(numeric_expr,                              " +1.5 "));
    //REQUIRE_NOTHROW(parse(numeric_expr,                              " -1.5 "));

    auto s = preprocess_file("dtrsm.f");
    print_lns("************************", s, "************************");
    //BEEP(parse(executable_program, s));

}



}
