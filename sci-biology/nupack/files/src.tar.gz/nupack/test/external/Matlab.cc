#include "../Test.h"
#include <nupack/external/Matlab.h>

#include <chrono>
#include <thread>

namespace nupack { namespace matlab {

PROTOTYPE("matlab") = [](Context ct) {
#   ifdef NUPACK_MATLAB
    auto a = Array<double, 2>(10, 3);

    vec<double> blah(30);
    a.set_data(blah);
    print(a);

    auto m = a.as_arma();
    m += 1;
    auto b = Array<double, 2>(m);
    m += 1;

    print_lns(a, b);

    auto eng = Engine();
    eng.put("a", a);
    eng.eval("a = a * 3\na = a * 6");
    eng.eval("\n");
    auto a2 = eng.get<double, 2>("a");

    print(a);
    print(a2); // a2 != a. It was copied.
#   endif
};

}}
