#include <nupack/execution/Local.h>

#include <H5Cpp.h>
#include "../Test.h"
#include <nupack/types/Matrix.h>

namespace nupack {
/*
PROTOTYPE("hdf") = [](Context ct) {

    File_Path path("test.h5");
    auto file = H5_Node(path);
    auto g = H5_Node(file, "Data");
    auto g2 = H5_Node(g, "Inside Data");

    auto x = [&](auto i){return 1;};
    print_lns(type_name<>(x), typeid(x).name(), GetTypeName<decltype(x)>());

    auto s = string("I hope it works!");
    auto in1 = H5_Object(g2, "My string", s);
    auto out1 = H5_Object(g2, "My string");
    out1.load(s);
    ct.equal(s, "I hope it works!");

    double d = 5.23758274656;
    auto in2 = H5_Object(g2, "My double", d);
    auto out2 = H5_Object(g2, "My double");
    out2.load(d);
    ct.equal(d, 5.23758274656);
    remove(path);
}

PROTOTYPE("exec2") = [](Context ct) {
    Cached_Executor<Local> ex("exec2.h5");
    std::pair<int, bool> value;

    ex.write("no arguments");
    {
        auto f = []{return 3;};
        value = ex.check_call(f);
        print(value);
        ct.equal(value.first, 3);
    }

    ex.write("easy arguments");
    {
        auto f = [&]{return 4 * 2;};
        value = ex.check_call(f, 4, "okay");
        print(value);
        ct.equal(value.first, 8);
    }

    ex.write("hard arguments");
    {
        Mat<double> m(4, 4); m.zeros();
        auto f = [&]{return 4 * 5;};
        value = ex.check_call(f, m);
        print(value);
        ct.equal(value.first, 20);
    }

    ex.write("hard return");
    {
        auto f = [&]{return Mat<double>();};
        auto m = ex.call(f, 1);
    }
}
*/
}
