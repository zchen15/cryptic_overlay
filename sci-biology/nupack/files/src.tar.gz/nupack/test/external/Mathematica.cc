#include <nupack/external/Mathematica.h>
#include <nupack/types/IO.h>
#include "../Test.h"

namespace nupack { namespace mma {

UNIT_TEST("mma/evaluate") = [](Context ct) {
#   ifdef NUPACK_MATHEMATICA
    Engine eng(false);
    ct.near(eng.evaluate<double>("2.5*2*2"), 10.0);
    eng.set("x", 2);
    ct.near(eng.evaluate<double>("2.25 * x"), 4.5);

    // Sort of works but not for > 1 expression I think
    //Mathematica_Engine interactive(true);
    //interactive.set("x", 2);
#   endif
};

}}
