#pragma once
#include <nupack/reflect/Print.h>
#include <nupack/types/IO.h>

#include <x4.hpp>
//#include <boost/config/warning_disable.hpp>
//#include <boost/spirit/home/x3.hpp>

namespace nupack {

namespace fortran {
using namespace x4::literals;
using x4::seq;
using x4::any;

template <class ...Ts> auto paren(Ts &&...ts) {return seq('(', std::forward<Ts>(ts)..., ')');}

static constexpr auto dot = '.'_x;
static constexpr auto comma = ','_x;
static constexpr auto colon = ':'_x;
using x4::eol;

template <class T, class Sep=decltype(comma)> auto list(T t, Sep s=comma) {return seq(~t, *seq(s, t));}

X4_DECLARE(reserved_name);

//auto const db = [](std::string n) {
//    return [n](auto& ct) {
//        std::string s(_where(ct).begin(), _where(ct).end());
//        std::cout << n << " '''\n" << s << "\n'''\n";
//    };
//};

/******************************************************************************************/

X4_DECLARE(executable_program);
X4_DECLARE(program_unit);
X4_DECLARE(main_program);
X4_DECLARE(external_subprogram);
X4_DECLARE(function_subprogram);
X4_DECLARE(subroutine_subprogram);
X4_DECLARE(module);
X4_DECLARE(block_data);
X4_DECLARE(specification_part);
X4_DECLARE(implicit_part);
X4_DECLARE(implicit_part_stmt);
X4_DECLARE(declaration_construct);
X4_DECLARE(execution_part);
X4_DECLARE(execution_part_construct);
X4_DECLARE(internal_subprogram_part);
X4_DECLARE(internal_subprogram);
X4_DECLARE(module_subprogram_part);
X4_DECLARE(module_subprogram);
X4_DECLARE(specification_stmt);
X4_DECLARE(executable_construct);
X4_DECLARE(action_stmt);
X4_DECLARE(character);
X4_DECLARE(alphanumeric_character);
X4_DECLARE(underscore);
X4_DECLARE(name);
X4_DECLARE(constant);
X4_DECLARE(literal_constant);
X4_DECLARE(named_constant);
X4_DECLARE(int_constant);
X4_DECLARE(char_constant);
X4_DECLARE(intrinsic_operator);
X4_DECLARE(power_op);
X4_DECLARE(mult_op);
X4_DECLARE(add_op);
X4_DECLARE(concat_op);
X4_DECLARE(rel_op);
X4_DECLARE(not_op);
X4_DECLARE(and_op);
X4_DECLARE(or_op);
X4_DECLARE(equiv_op);
X4_DECLARE(defined_operator);
X4_DECLARE(defined_unary_op);
X4_DECLARE(defined_binary_op);
X4_DECLARE(extended_intrinsic_op);
X4_DECLARE(label);
X4_DECLARE(signed_digit_string);
X4_DECLARE(digit_string);
X4_DECLARE(signed_int_literal_constant);
X4_DECLARE(int_literal_constant);
X4_DECLARE(kind_param);
X4_DECLARE(sign);
X4_DECLARE(boz_literal_constant);
X4_DECLARE(binary_constant);
X4_DECLARE(octal_constant);
X4_DECLARE(hex_constant);
X4_DECLARE(hex_digit);
X4_DECLARE(signed_real_literal_constant);
X4_DECLARE(real_literal_constant);
X4_DECLARE(significand);
X4_DECLARE(exponent_letter);
X4_DECLARE(exponent);
X4_DECLARE(complex_literal_constant);
X4_DECLARE(real_part);
X4_DECLARE(imag_part);
X4_DECLARE(char_literal_constant);
X4_DECLARE(logical_literal_constant);
X4_DECLARE(derived_type_define);
X4_DECLARE(private_sequence_stmt);
X4_DECLARE(derived_type_stmt);
X4_DECLARE(end_type_stmt);
X4_DECLARE(component_def_stmt);
X4_DECLARE(component_attr_spec);
X4_DECLARE(component_array_spec);
X4_DECLARE(component_decl);
X4_DECLARE(structure_constructor);
X4_DECLARE(array_constructor);
X4_DECLARE(ac_value);
X4_DECLARE(ac_implied_do);
X4_DECLARE(ac_implied_do_control);
X4_DECLARE(ac_do_variable);
X4_DECLARE(type_declaration_stmt);
X4_DECLARE(type_spec);
X4_DECLARE(attr_spec);
X4_DECLARE(entity_decl);
X4_DECLARE(kind_selector);
X4_DECLARE(char_selector);
X4_DECLARE(length_selector);
X4_DECLARE(char_length);
X4_DECLARE(type_param_value);
X4_DECLARE(access_spec);
X4_DECLARE(intent_spec);
X4_DECLARE(array_spec);
X4_DECLARE(explicit_shape_spec);
X4_DECLARE(lower_bound);
X4_DECLARE(upper_bound);
X4_DECLARE(assumed_shape_spec);
X4_DECLARE(deferred_shape_spec);
X4_DECLARE(assumed_size_spec);
X4_DECLARE(intent_stmt);
X4_DECLARE(optional_stmt);
X4_DECLARE(access_stmt);
X4_DECLARE(access_id);
X4_DECLARE(save_stmt);
X4_DECLARE(saved_entity);
X4_DECLARE(dimension_stmt);
X4_DECLARE(allocatable_stmt);
X4_DECLARE(pointer_stmt);
X4_DECLARE(target_stmt);
X4_DECLARE(data_stmt);
X4_DECLARE(data_stmt_set);
X4_DECLARE(data_stmt_object);
X4_DECLARE(data_stmt_value);
X4_DECLARE(data_stmt_constant);
X4_DECLARE(data_stmt_repeat);
X4_DECLARE(data_implied_do);
X4_DECLARE(data_i_do_object);
X4_DECLARE(data_i_do_variable);
X4_DECLARE(parameter_stmt);
X4_DECLARE(named_constant_define);
X4_DECLARE(implicit_stmt);
X4_DECLARE(implicit_spec);
X4_DECLARE(letter_spec);
X4_DECLARE(namelist_stmt);
X4_DECLARE(namelist_group_object);
X4_DECLARE(equivalence_stmt);
X4_DECLARE(equivalence_set);
X4_DECLARE(equivalence_object);
X4_DECLARE(common_stmt);
X4_DECLARE(common_block_object);
X4_DECLARE(variable);
X4_DECLARE(subobject);
X4_DECLARE(logical_variable);
X4_DECLARE(default_logical_variable);
X4_DECLARE(char_variable);
X4_DECLARE(default_char_variable);
X4_DECLARE(int_variable);
X4_DECLARE(default_int_variable);
X4_DECLARE(substring);
X4_DECLARE(parent_string);
X4_DECLARE(substring_range);
X4_DECLARE(data_ref);
X4_DECLARE(part_ref);
X4_DECLARE(structure_component);
X4_DECLARE(array_element);
X4_DECLARE(array_section);
X4_DECLARE(subscript);
X4_DECLARE(section_subscript);
X4_DECLARE(subscript_triplet);
X4_DECLARE(stride);
X4_DECLARE(vector_subscript);
X4_DECLARE(allocate_stmt);
X4_DECLARE(stat_variable);
X4_DECLARE(allocation);
X4_DECLARE(allocate_object);
X4_DECLARE(allocate_shape_spec);
X4_DECLARE(allocate_lower_bound);
X4_DECLARE(allocate_upper_bound);
X4_DECLARE(nullify_stmt);
X4_DECLARE(pointer_object);
X4_DECLARE(deallocate_stmt);
X4_DECLARE(primary);
X4_DECLARE(constant_subobject);
X4_DECLARE(level_1_expr);
X4_DECLARE(mult_operand);
X4_DECLARE(add_operand);
X4_DECLARE(level_2_expr);
X4_DECLARE(level_3_expr);
X4_DECLARE(level_4_expr);
X4_DECLARE(and_operand);
X4_DECLARE(or_operand);
X4_DECLARE(equiv_operand);
X4_DECLARE(level_5_expr);
X4_DECLARE(expr);
X4_DECLARE(logical_expr);
X4_DECLARE(char_expr);
X4_DECLARE(default_char_expr);
X4_DECLARE(int_expr);
X4_DECLARE(numeric_expr);
X4_DECLARE(initialization_expr);
X4_DECLARE(char_initialization_expr);
X4_DECLARE(int_initialization_expr);
X4_DECLARE(logical_initialization_expr);
X4_DECLARE(specification_expr);
X4_DECLARE(assignment_stmt);
X4_DECLARE(pointer_assignment_stmt);
X4_DECLARE(target);
X4_DECLARE(where_stmt);
X4_DECLARE(where_construct);
X4_DECLARE(where_construct_stmt);
X4_DECLARE(mask_expr);
X4_DECLARE(elsewhere_stmt);
X4_DECLARE(end_where_stmt);
X4_DECLARE(block);
X4_DECLARE(if_construct);
X4_DECLARE(if_then_stmt);
X4_DECLARE(else_if_stmt);
X4_DECLARE(else_stmt);
X4_DECLARE(end_if_stmt);
X4_DECLARE(if_stmt);
X4_DECLARE(case_construct);
X4_DECLARE(select_case_stmt);
X4_DECLARE(case_stmt);
X4_DECLARE(end_select_stmt);
X4_DECLARE(case_expr);
X4_DECLARE(case_selector);
X4_DECLARE(case_value_range);
X4_DECLARE(case_value);
X4_DECLARE(do_construct);
X4_DECLARE(block_do_construct);
X4_DECLARE(do_stmt);
X4_DECLARE(label_do_stmt);
X4_DECLARE(nonlabel_do_stmt);
X4_DECLARE(loop_control);
X4_DECLARE(do_variable);
X4_DECLARE(do_block);
X4_DECLARE(end_do);
X4_DECLARE(end_do_stmt);
X4_DECLARE(nonblock_do_construct);
X4_DECLARE(action_term_do_construct);
X4_DECLARE(do_body);
X4_DECLARE(do_term_action_stmt);
X4_DECLARE(outer_shared_do_construct);
X4_DECLARE(shared_term_do_construct);
X4_DECLARE(inner_shared_do_construct);
X4_DECLARE(do_term_shared_stmt);
X4_DECLARE(cycle_stmt);
X4_DECLARE(exit_stmt);
X4_DECLARE(goto_stmt);
X4_DECLARE(computed_goto_stmt);
X4_DECLARE(assign_stmt);
X4_DECLARE(assigned_goto_stmt);
X4_DECLARE(arithmetic_if_stmt);
X4_DECLARE(continue_stmt);
X4_DECLARE(stop_stmt);
X4_DECLARE(stop_code);
X4_DECLARE(pause_stmt);
X4_DECLARE(io_unit);
X4_DECLARE(external_file_unit);
X4_DECLARE(internal_file_unit);
X4_DECLARE(open_stmt);
X4_DECLARE(connect_spec);
X4_DECLARE(file_name_expr);
X4_DECLARE(close_stmt);
X4_DECLARE(close_spec);
X4_DECLARE(read_stmt);
X4_DECLARE(write_stmt);
X4_DECLARE(print_stmt);
X4_DECLARE(io_control_spec);
X4_DECLARE(format);
X4_DECLARE(input_item);
X4_DECLARE(output_item);
X4_DECLARE(io_implied_do);
X4_DECLARE(io_implied_do_object);
X4_DECLARE(io_implied_do_control);
X4_DECLARE(backspace_stmt);
X4_DECLARE(endfile_stmt);
X4_DECLARE(rewind_stmt);
X4_DECLARE(position_spec);
X4_DECLARE(inquire_stmt);
X4_DECLARE(inquire_spec);
X4_DECLARE(format_stmt);
X4_DECLARE(format_specification);
X4_DECLARE(format_item);
X4_DECLARE(r);
X4_DECLARE(data_edit_desc);
X4_DECLARE(w);
X4_DECLARE(m);
X4_DECLARE(d);
X4_DECLARE(e);
X4_DECLARE(control_edit_desc);
X4_DECLARE(k);
X4_DECLARE(position_edit_desc);
X4_DECLARE(n);
X4_DECLARE(sign_edit_desc);
X4_DECLARE(blank_interp_edit_desc);
X4_DECLARE(char_string_edit_desc);
X4_DECLARE(c);
X4_DECLARE(program_stmt);
X4_DECLARE(end_program_stmt);
X4_DECLARE(module_stmt);
X4_DECLARE(end_module_stmt);
X4_DECLARE(use_stmt);
X4_DECLARE(rename);
X4_DECLARE(only);
X4_DECLARE(block_data_stmt);
X4_DECLARE(end_block_data_stmt);
X4_DECLARE(interface_block);
X4_DECLARE(interface_stmt);
X4_DECLARE(end_interface_stmt);
X4_DECLARE(interface_body);
X4_DECLARE(module_procedure_stmt);
X4_DECLARE(generic_spec);
X4_DECLARE(external_stmt);
X4_DECLARE(intrinsic_stmt);
X4_DECLARE(function_reference);
X4_DECLARE(call_stmt);
X4_DECLARE(actual_arg_spec);
X4_DECLARE(keyword);
X4_DECLARE(actual_arg);
X4_DECLARE(alt_return_spec);
X4_DECLARE(function_stmt);
X4_DECLARE(prefix);
X4_DECLARE(end_function_stmt);
X4_DECLARE(subroutine_stmt);
X4_DECLARE(dummy_arg);
X4_DECLARE(end_subroutine_stmt);
X4_DECLARE(entry_stmt);
X4_DECLARE(return_stmt);
X4_DECLARE(contains_stmt);
X4_DECLARE(stmt_function_stmt);

/******************************************************************************************/

X4_DEFINE(executable_program)           = +program_unit;

X4_DEFINE(program_unit)                 = main_program          /* % f */
                                        | function_subprogram   /* % f */
                                        | subroutine_subprogram /* % f */
                                        | module                /* % f */
                                        | block_data            /* % f */;

X4_DEFINE(main_program)                 = seq(~program_stmt, specification_part, ~execution_part, ~internal_subprogram_part, end_program_stmt)
                                        % [](auto ps, auto ...ts) {};

X4_DEFINE(function_subprogram)          = seq(function_stmt, specification_part, ~execution_part, ~internal_subprogram_part, end_function_stmt)
                                        % [](auto ...ts) {};

X4_DEFINE(subroutine_subprogram)        = seq(subroutine_stmt, specification_part, ~execution_part, ~internal_subprogram_part, end_subroutine_stmt)
                                        % [](auto ...ts) {};

X4_DEFINE(module)                       = seq(module_stmt, specification_part, ~module_subprogram_part, end_module_stmt);

X4_DEFINE(block_data)                   = seq(block_data_stmt, specification_part, end_block_data_stmt) ;

X4_DEFINE(specification_part)           = seq(*use_stmt, ~implicit_part, *declaration_construct);

X4_DEFINE(implicit_part)                = seq(*implicit_part_stmt, implicit_stmt);

X4_DEFINE(implicit_part_stmt)           = implicit_stmt
                                        | parameter_stmt
                                        //| format_stmt
                                        | entry_stmt;

X4_DEFINE(declaration_construct)        = derived_type_define
                                        | interface_block
                                        | type_declaration_stmt
                                        | specification_stmt
                                        | parameter_stmt
                                        //| format_stmt
                                        | entry_stmt
                                        | stmt_function_stmt;

X4_DEFINE(execution_part)               = seq(executable_construct, *execution_part_construct);

X4_DEFINE(execution_part_construct)     = executable_construct
                                        //| format_stmt
                                        | data_stmt
                                        | entry_stmt;

X4_DEFINE(internal_subprogram_part)     = seq(contains_stmt, +internal_subprogram);

X4_DEFINE(internal_subprogram)          = function_subprogram
                                        | subroutine_subprogram;

X4_DEFINE(module_subprogram_part)       = seq(contains_stmt, +module_subprogram);

X4_DEFINE(module_subprogram)            = function_subprogram
                                        | subroutine_subprogram;

X4_DEFINE(specification_stmt)           = access_stmt
                                        | allocatable_stmt
                                        | common_stmt
                                        | data_stmt
                                        | dimension_stmt
                                        | equivalence_stmt
                                        | external_stmt
                                        | intent_stmt
                                        | intrinsic_stmt
                                        | namelist_stmt
                                        | optional_stmt
                                        | pointer_stmt
                                        | save_stmt
                                        | target_stmt;

X4_DEFINE(executable_construct)         = seq(eol, action_stmt)
                                        | case_construct
                                        | do_construct
                                        | if_construct
                                        | where_construct;

X4_DEFINE(action_stmt)                  = allocate_stmt
                                        | assignment_stmt
                                        | backspace_stmt
                                        | call_stmt
                                        | close_stmt
                                        | computed_goto_stmt
                                        | continue_stmt
                                        | cycle_stmt
                                        | deallocate_stmt
                                        | endfile_stmt
                                        //| end_function_stmt
                                        //| end_program_stmt
                                        //| end_subroutine_stmt
                                        | exit_stmt
                                        | goto_stmt
                                        | if_stmt
                                        | inquire_stmt
                                        | nullify_stmt
                                        | open_stmt
                                        | pointer_assignment_stmt
                                        | print_stmt
                                        | read_stmt
                                        | return_stmt
                                        | rewind_stmt
                                        | stop_stmt
                                        | where_stmt
                                        | write_stmt
                                        | arithmetic_if_stmt
                                        | assign_stmt
                                        | assigned_goto_stmt
                                        | pause_stmt;

X4_DEFINE(character)                    = alphanumeric_character
                                        | x4::punct_x;

X4_DEFINE(alphanumeric_character)       = x4::alpha_x
                                        | x4::digit_x
                                        | underscore;

X4_DEFINE(underscore)                   = '_'_x;

X4_DEFINE(reserved_name)                = any("end", "subroutine");

X4_DEFINE(name)                         = x4::lexeme(x4::alpha_x, *alphanumeric_character) - reserved_name;

X4_DEFINE(constant)                     = literal_constant
                                        | named_constant;

X4_DEFINE(literal_constant)             = real_literal_constant
                                        | int_literal_constant
                                        | complex_literal_constant
                                        | logical_literal_constant
                                        | char_literal_constant
                                        | boz_literal_constant;

X4_DEFINE(named_constant)               = name;

X4_DEFINE(int_constant)                 = constant;

X4_DEFINE(char_constant)                = constant;

X4_DEFINE(intrinsic_operator)           = power_op
                                        | mult_op
                                        | add_op
                                        | concat_op
                                        | rel_op
                                        | not_op
                                        | and_op
                                        | or_op
                                        | equiv_op;

X4_DEFINE(power_op)                     = "**"_x;

X4_DEFINE(mult_op)                      = '*'_x
                                        | '/'_x;

X4_DEFINE(add_op)                       = '+'_x
                                        | '-'_x;

X4_DEFINE(concat_op)                    = "//"_x;

X4_DEFINE(rel_op)                       = ".eq."_x
                                        | ".ne."_x
                                        | ".lt."_x
                                        | ".le."_x
                                        | ".gt."_x
                                        | ".ge."_x
                                        | "=="_x
                                        | "/="_x
                                        | "< "_x
                                        | "<="_x
                                        | "> "_x
                                        | ">="_x;

X4_DEFINE(not_op)                       = ".not."_x;

X4_DEFINE(and_op)                       = ".and."_x;

X4_DEFINE(or_op)                        = ".or."_x;

X4_DEFINE(equiv_op)                     = ".eqv."_x | ".neqv."_x;

X4_DEFINE(defined_operator)             = defined_unary_op
                                        | defined_binary_op
                                        | extended_intrinsic_op;

X4_DEFINE(defined_unary_op)             = x4::lexeme(dot, +x4::alpha_x, dot)
                                        | sign;

X4_DEFINE(defined_binary_op)            = x4::lexeme(dot, +x4::alpha_x, dot);

X4_DEFINE(extended_intrinsic_op)        = intrinsic_operator;

X4_DEFINE(label)                        = x4::short_x;

X4_DEFINE(signed_digit_string)          = seq(~sign, digit_string);

X4_DEFINE(digit_string)                 = x4::ulong_x;

X4_DEFINE(signed_int_literal_constant)  = x4::long_x;

X4_DEFINE(int_literal_constant)         = seq(digit_string, ~seq('_', kind_param)); // messed up

X4_DEFINE(kind_param)                   = digit_string
                                        | x4::int_x;

X4_DEFINE(sign)                         = '+'_x
                                        | '-'_x;

X4_DEFINE(boz_literal_constant)         = binary_constant
                                        | octal_constant
                                        | hex_constant;

X4_DEFINE(binary_constant)              = seq("B\'", x4::ulong_x, "\'")
                                        | seq("B\"", x4::ulong_x, '"');

X4_DEFINE(octal_constant)               = seq("O\'", x4::ulong_x, "\'")
                                        | seq("O\"", x4::ulong_x, '"');

X4_DEFINE(hex_constant)                 = seq("Z\'", x4::ulong_x, "\'")
                                        | seq("Z\"", x4::ulong_x, '"');

X4_DEFINE(hex_digit)                    = x4::digit_x | any('A', 'B', 'C', 'D', 'E', 'F');

X4_DEFINE(signed_real_literal_constant) = seq(~sign, real_literal_constant);

X4_DEFINE(real_literal_constant)        = seq(significand, ~seq(exponent_letter, exponent), ~seq('_', kind_param))
                                        | seq(digit_string, exponent_letter, exponent, ~seq('_', kind_param));

X4_DEFINE(significand)                  = seq(digit_string, dot, ~digit_string)
                                        | seq(dot, digit_string);

X4_DEFINE(exponent_letter)              = "d"_x
                                        | "e"_x;

X4_DEFINE(exponent)                     = signed_digit_string;

X4_DEFINE(complex_literal_constant)     = paren(real_part, ','_x, imag_part);

X4_DEFINE(real_part)                    = signed_int_literal_constant
                                        | signed_real_literal_constant;

X4_DEFINE(imag_part)                    = signed_int_literal_constant
                                        | signed_real_literal_constant;

X4_DEFINE(char_literal_constant)        = seq(~seq(kind_param, '_'), x4::lexeme('\'', *(x4::char_x - '\''_x), '\''))
                                        | seq(~seq(kind_param, '_'), x4::lexeme('"', *(x4::char_x - '"'_x), '"'));

X4_DEFINE(logical_literal_constant)     = seq(".true.",  ~seq('_', kind_param))
                                        | seq(".false.", ~seq('_', kind_param));

X4_DEFINE(derived_type_define)          = seq(derived_type_stmt, *private_sequence_stmt, +component_def_stmt, end_type_stmt);

X4_DEFINE(private_sequence_stmt)        = seq(eol, "private")
                                        | seq(eol, "sequence");

X4_DEFINE(derived_type_stmt)            = seq(eol, "type", ~seq(~seq(',', access_spec), "::"), name);

X4_DEFINE(end_type_stmt)                = seq(eol, "end", "type", ~name);

X4_DEFINE(component_def_stmt)           = seq(eol, type_spec, ~seq(~seq(',', component_attr_spec / ','), "::"), component_decl / ',');

X4_DEFINE(component_attr_spec)          = "pointer"
                                        | seq("dimension", paren(component_array_spec));

X4_DEFINE(component_array_spec)         = explicit_shape_spec / ','
                                        | deferred_shape_spec / ',';

X4_DEFINE(component_decl)               = seq(name, ~seq(paren(component_array_spec)), ~seq('*', char_length));

X4_DEFINE(structure_constructor)        = seq(name, paren(expr / ','));

X4_DEFINE(array_constructor)            = seq("(/", (ac_value / ','), "/)");

X4_DEFINE(ac_value)                     = expr
                                        | ac_implied_do;

X4_DEFINE(ac_implied_do)                = paren(ac_value / ',', ',', ac_implied_do_control);

X4_DEFINE(ac_implied_do_control)        = seq(ac_do_variable, '=', default_int_variable, ',', default_int_variable, ~seq(',', default_int_variable));

X4_DEFINE(ac_do_variable)               = default_int_variable;

X4_DEFINE(type_declaration_stmt)        = seq(eol, type_spec, ~seq(~seq(',', attr_spec / ','), "::"), entity_decl / ',');

X4_DEFINE(type_spec)                    = seq("integer", ~kind_selector)
                                        | seq("real", ~kind_selector)
                                        | seq("double", "precision")
                                        | seq("complex", ~kind_selector)
                                        | seq("character", ~char_selector)
                                        | seq("logical", ~kind_selector)
                                        | seq("type", paren(name));

X4_DEFINE(attr_spec)                    = "parameter"_x
                                        | "access_spec"_x
                                        | "allocatable"_x
                                        | seq("dimension"_x, paren(array_spec))
                                        | "external"_x
                                        | seq("intent"_x, paren(intent_spec))
                                        | "intrinsic"_x
                                        | "optional"_x
                                        | "pointer"_x
                                        | "save"_x
                                        | "target"_x;

X4_DEFINE(entity_decl)                  = seq(name, ~paren(array_spec), ~seq('*', char_length), ~seq('=', initialization_expr)); // edit

X4_DEFINE(kind_selector)                = paren(~seq("kind"_x, '='), int_initialization_expr);

X4_DEFINE(char_selector)                = length_selector
                                        | paren("len"_x, '=', type_param_value, ',', "kind"_x, '=', int_initialization_expr)
                                        | paren(type_param_value, ',', ~"kind"_x, '=', int_initialization_expr)
                                        | paren("kind"_x, '=', int_initialization_expr, ~seq(',', "len"_x, '=', type_param_value));

X4_DEFINE(length_selector)              = paren(~seq("len"_x, '='), type_param_value)
                                        | seq('*', char_length, ~','_x);

X4_DEFINE(char_length)                  = paren(type_param_value)
                                        | signed_int_literal_constant;

X4_DEFINE(type_param_value)             = specification_expr
                                        | '*';

X4_DEFINE(access_spec)                  = any("public", "private");

X4_DEFINE(intent_spec)                  = any("in", "out", "inout");

X4_DEFINE(array_spec)                   = assumed_size_spec
                                        | list(explicit_shape_spec)
                                        | list(assumed_shape_spec)
                                        | list(deferred_shape_spec);

X4_DEFINE(explicit_shape_spec)          = seq(~seq(lower_bound, ':'), upper_bound);

X4_DEFINE(lower_bound)                  = specification_expr;

X4_DEFINE(upper_bound)                  = specification_expr;

X4_DEFINE(assumed_shape_spec)           = seq(~lower_bound, ':');

X4_DEFINE(deferred_shape_spec)          = ':'_x;

X4_DEFINE(assumed_size_spec)            = seq(*seq(explicit_shape_spec, ','), ~seq(lower_bound, ':'_x), '*'_x);

X4_DEFINE(intent_stmt)                  = seq(eol, "intent", paren(intent_spec), ~"::"_x, name / ',');

X4_DEFINE(optional_stmt)                = seq(eol, "optional", ~"::"_x, name / ',');

X4_DEFINE(access_stmt)                  = seq(access_spec, ~seq("::"_x, access_id / ','));

X4_DEFINE(access_id)                    = name
                                        | generic_spec;

X4_DEFINE(save_stmt)                    = seq(eol, "save", ~seq(~"::"_x, saved_entity / ','));

X4_DEFINE(saved_entity)                 = seq('/', name, '/')
                                        | name;

X4_DEFINE(dimension_stmt)               = seq(eol, "dimension", ~"::"_x, seq(name, paren(array_spec)) / ',');

X4_DEFINE(allocatable_stmt)             = seq(eol, "allocatable", ~"::"_x, seq(name, ~paren(deferred_shape_spec / ',')) / ',');

X4_DEFINE(pointer_stmt)                 = seq(eol, "pointer", ~"::"_x, seq(name, ~paren(deferred_shape_spec / ',')) / ',');

X4_DEFINE(target_stmt)                  = seq(eol, "target", ~"::"_x, seq(name, ~paren(array_spec)) / ',');

X4_DEFINE(data_stmt)                    = seq(eol, "data", data_stmt_set / ',');

X4_DEFINE(data_stmt_set)                = seq(data_stmt_object / ',', '/', data_stmt_value / ',', '/');

X4_DEFINE(data_stmt_object)             = variable
                                        | data_implied_do;

X4_DEFINE(data_stmt_value)              = seq(~data_stmt_repeat, '*'_x, data_stmt_constant);

X4_DEFINE(data_stmt_constant)           = signed_int_literal_constant
                                        | signed_real_literal_constant
                                        | structure_constructor
                                        | boz_literal_constant;

X4_DEFINE(data_stmt_repeat)             = signed_int_literal_constant;

X4_DEFINE(data_implied_do)              = paren(data_i_do_object / ',', ',', data_i_do_variable, '=', default_int_variable, ',', default_int_variable, ~seq(',', default_int_variable));

X4_DEFINE(data_i_do_object)             = array_element
                                        | structure_component
                                        | data_implied_do;

X4_DEFINE(data_i_do_variable)           = default_int_variable;

X4_DEFINE(parameter_stmt)               = seq(eol, "parameter"_x, paren(named_constant_define / ','));

X4_DEFINE(named_constant_define)        = seq(named_constant, '=', initialization_expr);

X4_DEFINE(implicit_stmt)                = seq(eol, "implicit"_x, implicit_spec / ',')
                                        | seq(eol, "implicit"_x, "none"_x);

X4_DEFINE(implicit_spec)                = seq(type_spec, paren(letter_spec / ','));

X4_DEFINE(letter_spec)                  = seq(x4::alpha_x, ~seq('-', x4::alpha_x));

X4_DEFINE(namelist_stmt)                = seq(eol, "namelist", seq('/', name, '/', namelist_group_object / ',') / ~','_x);

X4_DEFINE(namelist_group_object)        = name;

X4_DEFINE(equivalence_stmt)             = seq(eol, "equivalence", equivalence_set / ',');

X4_DEFINE(equivalence_set)              = paren(equivalence_object, ',', equivalence_object / ',');

X4_DEFINE(equivalence_object)           = name
                                        | array_element
                                        | substring;

X4_DEFINE(common_stmt)                  = seq(eol, "common", seq(~seq('/', ~name, '/'), common_block_object / ',') / ~','_x);

X4_DEFINE(common_block_object)          = seq(name, ~paren(explicit_shape_spec / ','));

X4_DEFINE(variable)                     = subobject
                                        | name;

X4_DEFINE(subobject)                    = array_element
                                        | array_section
                                        | structure_component
                                        | substring;

X4_DEFINE(logical_variable)             = variable;
X4_DEFINE(default_logical_variable)     = variable;
X4_DEFINE(char_variable)                = variable;
X4_DEFINE(default_char_variable)        = variable;
X4_DEFINE(int_variable)                 = variable;
X4_DEFINE(default_int_variable)         = variable;

X4_DEFINE(substring)                    = seq(parent_string, paren(substring_range));

X4_DEFINE(parent_string)                = name
                                        | array_element
                                        | structure_component
                                        | int_constant;

X4_DEFINE(substring_range)              = seq(~int_expr, ':', ~int_expr);

X4_DEFINE(data_ref)                     = seq(part_ref / '%'_x);

X4_DEFINE(part_ref)                     = seq(name, ~paren(section_subscript / ','));

X4_DEFINE(structure_component)          = data_ref;

X4_DEFINE(array_element)                = data_ref;

X4_DEFINE(array_section)                = seq(data_ref, ~paren(substring_range));

X4_DEFINE(subscript)                    = int_expr;

X4_DEFINE(section_subscript)            = subscript
                                        | subscript_triplet
                                        | vector_subscript;

X4_DEFINE(subscript_triplet)            = seq(~subscript, ':', ~subscript, ~seq(':', stride));
X4_DEFINE(stride)                       = int_expr;
X4_DEFINE(vector_subscript)             = int_expr;
X4_DEFINE(allocate_stmt)                = seq("allocate", paren(allocation / ',', ~seq(',', "stat"_x, '='_x, stat_variable)));
X4_DEFINE(stat_variable)                = int_expr;
X4_DEFINE(allocation)                   = seq(allocate_object, ~paren(allocate_shape_spec / ','_x));
X4_DEFINE(allocate_object)              = name
                                        | structure_component;
X4_DEFINE(allocate_shape_spec)          = seq(~allocate_lower_bound, ':'_x, allocate_upper_bound);
X4_DEFINE(allocate_lower_bound)         = int_expr;
X4_DEFINE(allocate_upper_bound)         = int_expr;
X4_DEFINE(nullify_stmt)                 = seq("nullify", paren(pointer_object / ','_x));

X4_DEFINE(pointer_object)               = name
                                        | structure_component;

X4_DEFINE(deallocate_stmt)              = seq("deallocate", paren(allocate_object / ','_x, ~seq(',', "stat", '=', stat_variable)));

X4_DEFINE(primary)                      = function_reference
                                        | constant
                                        | constant_subobject
                                        | variable
                                        | array_constructor
                                        | structure_constructor
                                        | paren(expr);

X4_DEFINE(constant_subobject)           = subobject;

X4_DEFINE(level_1_expr)                 = seq(~defined_unary_op, primary);

X4_DEFINE(mult_operand)                 = level_1_expr / power_op;

X4_DEFINE(add_operand)                  = mult_operand / mult_op;

X4_DEFINE(level_2_expr)                 = add_operand / add_op;

X4_DEFINE(level_3_expr)                 = level_2_expr / concat_op;

X4_DEFINE(level_4_expr)                 = level_3_expr / rel_op;

X4_DEFINE(and_operand)                  = seq(~not_op, level_4_expr);

X4_DEFINE(or_operand)                   = and_operand / and_op;

X4_DEFINE(equiv_operand)                = or_operand / or_op;

X4_DEFINE(level_5_expr)                 = equiv_operand / equiv_op;

X4_DEFINE(expr)                         = level_5_expr / defined_binary_op;

X4_DEFINE(logical_expr)                 = expr;

X4_DEFINE(char_expr)                    = expr;

X4_DEFINE(default_char_expr)            = expr;

X4_DEFINE(int_expr)                     = expr;

X4_DEFINE(numeric_expr)                 = expr;

X4_DEFINE(initialization_expr)          = expr;

X4_DEFINE(char_initialization_expr)     = char_expr;

X4_DEFINE(int_initialization_expr)      = int_expr;

X4_DEFINE(logical_initialization_expr)  = logical_expr;

X4_DEFINE(specification_expr)           = int_expr;

X4_DEFINE(assignment_stmt)              = seq(variable, '=', expr);

X4_DEFINE(pointer_assignment_stmt)      = seq(pointer_object, "=>", target);

X4_DEFINE(target)                       = variable
                                        | expr;

X4_DEFINE(where_stmt)                   = seq(eol, "where", paren(mask_expr), assignment_stmt);

X4_DEFINE(where_construct)              = seq(where_construct_stmt, +assignment_stmt, ~seq(elsewhere_stmt, +assignment_stmt), end_where_stmt);

X4_DEFINE(where_construct_stmt)         = seq(eol, "where", paren(mask_expr));

X4_DEFINE(mask_expr)                    = logical_expr;

X4_DEFINE(elsewhere_stmt)               = seq(eol, "elsewhere");

X4_DEFINE(end_where_stmt)               = seq(eol, "end", "where");

X4_DEFINE(block)                        = +execution_part_construct;

X4_DEFINE(if_construct)                 = seq(if_then_stmt, block, *seq(else_if_stmt, block), ~seq(else_stmt, block), end_if_stmt);

X4_DEFINE(if_then_stmt)                 = seq(eol, ~seq(name, ':'), "if", paren(expr), "then")
                                        % [](auto ...ts){};

X4_DEFINE(else_if_stmt)                 = seq(eol, "else", "if", paren(expr), "then", ~name)
                                        % [](auto ...ts){};

X4_DEFINE(else_stmt)                    = seq(eol, "else", ~name);

X4_DEFINE(end_if_stmt)                  = seq(eol, "end", "if", ~name);

X4_DEFINE(if_stmt)                      = seq("if", paren(expr), action_stmt);

X4_DEFINE(case_construct)               = seq(select_case_stmt, ~case_stmt, *block, end_select_stmt);
X4_DEFINE(select_case_stmt)             = seq(eol, ~seq(name, ':'), "select", "case", paren(case_expr));
X4_DEFINE(case_stmt)                    = seq(eol, "case", case_selector, ~name);
X4_DEFINE(end_select_stmt)              = seq(eol, "end"_x, "select", ~name);
X4_DEFINE(case_expr)                    = expr;

X4_DEFINE(case_selector)                = paren(case_value_range / ',')
                                        | "default"_x;

X4_DEFINE(case_value_range)             = case_value
                                        | seq(case_value, ':')
                                        | seq(':', case_value)
                                        | seq(case_value, ':', case_value);

X4_DEFINE(case_value)                   = expr; //scalar_int_initialization_expr | scalar_char_initialization_expr | scalar_logical_initialization_expr;

X4_DEFINE(do_construct)                 = block_do_construct
                                        | nonblock_do_construct;

X4_DEFINE(block_do_construct)           = seq(do_stmt, do_block, end_do);

X4_DEFINE(do_stmt)                      = label_do_stmt
                                        | nonlabel_do_stmt;

X4_DEFINE(label_do_stmt)                = seq(eol, ~seq(name, ':'), "do", label, ~loop_control);

X4_DEFINE(nonlabel_do_stmt)             = seq(eol, ~seq(name, ':'), "do", ~loop_control);

X4_DEFINE(loop_control)                 = seq(~','_x, do_variable, '=', numeric_expr, ',', numeric_expr, ~seq(',', numeric_expr))
                                        | seq(~','_x, "while", paren(expr));

X4_DEFINE(do_variable)                  = variable;

X4_DEFINE(do_block)                     = block;

X4_DEFINE(end_do)                       = end_do_stmt
                                        | continue_stmt;

X4_DEFINE(end_do_stmt)                  = seq(eol, "end", "do", ~name)
                                        % [] (auto ...ts) {};

X4_DEFINE(nonblock_do_construct)        = action_term_do_construct
                                        | outer_shared_do_construct;

X4_DEFINE(action_term_do_construct)     = seq(label_do_stmt, do_body, do_term_action_stmt);

X4_DEFINE(do_body)                      = execution_part_construct;

X4_DEFINE(do_term_action_stmt)          = action_stmt;

X4_DEFINE(outer_shared_do_construct)    = seq(label_do_stmt, do_body, shared_term_do_construct);

X4_DEFINE(shared_term_do_construct)     = outer_shared_do_construct
                                        | inner_shared_do_construct;

X4_DEFINE(inner_shared_do_construct)    = seq(label_do_stmt, do_body, do_term_shared_stmt);

X4_DEFINE(do_term_shared_stmt)          = action_stmt;

X4_DEFINE(cycle_stmt)                   = seq("cycle", ~name);

X4_DEFINE(exit_stmt)                    = "exit"_x;

X4_DEFINE(goto_stmt)                    = seq("go", "to", label);

X4_DEFINE(computed_goto_stmt)           = seq("go", "to", paren(label / ','), ~seq(',', expr));

X4_DEFINE(assign_stmt)                  = seq("assign", label, "to", default_int_variable);

X4_DEFINE(assigned_goto_stmt)           = seq("go", "to", x4::int_x, ~seq(~','_x, paren(label / ',')));

X4_DEFINE(arithmetic_if_stmt)           = seq(eol, "if", paren(expr), label, ',', label, ',', label);

X4_DEFINE(continue_stmt)                = seq(eol, ~label, "continue"_x);

X4_DEFINE(stop_stmt)                    = seq("stop", ~stop_code);

X4_DEFINE(stop_code)                    = char_constant
                                        | x4::short_x;

X4_DEFINE(pause_stmt)                   = seq("pause", ~stop_code);

X4_DEFINE(io_unit)                      = external_file_unit
                                        | '*'_x
                                        | internal_file_unit;

X4_DEFINE(external_file_unit)           = int_expr;

X4_DEFINE(internal_file_unit)           = default_char_variable;

X4_DEFINE(open_stmt)                    = seq("open", paren(connect_spec / ','));

X4_DEFINE(connect_spec)                 = seq(~seq("unit", '='), external_file_unit)
                                        | seq("iostat",    '=', default_int_variable)
                                        | seq("err",       '=', label)
                                        | seq("file",      '=', file_name_expr)
                                        | seq("status",    '=', default_char_expr)
                                        | seq("access",    '=', default_char_expr)
                                        | seq("form",      '=', default_char_expr)
                                        | seq("recl",      '=', int_expr)
                                        | seq("blank",     '=', default_char_expr)
                                        | seq("position",  '=', default_char_expr)
                                        | seq("action",    '=', default_char_expr)
                                        | seq("delim",     '=', default_char_expr)
                                        | seq("pad",       '=', default_char_expr);

X4_DEFINE(file_name_expr)               = default_char_expr;

X4_DEFINE(close_stmt)                   = seq("close", paren(close_spec / ','));

X4_DEFINE(close_spec)                   = seq(~seq("unit", '='), external_file_unit)
                                        | seq("iostat", '=', default_int_variable)
                                        | seq("err", '=', label)
                                        | seq("status", '=', default_char_expr);

X4_DEFINE(read_stmt)                    = seq("read", paren(io_control_spec / ','), ~input_item / ',')
                                        | seq("read", "format"_x, ~','_x, input_item / ',');

X4_DEFINE(write_stmt)                   = seq("write", paren(io_control_spec / ','), ~output_item / ',');

X4_DEFINE(print_stmt)                   = seq("print", "format"_x, ~','_x, output_item / ',');

X4_DEFINE(io_control_spec)              = seq(~seq("unit", '='), io_unit)
                                        | seq("fmt",       '=', format)
                                        | seq("nml",       '=', name)
                                        | seq("rec",       '=', int_expr)
                                        | seq("iostat",    '=', default_int_variable)
                                        | seq("err",       '=', label)
                                        | seq("end",       '=', label)
                                        | seq("advance",   '=', default_char_expr)
                                        | seq("size",      '=', default_int_variable)
                                        | seq("eor",       '=', label);

X4_DEFINE(format)                       = default_char_expr
                                        | label
                                        | '*'_x
                                        | default_int_variable;

X4_DEFINE(input_item)                   = variable
                                        | io_implied_do;

X4_DEFINE(output_item)                  = expr
                                        | io_implied_do;

X4_DEFINE(io_implied_do)                = paren(io_implied_do_object / ',', ',', io_implied_do_control);

X4_DEFINE(io_implied_do_object)         = input_item
                                        | output_item;

X4_DEFINE(io_implied_do_control)        = seq(do_variable, '=', expr, ',', expr, ~seq(',', expr));

X4_DEFINE(backspace_stmt)               = seq("backspace", external_file_unit)
                                        | seq("backspace", paren(position_spec / ','));

X4_DEFINE(endfile_stmt)                 = seq("endfile", external_file_unit)
                                        | seq("endfile", paren(position_spec / ','));

X4_DEFINE(rewind_stmt)                  = seq("rewind", external_file_unit)
                                        | seq("rewind", paren(position_spec / ','));

X4_DEFINE(position_spec)                = seq(~"unit"_x, '=', external_file_unit)
                                        | seq("iostat"_x, '=', default_int_variable)
                                        | seq("err"_x, '=', label);

X4_DEFINE(inquire_stmt)                 = seq("inquire", paren(inquire_spec / ','))
                                        | seq("inquire", paren("iolength"_x, '=', default_int_variable), output_item / ',');

X4_DEFINE(inquire_spec)                 = seq(~"unit"_x,       '=', external_file_unit)
                                        | seq("file"_x,        '=', file_name_expr)
                                        | seq("iostat"_x,      '=', default_int_variable)
                                        | seq("err"_x,         '=', label)
                                        | seq("exist"_x,       '=', default_logical_variable)
                                        | seq("opened"_x,      '=', default_logical_variable)
                                        | seq("number"_x,      '=', default_int_variable)
                                        | seq("named"_x,       '=', default_logical_variable)
                                        | seq("name"_x,        '=', default_char_variable)
                                        | seq("access"_x,      '=', default_char_variable)
                                        | seq("sequential"_x,  '=', default_char_variable)
                                        | seq("direct"_x,      '=', default_char_variable)
                                        | seq("form"_x,        '=', default_char_variable)
                                        | seq("formatted"_x,   '=', default_char_variable)
                                        | seq("unformatted"_x, '=', default_char_variable)
                                        | seq("recl"_x,        '=', default_int_variable)
                                        | seq("nextrec"_x,     '=', default_int_variable)
                                        | seq("blank"_x,       '=', default_char_variable)
                                        | seq("position"_x,    '=', default_char_variable)
                                        | seq("action"_x,      '=', default_char_variable)
                                        | seq("read"_x,        '=', default_char_variable)
                                        | seq("write"_x,       '=', default_char_variable)
                                        | seq("readwrite"_x,   '=', default_char_variable)
                                        | seq("delim"_x,       '=', default_char_variable)
                                        | seq("pad"_x,         '=', default_char_variable);

X4_DEFINE(format_stmt)                  = seq(eol, format, format_specification);

X4_DEFINE(format_specification)         = paren(format_item / ',');

X4_DEFINE(format_item)                  = seq(~r, data_edit_desc)
                                        | control_edit_desc
                                        | char_string_edit_desc
                                        | seq(~r, paren(format_item / ','));

X4_DEFINE(r)                            = int_literal_constant;

X4_DEFINE(data_edit_desc)               = seq("I"_x, w, ~seq(dot, m))
                                        | seq("B"_x, w, ~seq(dot, m))
                                        | seq("O"_x, w, ~seq(dot, m))
                                        | seq("Z"_x, w, ~seq(dot, m))
                                        | seq("F"_x, w, dot, d)
                                        | seq("E"_x, w, dot, d, ~seq("E", e))
                                        | seq("EN"_x, w, dot, d, ~seq("E", e))
                                        | seq("ES"_x, w, dot, d, ~seq("E", e))
                                        | seq("G"_x, w, dot, d, ~seq("E", e))
                                        | seq("L", w)
                                        | seq("A", ~w)
                                        | seq("D", w, dot, d);

X4_DEFINE(w)                            = int_literal_constant;
X4_DEFINE(m)                            = int_literal_constant;
X4_DEFINE(d)                            = int_literal_constant;
X4_DEFINE(e)                            = int_literal_constant;

X4_DEFINE(control_edit_desc)            = position_edit_desc
                                        | seq(~r, '/'_x)
                                        | ':'
                                        | sign_edit_desc
                                        | seq("k", "P"_x)
                                        | blank_interp_edit_desc;
X4_DEFINE(k)                            = signed_int_literal_constant;

X4_DEFINE(position_edit_desc)           = seq("T", n)
                                        | seq("TL", n)
                                        | seq("TR", n)
                                        | seq(n, "X");

X4_DEFINE(n)                            = int_literal_constant;

X4_DEFINE(sign_edit_desc)               = any("S", "SP", "SS");

X4_DEFINE(blank_interp_edit_desc)       = any("BN", "BZ"_x);

X4_DEFINE(char_string_edit_desc)        = char_literal_constant
                                        | seq("c", "H"_x, +x4::alpha_x);

X4_DEFINE(c)                            = int_literal_constant;

X4_DEFINE(program_stmt)                 = seq(eol, "program", name);

X4_DEFINE(end_program_stmt)             = seq(eol, "end", ~"program"_x, "[", name, "]");

X4_DEFINE(module_stmt)                  = seq(eol, "module", name);

X4_DEFINE(end_module_stmt)              = seq(eol, "end", ~"module"_x, "[", name, "]");

X4_DEFINE(use_stmt)                     = seq(eol, "use", name, ~','_x, rename / ',')
                                        | seq(eol, "use", name, ',', "only"_x, ':', "only"_x / ',');

X4_DEFINE(rename)                       = seq(eol, name, "=>", name);

X4_DEFINE(only)                         = access_id | seq(name, "=>", name);

X4_DEFINE(block_data_stmt)              = seq(eol, block, "data", ~name);

X4_DEFINE(end_block_data_stmt)          = seq(eol, "end", ~block, "data", "[", name, "]");

X4_DEFINE(interface_block)              = seq(interface_stmt, *interface_body, *module_procedure_stmt, end_interface_stmt);

X4_DEFINE(interface_stmt)               = seq(eol, "interface", ~generic_spec);

X4_DEFINE(end_interface_stmt)           = seq(eol, "end", "interface");

X4_DEFINE(interface_body)               = seq(function_stmt, ~specification_part, end_function_stmt)
                                        | seq(subroutine_stmt, ~specification_part, end_subroutine_stmt);

X4_DEFINE(module_procedure_stmt)        = seq(eol, "module", "procedure"_x, name / ',');

X4_DEFINE(generic_spec)                 = seq(name | "operator", paren(name) | "assignment", paren('='));

X4_DEFINE(external_stmt)                = seq(eol, "external", ~"::"_x, name / ',');

X4_DEFINE(intrinsic_stmt)               = seq(eol, "intrinsic", ~"::"_x, name / ',');

X4_DEFINE(function_reference)           = seq(name, paren(list(actual_arg_spec)));

X4_DEFINE(call_stmt)                    = seq("call", name, ~paren(list(actual_arg_spec)));

X4_DEFINE(actual_arg_spec)              = seq(~seq(keyword, '='), actual_arg);

X4_DEFINE(keyword)                      = name;

X4_DEFINE(actual_arg)                   = expr | variable | name | alt_return_spec;

X4_DEFINE(alt_return_spec)              = seq('*', label);

X4_DEFINE(function_stmt)                = seq(eol, ~prefix, "function", name, paren(list(name)), ~name, paren(name));

X4_DEFINE(prefix)                       = seq(type_spec, ~"recursive"_x)
                                        | seq("recursive"_x, ~type_spec);

X4_DEFINE(end_function_stmt)            = seq(eol, "end", ~"function"_x, ~name);

X4_DEFINE(subroutine_stmt)              = seq(eol, ~"recursive"_x, "subroutine", name, ~paren(list(dummy_arg)));

X4_DEFINE(dummy_arg)                    = name | '*';

X4_DEFINE(end_subroutine_stmt)          = seq(eol, "end", ~seq("subroutine", ~name));

X4_DEFINE(entry_stmt)                   = seq(eol, "entry", name, ~paren(list(dummy_arg)), ~name, paren(name));

X4_DEFINE(return_stmt)                  = seq("return", ~int_expr);

X4_DEFINE(contains_stmt)                = seq(eol, "contains");

X4_DEFINE(stmt_function_stmt)           = seq(eol, name, paren(name / ','), '=', expr);

/******************************************************************************************/

auto preprocess_file(char const *name) {
    std::stringstream ss;
    for (auto ln : io::file_lines(name)) {
        transform(ln, to_lower);
        if (io::has_content(ln, '*')) {
            auto it = io::first_nonspace(ln);
            if (*it == '$') std::copy(std::next(it), end_of(ln), std::ostream_iterator<char>(ss));
            else ss << '\n' << ln;
        }
    }
    return ss.str();
}

/******************************************************************************************/

template <class V, class P, class S>
bool phrase_parse(V const &v, P const &parse, S const &skip) {return x4::parser(parse, skip)(v);}

/******************************************************************************************/

}

}
