import re

rules = """
R201 executable-program
R202 program-unit
R1101 main-program
R203 external-subprogram
R1215 function-subprogram
R1219 subroutine-subprogram
R1104 module
R1110 block-data
R204 specification-part
R205 implicit-part
R206 implicit-part-stmt
R207 declaration-construct
R208 execution-part
R209 execution-part-construct
R210 internal-subprogram-part
R211 internal-subprogram
R212 module-subprogram-part
R213 module-subprogram
R214 specification-stmt
R215 executable-construct
R216 action-stmt
R301 character
R302 alphanumeric-character
R303 underscore
R304 name
R305 constant
R306 literal-constant
R307 named-constant
R308 int-constant
R309 char-constant
R310 intrinsic-operator
R708 power-op
R709 mult-op
R710 add-op
R712 concat-op
R714 rel-op
R719 not-op
R720 and-op
R721 or-op
R722 equiv-op
R311 defined-operator
R704 defined-unary-op
R724 defined-binary-op
R312 extended-intrinsic-op
R313 label
R401 signed-digit-string
R402 digit-string
R403 signed-int-literal-constant
R404 int-literal-constant
R405 kind-param
R406 sign
R407 boz-literal-constant
R408 binary-constant
R409 octal-constant
R410 hex-constant
R411 hex-digit
R412 signed-real-literal-constant
R413 real-literal-constant
R414 significand
R415 exponent-letter
R416 exponent
R417 complex-literal-constant
R418 real-part
R419 imag-part
R420 char-literal-constant
R421 logical-literal-constant
R422 derived-type-def
R423 private-sequence-stmt
R424 derived-type-stmt
R425 end-type-stmt
R426 component-def-stmt
R427 component-attr-spec
R428 component-array-spec
R429 component-decl
R430 structure-constructor
R431 array-constructor
R432 ac-value
R433 ac-implied-do
R434 ac-implied-do-control
R435 ac-do-variable
R501 type-declaration-stmt
R502 type-spec
R503 attr-spec
R504 entity-decl
R505 kind-selector
R506 char-selector
R507 length-selector
R508 char-length
R509 type-param-value
R510 access-spec
R511 intent-spec
R512 array-spec
R513 explicit-shape-spec
R514 lower-bound
R515 upper-bound
R516 assumed-shape-spec
R517 deferred-shape-spec
R518 assumed-size-spec
R519 intent-stmt
R520 optional-stmt
R521 access-stmt
R522 access-id
R523 save-stmt
R524 saved-entity
R525 dimension-stmt
R526 allocatable-stmt
R527 pointer-stmt
R528 target-stmt
R529 data-stmt
R530 data-stmt-set
R531 data-stmt-object
R532 data-stmt-value
R533 data-stmt-constant
R534 data-stmt-repeat
R535 data-implied-do
R536 data-i-do-object
R537 data-i-do-variable
R538 parameter-stmt
R539 named-constant-def
R540 implicit-stmt
R541 implicit-spec
R542 letter-spec
R543 namelist-stmt
R544 namelist-group-object
R545 equivalence-stmt
R546 equivalence-set
R547 equivalence-object
R548 common-stmt
R549 common-block-object
R601 variable
R602 subobject
R603 logical-variable
R604 default-logical-variable
R605 char-variable
R606 default-char-variable
R607 int-variable
R608 default-int-variable
R609 substring
R610 parent-string
R611 substring-range
R612 data-ref
R613 part-ref
R614 structure-component
R615 array-element
R616 array-section
R617 subscript
R618 section-subscript
R619 subscript-triplet
R620 stride
R621 vector-subscript
R622 allocate-stmt
R623 stat-variable
R624 allocation
R625 allocate-object
R626 allocate-shape-spec
R627 allocate-lower-bound
R628 allocate-upper-bound
R629 nullify-stmt
R630 pointer-object
R631 deallocate-stmt
R701 primary
R702 constant-subobject
R703 level-1-expr
R704 defined-unary-op
R705 mult-operand
R706 add-operand
R707 level-2-expr
R708 power-op
R709 mult-op
R710 add-op
R711 level-3-expr
R712 concat-op
R713 level-4-expr
R714 rel-op
R715 and-operand
R716 or-operand
R717 equiv-operand
R718 level-5-expr
R719 not-op
R720 and-op
R721 or-op
R722 equiv-op
R723 expr
R724 defined-binary-op
R725 logical-expr
R726 char-expr
R727 default-char-expr
R728 int-expr
R729 numeric-expr
R730 initialization-expr
R731 char-initialization-expr
R732 int-initialization-expr
R733 logical-initialization-expr
R734 specification-expr
R735 assignment-stmt
R736 pointer-assignment-stmt
R737 target
R738 where-stmt
R739 where-construct
R740 where-construct-stmt
R741 mask-expr
R742 elsewhere-stmt
R743 end-where-stmt
R801 block
R802 if-construct
R803 if-then-stmt
R804 else-if-stmt
R805 else-stmt
R806 end-if-stmt
R807 if-stmt
R808 case-construct
R809 select-case-stmt
R810 case-stmt
R811 end-select-stmt
R812 case-expr
R813 case-selector
R814 case-value-range
R815 case-value
R816 do-construct
R817 block-do-construct
R818 do-stmt
R819 label-do-stmt
R820 nonlabel-do-stmt
R821 loop-control
R822 do-variable
R823 do-block
R824 end-do
R825 end-do-stmt
R826 nonblock-do-construct
R827 action-term-do-construct
R828 do-body
R829 do-term-action-stmt
R830 outer-shared-do-construct
R831 shared-term-do-construct
R832 inner-shared-do-construct
R833 do-term-shared-stmt
R834 cycle-stmt
R835 exit-stmt
R836 goto-stmt
R837 computed-goto-stmt
R838 assign-stmt
R839 assigned-goto-stmt
R840 arithmetic-if-stmt
R841 continue-stmt
R842 stop-stmt
R843 stop-code
R844 pause-stmt
R901 io-unit
R902 external-file-unit
R903 internal-file-unit
R904 open-stmt
R905 connect-spec
R906 file-name-expr
R907 close-stmt
R908 close-spec
R909 read-stmt
R910 write-stmt
R911 print-stmt
R912 io-control-spec
R913 format
R914 input-item
R915 output-item
R916 io-implied-do
R917 io-implied-do-object
R918 io-implied-do-control
R919 backspace-stmt
R920 endfile-stmt
R921 rewind-stmt
R922 position-spec
R923 inquire-stmt
R924 inquire-spec
R1001 format-stmt
R1002 format-specification
R1003 format-item
R1004 r
R1005 data-edit-desc
R1006 w
R1007 m
R1008 d
R1009 e
R1010 control-edit-desc
R1011 k
R1012 position-edit-desc
R1013 n
R1014 sign-edit-desc
R1015 blank-interp-edit-desc
R1016 char-string-edit-desc
R1017 c
R1101 main-program
R1102 program-stmt
R1103 end-program-stmt
R1104 module
R1105 module-stmt
R1106 end-module-stmt
R1107 use-stmt
R1108 rename
R1109 only
R1110 block-data
R1111 block-data-stmt
R1112 end-block-data-stmt
R1201 interface-block
R1202 interface-stmt
R1203 end-interface-stmt
R1204 interface-body
R1205 module-procedure-stmt
R1206 generic-spec
R1207 external-stmt
R1208 intrinsic-stmt
R1209 function-reference
R1210 call-stmt
R1211 actual-arg-spec
R1212 keyword
R1213 actual-arg
R1214 alt-return-spec
R1215 function-subprogram
R1216 function-stmt
R1217 prefix
R1218 end-function-stmt
R1219 subroutine-subprogram
R1220 subroutine-stmt
R1221 dummy-arg
R1222 end-subroutine-stmt
R1223 entry-stmt
R1224 return-stmt
R1225 contains-stmt
R1226 stmt-function-stmt
"""

rules = [ln.replace('-', '_').split() for ln in rules.split('\n')]
rules = [r for r in rules if len(r) == 2]

def print_rules():
    x = len(max(rules, key=lambda r: len(r[1]))[1])
    pad = lambda r: ' ' * (x - len(r[1]))

    for r in rules:
        print('auto const ' + r[1] + pad(r) + ' = x3::rule("{}")'.format(r[0]))
    for r in rules:
        print('auto const ' + r[1] + '_def' + pad(r) + ' = ;')

    print('BOOST_SPIRIT_DEFINE({});'.format(', '.join(r[1] for r in rules)))

defs = """
is program-unit
[ program-unit ] ...
is main-program
or external-subprogram or module
or block-data
is [ program-stmt ]
[ specification-part ]
[ execution-part ]
[ internal-subprogram-part ] end-program-stmt
is function-subprogram or subroutine-subprogram
is function-stmt
[ specification-part ]
[ execution-part ]
[ internal-subprogram-part ] end-function-stmt
is subroutine-stmt
[ specification-part ]
[ execution-part ]
[ internal-subprogram-part ] end-subroutine-stmt
is module-stmt
[ specification-part ]
[ module-subprogram-part ] end-module-stmt
is block-data-stmt
[ specification-part ] end-block-data-stmt
is [ use-stmt ] ... [ implicit-part ]
[ declaration-construct ] ...
is [ implicit-part-stmt ] ... implicit-stmt
is implicit-stmt
or parameter-stmt or format-stmt
or entry-stmt
is derived-type-def
or interface-block
or type-declaration-stmt or specification-stmt
or parameter-stmt
or format-stmt
or entry-stmt
or stmt-function-stmt
is executable-construct
[ execution-part-construct ] ...
is executable-construct or format-stmt
or data-stmt
or entry-stmt
is contains-stmt internal-subprogram
[ internal-subprogram ] ... is function-subprogram
or subroutine-subprogram
is contains-stmt module-subprogram
[ module-subprogram ] ... is function-subprogram
or subroutine-subprogram
is access-stmt
or allocatable-stmt or common-stmt or data-stmt
or dimension-stmt
or equivalence-stmt or external-stmt
or intent-stmt
or intrinsic-stmt
or namelist-stmt or optional-stmt or pointer-stmt or save-stmt
or target-stmt
is action-stmt
or case-construct or do-construct
or if-construct
or where-construct
is allocate-stmt
or assignment-stmt
or backspace-stmt
or call-stmt
or close-stmt
or computed-goto-stmt
or continue-stmt
or cycle-stmt
or deallocate-stmt
or endfile-stmt
or end-function-stmt
or end-program-stmt
or end-subroutine-stmt
or exit-stmt
or goto-stmt
or if-stmt
or inquire-stmt
or nullify-stmt
or open-stmt
or pointer-assignment-stmt or print-stmt
or read-stmt
or return-stmt
or rewind-stmt
or stop-stmt
or where-stmt
or write-stmt
or arithmetic-if-stmt
or assign-stmt
or assigned-goto-stmt
or pause-stmt
is alphanumeric-character or special-character
is letter
or digit
or underscore
is _
is letter [ alphanumeric-character ] ...
is literal-constant or named-constant
is int-literal-constant
or real-literal-constant
or complex-literal-constant or logical-literal-constant or char-literal-constant
or boz-literal-constant
is name
is constant is constant
is power-op or mult-op or add-op or concat-op or rel-op
or not-op or and-op or or-op
or equiv-op
is ** is *
or / is +
or –
is //
is .eq. or .ne. or .lt.
or .le. or .gt. or .ge. or == or /= or < or <= or > or >=
is .not.
is .and.
is .or.
is .eqv.
or .neqv.
is defined-unary-op
or defined-binary-op
or extended-intrinsic-op
is .letter [letter] ...
is .letter [letter] ...
is intrinsic-operator
is digit [ digit [ digit [ digit [ digit ] ] ] ]
is [sign] digit-string
is digit [digit] ...
is [sign] int-literal-constant
is digit-string [_kind-param]
is digit-string
or scalar-int-constant-name
is +
is -
is binary-constant
or octal-constant
or hex-constant
is B'digit[digit]...'
is B"digit[digit]..."
is O'digit[digit]...'
is O"digit[digit]..."
is Z'digit[digit]...'
is Z"digit[digit]..."
is digit
or A
or B or C or D or E or F
is [sign] real-literal-constant
is significand [exponent-letter exponent][_kind-param]
or digit-string exponent-letter exponent [_kind-param]
is digit-string.[digit-string]
or .digit-string
is E
or D
is signed-digit-string
is (real-part, imag-part)
is signed-int-literal-constant or signed-real-literal-constant
is signed-int-literal-constant or signed-real-literal-constant
is [ kind-param _ ] ' [ rep-char ] ... '
or [ kind-param _ ] " [ rep-char ] ... "
is .true.[_kind-param]
is .false.[_kind-param]
is derived-type-stmt
[ private-sequence-stmt ] ... component-def-stmt
[ component-def-stmt ] ... end-type-stmt
is private
or sequence
is type [ [ , access-spec ] :: ] type-name
is end type [ type-name ]
is type-spec [ [ , component-attr-spec-list ] :: ] component-decl-list
is pointer
or dimension ( component-array-spec )
is explicit-shape-spec-list or deferred-shape-spec-list
is component-name [ ( component-array-spec ) ] [ * char-length ] is type-name ( expr-list )
is (/ ac-value-list /)
is expr
or ac-implied-do
is ( ac-value-list , ac-implied-do-control )
is ac-do-variable = scalar-int-expr , scalar-int-expr [ , scalar-int-expr ] is scalar-int-variable
is type-spec [ [ , attr-spec ] ... :: ] entity-decl-list
is integer [ kind-selector ] or real [ kind-selector ]
or double precision
or complex [ kind-selector ] or character [ char-selector ] or logical [ kind-selector ]
or type ( type-name )
is parameter
or access-spec
or allocatable
or dimension ( array-spec ) or external
or intent ( intent-spec )
or intrinsic
or optional
or pointer
or save
or target
is object-name [ ( array-spec ) ] [ * char-length ] [ = initialization-expr ] or function-name [ ( array-spec ) ] [ * char-length ]
is ( [ kind = ] scalar-int-initialization-expr )
is length-selector
or ( len = type-param-value , kind = scalar-int-initialization-expr )
or ( type-param-value , [ kind = ] scalar-int-initialization-expr )
or ( kind = scalar-int-initialization-expr [ , len = type-param-value ] )
is ( [ len = ] type-param-value ) or * char-length [ , ]
is ( type-param-value )
or scalar-int-literal-constant
is specification-expr or *
is public or private
is in
or out or inout
is explicit-shape-spec-list or assumed-shape-spec-list or deferred-shape-spec-list or assumed-size-spec
is [ lower-bound : ] upper-bound is specification-expr
is specification-expr
is [ lower-bound ] :
is :
is [ explicit-shape-spec-list , ] [ lower-bound : ] * is intent ( intent-spec ) [ :: ] dummy-arg-name-list is optional [ :: ] dummy-arg-name-list
is access-spec [ [ :: ] access-id-list ]
is use-name or generic-spec
is save [ [ :: ] saved-entity-list ] is object-name
or / common-block-name /
is dimension [ :: ] array-name ( array-spec ) #
[ , array-name ( array-spec ) ] ...
is allocatable [ :: ] array-name [ ( deferred-shape-spec-list ) ] #
[ , array-name [ ( deferred-shape-spec-list ) ] ] ...
is pointer [ :: ] object-name [ ( deferred-shape-spec-list ) ] #
[ , object-name [ ( deferred-shape-spec-list ) ] ] ...
is target [ :: ] object-name [ ( array-spec ) ] #
[ , object-name [ ( array-spec ) ] ] ... is data data-stmt-set [ [ , ] data-stmt-set ] ...
is data-stmt-object-list / data-stmt-value-list / is variable
or data-implied-do
is [ data-stmt-repeat * ] data-stmt-constant
is scalar-constant
or signed-int-literal-constant or signed-real-literal-constant or structure-constructor
or boz-literal-constant
is scalar-int-constant
is ( data-i-do-object-list , data-i-do-variable = #
scalar-int-expr , scalar-int-expr [ , scalar-int-expr ] )
is array-element
or scalar-structure-component or data-implied-do
is scalar-int-variable
is parameter ( named-constant-def-list )
is named-constant = initialization-expr
is implicit implicit-spec-list or implicit none
is type-spec ( letter-spec-list ) is letter [ – letter ]
is namelist / namelist-group-name / namelist-group-object-list # [ [ , ] / namelist-group-name / namelist-group-object-list ] ...
is variable-name
is equivalence equivalence-set-list
is ( equivalence-object , equivalence-object-list )
is variable-name or array-element or substring
is common [ / [ common-block-name ] / ] common-block-object-list # [ [ , ] / [ common-block-name ] / common-block-object-list ] ...
is variable-name [ ( explicit-shape-spec-list ) ]
is scalar-variable-name or array-variable-name or subobject
is array-element
or array-section
or structure-component or substring
is variable
is variable
is variable
is variable
is variable
is variable
is parent-string ( substring-range )
is scalar-variable-name
or array-element
or scalar-structure-component or scalar-constant
is [ scalar-int-expr ] : [ scalar-int-expr ] is part-ref [ % part-ref ] ...
is part-name [ ( section-subscript-list ) ] is data-ref
is data-ref
is data-ref [ ( substring-range ) ]
is scalar-int-expr
is subscript
or subscript-triplet or vector-subscript
is [ subscript ] : [ subscript ] [ : stride ]
is scalar-int-expr
is int-expr
is allocate ( allocation-list [ , stat = stat-variable ] ) is scalar-int-variable
is allocate-object [ ( allocate-shape-spec-list ) ] is variable-name
or structure-component
is [ allocate-lower-bound : ] allocate-upper-bound
is scalar-int-expr
is scalar-int-expr
is nullify ( pointer-object-list )
is variable-name
or structure-component
is deallocate ( allocate-object-list [ , stat = stat-variable ] )
is constant
or constant-subobject or variable
or array-constructor
or structure-constructor or function-reference or (expr)
is subobject
is [ defined-unary-op ] primary
is . letter [ letter ] ... .
is level-1-expr [ power-op mult-operand ]
is [ add-operand mult-op ] mult-operand
is [ [ level-2-expr ] add-op ] add-operand
is **
is * or /
is + or –
is [ level-3-expr concat-op ] level-2-expr is //
is [ level-3-expr rel-op ] level-3-expr
is .eq. or .ne. or .lt. or .le. or .gt. or .ge. or == or /= or < or <= or > or >=
is [ not-op ] level-4-expr
is [ or-operand and-op ] and-operand
is [ equiv-operand or-op ] or-operand
is [ level-5-expr equiv-op ] equiv-operand is .not.
is .and.
is .or.
is .eqv. or .neqv.
is [ expr defined-binary-op ] level-5-expr is . letter [ letter ] ... .
is expr
is expr
is expr
is expr
is expr
is expr
is char-expr
is int-expr
is logical-expr
is scalar-int-expr
is variable = expr
is pointer-object => target is variable
or expr
is where ( mask-expr ) assignment-stmt
is where-construct-stmt
[ assignment-stmt ] ...
[ elsewhere-stmt
[ assignment-stmt ] ... ]
end-where-stmt
is where ( mask-expr ) is logical-expr
is elsewhere
is end where
is [ execution-part-construct ] ...
is if-then-stmt block
[ else-if-stmt block ] ...
[ else-stmt block ]
end-if-stmt
is [ if-construct-name : ] if ( scalar-logical-expr ) then
is else if ( scalar-logical-expr ) then [ if-construct-name ]
is else [ if-construct-name ]
is end if [ if-construct-name ]
is if ( scalar-logical-expr ) action-stmt
is select-case-stmt [ case-stmt
block ] ... end-select-stmt
is [ case-construct-name : ] select case ( case-expr )
is case case-selector [ case-construct-name]
is end select [ case-construct-name ]
is scalar-int-expr
or scalar-char-expr
or scalar-logical-expr

is ( case-value-range-list )
or default
is case-value
or case-value :
or : case-value
or case-value : case-value
is scalar-int-initialization-expr
or scalar-char-initialization-expr
or scalar-logical-initialization-expr
is block-do-construct
or nonblock-do-construct
is do-stmt do-block
end-do
is label-do-stmt
or nonlabel-do-stmt
is [ do-construct-name : ] do label [ loop-control ]
is [ do-construct-name : ] do [ loop-control ]
is [ , ] do-variable = scalar-numeric-expr , scalar-numeric-expr [ , scalar-numeric-expr ]
or [ , ] while ( scalar-logical-expr )
is scalar-variable
is block
is end-do-stmt
or continue-stmt
is end do [do-construct-name]
is action-term-do-construct
or outer_shared_do_construct
is label-do-stmt
do-body
do-term-action-stmt
is execution-part-construct
is action-stmt
is label-do-stmt
do-body
shared-term-do-construct
is outer_shared_do_construct
or inner_shared_do_construct
is label-do-stmt
do-body
do-term-shared-stmt
is action-stmt
is cycle [do-construct-name]
is exit
is go to label
is go to ( label-list ) [ , ] scalar-int-expr
is assign label to scalar-int-variable
is go to scalar-int-variable [ [ , ] ( label-list ) ]
is if ( scalar-numeric-expr ) label , label , label
is continue
is stop [ stop-code ]
is scalar-char-constant
or digit [ digit [ digit [ digit [ digit ] ] ] ]
is pause [ stop-code ]
is external-file-unit or *
or internal-file-unit
is scalar-int-expr
is default-char-variable
is open ( connect-spec-list )
is [ unit = ] external-file-unit
or iostat = scalar-default-int-variable or err = label
or file = file-name-expr
or status = scalar-default-char-expr or access = scalar-default-char-expr or form = scalar-default-char-expr
or recl = scalar-int-expr
or blank = scalar-default-char-expr or position = scalar-default-char-expr or action = scalar-default-char-expr or delim = scalar-default-char-expr or pad = scalar-default-char-expr
is scalar-default-char-expr is close ( close-spec-list )
is [ unit = ] external-file-unit
or iostat = scalar-default-int-variable or err = label
or status = scalar-default-char-expr
is read ( io-control-spec-list ) [ input-item-list ] or read format [ , input-item-list ]
is write ( io-control-spec-list ) [ output-item-list ]
is print format [ , output-item-list ]
is [ unit = ] io-unit
or [ fmt = ] format
or [ nml = ] namelist-group-name
or rec = scalar-int-expr
or iostat = scalar-default-int-variable or err = label
or end = label
or advance = scalar-default-char-expr or size = scalar-default-int-variable
or eor = label
is default-char-expr
or label
or *
or scalar-default-int-variable
is variable
or io-implied-do
is expr
or io-implied-do
is ( io-implied-do-object-list , io-implied-do-control ) is input-item
or output-item
is do-variable = scalar-numeric-expr , scalar-numeric-expr [ , scalar-numeric-expr ]
is backspace external-file-unit
or backspace ( position-spec-list )
is endfile external-file-unit
or endfile ( position-spec-list )
is rewind external-file-unit
or rewind ( position-spec-list )
is [ unit = ] external-file-unit
or iostat = scalar-default-int-variable or err = label
is inquire ( inquire-spec-list )
or inquire ( iolength = scalar-default-int-variable ) output-item-list
is [ unit = ] external-file-unit
or file = file-name-expr
or iostat = scalar-default-int-variable
or err = label
or exist = scalar-default-logical-variable
or opened = scalar-default-logical-variable
or number = scalar-default-int-variable
or named = scalar-default-logical-variable
or name = scalar-default-char-variable
or access = scalar-default-char-variable
or sequential = scalar-default-char-variable or direct = scalar-default-char-variable
or form = scalar-default-char-variable
or formatted = scalar-default-char-variable or unformatted = scalar-default-char-variable or recl = scalar-default-int-variable
or nextrec = scalar-default-int-variable
or blank = scalar-default-char-variable
or position = scalar-default-char-variable
or action = scalar-default-char-variable
or read = scalar-default-char-variable
or write = scalar-default-char-variable
or readwrite = scalar-default-char-variable
or delim = scalar-default-char-variable
or pad = scalar-default-char-variable
is format format-specification
is ( [ format-item-list ] )
is [ r ] data-edit-desc or control-edit-desc
or char-string-edit-desc or [ r ] ( format-item-list )
is int-literal-constant
is Iw[.m] or Bw[.m] or Ow[.m] or Zw[.m]
or Fw.d
or Ew.d[Ee] or ENw.d[Ee] or ESw.d[Ee] or Gw.d[Ee] or Lw
or A[w]
or Dw.d
s int-literal-constant is int-literal-constant is int-literal-constant is int-literal-constant
is position-edit-desc or [r]/
or :
or sign-edit-desc
or kP
or blank-interp-edit-desc
is signed-int-literal-constant
is Tn or TLn or TRn or nX
is int-literal-constant
is S or SP or SS
is BN or BZ
is char-literal-constant
or c H rep-char [ rep-char ] ...
is int-literal-constant
is [ program-stmt ]
[ specification-part ]
[ execution-part ]
[ internal-subprogram-part ] end-program-stmt
is program program-name
is end [ program [ program-name ] ]
is module-stmt
[ specification-part ]
[ module-subprogram-part ] end-module-stmt
is module module-name
is end [ module [ module-name ] ]
is use module-name [ , rename-list ]
or use module-name , only : [ only-list ]
is local-name => use-name is access-id
or [ local-name => ] use-name
is block-data-stmt
[ specification-part ] end-block-data-stmt
is block data [ block-data-name ]
is end [ block data [ block-data-name ] ]
is interface-stmt
[ interface-body ] ...
[ module-procedure-stmt ] ... end-interface-stmt
is interface [ generic-spec ]
is end interface
is function-stmt
[ specification-part ]
end-function-stmt
or subroutine-stmt
[ specification-part ] end-subroutine-stmt
is module procedure procedure-name-list
is generic-name
or operator ( defined-operator ) or assignment ( = )
is external [ :: ] external-name-list
is intrinsic [ :: ] intrinsic-procedure-name-list
is function-name ( [ actual-arg-spec-list ] )
is call subroutine-name [ ( [ actual-arg-spec-list ] ) ] is [ keyword = ] actual-arg
is dummy-arg-name
is expr
or variable
or procedure-name or alt-return-spec
is * label
is function-stmt
[ specification-part ]
[ execution-part ]
[ internal-subprogram-part ] end-function-stmt
is [ prefix ] function function-name ( [ dummy-arg-name-list ] ) # [ result ( result-name ) ]
is type-spec [ recursive ] or recursive [ type-spec ]
is end [ function [ function-name ] ]
is subroutine-stmt
[ specification-part ]
[ execution-part ]
[ internal-subprogram-part ] end-subroutine-stmt
is [ recursive ] subroutine subroutine-name [ ( [ dummy-arg-list ] ) ] is dummy-arg-name
or *
is end [ subroutine [ subroutine-name ] ]
is entry entry-name [ ( [ dummy-arg-list ] ) [ result ( result-name ) ] ] is return [ scalar-int-expr ]
is contains
is function-name ( [ dummy-arg-name-list ] ) = scalar-expr
"""

defs = defs.replace('-', '_')
defs = re.sub(r'\[([^\]]*)\]', r'-\1', defs)
defs = re.sub(r'\bor\b', '|', defs)
defs = [d.strip() for d in re.split(r'\bis\b', defs)]

defs = [d.split() for d in defs if len(d.split())]

defs2 = []
for d in defs:
    s = ''
    i = 0
    while i < len(d):
        if d[i] == '-' and i + 2 < len(d) and d[i + 2] == '...':
            s += ' >> ' + d[i + 1] + ' % ' + 'x3::eol'
            i += 3
        elif d[i] == '-' and i + 1 < len(d):
            s += ' >> -' + d[i + 1]
            i += 2
        elif d[i] == '|':
            s += ' | ' + d[i + 1]
            i += 2
        elif d[i].isidentifier():
            s += ' >> ' + d[i]
            i += 1
        else:
            s += ' >> ' + d[i]
            i += 1
    defs2.append(s)

for s in defs2:
    print(s)

print(len(rules), len(defs2))
