#include "Test.h"

#include <nupack/common/Random.h>
#include <nupack/common/Runtime.h>

#include <map>
#include <fstream>

namespace nupack {

double max_test_time() {
    return lilwil::get_value("max_time").convert<double>();
}

int test_output() {
    return lilwil::get_value("verbose").convert<lilwil::Integer>();
}

bool overtime(Context const &ct) {
    return std::chrono::duration<double>(lilwil::Clock::now() - ct.start_time).count() > max_test_time();
}

}
