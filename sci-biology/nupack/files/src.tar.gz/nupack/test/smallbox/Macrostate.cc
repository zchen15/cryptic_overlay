#include <nupack/execution/Local.h>
#include <nupack/smallbox/SmallBox.h>
// #include <nupack/smallbox/OriginalSmallBox.h>
#include <nupack/jump/Jump.h>
#include <nupack/model/Model.h>

#include "../Test.h"

namespace nupack::kmc {

/******************************************************************************************/

PROTOTYPE("macro/associate-dimer") = [](Context ct) {
    //auto w = jump_state({"GGGACGAGGC", "GCCUCGUCCC"}, "..........+..........", moves::full);
    auto w = jump_state({"GAGGC", "GCCUC"}, ".....+.....");
    auto us = run_small_box(Local(8), copies(w, 500));
    // enumerate_small_box<decltype(w)>(std::move(first_of(us)));
};

PROTOTYPE("macro/small-box") = [](Context ct) {
    auto w = jump_state({"GUCGCGUCGCGUCGCUAUGCGAC"}, "..........(((((...)))))", moves::full);
                                                   //"(((((((.((...)).)))))))"
    //auto w = jump_state({"GUCGCGUCGCGUC"}, ".............", km);
    auto us = run_small_box(Local(4), copies(w, 500), 0.0002, 0.25, 100, 1000);
    // auto us, R, pfs = original_small_box(Local(4), copies(w, 500), 0.00001, 0.45, 100, 1000);

    // enumerate_small_box<decltype(w)>(std::move(first_of(us)));
};

/******************************************************************************************/

PROTOTYPE("small-box") = [](Context ct) {
    auto w = jump_state({"GGGACGAGGC", "GCCUCGUCCC"}, "..........+..........", moves::full);
    auto v = sorted(enumerate_states(w), MfeComparator());
    auto p = stationary_populations(v);
    if (test_output()) izip(v, [&](auto i, auto const &w) {print(w.dp(), w.energy, p(i));});
};

UNIT_TEST("outer-product") = [](Context ct) {
    real_col c2(2), c3(3);
    real_row r2(2), r3(3);
    real_mat m;

    m = la::outer(c2, r3);
    ct.equal(m.n_rows, 2);
    ct.equal(m.n_cols, 3);

    m = la::outer(r2, c3);
    ct.equal(m.n_rows, 2);
    ct.equal(m.n_cols, 3);

    m = la::outer(r2, r3);
    ct.equal(m.n_rows, 2);
    ct.equal(m.n_cols, 3);

    m = la::outer(c2, c3);
    ct.equal(m.n_rows, 2);
    ct.equal(m.n_cols, 3);
};

}
