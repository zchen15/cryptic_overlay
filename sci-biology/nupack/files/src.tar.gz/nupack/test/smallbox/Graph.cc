#include <nupack/kmc/Graph.h>
#include <nupack/kmc/Run.h>
#include <nupack/kmc/Timer.h>
#include <nupack/jump/Jump.h>
#include <nupack/model/Model.h>
#include <nupack/types/Database.h>

#include "../Test.h"

#include <boost/graph/boyer_myrvold_planar_test.hpp>

namespace nupack { namespace kmc {

/******************************************************************************************/

PROTOTYPE("graph/state") = [](Context ct) {
    auto c = EnergyDatabase("mfe-rna95-none-ms.json")[5];
    auto w = jump_state(c.first, c.second.structure);
    auto gm = GraphMaker();
    runner()(w, 0.01, gm);
    print(len(gm));
    std::ofstream of("graph2.dot");
    gm.write_graphviz(of);
    print(boost::boyer_myrvold_planarity_test(gm.graph));
};

/******************************************************************************************/

UNIT_TEST("graph/loop") = [](Context ct) {
    auto c = maximum(EnergyDatabase("mfe-rna95-none-ms.json"), [](auto const &p) {return len(p.first);});
    auto w = jump_state(c.first, c.second.structure);
    auto g = LoopGraph(w);
    if (test_output()) g.write(io::out());
    ct.require(true);
};

/******************************************************************************************/

PROTOTYPE("graph/loop") = [](Context ct) {
    auto c = EnergyDatabase("mfe-rna95-none-ms.json")[5];
    auto w = jump_state(c.first, c.second.structure);

    auto lgm = LoopGraphMaker(w);
    runner()(w, Timer::with_max_step(1000), lgm);

    lgm.write("test_");

    // from glob import glob
    // from subprocess import check_call
    //
    // for i in glob('*.dot'):
    //     args = ['dot', '-Tpng', '-Kneato', i, '-o', i.replace('.dot', '.png')]
    //     check_call(args)
};

/******************************************************************************************/

}}
