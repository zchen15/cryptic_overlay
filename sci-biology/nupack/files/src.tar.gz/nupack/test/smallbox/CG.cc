#include "../Test.h"

#include <nupack/jump/Jump.h>
#include <nupack/model/Model.h>

#include <nupack/types/Matrix.h>
#include <nupack/types/IO.h>

#include <nupack/markov/RandomNetwork.h>
#include <nupack/markov/Lumping.h>
#include <nupack/markov/Enumerate.h>

#include <nupack/kmc/Pairing.h>
#include <nupack/kmc/Timer.h>
#include <nupack/kmc/Run.h>

namespace nupack {

PROTOTYPE("network") = [](Context ct) {
    print("network");
    auto g = RandomRateNetwork(40, 150, 100.0, 5.0);
    g.write_graphviz(io::out());
    Mat<double> m(40, 40);
    g.fill_rate_matrix(m);
    print(m);
    print(arma::eig_gen(m));
};

/******************************************************************************************/

PROTOTYPE("commute_time") = [](Context ct) {
    auto w0 = jump_state({"AAAACGUUCGGUUACC"}, "..(((.....)))...", moves::full);
    auto w  = jump_state({"AAAACGUUCGGUUACC"}, "................", moves::full);
    auto trigger = [&](auto const &w, auto) {return w == w0;};
    auto timer = kmc::Timer();
    auto log = [&](auto const &w, auto) {print(w.dp()); return true;};
    kmc::runner()(w, trigger, timer, log);
    print(timer.step);
};

/******************************************************************************************/

PROTOTYPE("vectorization") = [](Context ct) {
    vec<double> s(1020004);
    for (auto & i : s) i = int(i) % int(2 * i - i / 2 + 7);

    print(time_it([&]{
        std::size_t i = 0; auto b = begin_of(s) + 1;
        for (; b < end_of(s) - 1; ++i, b += 4) {*b = std::exp(i);}
    }));
};

/******************************************************************************************/

PROTOTYPE("lumping/1") = [](Context ct) {
    SortedRates::RateTuples rates = {
        std::make_tuple(0, 1, 0.625),
        std::make_tuple(0, 2, 0.35),
        std::make_tuple(0, 0, 0.5783),
        std::make_tuple(1, 0, 0.23),
        std::make_tuple(1, 2, 0.15),
        std::make_tuple(1, 1, 0.938),
        std::make_tuple(2, 0, 0),
        std::make_tuple(2, 1, 0.58),
        std::make_tuple(2, 2, 0.987)
    };
    auto r = SortedRates(rates);
    BEEP(r);
    auto lump = ExactLumper(3);
    BEEP(lump);
    lump(r);
    BEEP(lump);
};

/******************************************************************************************/

PROTOTYPE("spsolve") = [](Context ct) {
    arma::sp_mat A(4, 4);
    A(0, 0) = 1;
    A(1, 1) = 1;
    A(2, 2) = 1;
    A(3, 3) = 1;
    arma::vec b = {1, 2, 3, 4};
    arma::vec x = {0./0., 0, 0, 0};
    spsolve(x, A, b);
    print(x);
};

/******************************************************************************************/

PROTOTYPE("lumping/2") = [](Context ct) {
    SortedRates::RateTuples rates = {
        std::make_tuple(0, 0, 1.0/3),
        std::make_tuple(0, 1, 1.0/2),
        std::make_tuple(0, 2, 1.0/6),
        std::make_tuple(1, 0, 1.0/2),
        std::make_tuple(1, 1, 1.0/2),
        std::make_tuple(1, 2, 0.0),
        std::make_tuple(2, 0, 1.0/4),
        std::make_tuple(2, 1, 1.0/2),
        std::make_tuple(2, 2, 1.0/4)
    };
    auto r = SortedRates(rates);
    BEEP(r);
    auto lump = ExactLumper(3);
    BEEP(lump);
    lump(r);
    BEEP(lump);
};

PROTOTYPE("lumping/3") = [](Context ct) {
    SortedRates::RateTuples rates = {
        std::make_tuple(0, 0, 1.23/43),
        std::make_tuple(0, 1, 1.23/2),
        std::make_tuple(0, 2, 1.23/64),
        std::make_tuple(1, 0, 1.23/2),
        std::make_tuple(1, 1, 1.23/2),
        std::make_tuple(1, 2, 0.23),
        std::make_tuple(2, 0, 1.23/42),
        std::make_tuple(2, 1, 1.23/21),
        std::make_tuple(2, 2, 1.23/4)
    };
    auto r = SortedRates(rates);
    BEEP(r);
    auto lump = ExactLumper(3);
    BEEP(lump);
    lump(r);
    BEEP(lump);
};

/******************************************************************************************/

PROTOTYPE("lumping/4") = [](Context ct) {
    auto v = enumerate_states(jump_state("UCGAATCTAGCCG", {}, moves::full));
    BEEP(len(v));
    auto p = stationary_populations(v);
    auto rates = rate_tuples_from_states(v);
    rates.erase(begin_of(rates), begin_of(rates) + len(v));
    auto r = SortedRates(rates);
    auto lump = ExactLumper(len(v));
    BEEP(lump);
    lump(r);
    BEEP(lump);
};

/******************************************************************************************/

}
