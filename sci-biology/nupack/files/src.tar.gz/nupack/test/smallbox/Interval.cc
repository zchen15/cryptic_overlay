#include <nupack/smallbox/Methods.h>
#include <nupack/smallbox/Scanner.h>

#include <nupack/model/Model.h>

#include <nupack/kmc/Pairing.h>
#include <nupack/kmc/Timer.h>
#include <nupack/kmc/MFE.h>
#include <nupack/kmc/FreeEnergy.h>
#include <nupack/kmc/JoinPropensity.h>
#include <nupack/kmc/Run.h>

#include <nupack/jump/Jump.h>
#include <nupack/execution/Local.h>

#include "../Test.h"
#include <nupack/types/Database.h>

namespace nupack::kmc {

UNIT_TEST("smallbox/intervals") = [](Context ct) {
    auto t = std::make_tuple(PairInterval<arma::mat>());
    auto x = get(t, pair_probability());

    auto u = std::make_tuple(TimeInterval());
    auto y = get(u, sample_time());

    auto z2 = get(std::make_tuple(TimeInterval()), sample_time());

    auto u2 = std::make_tuple(MfeInterval<JumpState<>>());
    if (false) auto y2 = get(u2, mfe_state()); // would segfault, just checking the compilation
};

/******************************************************************************************/

UNIT_TEST("smallbox/counters/free-energy") = [](Context ct) {
    ct.info("Collect all unique states to calculate approximate free energy");
    auto w = jump_state({"AAAAT"}, ".....");
    FreeEnergyIntegrator fe(w.model.beta);
    auto Timer = Timer::with_max_time(0.01);
    runner()(w, Timer, fe);
    auto result = fe.next();
    if (test_output()) print_lns(w.sequence(), result);
};

/******************************************************************************************/

UNIT_TEST("smallbox/n_windows") = [](Context ct) {
    auto c = EnergyDatabase("mfe-rna95-none-ss.json")[4];
    auto w0 = jump_state(c.first, c.second.structure, moves::full, Ensemble::none);

    auto scan = scanner(0, Timer::with_max_time(0.0001));
    run_until(w0, [&](Ignore, Ignore){return scan.good() && len(scan) > 3;}, std::tie(scan));
    ct.equal(len(scan), 4, "number of windows should be 4");
    if (test_output()) {
        for (auto &&w : scan.intervals(sample_time())) print(w);
    }
};

/******************************************************************************************/

PROTOTYPE("smallbox/last2-stable") = [](Context ct) {
    auto const w = jump_state("ATCGTAGCTAG", "...........", moves::full, Ensemble::none);

    auto const scan = scanner(0, Timer::with_max_time(0.0001), PairIntegrator<Mat<real>>(),
        MfeRecorder<JumpState<>>(1), JoinPropensityIntegrator(), FreeEnergyIntegrator(w.model.beta));

    auto v = Local().map(2, 1, [&](auto const &...) {
        auto s = scan;
        auto stop = [&](Ignore, Ignore) {return s.good() && pair_probability_l1(last_n(s, 2)) < 0.05;};
        runner()(copy(w), stop, s);
        return join_intervals(last_n(s, 2));
    });
    if (test_output()) {
        for (auto const &x : v) print(x);
        for (auto &&w : scan.intervals(sample_time())) print(w);
    }
};

/******************************************************************************************/

PROTOTYPE("smallbox/log2-stable") = [](Context ct) {
    Local ex(4);
    auto c = EnergyDatabase("mfe-rna95-none-ss.json")[4];
    auto const w = jump_state(c.first, c.second.structure, moves::full, Ensemble::none);

    auto const scan = scanner(0, Timer::with_max_time(0.0001), PairIntegrator<Mat<double>>(),
                             MfeRecorder<JumpState<>>(1), JoinPropensityIntegrator(), FreeEnergyIntegrator(w.model.beta));

    if (test_output()) print(w.sequence());
    auto v = ex.map(10, 1, [&](auto const &...) {
        auto s = scan;
        auto stop = [&] (Ignore, Ignore) -> usize {
            if (!s.good()) return 0;
            return log_scan(s, [](auto const &v){return pair_probability_l1(v) < 0.05;});
        };

        auto n = runner()(copy(w), stop, s);
        static_assert(std::is_arithmetic<decltype(n)>::value, "should not be bool");
        return join_intervals(last_n(s, 2 * n));
    });
    if (test_output()) print(v);
};

/******************************************************************************************/

UNIT_TEST("smallbox/approx-pair-probability") = [](Context ct) {
    auto c = EnergyDatabase("mfe-rna95-none-ms.json")[4];
    auto w = jump_state(c.first, c.second.structure, moves::full);
    auto ppc = PairIntegrator<real_mat>();
    auto Timer = Timer::with_max_time(0.1);
    runner()(w, Timer, ppc);
    //ct.info(Timer.next());
    auto result = get(ppc.next(), pair_probability());
    ct.equal(la::esum(result), about(w.n_bases()), result);
};

/******************************************************************************************/

}
