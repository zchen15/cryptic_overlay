
'''
The following is used to import the top-level nupack module
no matter what name it is actually called.

Test modules should just
- import the 'nu' name from here
- import using import_nupack('name.of.submodule')
'''

from importlib import import_module
from .. import __name__ as root

def import_nupack(name=''):
    return import_module('%s.%s' % (root, name) if name else root)

nu = import_nupack()


