import numpy

'''
This file was used to test the interior loop backtracking order and make sure
it is consistent with the forward N^4 results
'''

# return A.total(range(5, min(1e10-3, j-i-8)), [=, &Q, &t](auto s) {
#     cspan R(5, min(1e10+2-s, j-i-s-3));
#     return A.dot(Q.YA(R+i, j-s), t.int_size(R+s-2), t.int_asym(s, R));

def ss_forward(i, j):
    for s in range(5, j-i-8):
        for r in range(5, j-i-s-3):
            yield (i+r, j-s, r+s-2, s, r)


# return A.total(range(10, min(1e10+2, j-i-3)), [=, &Q, &t](auto z) {
#     return A.total(range(5, z-4), [=, &Q, &t](auto s) {
#         return A.product(Q.YA(i+s, j+s-z), t.int_size(z-2), t.int_asym(s, z-s));

def ss_backward(i, j):
    for z in range(10, j-i-3):
        for s in range(5, z-4):
            yield (i+z-s, j-s, z-2, s, z-s)


# return A.total(range(5, min(1e10-3, j-n+1)), [=, &Q, &t] (auto s) {
#     cspan R(5, min(1e10+2-s, m-i));
#     return A.dot(Q.YA(R+i, j-s), t.int_size(R+s-2), t.int_asym(s, R));

def ms_forward_old(i, j, m, n):
    for s in range(5, j-n+1):
        for r in range(5, m-i):
            yield (i+r, j-s, r+s-2, s, r)

# return A.total(range(10, min(1e10+2, j-n+m-i)), [=, &Q, &t](auto z) {
#     return A.total(range(5, min(z-4, m-i+1)), [=, &Q, &t](auto s) {
#         return A.product(Q.YA(i+s, j+s-z), t.int_size(z-2), t.int_asym(s, z-s));

def ms_forward(i, j, m, n):
    for s in range(5, min(1e10-3, j-n+1)):
        for r in range(5, min(1e10+2-s, m-i)):
            yield (i+r, j-s, r+s-2, s, r)

def ms_backward_old(i, j, m, n):
    for z in range(10, j+m+1-n-i):
        for r in range(max(5, z+n-j), min(z-4, m-i)):
            yield (i+r, j+r-z, z-2, z-r, r)

def ms_backward(i, j, m, n):
    for z in range(10, min(100000000, j+m+1-n-i)):
        for r in range(max(5, z-j+n), min(z-4, m-i)):
            yield (i+r, j+r-z, z-2, z-r, r)


def test_iloops(iters=1000):
    for it in range(iters):
        i, j = sorted(numpy.random.randint(0, 50, size=2))
        x, y = sorted(ss_forward(i, j)), sorted(ss_backward(i, j))
        assert x == y, (set(x).difference(y), set(y).difference(x))
        # print(it, end='\r')


    for it in range(iters):
        i, m, n, j = sorted(numpy.random.randint(0, 30, size=4))
        if i == m:
            continue
        x, y = sorted(ms_forward(i, j, m, n)), sorted(ms_backward(i, j, m, n))
        assert x == y, (i, m, n, j, set(x).difference(y), set(y).difference(x))
        # print(it, end='\r')
