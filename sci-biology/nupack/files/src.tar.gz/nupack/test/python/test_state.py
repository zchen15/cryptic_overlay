from . import nu

def test_state():
    mod = nu.Model(ensemble='min')
    assert 0 == nu.kmc.State('AAA', model=mod).calculate_energy(mod)
    assert 0 == nu.kmc.State('AAA', model=mod, kind='static', dp='...').calculate_energy(mod)
    assert 0 == nu.kmc.State('AAA', model=mod, dp='...').calculate_energy(mod)
    assert 0 == nu.kmc.State(['AAA'], model=mod, dp='...').calculate_energy(mod)
