import numpy as np
from . import nu
from concurrent.futures import ThreadPoolExecutor

def disabled_test_dots():
    nc = 1
    poisson  = 1.2
    af_alpha = (0.5, 0.6)[:nc]
    af_beta  = (2, 3)[:nc]
    detect   = (0.8, 0.7)[:nc]
    f_alpha  = (2.8, 3.1)[:nc]
    f_beta   = (3, 2)[:nc]
    sigma    = np.array([(0.05, 0.5)] * 3).T

    # args= (, 8, 6, , sigma, [nu.numeric.Gamma(a, b) for a, b in zip(af_alpha, af_beta)], detect, f_alpha, f_beta)


    data = nu.dots.random_data(n=int(1e4), sites=nu.numeric.Poisson(poisson),
        sigma=sigma, af=[nu.numeric.Gamma(a, b) for a, b in zip(af_alpha, af_beta)],
        detect=detect, alpha=f_alpha, beta=f_beta)

    # print(data.distances)
    # print(data.intensities)

    print(np.shape(data.intensities), np.shape(data.positions))

    sampler = nu.dots.DotSampler(data.intensities, data.positions)

    print(sampler.minimize(poisson, sigma, af_alpha, af_beta, detect, f_alpha, f_beta))
    x0 = np.array([poisson] + list(np.array([af_alpha, af_beta, detect, f_alpha, f_beta])[:, :nc].flatten()))

    put = lambda s, x: print(s, ' '.join('%5.3f' % i for i in x), sep='\n')

    put('x0', x0)
    ps = sampler.result(True)
    # put('minimized', ps)

    import time

    iters = 1000

    start = time.time()
    with ThreadPoolExecutor(4) as ex:
        jobs = [ex.submit(lambda: sampler.sample(iters, x0, 0.005 * x0, sigma, beta=1)[1:]) for _ in range(16)]
        results = [j.result() for j in jobs]

    # results = [sampler.sample(iters, x0, 0.005 * x0, sigma, beta=1) for _ in range(16)]

    print('Time', time.time() - start)

    mu, cov, n = map(sum, zip(*results))

    print('Acceptance', n / (16 * iters))


    mu, cov = mu/n, cov/n
    cov -= np.outer(mu, mu)

    std = np.sqrt(np.diagonal(cov))

    put('mean', mu)
    put('std', std)


if __name__ == '__main__':
    test_dots()
