# Files

In input there are four files:

1. `example.in`
2. `struc_example.in`
3. `complexes_input.con`
4. `complexes_input.in`

File 1 is to be used with scripts `pfunc`, `count`, `mfe`, `pairs`, `sample`, and `subopt`. `pfunc` and `count` do not emit files, but the others do when run with an input file. File 2 is used with the scripts `energy` and `prob`. Files 3 and 4 together are run with the scripts `complexes` and `concentrations`.
