PREFIX=nupack/scripts

$PREFIX/complexdefect -mfe input/struc_example
$PREFIX/complexdefect -multi -temperature 25 -material dna -mfe input/struc_example
$PREFIX/complexdefect -multi -temperature 25 -material dna input/struc_example
$PREFIX/complexdefect input/struc_example
$PREFIX/complexes -material DNA -sodium 1.0 -magnesium 0.0 -temperature 25 -dangles some -cutoff 0.0001 -pairs -mfe -concentrations -quiet input/complexes_input
$PREFIX/complexes -material DNA -sodium 1.0 -magnesium 0.0 -temperature 25 -dangles some -cutoff 0.0001 -pairs -mfe -concentrations input/complexes_input
$PREFIX/concentrations input/complexes_input
$PREFIX/count -multi -temperature 25 -material dna input/example
$PREFIX/energy -multi -temperature 25 -material dna input/struc_example
$PREFIX/mfe -multi -temperature 25 -material dna input/example
$PREFIX/pairs -multi -temperature 25 -material dna input/example
$PREFIX/pairs -multi -temperature 25 -material dna -dangles some input/example
$PREFIX/pfunc -multi -temperature 25 -material dna input/example
$PREFIX/prob -multi -temperature 25 -material dna input/struc_example
$PREFIX/prob -temperature 25 -material dna input/struc_example
$PREFIX/sample -multi -temperature 25 -material dna input/example
$PREFIX/sample -multi -temperature 25 -material dna -samples 100000 input/example
$PREFIX/sample -multi -temperature 25 -material dna -samples 1000 input/example
$PREFIX/sample -multi -temperature 25 -material dna -samples 1 input/example
$PREFIX/sample -multi -temperature 25 -material dna -samples 10 input/example
$PREFIX/sample -multi -temperature 25 -material dna -samples 100 input/example
$PREFIX/subopt -multi -temperature 25 -material dna -gap 1.0 input/example
$PREFIX/subopt -multi -temperature 25 -material dna -gap 2.0 input/example

mv input/complexes_input.eq input/complexes_input.ocx input/complexes_input.ocx-key input/complexes_input.ocx-mfe input/complexes_input.ocx-ppairs input/example.mfe input/example.ppairs input/example.sample input/example.subopt output/
colordiff -r reference output
