cmds = '''complexdefect -mfe input/struc_example
complexdefect -multi -temperature 25 -material dna -mfe input/struc_example
complexdefect -multi -temperature 25 -material dna input/struc_example
complexdefect input/struc_example
complexes -material DNA -sodium 1.0 -magnesium 0.0 -temperature 25 -dangles some -cutoff 0.0001 -pairs -mfe -concentrations -quiet input/complexes_input
complexes -material DNA -sodium 1.0 -magnesium 0.0 -temperature 25 -dangles some -cutoff 0.0001 -pairs -mfe -concentrations input/complexes_input
concentrations input/complexes_input
count -multi -temperature 25 -material dna input/example
energy -multi -temperature 25 -material dna input/struc_example
mfe -multi -temperature 25 -material dna input/example
pairs -multi -temperature 25 -material dna input/example
pairs -multi -temperature 25 -material dna -dangles some input/example
pfunc -multi -temperature 25 -material dna input/example
prob -multi -temperature 25 -material dna input/struc_example
prob -temperature 25 -material dna input/struc_example
sample -multi -temperature 25 -material dna input/example
sample -multi -temperature 25 -material dna -samples 100000 input/example
sample -multi -temperature 25 -material dna -samples 1000 input/example
sample -multi -temperature 25 -material dna -samples 1 input/example
sample -multi -temperature 25 -material dna -samples 10 input/example
sample -multi -temperature 25 -material dna -samples 100 input/example
subopt -multi -temperature 25 -material dna -gap 1.0 input/example
subopt -multi -temperature 25 -material dna -gap 2.0 input/example'''.split('\n')

cmds = [c.split() for c in cmds]

for c in cmds:
    print(c)


# mv input/complexes_input.eq input/complexes_input.ocx input/complexes_input.ocx-key input/complexes_input.ocx-mfe input/complexes_input.ocx-ppairs input/example.mfe input/example.ppairs input/example.sample input/example.subopt output/
# colordiff -r reference output
