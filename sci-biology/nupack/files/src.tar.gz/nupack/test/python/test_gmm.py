
from . import nu
import numpy as np
from scipy.stats import multivariate_normal as normal

def test_gmm():
    n = 2
    # I = (65535 * np.random.random([10, 12, 14])).astype(np.uint16)
    I = np.random.random([10, 12, 14])
    grid = [np.linspace(0, 2 + np.random.random(), i) for i in I.shape]
    locs = np.array([(i, j) for i in range(n) for j in range(i+1, n)]).T
    # locs = np.ndarray([0, 0])
    # input()


    def objective(M, disp=False, return_b=False, return_a=False, return_off=False):
        mesh = np.meshgrid(*grid, indexing='ij')
        pts = np.asarray([g.flatten() for g in mesh]).T

        funcs = [normal(mean=m, cov=np.diag(s**2)) for m, s in zip(M[0].T, M[1].T)]
        disp and print(len(funcs))
        disp and print('b')
        b = np.array([(I.ravel() * f.pdf(pts)).sum() for f in funcs])
        disp and print(b)


        disp and print('A')
        A = np.array([[(f.pdf(pts) * g.pdf(pts)).sum() for f in funcs] for g in funcs])
        disp and print(A)

        x = np.linalg.solve(A, b)
        ob = x @ A @ x - 2 * b @ x
        disp and print('Exact objective', ob)
        if return_b:
            return b[0]
        if return_a:
            return A[0, 0]
        if return_off:
            return A[0, 1]
        return ob

    M = 1 + np.random.random([2, 3, n])
    # M[0, 0, 0] +=
    objective(M, disp=True)

    for dx in (1e-5, 1e-8, 1e-10)[:1]:
        P = M.copy()
        P[0, 1, 0] -= dx
        o0 = objective(P)
        P = M.copy()
        P[0, 1, 0] += dx
        o2 = objective(P)

        print('Calculated gradient', (o2 - o0) / (2 * dx))

        P = M.copy()
        P[1, 1, 0] -= dx
        o0 = objective(P)
        P = M.copy()
        P[1, 1, 0] += dx
        o2 = objective(P)
        print('Calculated gradient', (o2 - o0) / (2 * dx))

    results = []
    for i in range(1):
        obj, x, grad = nu.numeric.gmm_squared_loss(I, M, grid, locs)
        print('Gradient', grad[:, 1, 0])
        ii = ((I.astype(float))**2).sum()
        print('Objective', obj, 'x', x)#, 'gradient', grad, sep='\n')
        print('Best', ii, obj/ii)
        results.append(obj)

    print(results)
