#include <nupack/flow/Subgraph.h>
#include <nupack/flow/Exact.h>

#include <nupack/state/State.h>
#include <nupack/kmc/Run.h>
#include <nupack/kmc/Timer.h>

#include <nupack/standard/Flat.h>
#include <nupack/execution/Local.h>
#include <nupack/external/SDD.h>
#include "../Test.h"

#include <chrono>
#include <thread>

namespace nupack {

PROTOTYPE("flow") = [](Context ct) {
    SddSolver matlab("superlu", "lamg");
    la::Solver arma("lapack");
    auto km = Model(Ensemble::none);

    //W a("CTAGTCGATCGACTGATCACGATCGTAGCTTA", PairList(), km);
    //W b = a.with_structure(".....((((((........)))))).......");

    //W a("GUUGGCCAGAACCAACGCUGGGUUGCACCAAUGUGG", ".....((((........))))......(((...)))", km);
    //W b = a.with_structure("(((((......)))))..(((......)))......");

    auto const a = jump_state("CGGCGGCGCGGCGGCGAAACGCCGCCG", "((((((((...........))))))))", moves::full, km);
    auto const b = a.with_structure("........((((((((...))))))))");

    //W a("AAAAGCTAGCTAGCTGACTGACTAAT");
    //W b = a.with_structure("...((((....))))...........");

    //W a({"AAAAAAAATTTTTTTT"}, "", km);
    //W b = a.with_structure("..(((((....)))))");
    auto R_bcs = separated_system(a, b);
    //Subgraph<W> subgraph(50000);
    //subgraph.run_milestone_1(a, b, arma);
    //print("Sizes:", len(subgraph), len(ws));

    auto flow = enumerated_flow(std::move(R_bcs.first), std::move(R_bcs.second), matlab);
    print("Exact commute time =", flow.second);

    // Col<double> ge(len(ws)), gs(len(ws)); ge.zeros(); gs.zeros();
    // gs.head(subgraph.g.n_elem) = subgraph.g;

    // std::set<PairList> lookup;
    // auto ps = indirect_view(ws, &W::pairs);
    // for (auto const &p : ps) lookup.emplace_hint(end_of(lookup), p);

    // vec<usize> e_to_s(ge.n_elem);

    // for (auto i : enumerate(subgraph.states)) {
    //     auto ie = binary_search_index(ws, *i);
    //     e_to_s[ie] = i;
    //     if (bcs.count(ie)) ie = bcs.find(ie) - begin_of(bcs);
    //     else ie += (end_of(bcs) - bcs.lower_bound(ie));
    //     ge(i) = flow.first(ie);
    //     lookup.erase(i->pairs);
    // }

    // for (auto i : enumerate(lookup)) {
    //     auto ie = binary_search_index(ps, *i);
    //     e_to_s[ie] = i + len(subgraph);
    //     ie += (end_of(bcs) - bcs.lower_bound(ie));
    //     ge(i + len(subgraph)) = flow.first(ie);
    // }

    // ge.save("enumerated-g.txt", arma::raw_ascii);
    // gs.save("subgraph-g.txt", arma::raw_ascii);
    // // Output g indexed as subgraph, R indexed as subgraph

    // std::ofstream ofs("R.txt"); ofs << std::setprecision(40);
    // for_each_rate(ws, [&](auto i, auto j, auto r) {
    //     ofs << e_to_s[i] + 1 << " " << e_to_s[j] + 1 << " " << r << "\n";
    // });

    // Col<double> st = stationary_populations(ws), st2(len(ws));
    // st2.zeros(); st2 /= 0.0;

    // for (auto i : enumerate(e_to_s)) st2(*i) = st(i);

    // st2.save("stationary.txt", arma::raw_ascii);
};

PROTOTYPE("matlab-flow") = [](Context ct) {
    auto a = jump_state("AAAAGCTAGCTAGCTGACTGACTAAT", {}, moves::full);
    auto b =  a.with_structure("...((((....))))...........");

    auto R_bcs = separated_system(a, b);

    auto test = [&](auto &&solve) {
        solve.wait();
        auto g = enumerated_flow(R_bcs.first, R_bcs.second, solve, echo);
        return g.second;
    };

    print("lamg", test(SddSolver("superlu", "lamg")));
    print("cmg ", test(SddSolver("superlu", "cmg")));
    print("arma", test(la::Solver("superlu")));
};

PROTOTYPE("sdd-partial-inverse") = [](Context ct) {
    Model mod(Ensemble::min, ParameterFile("DNA"), ModelConditions{298.15}, {}, WobblePairing::off);
    auto w = jump_state("CCTATAGGAGAAACCTATAGGAAGACCTATAGG", {}, moves::full, std::move(mod));
    vec<JumpState<>> ws;
    ws.emplace_back(w.with_structure("((((((((.....))))))))....((....))"));
    ws.emplace_back(w.with_structure("((....)).....((((((((....))))))))"));
    ws.emplace_back(w.with_structure("((((((((.....((....))....))))))))"));

    // auto w = jump_state("AAAAGCTAGCTAGCTGA", {}, moves::full);
    // vec<JumpState<>> ws;
    // ws.emplace_back(w);
    // ws.emplace_back(ws[0].with_structure("...((((....)))).."));

    {auto S = enumerated_partial_inverse(SddSolver("lapack", "cmg", 50), ws); BEEP(S);}
    {auto S = enumerated_partial_inverse(SddSolver("lapack", "lamg", 50), ws); BEEP(S);}
    {auto S = enumerated_partial_inverse(SddSolver("superlu", "cmg", 1e12), ws); BEEP(S);}
    // {auto S = enumerated_partial_inverse(SddSolver("lapack", "cmg", 1e10), ws); BEEP(S);}
};

PROTOTYPE("partial-inverse") = [](Context ct) {
    SddSolver matlab("superlu", "lamg", 50);
    matlab.wait();
    la::Solver arma("superlu");

    //vec<JumpState<>> ws = {jump_state(    "AAAAGCTAGCTAGCTGACTGACTAAT", moves::full)};
    //ws.emplace_back(ws[0].with_structure("...((((....))))..........."));
    auto w = jump_state("AAAAGCTAGCTAGCTGA", {}, moves::full);
    vec<JumpState<>> ws;
    ws.emplace_back(w);
    ws.emplace_back(ws[0].with_structure("...((((....)))).."));

    auto const Rpi1 = all_rates<real_mat>(ws, 0);
    BEEP(rank(first_of(Rpi1)), la::shape(first_of(Rpi1)));

    auto const pi = second_of(Rpi1);
    auto const Se = la::eval(fundamental_from_rates(first_of(Rpi1), pi) * diagmat(1 / pi));
    auto const S1 = partial_inverse(first_of(Rpi1), pi, third_of(Rpi1));

    auto const Rpi2 = all_rates<real_csc>(ws, 0);
    auto const S2 = partial_inverse(first_of(Rpi2), second_of(Rpi2), third_of(Rpi2), matlab);

    izip(third_of(Rpi1), [&](auto a, auto b) {
        for (auto i : indices(pi))
            print(Se(i, b), S1(i, a), S2(i, a));
    });

    Col<arma::uword> idx(len(third_of(Rpi2)));
    izip(third_of(Rpi2), [&](auto i, auto j) {idx(i) = j;});
    print("Se");
    la::eval(la::eval(Se.rows(idx)).cols(idx)).raw_print(io::out());
    print("S1");
    la::eval(S1.rows(idx)).raw_print(io::out());
    print("S2");
    la::eval(S2.rows(idx)).raw_print(io::out());
};

PROTOTYPE("biggish-flow") = [](Context ct) {
    auto km = Model(Ensemble::none);

    la::Solver arma("superlu");
    SddSolver matlab("superlu", "lamg", 50);

    // vec<JumpState<><typename km::Ensemble>> ws = {jump_state("CGGCGGCGCGGCGGCGAAACGCCGCCG", "((((((((...........))))))))", km)};
    // ws.emplace_back(                           ws[0].with_structure("........((((((((...))))))))"));

    vec<JumpState<>> ws = {jump_state("GGCCGGGGCCGGAAACCGGCC", "((((((.........))))))", moves::full, km)};
    ws.emplace_back(                     ws[0].with_structure("......((((((...))))))"));


    auto const t = all_rates<real_mat>(ws, 0.0);
    unpack(t, [&](auto const &R, auto const &pi, auto const &index) {
        auto S = partial_inverse(R, pi, index);
        Col<arma::uword> idx(len(index));
        izip(index, [&](auto i, auto j) {idx(i) = j;});
        BEEP(norm(S.t() * pi));
        BEEP(norm(R.t() * pi));
        BEEP(norm(arma::abs(R).t() * pi));
        BEEP(norm(arma::abs(S).t() * pi));
        la::eval(S.rows(idx)).raw_print(io::out());
        //BEEP(S);
    });
};

PROTOTYPE("hard-flow-cmg") = [](Context ct) {
    SddSolver matlab("superlu", "cmg");

    auto y = std::make_shared<System const>("ACGTGATCGTAGCTAGCTGATGCTAGCTAGCTAGCTACGATCGTACGTAGCTGATCGATCGTACGTAGCTAGCTAGGGATGTACGT");
    auto a = jump_state(y, "((((((((((((((((((..........))))))))))))))..))))...........(((((................))))).", moves::full);
    auto b = jump_state(y, "((((.(((..(((((((....)))))))(((((((((((((((..(......)..)))))))....))))))))...)))..))))", moves::full);

    auto R_bcs = separated_system(a, b);

    matlab.wait();
    auto flow = enumerated_flow(std::move(R_bcs.first), std::move(R_bcs.second), matlab);
    print("MATLAB commute time =", flow.second);
};

PROTOTYPE("hard-flow-subgraph") = [](Context ct) {
    //la::Solver sdd;
    SddSolver sdd("superlu", "lamg", 1000);

    auto a = jump_state("AAAAGCTAGCTAGCTGACTGACTAAT", {}, moves::full);
    auto b =  a.with_structure("...((((....))))...........");


//    auto y = std::make_shared<System const>("ACGTGATCGTAGCTAGCTGATGCTAGCTAGCTAGCTACGATCGTACGTAGCTGATCGATCGTACGTAGCTAGCTAGGGATGTACGT");
//    auto a = jump_state(y, "((((((((((((((((((..........))))))))))))))..))))...........(((((................))))).");
//    auto b = jump_state(y, "((((.(((..(((((((....)))))))(((((((((((((((..(......)..)))))))....))))))))...)))..))))");

    Subgraph<JumpState<>> subgraph(50000);
    subgraph.run_milestone_1(a, b, sdd);
};

PROTOTYPE("hard-flow-traj") = [](Context ct) {
    auto y = std::make_shared<System const>("ACGTGATCGTAGCTAGCTGATGCTAGCTAGCTAGCTACGATCGTACGTAGCTGATCGATCGTACGTAGCTAGCTAGGGATGTACGT");
    auto const a = jump_state(y, "((((((((((((((((((..........))))))))))))))..))))...........(((((................))))).", moves::full);
    auto const b = jump_state(y, "((((.(((..(((((((....)))))))(((((((((((((((..(......)..)))))))....))))))))...)))..))))", moves::full);

    Local ex(4);
    auto v = ex.map(1000, 1, [&](auto &&env, auto i){
        print(i);
        auto start = a, end = b;
        kmc::Timer Timer;
        kmc::runner()(start, Timer, [&](auto const &w, auto){return w == end;});
        return Timer.time;
    });
    print(v);

    auto v2 = ex.map(1000, 1, [&](auto &&env, auto i){
        print(i);
        auto start = b, end = a;
        kmc::Timer Timer;
        kmc::runner()(start, Timer, [&](auto const &w, auto){return w == end;});
        return Timer.time;
    });
    print(v2);
};

}
