#include "../Test.h"
#include <nupack/markov/Enumerate.h>
#include <nupack/markov/Matrices.h>
#include <nupack/markov/LazyMat.h>
#include <nupack/model/Model.h>
#include <nupack/jump/Jump.h>

namespace nupack {

UNIT_TEST("kmc/low_rank_mat") = [](Context ct) {
    auto v = enumerate_states(jump_state("UCGAATAAG", {}, moves::full));
    auto R = rates_from_states(v);

    auto L = make_lazy(R.n_rows, R.n_cols, Low_Rank_Mat::from_full(R));
    for_pairs(0, R.n_cols, [&](auto i, auto j){
        ct.within(R(i, j), L(i, j), 1e-6);
    });
    la::for_cols(R, [&](auto j) {
        auto l = L.col(j);
        auto r = R.col(j);
        ct.info(l);
        ct.info(r);
        ct.equal(accu(arma::abs(L.col(j))), about(accu(arma::abs(R.col(j)))));
    });

    ct.equal(accu(arma::abs(L.cols(0, R.n_cols-1))), about(accu(arma::abs(R.cols(0, R.n_cols-1)))));
};

}
