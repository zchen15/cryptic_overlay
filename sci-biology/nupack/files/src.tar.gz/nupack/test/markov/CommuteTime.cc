#include "../Test.h"
#include <nupack/markov/Cluster.h>
#include <nupack/markov/Enumerate.h>
#include <nupack/markov/Matrices.h>
#include <nupack/markov/MarkovSystem.h>
#include <nupack/model/Model.h>
#include <nupack/jump/Jump.h>

namespace nupack {

PROTOTYPE("distance_comparison") = [](Context ct) {
    auto w = jump_state("UCGAATCGTACGTAACAATAGCCG", {}, moves::full);
    auto v = enumerate_states(w); BEEP(len(v));

    auto sys = DenseMarkovSystem(rates_from_states(v));

    auto D = Distance::from_states(v);
    D.save("distance.csv", arma::csv_ascii);
    auto ID = integer_pp_distance(D, w.n_bases());
    auto const &C = sys.Commute;
    C.save("commute.csv", arma::csv_ascii);

    arma::mat E(C.n_rows, C.n_cols);
    for_pairs(0, C.n_rows, [&](auto j, auto i){
        E(i, j) = -1.0 / sys.Rates(i, i) + -1.0 / sys.Rates(j, j);
    });

    E.save("dummy.csv", arma::csv_ascii);

    BEEP(accu(C), accu(C % C) - accu(C) * accu(C));
    BEEP(accu(D), accu(D % D) - accu(D) * accu(D));
    BEEP(accu(E), accu(E % E) - accu(E) * accu(E));

    BEEP(pearson_r2(C, D));
    commute_histogram(ID, C, w.n_bases()).save(io::out(), arma::raw_ascii);
};

/******************************************************************************************/

PROTOTYPE("sparse_low_rank_mat") = [](Context ct) {
    using M = arma::sp_mat;
    auto w = jump_state("UCGAATCGAAAG", {}, moves::full);
    auto v = enumerate_states(w); BEEP(len(v));
    auto p = stationary_populations(v);

    auto R = rates_from_states<M>(v);
    auto Z = fundamental_from_rates(R, p, 10);
    auto H = hitting_from_fundamental(Z, p);
    auto C = commute_from_hitting(H);

    auto R0 = rates_from_states(v);
    auto Z0 = fundamental_from_rates(R0, p);
    auto H0 = hitting_from_fundamental(Z0, p);
    auto C0 = commute_from_hitting(H0);

    print(Z0);
    print(Z.Full());

    print(C0);
    print(C.Full());
};

PROTOTYPE("commute_time_check") = [](Context ct) {
    using M = arma::sp_mat;
    auto km = Model(Ensemble::min);
    km.beta = 0;
    auto w = jump_state("UCGAATCATCGATCGTAGCTATATGGAAAG", {}, moves::full, km);
    auto v = enumerate_states(w); BEEP(len(v));
    auto p = stationary_populations(v);

    auto R = rates_from_states<M>(v);
    //R = R / real(arma::trace(R) / R.n_rows);
    arma::vec diag{R.diag()};
    real dmin = -arma::max(diag);
    print_lns("Minimum degree:", dmin);

    R.diag().fill(0);
    real wmax = arma::max(arma::nonzeros(R));
    print_lns("Maximum weight:", wmax);
    //arma::cx_vec evals; arma::cx_mat evecs;
    //arma::eigs_gen(evals, evecs, R, 5, "sm", 0.01);
    //print_lns("Smallest eigenvalues:", evals);

    //BEEP(2 * (1 / (1 - real(evals(1))) + 2) * wmax / dmin / dmin);

    //auto Z = Fundamental::from_rates(R, p, 10);
    //auto H = hitting_from_fundamental(Z, p);
    //auto C = commute_from_hitting(H);
};

PROTOTYPE("large_commute_time") = [](Context ct) {
    using M = arma::sp_mat;
    auto w = jump_state("UCGAATCTAATCGAATCGTATGCGATGAAAG", {}, moves::full);
    auto v = enumerate_states(w); BEEP(len(v));
    auto p = stationary_populations(v);
    auto R = rates_from_states<M>(v);
    v.clear();

    auto Z = fundamental_from_rates(R, p, 10);
    auto H = hitting_from_fundamental(Z, p);
    auto C = commute_from_hitting(H);

    //print(Z.Full());
    //print(C.Full());
};

}
