#include "../Test.h"
#include <nupack/markov/Enumerate.h>
#include <nupack/markov/Matrices.h>
#include <nupack/model/Model.h>
#include <nupack/jump/Jump.h>
#include <nupack/types/Generator.h>

namespace nupack {

void test_enumerate(usize n, vec<string> const &seqs) {
    auto v = enumerate_states(jump_state(seqs, {}, moves::full, Model(Ensemble::min, {}, {}, {}, WobblePairing::off)));
    NUPACK_REQUIRE(len(v), ==, n);
}

/******************************************************************************************/

UNIT_TEST("kmc/enum") = [](Context ct) {
    ct.equal(9311, len(enumerate_states(jump_state("GUCGCGUCGCGUCGCUAUGCGAC", {}, moves::full, Model(Ensemble::min, {}, {}, {}, WobblePairing::off)))));
    auto const v = enumerate_states(jump_state("GUCGCGUCGCGUCGCUAUGCGAC", {}, moves::full, Model(Ensemble::min, {}, {}, {}, WobblePairing::on)));
    for (auto const &w : v) ct.require(std::isfinite(w.energy), w.energy);
    ct.equal(23208, len(v));
};

/******************************************************************************************/

UNIT_TEST("kmc/enum/1") = [](Context ct) {
    test_enumerate(126445, {"GACTGACTGACTGACTGATCGATCGTAGCTA"});
    test_enumerate(11783,  {"GAAACUUUCUUGGACGAGUGCCCUG"});
    test_enumerate(8,      {"UGAAGGUAAAG"});
    test_enumerate(58,     {"CCCCCGAGGUUGAU"});
    test_enumerate(628,    {"AUUAGAUGAAAACACCGCAACC"});
    test_enumerate(4,      {"CGGGAUGGU"});
    test_enumerate(120187, {"AAGGAAUUAUUGUUUGCCGACUGUUGGACU"});
};

/******************************************************************************************/

UNIT_TEST("kmc/enum/2") = [](Context ct) {
    test_enumerate(2,      {"CAAAG"});
    test_enumerate(2,      {"ACAAAGA"});
    test_enumerate(5,      {"CAAAGACAAAG"});
    test_enumerate(1710,   {"AAACCCTTT", "AAACCCCTTT"});
    test_enumerate(10673,  {"AAACCCTTTACTGATAAACCCCTTT"});
    return;
    test_enumerate(669089, {"GUAAUCAUAC", "GGAUCGUGGU", "AAACGCAGUU"});
};

/******************************************************************************************/

PROTOTYPE("kmc/enum/3") = [](Context ct) {
    auto v = enumerate_states(jump_state({"AAAATAAT"}, {}, moves::full, Model(Ensemble::min, {}, {}, {}, WobblePairing::off)));
    for (auto const &i : v)
      print(i.dp());
    auto dist = Distance::from_states(v);
    print(dist);
    print(arma::sqrt(dist));
    print(arma::eig_gen(arma::sqrt(dist)));
    print(len(v));
};

/******************************************************************************************/

PROTOTYPE("kmc/enum/rates") = [](Context ct) {
    auto v = enumerate_states(jump_state("GUCGCGUCGCGUCGCUAUGCGAC", {}, moves::full, Model(Ensemble::min, {}, {}, {}, WobblePairing::on)));
    for (auto const &i: v) {ct.greater(i.energy, -100000); ct.less(i.energy, +100000);}
    auto R = rates_from_states(v);
};


PROTOTYPE("kmc/enum/rates2") = [](Context ct) {
    auto w = jump_state({"CCCCGT"}, "......", moves::full, Model(Ensemble::min, {}, {}, {}, WobblePairing::off));
    auto v = enumerate_states(w);
    print(len(v));
    for (auto const &i : v) print(i.dp(), i.energy, i.boltz());
    print(sum(v, [](auto const &w){return w.boltz();}));
};

/******************************************************************************************/

PROTOTYPE("kmc/enum/generator") = [](Context ct) {
    auto const w = jump_state({"TCAGACTGATCGAATCGTAATCGTAGCTAGCTCGTTACGA"}, {}, moves::full, Model(Ensemble::min, {}, {}, {}, WobblePairing::off));
    auto const fun = NUPACK_FUNCTOR(for_enumerated_states);

    print(time_it([&] {
        for_enumerated_states(w, [](auto &&w) {clobber_memory();});
    }));

    print(time_it([&] {
        BlockedGenerator<decay<decltype(w)>, 2> gen(w, fun);
        for (auto &&w : gen) clobber_memory();
    }));

    print(time_it([&] {
        BlockedGenerator<decay<decltype(w)>, 1> gen(w, fun);
        for (auto &&w : gen) clobber_memory();
    }));

    print(time_it([&] {
        Generator<decay<decltype(w)>> gen(w, fun);
        for (auto &&w : gen) clobber_memory();
    }));
};

//PROTOTYPE("Rate3") = [](Context ct) {
//    auto km = model();
//    auto y = System({"AAAATTAAAATATTATATAAATAAT"});
//    auto v = enumerate_states(y);
//    auto r = make_rate_matrix<arma::SpMat<double>>(v, km);
//    ct.info(r);
//    ct.info(arma::accu(r));
//}

/******************************************************************************************/

}
