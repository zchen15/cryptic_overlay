#include "../Test.h"
#include <nupack/model/Model.h>
#include <nupack/markov/Cluster.h>
#include <nupack/markov/Enumerate.h>
#include <nupack/markov/Matrices.h>
#include <nupack/jump/Jump.h>

namespace nupack {

/******************************************************************************************/

PROTOTYPE("medoids2") = [](Context ct) {
    arma::vec pos = {1,2,3, 11,12,13, 21,22,23};
    arma::mat D(9, 9);
    for_pairs(0, 9, [&] (auto i, auto j){D(j, i) = std::abs(pos(j) - pos(i));});
    auto medoids = k_medoids(3, 10000, D);
    auto clusters = clusters_from_medoids(medoids, D);
    print_lns(medoids, clusters);
};

/******************************************************************************************/

PROTOTYPE("medoids") = [](Context ct) {
    auto km = Model(Ensemble::min); //km.beta = 0;
    ComplexSet cs;
    print(len(cs));
    auto v = enumerate_states(jump_state({"UCGAATCGAGCTAACAAAG"}, {}, moves::full)); BEEP(len(v));
    auto p = stationary_populations(v);
    auto R = rates_from_states(v);
    auto D = Distance::from_states(v);
    auto ID = integer_pp_distance(D, v[0].n_bases());
    auto Z = fundamental_from_rates(R, p);
    auto H = hitting_from_fundamental(Z, p);
    H.save("h.csv", arma::csv_ascii);
    R.save("r.csv", arma::csv_ascii);

    auto lumps = find_lumps(R, p, 5);
    print(lumps);

    auto C = commute_from_hitting(H);

    auto accept = [](auto i, auto j) {
        return j < i || random_float() < std::exp((i - j) / i);
    };

    //C.each_row() %= p;
    //C.each_col() %= p;
    print(p);
    auto medoids = k_medoids(3, 10000, C);
    auto clusters = clusters_from_medoids(medoids, C);
    print_lns("C Medoids", medoids);
    print_lns("C Clusters", clusters);
    C.save("c.csv", arma::csv_ascii);

    medoids = k_medoids(3, 10000, D);
    clusters = clusters_from_medoids(medoids, D);
    print_lns("D Medoids", medoids);
    print_lns("D Clusters", clusters);
    D.save("d.csv", arma::csv_ascii);
};

/******************************************************************************************/

}
