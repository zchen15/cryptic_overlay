#include "../Test.h"

#include <nupack/markov/Enumerate.h>
#include <nupack/execution/Local.h>
#include <nupack/kmc/Timer.h>
#include <nupack/kmc/Run.h>
#include <nupack/jump/Jump.h>
#include <nupack/model/Model.h>

#include <boost/math/distributions/inverse_chi_squared.hpp>

namespace nupack {

template <class W> void test_boltzmann_consistency(Context &ct, W w0, usize n_steps) {
    std::map<W, real> pops;

    auto t = kmc::Timer::with_max_step(n_steps);
    kmc::runner()(w0, t, [&](auto const &w, auto t) {pops[w] += t;});

    auto v = enumerate_states(w0.with_structure());
    for(auto w : v) print(w.dp(), w.energy);
    real_col pt = stationary_populations(v), pe = pt;
    izip(v, [&](auto i, auto const &w) {pe(i) = pops[w];});

    pt /= accu(pt); pe /= accu(pe);
    print(pt);
    print(pe);

    // Using a chi square with assumed sample length = # steps
    real chi2 = t.step * accu((pe - pt) % (pe - pt) / pt);
    print("chi-2 =", chi2);

    auto dist = boost::math::inverse_chi_squared();
    print("p-value =", 1 - boost::math::cdf(dist, chi2));
}

template <class W> void test_rate_matrix(Context &ct, W w0, usize n_steps) {
    auto v = enumerate_states(w0.with_structure());
    auto Rt = rates_from_states(v);
    auto p = stationary_populations(v);
    auto Re = Rt; Re.zeros();

    auto t = kmc::Timer::with_max_step(n_steps);

    auto last = w0;
    kmc::runner()(w0, t, [&](auto const &w, auto t) {
        if (w != last) {
            auto i = binary_search(v, last) - begin_of(v);
            auto j = binary_search(v, w) - begin_of(v);
            Re(i, j) += 1;
            auto const dp0 = last.dp(), dp1 = w.dp();
            ct.near(Rt(i, j), w.last_move.rate, dp0, dp1);
        }
        last = w;
    });
    Re /= t.time;

    for_pairs(0, Rt.n_rows, [&](auto i, auto j) {Rt(i, j) *= p(i);});
    auto flux = -accu(Rt.diag());

    print_lns(Rt, Re);
    real chi2 = 0;
    // Using a chi square with assumed sample length = # steps
    for(auto i : range(Rt.n_rows)) for(auto j : range(i + 1, Rt.n_rows))
        if (Rt(i, j) > 0) chi2 += t.step * pow(Rt(i, j) - Re(i, j), 2) / Rt(i, j) / flux;

    print("chi-2 =", chi2);

    auto dist = boost::math::inverse_chi_squared();
    print("p-value =", 1 - boost::math::cdf(dist, chi2));
}

template <class X, class W>
void test_hitting_times(X &&ex, W w0, usize n_steps) {
    auto v = enumerate_states(w0.with_structure());
    auto R = rates_from_states(v);
    auto p = stationary_populations(v);
    auto Z = fundamental_from_rates(R, p);
    auto H0 = hitting_from_fundamental(Z, p);
    print(H0);

    std::map<W, usize> lookup;
    izip(v, [&](auto i, auto const &w) {lookup[w] = i;});

    auto Hs = ex.map(n_steps, 1, [&](auto const &...) {
        real_mat H = H0; H.fill(-1);
        kmc::Timer timer;
        auto w = w0;
        auto n2 = len(v) * (len(v) - 1);

        auto stop = [&](auto const &w, auto t) {
            auto i = lookup.at(w);
            if (H(i, i) < 0) H(i, i) = timer.time - t;
            for (auto j : indices(v))
                if (j != i && H(j, j) >= 0 && H(j, i) < 0)
                    H(j, i) = timer.time - t - H(j, j);
            return --n2;
        };
        kmc::runner()(w, stop, timer);
        return H;
    });
    real_mat H = 0 * H0;
    for (auto const &m : Hs) H += m;
    H /= n_steps;

    print((H - H0) / H0);
};

/******************************************************************************************/

PROTOTYPE("rate-matrix-consistency") = [](Context ct) {
    auto km = Model(Ensemble::min, {}, {}, {}, WobblePairing::off);
    fork(km.rate_function, [](auto &f) {f.molarity = 0.01;});
    //auto w = jump_state({"AAAAT"}, ".....", moves::full, km);
    //auto w = jump_state({"AAAAT", "TTTTA"}, ".....+.....", moves::full, km);
    // auto w = jump_state({"AAA", "TTT"}, "...+...", moves::full, km);
    auto w = jump_state({"GCATGCTTTTGCATGC"}, PairList(), moves::full, km);
    // auto w = jump_state({"ACTGATCGT", "ACTGATCACGTAG"}, ".........+.............", moves::full, km);
    test_rate_matrix(ct, w, 100000);
};

PROTOTYPE("boltzmann-consistency") = [](Context ct) {
    auto km = Model(Ensemble::min, {}, {}, {}, WobblePairing::off);
    fork(km.rate_function, [](auto &f) {f.molarity = 0.01;});
    //auto w = jump_state({"AAAAT", "TTTTA"}, ".....+.....", moves::full, km);
    // auto w = jump_state({"AAAATTTT"}, PairList(), moves::full, km);
    auto w = jump_state({"GCATGCTTTTGCATGC"}, PairList(), moves::full, km);
    // auto w = jump_state({"ACTGATCGT", "ACTGATCACGTAG"}, ".........+.............", moves::full, km);
    test_boltzmann_consistency(ct, w, 100000);
};

PROTOTYPE("hitting-time/metropolis") = [](Context ct, long reps) {
    Local ex(4);
    auto km = Model(Ensemble::min, ParameterFile("RNA"), ModelConditions(), Metropolis(), WobblePairing::off);
    // auto w = jump_state({"ACTGATCGTACTGATCACGTAG"}, "......................", moves::full, km);
    auto w = jump_state({"GCATGCTTTTGCATGC"}, PairList(), moves::full, km);
    test_hitting_times(ex, w, reps);
};


PROTOTYPE("hitting-time/kawasaki") = [](Context ct, long reps) {
    Local ex(4);
    auto km = Model(Ensemble::min, ParameterFile("RNA"), ModelConditions(), Kawasaki(), WobblePairing::off);
    // km.rate_function = Kawasaki();
    auto w = jump_state({"GCATGCTTTTGCATGC"}, PairList(), moves::full, km);
    test_hitting_times(ex, w, reps);
};


PROTOTYPE("wolfe-consistency") = [](Context ct) {
    Local ex(4);
    auto km = Model(Ensemble::min, {}, {}, {}, WobblePairing::off);
    for (auto m : {1e-2, 1e-3, 1e-4, 1e-5, 1e-6}) {
        fork(km.rate_function, [m](auto &f) {f.molarity = m;});
        auto w = jump_state({"GGGACGAGGC", "GCCUCGUCCC"}, "..........+..........", moves::full, km);

        test_boltzmann_consistency(ct, w, 100000);
        test_rate_matrix(ct, w, 100000);
        test_hitting_times(ex, w, 100000);
    }
};


PROTOTYPE("consistency") = [](Context ct, long reps, bool kawasaki) {
    auto km = kawasaki ? Model(Ensemble::min, ParameterFile("DNA"), ModelConditions(), Kawasaki(), WobblePairing::off)
                       : Model(Ensemble::min, ParameterFile("DNA"), ModelConditions(), Metropolis(), WobblePairing::off);

    auto const w0 = jump_state({"GCATGCTTTTGCATGC"}, PairList(), moves::full, km);
    auto const w2 = jump_state({"GCATGCTTTTGCATGC"}, "((((((....))))))", moves::full, km);
    auto v = enumerate_states(w0.with_structure());
    auto R = rates_from_states(v);
    auto p = stationary_populations(v);
    auto Z = fundamental_from_rates(R, p);
    auto H0 = hitting_from_fundamental(Z, p);

    auto times = vmap<Col<real>>(range(reps), [&](auto i) {
        auto w = w0;
        real t = 0;
        while (w2.pairs != w.pairs) {
            t += w.timestep();
            w.step();
        }
        return t;
    });
    print(H0(0, H0.n_rows-1), la::mean(times), la::stddev(times));
};





}
