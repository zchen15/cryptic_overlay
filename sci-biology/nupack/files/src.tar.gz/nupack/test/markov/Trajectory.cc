#include <nupack/markov/Trajectory.h>                     // for Trajectory
#include <nupack/types/Matrix.h>                          // for Mat
#include "../Test.h"

namespace nupack {

UNIT_TEST("traj_stream") = [](Context ct) {
    using M = real_mat;
    auto t = Trajectory<M>();
    t.distances = M(5, 5, arma::fill::eye);
    t.rates = M(5, 5, arma::fill::ones);
    std::ofstream os("m.save");
    t.save(os);
    os.flush();
    std::ifstream is("m.save");
    auto t2 = Trajectory<M>();
    t2.load(is);
    ct.require(all(all(t2.distances == t.distances)));
    ct.require(all(all(t2.rates == t.rates)));
};

}
