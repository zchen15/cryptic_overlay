#include "../Test.h"
#include <nupack/jump/Jump.h>
#include <nupack/markov/Propagate.h>
#include <nupack/markov/Matrices.h>
#include <nupack/markov/Enumerate.h>
#include <nupack/model/Model.h>

namespace nupack {

PROTOTYPE("ode/1") = [](Context ct) {
    auto v = enumerate_states(jump_state("AAAATTAATAAATAA", {}, moves::full));
    auto r = rates_from_states(v);

    print(la::esum(r), la::n_rows(r));

    ct.section("Approximate", [&](Context ct) {
        auto vec = Col<double>(la::n_rows(r)); la::fill_zero(vec); vec(1) = 1;
        rk_propagate(r, vec, 5.0e-6, 1.e-8);
        print(vec); print(la::esum(vec));
    });

    ct.section("Exact 1 step", [&](Context ct) {
        auto vec = Col<double>(la::n_rows(r)); la::fill_zero(vec); vec(1) = 1;
        propagate_exactly(r, vec, 5.0e-6);
        print(vec); print(la::esum(vec));
    });

    ct.section("Exact uniform steps", [&](Context ct) {
        auto vec = Col<double>(la::n_rows(r)); la::fill_zero(vec); vec(1) = 1;
        auto m = propagate_exactly(r, vec, 2.5e-6, 2);
        print(m.col(1)); print(la::esum(m.col(1)));
    });

    ct.section("Exact variable steps", [&](Context ct) {
        auto vec = Col<double>(la::n_rows(r)); la::fill_zero(vec); vec(1) = 1;
        auto m2 = propagate_exactly(r, vec, {2.5e-6, 5.0e-6});
        print(m2.col(1)); print(la::esum(m2.col(1)));
    });

    //print(cuthill_mckee_ordering(r));
};

PROTOTYPE("ode/2") = [](Context ct) {
    //auto y = System({"TTTCATCGACAAGACTACGTACGCCCCTCTAG"});
    //auto y = System({"CCTATAGGAGAAACCTATAGGAAGACCTATAGG"});
    //auto y = System({"AAAATTAAAATAA"});
    auto v = enumerate_states(jump_state("GUCGCGUCGCGUCGCUAUGCGAC", {}, moves::full));
    print(len(v));
    auto R = rates_from_states(v);
    //M s = 0.5 * (R + R.t());

    //print(la::n_rows(s));
    //print(n_nonzero(s));
    //print(la::esum(s));

    //Col<double> eig_s = real(arma::eig_sym(s));
    //print(eig_s);

    print(la::n_rows(R));
    //print(n_nonzero(R));
    print(la::esum(R));

//    arma::cx_mat<double> cx_evec; arma::cx_vec<double> cx_eval;
//    arma::eig_gen(R, evec, eval);
//    Mat<double> evec = real(cx_evec);
//    Col<double> eval = real(cx_eval);
//    for (auto i : indices(evec)) print(evec(1, i))

//    auto vec = Col<double>(la::n_rows(R)); la::fill_zero(vec); vec(1) = 1;
//    rk_propagate(R, vec, 1.0e-7, 1.0e-8);
//
//    print(vec);
//    print(la::esum(vec));
};

PROTOTYPE("ode/3") = [](Context ct) {
    auto km = Model(Ensemble::min);
    fork(km.rate_function, [](auto &f) {f.bimolecular_scaling *= 1.0e-3;});
    auto v = enumerate_states(jump_state({"GGGACGAGGC", "GCCUCGUCCC"}, {}, moves::full, km));
    print(len(v));

    double pf2 = 0, pf1 = 0;
    for (auto const &w : v) {
        if (len(w.complexes) == 2) pf2 += exp(-km.beta * w.energy);
        else pf1 += exp(-km.beta * w.energy);
    }

    print(len(v));

    auto rates = rate_tuples_from_states(v);

    double dimer_rate = 0;
    for (auto const &r : rates) {
        auto const &w2 = v[std::get<0>(r)], & w1 = v[std::get<1>(r)];
        if (len(w2.complexes) == 2 && len(w1.complexes) == 1)
            dimer_rate += std::get<2>(r) * exp(-km.beta * w2.energy) / pf2;
    }

    BEEP(dimer_rate, pf1, pf2, pf1 + pf2);

    //M r = rate_matrix<M>(v, km);
    //print(r);
};


PROTOTYPE("ode/4") = [](Context ct) {
    auto km = Model(Ensemble::min);
    ct.section("1", [](Context ct) {
        auto v = enumerate_states(jump_state("AAAATTTAA", {}, moves::full));
        for (auto const &w : v) print(w.dp());
    });

    ct.section("2", [](Context ct) {
        auto v = enumerate_states(jump_state({"AAA", "TTT"}, {}, moves::full));
        for (auto const &w : v) print(w.dp());
        print(len(v));
        auto r = rates_from_states<SpMat<double>>(v);
        print(r);
    });
};

}
