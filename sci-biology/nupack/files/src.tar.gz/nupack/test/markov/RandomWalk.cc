#include "../Test.h"
#include <nupack/jump/Jump.h>
#include <nupack/markov/Enumerate.h>
#include <nupack/markov/Matrices.h>
#include <nupack/markov/RandomWalk.h>
#include <nupack/execution/Local.h>
#include <nupack/model/Model.h>
#include <nupack/reflect/SerializeMatrix.h>

#include <atomic>

namespace nupack::markov {

/******************************************************************************************/

template <class D>
struct DistributionDraw {
    mutable D distribution;

    template <class ...Ts>
    DistributionDraw(Ts &&...ts) : distribution(fw<Ts>(ts)...) {}

    template <class RNG=decltype(StaticRNG) &>
    auto operator()(RNG &&gen=StaticRNG) const {return distribution(gen);}
};


template <class T>
struct ConstantDraw {
    T value;

    auto operator()() const {return value;}
};

template <class T>
auto draw_exponential(T const &t) {return DistributionDraw<std::exponential_distribution<T>>(t);}

template <class T>
auto draw_constant(T const &t) {return ConstantDraw<T>{t};}

/******************************************************************************************/

UNIT_TEST("walk/algebra") = [](Context ct) {
    //auto y = System({"UCGAAAAAG"});
    //auto y = System({"CTAGCTAGCTGACTGATCGATCG"});
    auto v = enumerate_states(jump_state("UCGAAAAAGATCG", {}, moves::full));
    auto R = rates_from_states(v);
    auto p = stationary_populations(v);
    auto Z = fundamental_from_rates(R, p);
    auto H = hitting_from_fundamental(Z, p);

    if (true) return;
    R.save("R.txt", arma::raw_ascii);
    Z.save("Z.txt", arma::raw_ascii);
    H.save("H.txt", arma::raw_ascii);
    p.save("p.txt", arma::raw_ascii);
    print(la::re(eig_gen(R)));
};

UNIT_TEST("walk/random_stochastic") = [](Context ct) {
    auto [R, p] = random_stochastic<real>(64);
    ct.less(la::abs(p.t() * R).max(), 1e-8);
    ct.less(la::abs(la::sum(R, 1)).max(), 1e-8);
    auto const Z = fundamental_from_rates(R, p);
    ct.less(la::abs(p.t() * Z).max(), 1e-8);
    ct.less(la::abs(la::sum(Z, 1)).max(), 1e-8);
    if (test_output()) print_lns("eigenvalues", real_eigenvalues(R));
};

template <class Dist>
auto test_moments(uint n, uint m, uint reps, Dist const &time) {
    auto [R, pi] = random_stochastic<real>(n);
    print(real_eigenvalues(R));
    auto const Z = fundamental_from_rates(R, pi);
    Mat<real> F = la::randu(m, n);
    RandomWalker<real> walker{R};
    auto dist = discrete_distribution(pi);
    auto samples = vmap(range(reps), [&](auto r) {
        real const t = time();
        uint const start = dist(StaticRNG);
        Col<real> local_times(m, la::fill::zeros);
        walker(start, t, [&](auto i, auto j, auto t) {local_times += t * F.col(i); return false;});
        return std::make_pair(std::move(local_times), t);
    });
    json out;
    out["pi"] = pi;
    out["R"] = R;
    out["F"] = F;
    out["samples"] = samples;
    return out;
}

PROTOTYPE("walk/generate-data") = [](Context ct, long n=10, long m=1024, real length=100) {
    auto [R, pi] = random_stochastic<real>(n);
    RandomWalker<real> const walker{R};
    auto dist = discrete_distribution(pi);
    auto v = sorted(real_eigenvalues(R));
    auto const time = -length / v.end()[-2];
    print(v, time);

    auto paths = vmap(range(m), [&](auto r) {
        uint const start = dist(StaticRNG);
        vec<std::tuple<uint, uint, real>> path;
        walker(start, time, [&](auto i, auto j, auto t) {path.emplace_back(i, j, t); return false;});
        return path;
    });

    json out;
    out["R"] = R;
    out["pi"] = pi;
    out["paths"] = paths;
    std::ofstream("paths.json") << out;
};


PROTOTYPE("walk/moments") = [](Context ct) {
    json out;
    out.emplace_back(std::make_pair(-1, test_moments(16, 16, 1e7, draw_constant(10))));
    for (auto t : {1e1, 1e0, 1e-1, 1e-2, 1e-3, 1e-4, 1e-5, 1e-6, 1e-7, 1e-8})
        out.emplace_back(std::make_pair(t, test_moments(16, 16, 1e7, draw_exponential(1/t))));
    std::ofstream("moments.json") << out;
};

PROTOTYPE("walk/inverse") = [](Context ct) {
    //auto y = System({"UCGAAAAAG"});
    auto v = enumerate_states(jump_state("UCGAAAAAGATCG", {}, moves::full));
    auto R = rates_from_states(v);
    //R /= (esum(abs(R)) / R.n_rows / R.n_cols);
    auto p = stationary_populations(v);
    auto Z = fundamental_from_rates(R, p);
    auto H = hitting_from_fundamental(Z, p);
    auto H2 = H;

    print(eig_gen(R));
    print(eig_gen(Z));

    RandomWalker<real> walker(-Z);

    real max_time = H.max();
    print(max_time);

    vec<real> times(100000);
    for_pairs(0, R.n_rows, [&](usize i, usize j) {
        print(i,j,R.n_rows);
        collect(times, [&]{return walker.hitting_time(i, j, 100 * max_time).value();});
        H2(i, j) = sum(times) / len(times);
    });
    H2.diag().fill(0);
    print_lns("H", H);
    print_lns("R", R);
    print_lns("H2", H2);
    auto R2 = R; R2 *= 0;
    for_pairs(0, R2.n_rows, [&](usize i, usize j) {
        R2(i, j) = (R(j, j) - R(i, j)) / p(j);
    });
    print_lns("R2", eig_gen(R2));
    for_pairs(0, R2.n_rows, [&](usize i, usize j) {
        R2(i, j) = (R(i, i) - R(i, j)) / p(i);
    });
    print_lns("R3", eig_gen(R2));
    print_lns("p", p);

    auto Zp = H2; Zp *= 0
    ;
    for (auto j : range(Zp.n_rows))
        Zp(j, j) = p(j) * dot(H2.col(j), p);

    for_pairs(0, Zp.n_rows, [&](usize i, usize j) {
        if (i != j) Zp(i, j) = Zp(j, j) - p(j) * H2(i, j);
    });

    print_lns("Zp", Zp, "Zp eigenvalues", eig_gen(Zp));
};

/******************************************************************************************/

UNIT_TEST("walk/random") = [](Context ct) {
    auto v = enumerate_states(jump_state("CGCCCCCG", {}, moves::full));
    auto R = rates_from_states(v);
    auto p = stationary_populations(v);
    auto Z = fundamental_from_rates(R, p);
    auto H2 = hitting_from_fundamental(Z, p);
    decltype(R) H1(R.n_rows, R.n_cols);
    RandomWalker<real> walker(R);

    ct.less(arma::abs(p.t() * R).max(), 1e-5);

    vec<real> times(100000);
    for_pairs(0, R.n_rows, [&](usize i, usize j) {
        collect(times, [&]{return walker.hitting_time(i, j, 1000.0).value();});
        H1(i, j) = sum(times) / len(times);
    });

    H1.diag().fill(1);
    H2.diag().fill(1);

    ct.less((arma::abs(H1 - H2) / H1).max(), 0.015, H1, H2);
};

/******************************************************************************************/

PROTOTYPE("walk/distribution") = [](Context ct) {
    Local ex(6);
    auto v = enumerate_states(jump_state("UCGACATGCTATGGATGCTAAAAG", {}, moves::full));
    auto R = rates_from_states(v);
    RandomWalker<real> walker(R);

    print(len(v));
    usize i = len(v) * 1 / 4, j = len(v) * 3 / 4;
    print(v[i].dp(), v[j].dp());
    std::atomic<int> n(0);

    auto times = ex.map(10000, 1, [&](auto const &...){
        print(n++);
        return walker.hitting_time(i, j, 1000.0).value();
    });
    std::ofstream ofs(std::to_string(i) + "_" + std::to_string(j) + ".dat");
    ofs << std::fixed << std::setprecision(10);
    print_os(ofs, v[i].energy);
    print_os(ofs, v[j].energy);
    for (auto t : times) print_os(ofs, t);
};

/******************************************************************************************/

PROTOTYPE("hitting-time-triples") = [](Context ct) {
    Local ex(6);
    auto v = enumerate_states(jump_state("TACGTAGCTAGTCGC", {}, moves::full));
    auto R = rates_from_states(v);
    auto p = stationary_populations(v);
    auto Z = fundamental_from_rates(R, p);
    auto H = hitting_from_fundamental(Z, p);
    RandomWalker<real> const walker(R);

    auto n = len(v);
    usize a = n / 4, b = 3 * n / 4;
    usize m = 100000;
    std::atomic<usize> n_successful{0};

    auto hits = ex.map(m, 1, [&](auto const &...){
        arma::vec c(n); c.zeros();
        auto end = walker(a, 10000.0, [&](auto i, auto j, ...){++c(j); return j == b;}).first;
        n_successful += (end == b);
        c *= real(end == b);
        return c;
    });

    arma::vec c(n); c.zeros();
    for (auto const &h : hits) c += h;

    c /= n_successful;
    print(c);

    arma::vec theory_occ(n);
    for (auto j : range(n))
        theory_occ(j) = -p(j) * R(j, j) * (H(a, b) + H(b, j) - H(a, j));
    print(theory_occ);
};


/******************************************************************************************/

PROTOTYPE("hitting-time-edges") = [](Context ct) {
    Local ex(6);
    auto v = enumerate_states(jump_state("UCGAAAAAGATCG", {}, moves::full));
    auto R = rates_from_states(v);
    auto p = stationary_populations(v);
    auto Z = fundamental_from_rates(R, p);
    auto H = hitting_from_fundamental(Z, p);
    RandomWalker<real> const walker(R);

    usize n = len(v);
    usize a = n / 4;
    usize b = 3 * n / 4;
    print(a, b, H(a, b));
    usize m = 1000000;
    std::atomic<usize> n_successful{0}, steps{0};
    std::atomic<real> t{0};

    auto hits = ex.map(m, 1, [&](auto const &...){
        arma::mat c(n, n); c.zeros();

        auto p = walker(a, 10000.0, [&](auto i, auto j, auto){
            ++c(i, j);
            ++steps;
            return j == b;
        });
        t = t + p.second;

        n_successful += (p.first == b);
        print(n_successful);
        c *= real(p.first == b);
        return c;
    });

    arma::mat c(n, n); c.zeros();
    for (auto const &h : hits) c += h;
    print(steps, n_successful, real(steps) / n_successful);
    print(t / n_successful);

    c /= n_successful;
    c.save("Edges.txt", arma::raw_ascii);
};

/******************************************************************************************/

PROTOTYPE("hitting-time-min") = [](Context ct) {
    Local ex(6);
    auto v = enumerate_states(jump_state("UCGAAAAAGATCG", {}, moves::full));
    auto R = rates_from_states(v);
    auto p = stationary_populations(v);
    auto Z = fundamental_from_rates(R, p);
    auto H = hitting_from_fundamental(Z, p);
    RandomWalker<real> const walker(R);

    auto n = len(v);
    usize a = n / 4, b = n / 2, c = 3 * n / 4, d = c + 3;
    BEEP(p(a), p(b), p(c), p(d));
    print(a, b, H(a, b));
    usize m = 100000;
    std::atomic<real> n_successful{0};

    auto hits = ex.map(m, 1, [&](auto const &...){
        real t = 0;
        auto p = walker(a, 10000.0, [&](auto i, auto j, auto ts){
            if (i == b) t += ts;
            return (j == c) || (j == d);
        });
        n_successful = n_successful + (p.first == c);
        print(n_successful);
        return t;
    });

    print(sum(hits) / n_successful);

    BEEP(H(a, b), H(a, c), H(a, d));
    BEEP(H(b, a), H(b, c), H(b, d));
    BEEP(H(c, a), H(c, b), H(c, d));
    BEEP(H(d, a), H(d, b), H(d, c));
};

PROTOTYPE("hitting-time-subsets") = [](Context ct) {
    Local ex(6);
    auto v = enumerate_states(jump_state("UCGAAAAAGATCG", {}, moves::full));
    auto R = rates_from_states(v);
    auto p = stationary_populations(v);
    auto Z = fundamental_from_rates(R, p);
    auto H = hitting_from_fundamental(Z, p);
    RandomWalker<real> const walker(R);

    auto n = len(v);
    usize a = n / 4, b = n / 2, c = 3 * n / 4, d = c + 3;
    usize m = 100000;
    std::atomic<real> n_successful{0};

    // starting at A, what is probability of hitting B before C or D

    auto hits = ex.map(m, 1, [&](auto const &...){
        bool hit = false;
        auto p = walker(a, 10000.0, [&](auto i, auto j, auto){
            hit |= (i == b);
            return (j == c) || (j == d);
        });
        bool finished = (p.first == c || p.first == d);
        n_successful = n_successful + finished;
        print(n_successful);
        return std::make_pair(hit, p.second * finished);
    });

    real probability=0, time=0;
    for (auto i : hits) {
        probability += i.first;
        time += i.second;
    }
    time /= n_successful;
    probability /= n_successful;

    BEEP(probability, time);

    BEEP(H(a, b), H(a, c), H(a, d));
    BEEP(H(b, a), H(b, c), H(b, d));
    BEEP(H(c, a), H(c, b), H(c, d));
    BEEP(H(d, a), H(d, b), H(d, c));
};

PROTOTYPE("hitting-time-distribution-1") = [](Context ct) {
    Local ex(6);
    auto v = enumerate_states(jump_state("UCGAAAAAGATCG", {}, moves::full));
    auto R = rates_from_states(v);
    auto p = stationary_populations(v);
    auto Z = fundamental_from_rates(R, p);
    auto H = hitting_from_fundamental(Z, p);
    RandomWalker<real> const walker(R);

    auto n = len(v);
    usize a = n / 4, b = n / 2, c = 3 * n / 4, d = 21; // d = 21 for connected, d = 20 for not connected
    usize m = 100000;
    std::atomic<real> n_successful{0};

    // Does <ac ad> = Hac Had?

    auto hits = ex.map(m, 1, [&](auto const &...){
        real ac = 0, ad = 0, t = 0;
        auto p = walker(a, 10000.0, [&](auto i, auto j, auto ts){
            t += ts;
            if (j == c && ac == 0) ac = t;
            if (j == d && ad == 0) ad = t;
            return (ac != 0) && (ad != 0);
        });
        bool finished = ac != 0 && ad != 0;
        n_successful = n_successful + finished;
        print(n_successful);
        return std::make_tuple(finished, ac, ad);
    });

    real tcd = 0;
    for (auto const &i : hits) {
        if (first_of(i)) tcd += second_of(i) * third_of(i);
        print(second_of(i));
    }
    tcd /= n_successful;

    BEEP(H(a, c), H(a, d), H(a, c) * H(a, d), tcd, tcd / 2);
};

PROTOTYPE("hitting-time-distribution-2") = [](Context ct) {
    Local ex(6);
    auto v = enumerate_states(jump_state("UCGAAAAAGATCG", {}, moves::full));
    auto R = rates_from_states(v);
    auto p = stationary_populations(v);
    auto Z = fundamental_from_rates(R, p);
    auto H = hitting_from_fundamental(Z, p);
    RandomWalker<real> const walker(R);

    auto n = len(v);
    usize a = n / 4, b = n / 2, c = 3 * n / 4, d = 21; // d = 21 for connected, d = 20 for not connected
    usize m = 10000;
    std::atomic<real> n_successful{0};

    // Does <ac ad> = Hac Had?

    auto hits = ex.map(m, 1, [&](auto const &...){
        real ac = 0, ad = 0, ab = 0, t = 0;
        auto p = walker(a, 10000.0, [&](auto i, auto j, auto ts) {
            t += ts;
            if (j == b && ac != 0 && ad != 0) ab = t; // first b after first c and first d
            if (j == c && ac == 0) ac = t; // first c
            if (j == d && ad == 0) ad = t; // first d
            return ab != 0;
        });
        bool finished = (ab != 0);
        n_successful = n_successful + finished;
        print(n_successful);
        return std::make_tuple(finished, ab, ac, ad);
    });

    real t = 0;
    for (auto const &i : hits) {
        real cb = second_of(i) - third_of(i);
        real db = second_of(i) - std::get<3>(i);
        if (first_of(i)) t += cb * db;
        print(t);
    }
    t /= n_successful;

    BEEP(H(c, b), H(d, b), H(c, b) * H(d, b), t, t / 2);
};

PROTOTYPE("hitting-time-distribution-3") = [](Context ct) {
    Local ex(6);
    auto v = enumerate_states(jump_state("UCGAAAAAGATCG", {}, moves::full));
    auto R = rates_from_states(v);
    auto p = stationary_populations(v);
    auto Z = fundamental_from_rates(R, p);
    auto H = hitting_from_fundamental(Z, p);
    RandomWalker<real> const walker(R);

    auto n = len(v);
    usize a = n / 4, b = n / 2, c = a;//3 * n / 4;
    usize m = 100000;
    std::atomic<real> n_successful{0};

    // Does <Hab Hbc> = Hab Hbc?

    auto hits = ex.map(m, 1, [&](auto const &...){
        real ab = 0, bc = 0, t = 0;
        auto p = walker(a, 10000.0, [&](auto i, auto j, auto ts) {
            t += ts;
            if (j == b && ab == 0) ab = t;
            if (j == c && ab != 0) bc = t - ab;
            return bc != 0;
        });
        bool finished = (bc != 0);
        n_successful = n_successful + finished;
        print(n_successful);
        return std::make_tuple(finished, ab, bc);
    });

    real t = 0;
    for (auto const &i : hits) {
        if (first_of(i)) t += second_of(i) * third_of(i);
        print(t);
    }
    t /= n_successful;

    BEEP(H(a, b), H(b, c), H(a, b) * H(b, c), t, t / 2);
};

PROTOTYPE("hitting-time-distribution-4") = [](Context ct) {
    Local ex(6);
    auto v = enumerate_states(jump_state("UCGAAAAAGATCG", {}, moves::full));
    auto R = rates_from_states(v);
    auto p = stationary_populations(v);
    auto Z = fundamental_from_rates(R, p);
    auto H = hitting_from_fundamental(Z, p);
    RandomWalker<real> const walker(R);

    auto n = len(v);
    usize a = n / 4, b = n / 2, c = a;//3 * n / 4;
    usize m = 100000;
    std::atomic<real> n_successful{0};

    // Does <Hab Hbc> = Hab Hbc?

    auto hits = ex.map(m, 1, [&](auto const &...){
        real ab = 0, bc = 0, t = 0;
        auto p = walker(a, 10000.0, [&](auto i, auto j, auto ts) {
            t += ts;
            if (j == b && ab == 0) ab = t;
            if (j == c && ab != 0) bc = t - ab;
            return bc != 0;
        });
        bool finished = (bc != 0);
        n_successful = n_successful + finished;
        print(n_successful);
        return std::make_tuple(finished, ab, bc);
    });

    real t = 0;
    for (auto const &i : hits) {
        if (first_of(i)) t += second_of(i) * third_of(i);
        print(t);
    }
    t /= n_successful;

    BEEP(H(a, b), H(b, c), H(a, b) * H(b, c), t, t / 2);
};

PROTOTYPE("hitting-time-probability") = [](Context ct) {
    Local ex(6);
    auto v = enumerate_states(jump_state("UCGAAAAAGATCG", {}, moves::full));
    auto R = rates_from_states(v);
    auto p = stationary_populations(v);
    auto Z = fundamental_from_rates(R, p);
    auto H = hitting_from_fundamental(Z, p);
    RandomWalker<real> const walker(R);

    auto n = len(v);
    usize a = n / 4, c = 3 * n / 4, b = c + 1;
    usize m = 100000;
    std::atomic<real> n_b{0}, n_c{0};

    auto hits = ex.map(m, 1, [&](auto const &...){
        auto p = walker(a, 10000.0, [&](auto i, auto j, auto) {
            return (j == b || j == c);
        });
        if (p.first == b) n_b = n_b + 1;
        if (p.first == c) n_c = n_c + 1;
        print(n_b, n_c);
        return 0;
    });

    BEEP(n_b / (n_b + n_c));

    BEEP((H(a, c) + H(c, b) - H(a, b)) / (H(b, c) + H(c, b)));
    BEEP(a,b,c);
};

PROTOTYPE("multiplied-committor") = [](Context ct) {
    Local ex(6);
    auto v = enumerate_states(jump_state("UCGAAAAAGATCG", {}, moves::full));
    auto R = rates_from_states(v);
    auto p = stationary_populations(v);
    auto Z = fundamental_from_rates(R, p);
    auto H = hitting_from_fundamental(Z, p);
    RandomWalker<real> const walker(R);

    auto n = len(v);
    usize a = n / 4, b = n / 3 + 2, c = 3 * n / 4, d = 21; // d = 21 for connected, d = 20 for not connected
    usize m = 100000;
    std::atomic<real> n_successful{0};

    // Pa(b < c or d) == Pa(b < c) Pa(b < d)?

    auto hits = ex.map(m, 1, [&](auto const &...) -> real {
        bool finished;
        auto p = walker(a, 100000.0, [&](auto i, auto j, auto) {
            finished = (j == b || j == c || j == d);
            return (j == b || j == c || j == d);
        });
        n_successful = n_successful + finished;
        if (p.first == b) return 1;
        else return 0;
    });
    print(sum(hits) / n_successful);
    print(n_successful);

    auto abc = (H(a, c) + H(c, b) - H(a, b)) / (H(c, b) + H(b, c));
    auto abd = (H(a, d) + H(d, b) - H(a, b)) / (H(d, b) + H(b, d));
    print(abc, abd, abc * abd);

    print(H.row(a).eval());
};

}
