#include "../Test.h"
#include <nupack/types/Sequence.h>

namespace nupack {

UNIT_TEST("sequence/check-base-subset") = [](Context ct) {
    Sequence seq("ACGTURMSWKYVHDBN");
    zip(seq, [&](auto b) {ct.require(is_base_specialization(Base('N'), b));});
    seq = Sequence("A");
    zip(seq, [&](auto b) {ct.require(is_base_specialization(Base('A'), b));});
    seq = Sequence("C");
    zip(seq, [&](auto b) {ct.require(is_base_specialization(Base('C'), b));});
    seq = Sequence("G");
    zip(seq, [&](auto b) {ct.require(is_base_specialization(Base('G'), b));});
    seq = Sequence("TU");
    zip(seq, [&](auto b) {ct.require(is_base_specialization(Base('T'), b));});
    seq = Sequence("UT");
    zip(seq, [&](auto b) {ct.require(is_base_specialization(Base('U'), b));});
    seq = Sequence("AGR");
    zip(seq, [&](auto b) {ct.require(is_base_specialization(Base('R'), b));});
    seq = Sequence("ACM");
    zip(seq, [&](auto b) {ct.require(is_base_specialization(Base('M'), b));});
    seq = Sequence("CGS");
    zip(seq, [&](auto b) {ct.require(is_base_specialization(Base('S'), b));});
    seq = Sequence("AUW");
    zip(seq, [&](auto b) {ct.require(is_base_specialization(Base('W'), b));});
    seq = Sequence("GUK");
    zip(seq, [&](auto b) {ct.require(is_base_specialization(Base('K'), b));});
    seq = Sequence("CUY");
    zip(seq, [&](auto b) {ct.require(is_base_specialization(Base('Y'), b));});
    seq = Sequence("ACGMRSV");
    zip(seq, [&](auto b) {ct.require(is_base_specialization(Base('V'), b));});
    seq = Sequence("ACUTMWYH");
    zip(seq, [&](auto b) {ct.require(is_base_specialization(Base('H'), b));});
    seq = Sequence("AGUTRWKD");
    zip(seq, [&](auto b) {ct.require(is_base_specialization(Base('D'), b));});
    seq = Sequence("CGUTSYKB");
    zip(seq, [&](auto b) {ct.require(is_base_specialization(Base('B'), b));});
};


UNIT_TEST("sequence/check-sequence-subset") = [](Context ct) {
    Sequence  generic("ACGTURMSWKYVHDBN");
    Sequence specific("ACGUTACGUGCCCGGU");
    ct.require(is_sequence_specialization(generic, specific));
};


UNIT_TEST("sequence/check-complement") = [](Context ct) {
    Sequence seq("ACGTRMSWKYVHDBN_");
    ct.equal(reverse_complement(seq), Sequence("_NVHDBRMWSKYACGT"));
};

// [](Context ct) {};

} // nupack
