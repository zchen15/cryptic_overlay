#include "../Test.h"

#include <nupack/execution/Local.h>
#include <nupack/types/Matrix.h>
#include <nupack/iteration/Range.h>
#include <nupack/standard/Vec.h>
#include <nupack/standard/Map.h>
#include <nupack/standard/Variant.h>
#include <nupack/standard/Optional.h>
#include <nupack/loop/EdgeSet.h>
#include <nupack/reflect/Serialize.h>

#include <boost/optional/optional_io.hpp>
#include <sstream>

namespace nupack {

struct TestRepr {
    using is_member_comparable = True;
    int a, b;
    auto save_repr() const {return std::make_tuple(a, b);}
    void load_repr(std::tuple<int, int> t) {std::tie(a, b) = t;}
    NUPACK_REFLECT(TestRepr, a, b);
};

struct TestNamedRepr {
    using is_member_comparable = True;
    int a, b;
    static constexpr auto repr_names() {return make_names("first", "second");}
    auto save_repr() const {return std::make_tuple(a, b);}
    void load_repr(int x, int y) {a = x; b = y;}
    NUPACK_REFLECT(TestNamedRepr, a, b);
};

struct TestReflect {
    using is_member_comparable = True;
    int x, y;
    std::vector<int> z;
    NUPACK_REFLECT(TestReflect, x, y, z);
};

template <class T>
void test_json(Context &ct, T const &t) {
    auto s = json(t);
    if (test_output()) print(s);
    T t2 = s.get<T>();
    ct.equal(t2, t);
}

/******************************************************************************************/

UNIT_TEST("serialize/unique") = [](Context ct) {
    auto t = std::make_unique<double>(5.5);
    auto j = json(t);
    if (test_output()) print(j);
    auto u = j.get<std::unique_ptr<double>>();
    ct.equal(*t, *u);
};

UNIT_TEST("serialize/shared0") = [](Context ct) {
    std::shared_ptr<double> t;
    auto j = json(t);
    if (test_output()) print(j);
    auto u = j.get<std::shared_ptr<double>>();
    ct.equal(t, u);
};

UNIT_TEST("serialize/shared1") = [](Context ct) {
    auto t = std::make_shared<double>(5.5);
    auto j = save_shared(t, SharedMode::copy);
    if (test_output()) print(j);
    auto u = j.get<std::shared_ptr<double>>();
    ct.equal(*t, *u);
};

UNIT_TEST("serialize/shared2") = [](Context ct) {
    auto t = std::make_shared<double>(5.5);
    auto t2 = t;
    {
        auto j = save_shared(t, SharedMode::alias);
        if (test_output()) print(j);
        auto u = load_shared<std::shared_ptr<double>>(j.at(0), j.at(1));
        ct.equal(*t, *u);
    } {
        auto j = save_shared(t, SharedMode::copy);
        if (test_output()) print(j);
        auto u = load_shared<std::shared_ptr<double>>(j);
        ct.equal(*t, *u);
    }
};

/******************************************************************************************/

UNIT_TEST("serialize/variant") = [](Context ct) {
    test_json(ct, Variant<bool, int, std::string>{std::string("ok")});
    test_json(ct, Variant<bool, int, std::string>{true});
    test_json(ct, Variant<bool, int, std::string>{5});
    test_json(ct, Optional<int>{5});
    test_json(ct, Optional<int>{});
};

UNIT_TEST("serialize/class") = [](Context ct) {
    test_json(ct, TestNamedRepr{4,5});
    test_json(ct, TestRepr{4,5});
    test_json(ct, TestReflect{4,5, {1,2,4}});
};

UNIT_TEST("serialize/tuple") = [](Context ct) {
    test_json(ct, std::make_tuple(1, 2, std::string("test")));
    test_json(ct, std::make_pair(2.0, std::string("test")));
    test_json(ct, std::map<std::vector<int>, std::string>());
};

UNIT_TEST("serialize/vector") = [](Context ct) {
    test_json(ct, vec<int>{1, 2, 3, 4});
    test_json(ct, vec<double>{1, 2, 3, 4});
    test_json(ct, small_vec<float>{1, 2, 3, 4});
};

UNIT_TEST("serialize/members") = [](Context ct) {
    test_json(ct, TestReflect{1, 2, {1, 2, 3}});
};

UNIT_TEST("serialize/edgeset") = [](Context ct) {
    test_json(ct, EdgeSet());
};

UNIT_TEST("serialize/span") = [](Context ct) {
    test_json(ct, span(1, 5));
};

UNIT_TEST("serialize/array") = [](Context ct) {
    test_json(ct, std::array<int, 3>{1,2,3});
    test_json(ct, std::pair<int, int>{1,2});
};

UNIT_TEST("serialize/sequence") = [](Context ct) {
    test_json(ct, Sequence("ACTGATCGTA"));
    test_json(ct, Base('G'));
};

UNIT_TEST("serialize/armadillo") = [](Context ct) {
    Mat<double> m(3, 4); m.fill(1);
    // test_json(ct, m);
};

UNIT_TEST("serialize/stream") = [](Context ct) {

    std::stringstream is("{}{}{}[]{}1\"a\"true");
    for (auto i : range(8)) {
        json j;
        is >> j;
        std::cout << j;
    }
    // test_json(ct, m);
};

// PROTOTYPE("memo") = [](Context ct) {
//     Memo_Map map;
//     int x;
//     x = map.ram_call("ram", []{return 2;});
//     ct.equal(x, 2);
//     x = map.ram_call("ram", []{return 2;});
//     ct.equal(x, 2);
//
//     x = map.disk_call("disk", []{return 2;});
//     ct.equal(x, 2);
//     //for (auto const &i : map) print(i);
//     oa(map);
// }
//
// PROTOTYPE("exec") = [](Context ct) {
//     Cached_Executor<Local> ex("cache.json", 4);
//     auto blah = ex.call("testing1", []{return 2;});
//     print(blah);
//
//     arma::mat goo1(10, 10);
//     print(serialization_size(goo1));
//     string TestNamedRepr(1000, 'a');
//     print(serialization_size(TestNamedRepr));
//
//     auto blah2 = ex.call("testing2", [&]{return goo1;});
//     auto blah3 = ex.call("testing3", [&]{return TestNamedRepr;});
// }

/******************************************************************************************/

}






