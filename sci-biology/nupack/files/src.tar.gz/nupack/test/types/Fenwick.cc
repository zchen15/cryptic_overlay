#include "../Test.h"

#include <nupack/algorithms/Utility.h>
#include <nupack/types/Fenwick.h>
#include <nupack/types/IO.h>

namespace nupack {

UNIT_TEST("fenwick/emplace") = [](Context ct) {
    Fenwick<double> x(0);
    x.emplace_back(1);
    x.emplace_back(2);
    x.emplace_back(3);
    x.emplace_back(4);
    x.emplace_back(5);
    x.emplace_back(6);
    ct.equal(x.sum(0), 0);
    ct.equal(x.sum(1), 1);
    ct.equal(x.sum(2), 3);
    ct.equal(x.sum(3), 6);
    ct.equal(x.sum(4), 10);
    ct.equal(x.sum(5), 15);
    ct.equal(x.sum(6), 21);
    ct.equal(x.total(), 21);
    x.pop_back();
    ct.equal(x.sum(0), 0);
    ct.equal(x.sum(1), 1);
    ct.equal(x.sum(2), 3);
    ct.equal(x.sum(3), 6);
    ct.equal(x.sum(4), 10);
    ct.equal(x.sum(5), 15);
    ct.equal(x.total(), 15);
};

UNIT_TEST("fenwick/sum") = [](Context ct) {
    Fenwick<double> x(0, {1,2,3,4,5});
    ct.equal(x.sum(0), 0);
    ct.equal(x.sum(1), 1);
    ct.equal(x.sum(2), 3);
    ct.equal(x.sum(3), 6);
    ct.equal(x.sum(4), 10);
    ct.equal(x.sum(5), 15);
    ct.equal(x.total(), 15);
    x.update(2, 5);
    ct.equal(x.sum(0), 0);
    ct.equal(x.sum(1), 1);
    ct.equal(x.sum(2), 3);
    ct.equal(x.sum(3), 8);
    ct.equal(x.sum(4), 12);
    ct.equal(x.sum(5), 17);
    ct.equal(x.total(), 17);
    x.update(2, 3);
    ct.equal(x.sum(0), 0);
    ct.equal(x.sum(1), 1);
    ct.equal(x.sum(2), 3);
    ct.equal(x.sum(3), 6);
    ct.equal(x.sum(4), 10);
    ct.equal(x.sum(5), 15);
    ct.equal(x.total(), 15);
    x.swap_pos(0, 4);
    ct.equal(x.sum(0), 0);
    ct.equal(x.sum(1), 5);
    ct.equal(x.sum(2), 7);
    ct.equal(x.sum(3), 10);
    ct.equal(x.sum(4), 14);
    ct.equal(x.sum(5), 15);
    ct.equal(x.total(), 15);
    x.swap_pos(2, 3);
    ct.equal(x.sum(0), 0);
    ct.equal(x.sum(1), 5);
    ct.equal(x.sum(2), 7);
    ct.equal(x.sum(3), 11);
    ct.equal(x.sum(4), 14);
    ct.equal(x.sum(5), 15);
    ct.equal(x.total(), 15);
};

UNIT_TEST("fenwick/find") = [](Context ct) {
    Fenwick<double> x(0, {5,6,7,9});
    ct.equal(x.find(3).first, 0);
    ct.equal(x.find(5.5).first, 1);
    ct.equal(x.find(12).first, 2);
    ct.equal(x.find(26).first, 3);

    auto x2 = Fenwick<double>(0, {0.00709307, 0.167838, 0.273077, 25.3703, 2.76207});
    ct.equal(x2.find(26.1047).first, 4);
};

PROTOTYPE("fenwick/recursion") = [](Context ct) {
    int n = 0, max = 256;
    for (auto const p : range<std::int16_t>(max)) {
        print(as_bitset(p), int(p));
        for (auto i = minus_one(p); i >= pop_one_bit(p); i = pop_one_bit(i)-1, ++n) print(as_bitset(i), int(i));
        print(string(20, '-'));
    }
    ct.equal(n, max-1);
};

}
