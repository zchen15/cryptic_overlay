#include "../Test.h"
#include <nupack/execution/Local.h>
#include <nupack/execution/ThreadPool.h>
#include <nupack/execution/NetworkPool.h>

namespace nupack {

PROTOTYPE("future-promise") = [](Context ct) {
    std::promise<int> p;
    p.set_value(1);
    auto f = p.get_future();
    ct.equal(f.get(), 1);
}

PROTOTYPE("server-8222") = [](Context ct) {
    asio::io_service ios;
    using TCP = typename asio::ip::tcp;
    NetworkPool::Endpoint e{TCP::v4(), 8222};
    NetworkPool network(ios, e);
    BEEP("network constructed");
    ios.run();
    BEEP("ios done");
    sleep(5s);
    network.connect("8889");
    BEEP("network connected");
}

PROTOTYPE("client-8222") = [](Context ct) {
    asio::io_service ios;
    using TCP = typename asio::ip::tcp;
    NetworkPool::Endpoint e{TCP::v4(), 8889};
    NetworkPool network(ios, e);
    BEEP("network constructed");
    sleep(5s);
    network.connect("8222");
    BEEP("network connected");
    ios.run();
    BEEP("ios done");
}

PROTOTYPE("spread]") = [](Context ct) {
    Local ex(4);
    ex.spread(range(10), 1, [](auto i){std::this_thread::sleep_for(2s); print(i);});
}

PROTOTYPE("queue]") = [](Context ct) {
    ThreadPool<> ex(4);
    auto f = [] {std::this_thread::sleep_for(2s); print("done"); return false;};
    for (auto i : range(10)) ex.enqueue(f);
    ex.spread(range(10), 1, [](usize i){std::this_thread::sleep_for(2s); print(i);});
}

PROTOTYPE("queue2]") = [](Context ct) {
    ThreadPool<> ex(4);
    ex.spread(range(10), 1, [](auto i){std::this_thread::sleep_for(2s); print(i);});
}

PROTOTYPE("execs]") = [](Context ct) {
    auto execs = std::make_tuple(Local(), Thread_Exec(), Local());
    for_each(execs , [](auto &ex) {
        ex.fixed_split();
        ex.affinity_split();
        ex.map_reduce(10, 1, [](auto i) {return i;});
        echo | ex.spread(range(10), 1, [](auto i){std::this_thread::sleep_for(1s); print(i);});
    });
}

}
