#include <nupack/types/Generator.h>
#include <nupack/standard/Vec.h>
#include <nupack/iteration/Range.h>
#include "../Test.h"

namespace nupack {

/******************************************************************************************/

UNIT_TEST("coroutine") = [](Context ct) {
    auto fun = [](std::size_t n, auto &&f) {for (std::size_t i = 0; i != n; ++i) f(i);};
    auto n = std::size_t(1e5);
    vec<std::size_t> reference, blocked, nonblocked;

    auto t1 = time_it([&]{
        for (auto i : range(n)) reference.push_back(i);
    });

    auto t2 = time_it([&]{
        for (auto i : BlockedGenerator<std::size_t, 512>(n, fun)) blocked.push_back(i);
    });

    auto t3 = time_it([&]{
        for (auto i : Generator<std::size_t>(n, fun)) nonblocked.push_back(i);
    });

    ct.equal(reference, blocked);
    ct.equal(reference, nonblocked);
    if (test_output()) print("Sequential Blocked Unblocked\n", t1, t2, t3);
};

/******************************************************************************************/

}
