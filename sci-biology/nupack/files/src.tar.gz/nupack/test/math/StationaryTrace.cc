#include <nupack/math/StationarySolve.h>
#include <nupack/reflect/Serialize.h>
#include "../Test.h"

namespace nupack::trace {

/******************************************************************************************/

UNIT_TEST("trace/max-trace-column/bounded") = [](Context ct) {
    repeat_test(ct, 100000, [&](Ignore) {
        for (auto min : {0.0}) {
            la::Mat<real> const A = la::random_spd<real>(10), B = la::random_spd<real>(10);
            la::Mat<real> const C = la::randn(5, 10);
            la::Col<real> x = la::randu(10);
            if ((C * x).min() < 0) return;

            real r0 = trace_objective(x, A, B);
            ConstraintOptions<real> const cops{min, 1e10};
            auto [s0, s1, satisfied] = maximize_constrained_column(x, A, B, C, cops);
            real r1 = trace_objective(x, A, B);

            ct(HERE).less_eq(-1e-10, (C * x).min());
            ct(HERE).near(r0, s0, x);
            ct(HERE).near(r1, s1, x);
            ct(HERE).less(r0, r1);
        }
    });
};

/******************************************************************************************/

UNIT_TEST("trace/maximize/bounded") = [](Context ct) {
    repeat_test(ct, 100, [&](Ignore) {
        // for (auto m: {2, 3, 4, 6, 8}) {
        for (auto m: {4}) {
            la::Mat<real> const A = la::random_spd<real>(10), B = la::random_spd<real>(10);
            la::Col<real> const p = la::randu(10);
            ConstraintOptions<real> const cops{0, 1e10};
            Options<real> const ops{0, 1e10, 1e-6, 10000};

            auto out = stationary_maximum(m, A, B, p, Init::eigenvectors, cops, ops);

            ct(HERE).require(out.converged, out) &&
                ct(HERE).less_eq(0, out.solution.min());

            real r2 = stationary_objective(out.solution, A, B, p);
            ct(HERE).within(out.objective, r2, 1e-2, out);
        }
    });
};

/******************************************************************************************/

}
