#include <nupack/algorithms/Numeric.h>
#include <nupack/math/QuadraticRatio.h>
#include <nupack/math/Matrices.h>
#include <nupack/reflect/Serialize.h>
#include "../Test.h"

namespace nupack::trace {

/******************************************************************************************/

void test_quadratic_ratio(Context &ct, char const *fn, bool nn) {
    std::ifstream ifs(path_join(DefaultDataPath, fn));
    json j;
    ifs >> j;
    auto const v = std::move(j).get<vec< std::array<real, 8> >>();

    for (auto const &x : v) {
        Ratio<real> q{x[0], x[1], x[2], x[3], x[4], x[5]};
        auto p = nn ? q.nonnegative_solution(1e100) : q.unbounded_solution(1e100);
        ct.info("estimate", p);
        ct.info("mathematica", std::make_pair(x[6], x[7]));
        ct.less(x[7] - p.second, 1e-6);
    }
}

UNIT_TEST("trace/max-ratio/unbounded") = [](Context ct) {
    test_quadratic_ratio(ct, "unbounded-quadratic-ratio.json", false);
};

UNIT_TEST("trace/max-ratio/nonnegative") = [](Context ct) {
    test_quadratic_ratio(ct, "nonnegative-quadratic-ratio.json", true);
};

/******************************************************************************************/

UNIT_TEST("trace/max-ratio/bounded") = [](Context ct) {
    std::ifstream ifs(path_join(DefaultDataPath, "bounded-quadratic-ratio.json"));
    json j;
    ifs >> j;
    auto const v = std::move(j).get<vec< std::array<real, 10> >>();

    for (auto const &x : v) {
        Ratio<real> q{x[2], x[3], x[4], x[5], x[6], x[7]};
        auto p = q.bounded_solution(x[0], x[1]);
        ct.info("estimate", p);
        ct.info("mathematica", std::make_pair(x[8], x[9]));
        ct.less(x[9] - p.second, 1e-6);
    }
};

/******************************************************************************************/

UNIT_TEST("trace/polynomial-terms") = [](Context ct) {
    repeat_test(ct, 10000, [&](Ignore) {
        la::Mat<real> A = la::random_spd<real>(10);
        la::Col<real> x = la::randu(10);
        auto i = random_range(0, 10);
        auto [a, b, c] = polynomial_terms(A, x, la::dot(x, A * x), i);
        auto xi = x(i);
        auto check = la::dot(x, A * x);
        ct.near(a * xi * xi + b * xi + c, check);
    });
};

/******************************************************************************************/

/// (x^T A Y^{-1} A x)(x Y x) > (x A x)^2, Y diagonal
UNIT_TEST("trace/square-identity") = [](Context ct) {
    repeat_test(ct, 10000000, [&](Ignore) {
        la::Mat<real> const A = la::random_spd<real>(5);
        la::Col<real> x = la::randn(5), y = la::randu(5);
        ct(HERE).greater_eq(la::dot(x, A, la::diagmat(1/y), A, x) * la::dot(x, la::diagmat(y), x),
                            sq(la::dot(x, A, x)), A, x, y);
    });
};

/******************************************************************************************/

UNIT_TEST("trace/square-constraint") = [](Context ct) {
    uint m = 3, n = 5;
    usize success = 0;
    repeat_test(ct, std::size_t(1e8), [&](Ignore) {
        la::Mat<real> const B = la::random_spd<real>(n), A = B * B;
        la::Mat<real> const X = la::randu(n, m);
        la::Mat<real> const C = la::inv(X.t() * B * X) * X.t() * A * X * la::inv(X.t() * B * X);
        real v = C.min(), v1 = *inf, v2 = *inf, v3 = *inf;
        // BEEP(C, v);
        for (auto i : range(m)) {
            auto x = X.col(i);
            std::vector<la::uword> v;
            for (auto j : range(m)) if (i != j) v.push_back(j);

            la::Mat<real> Y = X.cols(la::uvec(v)), U = la::inv(Y.t() * B * Y);
            la::Col<real> y = (U * Y.t() * A * Y * U * Y.t() * B - U * Y.t() * A) * x;
            v1 = min(v1, y.min());
            y = -U * Y.t() * A * x;
            v2 = min(v2, y.min());

            la::Mat<real> W = la::eye(n, n) - Y * U * Y.t() * B;
            y = U * Y.t() * (A * W - la::dot(x, W.t(), A, W, x) / la::dot(x, B, W, x) * B) * x;
            v3 = min(v3, y.min());
        }
        // ct(HERE).equal(v >= 0, v1 >= 0 && v2 >= 0 && la::inv(X.t() * B * X).min() >= 0, v, v1, v2);
        ct(HERE).equal(v >= 0, v3 >= 0, v, v3);
        // ct(HERE).equal(ok, ok3);
        success += (v >= 0);
    });
    BEEP(success / 1e7);
};

/******************************************************************************************/

/// Iff (Y^T A Y) Y^T A x is negative, then (X^T A X)^{-1} is positive
UNIT_TEST("trace/positive-inverse-cd") = [](Context ct) {
    uint n = 5, m = 3, count = 0;
    repeat_test(ct, usize(1e6), [&](Ignore) {
        // Check that Q being all positive is same as v being all positive
        la::Mat<real> const A = la::random_spd<real>(n),
                            X = la::randn(n, m),
                            Q = la::inv(X.t() * A * X);
        real c1 = Q.min(), c2 = *inf;

        for (auto i : range(m)) {
            auto const x = X.col(i);
            auto Y = X; Y.shed_col(i);
            la::Col<real> v = -la::inv(Y.t() * A * Y) * Y.t() * A * x;
            c2 = min(c2, v.min());
        }

        ct.equal(c1 >= 0, c2 >= 0, c1, c2, Q);
        if (c1 >= 0) ++count;
    });
    print(count);
};

/******************************************************************************************/

/// Iff (Y^T A Y) Y^T A x is positive, then (X^T A X)^{-1} has negative offdiagonals
UNIT_TEST("trace/negative-inverse-cd") = [](Context ct) {
    uint n = 5, m = 3, count = 0;
    repeat_test(ct, usize(1e6), [&](Ignore) {
        // Check that Q being all positive is same as v being all positive
        la::Mat<real> const A = la::random_spd<real>(n),
                            X = la::randn(n, m),
                            Q = la::inv(X.t() * A * X);
        real c1 = (la::diagmat(Q.diag()) - Q).min(), c2 = *inf;

        for (auto i : range(m)) {
            auto const x = X.col(i);
            auto Y = X; Y.shed_col(i);
            la::Col<real> v = la::inv(Y.t() * A * Y) * Y.t() * A * x;
            c2 = min(c2, v.min());
        }

        ct.equal(c1 >= 0, c2 >= 0, c1, c2, Q);
        if (c1 >= 0) ++count;
    });
    print(count);
};

/******************************************************************************************/

/// Iff (X^T B X)^{-1} (X^T A X) (X^T B X)^{-1} has positive offdiagonals
UNIT_TEST("trace/positive-square-cd") = [](Context ct) {
    uint n = 5, m = 3, count = 0;
    repeat_test(ct, usize(1e7), [&](Ignore) {
        // Check that Q being all positive is same as v being all positive
        la::Mat<real> const B = la::random_spd<real>(n),
                            A = la::random_spd<real>(n),
                            X = la::pow(la::randn(n, m), 3),
                            Q = la::inv(X.t() * B * X),
                            R = Q * X.t() * A * X * Q;
        real c1 = R.min(), c2 = *inf, c3 = *inf;

        // if (Q.min() < 0) return; // not necessary but helps to hit these relevant cases faster

        for (auto i : range(m)) {
            auto const x = X.col(i);
            auto Y = X; Y.shed_col(i);
            la::Mat<real> U = la::inv(Y.t() * B * Y),
                          W = la::eye(n, n) - Y * U * Y.t() * B;
            real r = la::dot(x, W.t(), A, W, x) / la::dot(x, B, W, x);
            min_eq(c2, (U * Y.t() * (A * W - r * B) * x).min()); // I think this is basically exact
            min_eq(c3, (U * Y.t() * A * W * x).min()); // proxy
        }

        ct.equal(c1 >= 0, c2 >= 0, c1, c2, Q);
        if (c3 >= 0 && Q.min() >= 0) {++count; ct.require(c1);}
    });
    print(count);
};

/******************************************************************************************/

/// Iff (X^T B X)^{-1} (X^T A X) (X^T B X)^{-1} has negative offdiagonals
UNIT_TEST("trace/negative-square-cd") = [](Context ct) {
    uint n = 5, m = 3, count = 0;
    repeat_test(ct, usize(1e7), [&](Ignore) {
        // Check that Q being all positive is same as v being all positive
        la::Mat<real> const B = la::random_spd<real>(n),
                            A = la::random_spd<real>(n),
                            X = la::pow(la::randn(n, m), 3),
                            Q = la::inv(X.t() * B * X),
                            R = Q * X.t() * A * X * Q;
        real c1 = (10 * la::diagmat(R.diag()) - R).min(), c2 = *inf, c3 = *inf;

        for (auto i : range(m)) {
            auto const x = X.col(i);
            auto Y = X; Y.shed_col(i);
            la::Mat<real> U = la::inv(Y.t() * B * Y),
                          W = la::eye(n, n) - Y * U * Y.t() * B;
            real r = la::dot(x, W.t(), A, W, x) / la::dot(x, B, W, x);
            min_eq(c2, (-(U * Y.t() * (A * W - r * B) * x)).min()); // I think this is basically exact
            min_eq(c3, (-U * Y.t() * A * W * x).min()); // proxy
        }

        ct.equal(c1 >= 0, c2 >= 0, c1, c2, Q);
        if (c3 >= 0 && (10 * la::diagmat(Q.diag()) - Q).min() >= 0) {++count; ct.require(c1);}
    });
    print(count);
};

}
