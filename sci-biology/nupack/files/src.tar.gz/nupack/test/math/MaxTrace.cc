#include <nupack/math/ScalarSolve.h>
#include <nupack/math/Matrices.h>
#include <nupack/reflect/Serialize.h>
#include "../Test.h"

namespace nupack::trace {

/******************************************************************************************/

template <class S>
void test_max_trace_column(Context &ct, S solver) {
    repeat_test(ct, 10000, [&](Ignore) {
        la::Mat<real> A = la::random_spd<real>(10), B = la::random_spd<real>(10);
        la::Col<real> x = la::randu(10);

        real r0 = trace_objective(x, A, B);
        auto [s0, s1] = solver(x, A, B);
        real r1 = trace_objective(x, A, B);

        ct(HERE).near(r0, s0, x);
        ct(HERE).near(r1, s1, x);
        ct(HERE).less(r0, r1);
    });
}

UNIT_TEST("trace/max-trace-column/unbounded") = [](Context ct) {
    test_max_trace_column(ct, UnboundedColumnSolver<real>());
};

UNIT_TEST("trace/max-trace-column/nonnegative") = [](Context ct) {
    test_max_trace_column(ct, NonNegativeColumnSolver<real>());
};

/******************************************************************************************/

PROTOTYPE("math/maximize-trace-time") = [](Context ct) {
    for (auto m2 : range(9)) {
        for (auto n2 : range(m2 + 1, 10)) {
            auto const m = 4 << m2, n = 4 << n2;
            la::Mat<real> A = la::random_spd<real>(n), B = la::random_spd<real>(n);
            la::Mat<real> X = la::randu(n, m);
            ct.info("m", m);
            ct.info("n", n);
            print(m, n, time_it([&] {return maximize_trace(std::move(X), A, B, Options<real>(0, 1e10, 1e-4, 1));}));
        }
    }
};

/******************************************************************************************/

void test_maximize_init(Context &ct, Options<real> const &ops) {
    repeat_test(ct, 100, [&](Ignore) {
        // for (auto m: {2, 3, 4, 6, 8}) {
        for (auto m: {4}) {
            la::Mat<real> A = la::random_spd<real>(10), B = la::random_spd<real>(10);
            la::Mat<real> X = la::randu(10, m);

            real r1 = trace_objective(X, A, B);
            auto out = maximize_trace(std::move(X), A, B, ops);
            X = std::move(out.solution);
            ct.less_eq(ops.minimum, X.min());

            real r2 = trace_objective(X, A, B);
            ct.info("iters", out.iters);
            ct.info("objective", out.objective);
            ct.less(r1, r2);
        }
    });
}

UNIT_TEST("trace/maximize/nonnegative") = [](Context ct) {
    test_maximize_init(ct, Options<real>(0, 1e10, 1e-6, 1e4));
};

UNIT_TEST("trace/maximize/unbounded") = [](Context ct) {
    test_maximize_init(ct, Options<real>(-1e10, 1e10, 1e-6, 1e4));
};

/******************************************************************************************/

UNIT_TEST("math/maximize-trace-eigvec") = [](Context ct) {
    repeat_test(ct, 1000, [&](Ignore) {
        la::Mat<real> A = la::random_spd<real>(10), B = la::random_spd<real>(10);

        auto out = ct.timed(1, [&] {
            return trace_maximum(4, A, B, Init::random, Options<real>(0, 1e10, 1e-6, 1e4));
        });
        ct.info("iters", out.iters);
        ct.less_eq(0, out.solution.min(), out.solution);
    });
};

UNIT_TEST("math/quadratic-decomposition") = [](Context ct) {
    repeat_test(ct, 1000, [&](Ignore) {
        la::Mat<real> A = la::random_spd<real>(10), B = la::random_spd<real>(10);
        la::Mat<real> X = la::randu(10, 4);

        real r = trace_objective(X, A, B);
        auto x = X.col(0);
        auto Y = X.tail_cols(X.n_cols - 1);
        auto [Bi, Ap, Bp] = decompose_trace(la::eval(Y), A, B);
        real r2 = decomposed_objective(x, A, Bi, Ap, Bp, Y);
        ct.near(r, r2);
    });
};

/******************************************************************************************/

}
