#include "../Test.h"
#include <nupack/loop/EdgeSet.h>

namespace nupack {

UNIT_TEST("edges") = [](Context ct) {
    auto e0 = EdgeSet(3, {1, 2, 9, Ether}, Ether);
    auto e1 = EdgeSet(5, {3, 2}, 3);
    auto e2 = EdgeSet(2, {4, 6, 5, 7}, 5);

    e0.replace(9, 10);
    ct.equal(e0.edges, EdgeList({1, 2, 10, Ether}));
    if (Debug) ct.throw_as<Error>([&] {e0.replace(9, 10);});
};

UNIT_TEST("multisequence") = [](Context ct) {
    auto s = random_sequences(1, 10);
    NickSequence ms{s};
    NickSequence ms2{s[0]};
    ct.equal(ms, ms2);
};

}
