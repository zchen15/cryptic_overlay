#include <nupack/model/Model.h>
#include <nupack/jump/JumpLoop.h>
#include "../Test.h"
#include <nupack/common/Random.h>

#include <chrono>
#include <map>
#include <set>

#include <boost/math/distributions/inverse_chi_squared.hpp>

namespace nupack {

/******************************************************************************************/

template <class O1, class O2, class KM>
void check_rates(Context &ct, O1 const &o1, O2 const &o2, KM const &km, int n=10000) {
    ct.equal(o1.total_add_rate(), about(o2.total_add_rate()));
    if (o1.total_add_rate() == 0.0) return;
    std::map<BasePairAddition, double> h1, h2;
    auto dist = boost::math::inverse_chi_squared();

    auto mvs = o1.add_moves();
    std::set<BasePairAddition> ref_moves{begin_of(mvs), end_of(mvs)};

    for (auto i : range(n)) {
        auto r = random_float() * o1.total_add_rate();
        auto m1 = o1.choose_split(r, km);
        ct.require(ref_moves.count(m1));
        ++h1.emplace(m1, 0).first->second;
        auto m2 = o2.choose_split(r, km);
        ct.require(ref_moves.count(m2));
        ++h2.emplace(m2, 0).first->second;
    }

    for (auto & p : h1) {p.second /= n; h2.emplace(p.first, 0);}
    for (auto & p : h2) {p.second /= n; h1.emplace(p.first, 0);}

    double diff = 0;
    zip(h1, h2, [&](auto m1, auto m2) {
        ct.equal(m1.first.dE, about(m2.first.dE));
        diff += (m1.second - m2.second) * (m1.second - m2.second) / (m1.second + m2.second);
    });

    auto check = boost::math::cdf(dist, diff);
    ct.require((1 - boost::math::cdf(dist, n * diff)) > 0.001, diff, check);
}

/******************************************************************************************/

void test_lazy_rates(Context &ct, vec<string> const &strings) {
    auto km = Model(Ensemble::min, {}, {}, {}, WobblePairing::off);

    SequenceList seqs; for (auto i : strings) seqs.emplace_back(Sequence(i));
    SubsequenceList v; for (auto const &i : seqs) v.emplace_back(i.data(), i.data() + i.size());

    auto full = JumpSequenceSet(v, moves::full);
    full.update(km);
    auto lazy = JumpSequenceSet(v, moves::lazy);
    lazy.update(km);

    for (auto const &m : std::get<LazyMoveGen>(lazy.gen).easy_moves)
        ct.require((m.s1 <= m.s2 || (m.s1 == m.s2 && m.b1 < m.b2)));

    ct.equal(full.total_add_rate(), about(lazy.total_add_rate()));

    check_rates(ct, full, lazy, km);
}

/******************************************************************************************/

UNIT_TEST("lazy/multiloop-rates") = [](Context ct) {
    test_lazy_rates(ct, {"AA", "TC", "GG", "CT"});
    test_lazy_rates(ct, {"ATCGTA", "TCTGC", "GCCCCCG", "CT"});
    test_lazy_rates(ct, {"ATCGAGTA", "TCTAGC", "GCCCCAACG", "CT", "AGCACGT"});
    test_lazy_rates(ct, {"TAGTCC", "GGACTAGCTAGC", "GATCGTAGCTGT", "ATCCGTGACG", "CGATCGACT"});
    test_lazy_rates(ct, {"GT", "ACATCG", "CTCGATCT", "AATCG", "CTTGCTA", "TGT", "AGGCCGTTCA", "TCTTTCGT", "AGTTGGG", "CATC"});
    test_lazy_rates(ct, {"TGGGTG", "CCG", "CCGAG", "CTACACC", "GCGACG", "CAGAAGGA", "TGGTTTTG", "CATGA", "TGGAA"});
    test_lazy_rates(ct, {"GACA", "TTTAT", "ACTATA", "TTAACTCAT", "AACGGT", "AACGACATA", "TGC", "GCCCGCG", "CTTGGAA", "TATCTTGCC"});
    test_lazy_rates(ct, {"TATAGGGTAG", "CGCCCATA", "TTGACCA", "TCGGCGGCGT", "ACTGTT", "ATCCTCA", "TGCGCCT", "AAA", "TGTTC", "GGATCAGC", "GATCGG", "CTTCAC", "GGA", "TGAACGAAT", "ATTCC", "GTCGGATT", "AGTCA", "TGATTTGGGA", "TGCA"});
    test_lazy_rates(ct, {"CTTCAAGGA", "TATCCATCCC", "GCC", "GCGCCTT", "ACACAAAGAA", "TGAGTT", "AACG", "CAGGC", "GAG", "CG", "CAGC", "GCA", "TT", "ATTCT", "AGCTCCCTC", "GTT", "AGAAGT", "ATCA", "TG", "CAAG"});
    test_lazy_rates(ct, {"GGGCC", "GTAAGTTC", "GTGAAT", "AAA", "TTTAGTC", "GTACTGTC", "GTGA", "TT", "ATGTACTCGC", "GTCGACCTA", "TGATATT", "AG", "CTAGTTAC", "GA", "TTA", "TTGGCTTT", "ATACGAACGC", "GCG", "CC"});
    test_lazy_rates(ct, {"CTAGATTTGA", "TCTC", "GGCT", "AAGGTTGCAT", "ATCGG", "CCCCAATA", "TGCGGT", "AAAGGTAAA", "TTGCT", "AGCTTGGGGA", "TCTG"});
    test_lazy_rates(ct, {"GC", "GT", "ACCAGGAC", "GA", "TTCTCATTGT", "AAG", "CTCGCTTCAC", "GCTC", "GACCC", "GGC"});
    test_lazy_rates(ct, {"CTG", "CCTTCCG", "CTTTGTCCTA", "TCGC", "GGCCAATGTG", "CTAGGCG", "CTGAAGG", "CTACG", "CCGCAC", "GTCTGGGTCT", "AGAA", "TGGGA", "TAATGGA", "TCATGCTAT", "ACATG", "CCTTCATACT", "ATTTCC", "GAGAG", "CT", "ATCG"});
    test_lazy_rates(ct, {"TAGGAT", "ACAGAA", "TTCACT", "ACCCCCTG", "CGTCCCGTT", "ATAC", "GGTGGC", "GGTACACGA", "TACC", "GT", "AGGG", "CCCA", "TGGTTG", "CTA", "TCCGTAGGC", "GTTGA", "TTCCGATT", "AGAGGGAAC", "GCTCGA"});
    test_lazy_rates(ct, {"CTAGATTC", "GAGGGGAGG", "CTCGACGTTT", "AG", "CCAAACCAC", "GAAC", "GCATTGG", "CAG", "CTGCACTTCA", "TG", "CGAA", "TTTTACCTT", "AAAATTTCC", "GCGAGG"});
    test_lazy_rates(ct, {"TAAGCGA", "TCGAAT", "AG", "CAA", "TATC", "GGTATA", "TCTGTCGA", "TACATTA"});
    test_lazy_rates(ct, {"CTCAGCAG", "CAAACTGGAT", "ATAGAATTA", "TGGCA", "TCCCGTT", "AGTGCATA", "TCAGATG"});
    test_lazy_rates(ct, {"AGCGG", "CGTAT", "ACTC", "GGTTAGC", "GTTAC", "GGG", "CA", "TTCAAGGGAA", "TT", "ATGGAAAAT", "ACCGGT", "AG", "CGCGCCCGT", "AA", "TAGAGTT", "AGATCCATG", "CGCGT", "AATCC", "GGAGTCCGT"});
    test_lazy_rates(ct, {"AAAATT", "AT", "AC", "GAGG", "CACGGTTA", "TTAA", "TTCT", "AA", "TTGGA", "TC", "GCACAT", "ACGAG", "CGACGCAT"});
    test_lazy_rates(ct, {"AGGTCGT", "ACCCCATTTC", "GGATAGT", "AG", "CCTC", "GACCGT", "ATACCGAAGC", "GAG", "CACTAAC", "GGTCCGGCG", "CTACGGTAC", "GAC", "GTA", "TCTAACTA", "TTCCAGCCAG", "CCGAGTGGA", "TAT"});
    test_lazy_rates(ct, {"ACGC", "GCGGGCTAAA", "TGCCCGTAAA", "TTTG", "CAAACCAG", "CCGACTC", "GA", "TCGCAT"});
    test_lazy_rates(ct, {"CCCGATACC", "GGGA", "TGATAGGGGC", "GGGCCGA", "TCCAA", "TATAATT", "AGACGCT", "AGT", "AAACTGCC", "GAGC", "GTTAG", "CCA", "TAGGTCT", "AGGGTG", "CGT", "ACTATGGG", "CGAGCAAAGC", "GTG"});
    test_lazy_rates(ct, {"TCGT", "ATTCTAC", "GAGT", "AGGCAG", "CTCCCGT", "AAC", "GCT", "AGCT", "AACGGAAG", "CAATCT", "AAG", "CTG", "CTG", "CCTC", "GCCTTCGAGA", "TA"});
    test_lazy_rates(ct, {"ACG", "CTCTCTCT", "ACGAGCA", "TTAC", "GGGATCTAT", "ACA", "TT", "ATAT", "ATTACCCT"});
    test_lazy_rates(ct, {"ATTGCTAAG", "CTCA", "TCGGCTGGCA", "TAGGGCCC", "GGACAC", "GA", "TATTGTCAT", "AGCAGTGAAC", "GCTGCT"});
    test_lazy_rates(ct, {"TTCAAT", "ACTTTCA", "TG", "CTCTAGGC", "GTTCT", "ACATCAAC", "GA", "TTG", "CTTACTCT", "AAA"});
    test_lazy_rates(ct, {"ATA", "TTGCAGGATA", "TCT", "AAGTGCC", "GCGATTGG", "CACATGG", "CTTCCCGAT", "AGGATCGAT", "ACGGG", "CGACTG", "CAGCGGGT", "ATCGCCT", "ATCTC", "GAGAAGCC", "GGT"});
    test_lazy_rates(ct, {"ATTG", "CAA", "TAGATC", "GCGAGC", "GC", "GGAT", "AGCATGA", "TAACGAGC", "GC", "GGGTTTGT", "AGA", "TG", "CCGC", "GTGCAATGA", "TCCG", "CT", "AACAAGCT", "ACGAAGCCGT", "AT"});
    test_lazy_rates(ct, {"GGCATTAAGA", "TTTCAGAATC", "GCAT", "AGTGATAGG", "CTCGAAGCGC"});
    test_lazy_rates(ct, {"CATGGGACG", "CAA", "TGGT", "ATTGTCA", "TCACGC", "GACTAGGATG"});
    test_lazy_rates(ct, {"GATAAAGAC", "GATG", "CTC", "GAATGCCA", "TCCA", "TGTCGACCAT", "AAGAAT", "ATGC", "GGGGGAGC", "GGGCTGG", "CCTAGGAGGC"});
    test_lazy_rates(ct, {"CCGCAGTT", "ATT", "ATCAGCGG", "CAAAC", "GGGTACCG", "CGAAAC", "GAGGGGGTC", "GTGTGATC", "GTCT", "AATTTTG", "CGAA", "TGGTAATAG", "CAA", "TTTC", "GGCATT", "ATG"});
    test_lazy_rates(ct, {"TCGATC", "GTAG", "CTA", "TTCA", "TTA"});
    test_lazy_rates(ct, {"AGCAGC", "GCGTCAAA", "TCACGCCTTA", "TCTC", "GTC", "GATC", "GGCTGAT"});
    /*
    from random import randint, choice
    def gen():
        ret = []
        n = randint(4, 20)
        for i in range(n):
            length = randint(2, 10)
            ret.append([choice(['A', 'C', 'G', 'T']) for _ in range(length)])
        for (i, r) in enumerate(ret):
            ret[(i + 1) % len(ret)][0] = {'A':'T', 'T':'A', 'C':'G', 'G':'C'}[r[-1]]
        return 'test_lazy_rates(ct, {' + ', '.join('"' + ''.join(i) + '"' for i in ret) + '});'
    */
};

/******************************************************************************************/

UNIT_TEST("lazy/interior-rates") = [](Context ct) {
    test_lazy_rates(ct, {"GGTTAATTGATGACCGTTTG", "CCTTTAGGATTCCGCTC"});
    test_lazy_rates(ct, {"CACCCAGAC", "GG"});
    test_lazy_rates(ct, {"AGAATTG", "CCCGATGCGAACCAT"});
    test_lazy_rates(ct, {"CGGTCAACCGGTCTTTT", "ACCGG"});
    test_lazy_rates(ct, {"CC", "GCGTGTAATG"});
    test_lazy_rates(ct, {"GCCA", "TCTTCACGCCGTACAAATC"});
    test_lazy_rates(ct, {"GAGGCTGCGTGGAA", "TGAGCTCGATCCTGCCC"});
    test_lazy_rates(ct, {"TGGGACCGTA", "TACACAGTACTAAATAA"});
    test_lazy_rates(ct, {"GC", "GCGATAGTGACGTAAAAC"});
    test_lazy_rates(ct, {"CCTACGGTCTTTCC", "GGAG"});
    test_lazy_rates(ct, {"ACGTCGCAATCGCGTGG", "CTGGGT"});
    test_lazy_rates(ct, {"TAAAAGGAATTTTGCA", "TTTCCACGGGCCGCTA"});
    test_lazy_rates(ct, {"TGCC", "GCCAGAAAGGTAA"});
    test_lazy_rates(ct, {"TGGCCGCATGTGCGC", "GTA"});
    test_lazy_rates(ct, {"CGTCAGACGATGATGTGTCA", "TGTAAGCAATCG"});
    test_lazy_rates(ct, {"GG", "CC"});
    test_lazy_rates(ct, {"ACTCATAAACTGCGC", "GTTAT"});
    test_lazy_rates(ct, {"GTATCGAGTTAGGGCC", "GGCGTTTC"});
    test_lazy_rates(ct, {"ATGACGTGACTTAACTA", "TATGGATAATGT"});
    test_lazy_rates(ct, {"TCCACGGAGCGTTTTACCG", "CCGGCACTTCCA"});
    test_lazy_rates(ct, {"CAA", "TCCAATCGTAAGATG"});
    test_lazy_rates(ct, {"ACCTT", "ATT"});
    test_lazy_rates(ct, {"TTATGCGACATTTCCGTT", "AAAGTTACTCGGGGATA"});
    test_lazy_rates(ct, {"TCCAAGCGCATACGAGGTGG", "CTCATAA"});
    test_lazy_rates(ct, {"GACTACGCC", "GGTAAGCCGTAAC"});
    test_lazy_rates(ct, {"GCTCGATAAAGA", "TTAGTC"});
    test_lazy_rates(ct, {"CACGTAGTGACC", "GGG"});
    test_lazy_rates(ct, {"GAGCTTTGAGAATGA", "TTAC"});
    test_lazy_rates(ct, {"TCGG", "CCGA"});
    test_lazy_rates(ct, {"GCTGGCGTCGACC", "GCTTCGAC"});
    /*
    from random import randint, choice
    def gen():
        ret = []
        for i in range(2):
            length = randint(2, 20)
            ret.append([choice(['A', 'C', 'G', 'T']) for _ in range(length)])
        for (i, r) in enumerate(ret):
            ret[(i + 1) % len(ret)][0] = {'A':'T', 'T':'A', 'C':'G', 'G':'C'}[r[-1]]
        return 'test_lazy_rates(ct, {' + ', '.join('"' + ''.join(i) + '"' for i in ret) + '});'
    */
};

/******************************************************************************************/

UNIT_TEST("lazy/hairpin-rates") = [](Context ct) {
    test_lazy_rates(ct, {"CCCAAG"});
    test_lazy_rates(ct, {"GCTCCC"});
    test_lazy_rates(ct, {"GAACTAC"});
    test_lazy_rates(ct, {"AGGGCATACACTCT"});
    test_lazy_rates(ct, {"CTAAGGACGTGGCCG"});
    test_lazy_rates(ct, {"TTTAGTCTATCA"});
    test_lazy_rates(ct, {"TACAGCTAATTATGGA"});
    test_lazy_rates(ct, {"TTCCCGTA"});
    test_lazy_rates(ct, {"ATCCCCTCT"});
    test_lazy_rates(ct, {"GGGCTAGGTCGAC"});
    test_lazy_rates(ct, {"GAATGGAC"});
    test_lazy_rates(ct, {"AGAGATAATCCGAGT"});
    test_lazy_rates(ct, {"TATGCTGA"});
    test_lazy_rates(ct, {"GGACAAC"});
    test_lazy_rates(ct, {"TACCGA"});
    test_lazy_rates(ct, {"GATGGTCCTTGTTATACCC"});
    test_lazy_rates(ct, {"TCGCTGCA"});
    test_lazy_rates(ct, {"CATTAGCCCTCG"});
    test_lazy_rates(ct, {"CGCTG"});
    test_lazy_rates(ct, {"CGCGCAGCACCGTGTACCCG"});
    test_lazy_rates(ct, {"TGGGACGGTCGCTTTATTGA"});
    test_lazy_rates(ct, {"CCCACGAG"});
    test_lazy_rates(ct, {"GTATGTC"});
    test_lazy_rates(ct, {"TCCCAGGGGATTAGAGA"});
    test_lazy_rates(ct, {"TACCCACTTAA"});
    test_lazy_rates(ct, {"TTTAAGAA"});
    test_lazy_rates(ct, {"ATAGTCATGTAACCACTT"});
    test_lazy_rates(ct, {"GATAACTCATAAATC"});
    test_lazy_rates(ct, {"GCGGGTATGTAGC"});
    test_lazy_rates(ct, {"AGCATCCCCATT"});
    /*
    from random import randint, choice
    def gen():
        ret = []
        for i in range(1):
            length = randint(5, 20)
            ret.append([choice(['A', 'C', 'G', 'T']) for _ in range(length)])
        for (i, r) in enumerate(ret):
            ret[(i + 1) % len(ret)][0] = {'A':'T', 'T':'A', 'C':'G', 'G':'C'}[r[-1]]
        return 'test_lazy_rates(ct, {' + ', '.join('"' + ''.join(i) + '"' for i in ret) + '});'
    */
};

/******************************************************************************************/

UNIT_TEST("lazy/exterior-rates") = [](Context ct) {
    test_lazy_rates(ct, {"GG", "CTATTTGG_", "_C"});
    test_lazy_rates(ct, {"GAGCC", "GTGTCA", "TGG", "CCCAATGAG", "CTCGGACCA_", "_GGCCAAC"});
    test_lazy_rates(ct, {"AGTAATT", "AACACGGTACCT", "ACCCGTAA", "TACGACTGGGTT", "AGTGAACGCG_", "_G", "CACTATGCGAGA", "TCCATC", "GCT"});
    test_lazy_rates(ct, {"TTTCCAA_", "_AA", "TAC", "GGGTTC", "GC", "GGC", "GGCTTCGTAT", "ACCACC", "GTTAACTGCGA"});
    test_lazy_rates(ct, {"CACGGTTCAG", "CCCG", "CTG_", "_CAAGTG"});
    test_lazy_rates(ct, {"CCGCACATTG_", "_TTACG"});
    test_lazy_rates(ct, {"CCCCCCTTATTT", "AACAAA", "TAGATCC", "GTCAAC", "GTT", "ACCCG_", "_GCAACATTA", "TTCAGGTTG"});
    test_lazy_rates(ct, {"ATGCGCCATT", "ACTATTA", "TCCTTTGAAGC_", "_TGTGTTCCGT", "AGTTGAC", "GGA", "TCTGCAGATT", "ATATCT"});
    test_lazy_rates(ct, {"CGGACGTGG", "CGCC", "GTC", "GAAACGCAG", "CTTGGTCC", "GTGA", "TGGTGTC_", "_TAGCGAACA", "TCAAGT", "ATCAGACACG"});
    test_lazy_rates(ct, {"TCAACA", "TGTATA_", "_CGGTTGAAGAC", "GTTGTAA"});
    test_lazy_rates(ct, {"TGGCTGA", "T_", "_AGTACCAAG", "CCGCTG", "CATAATAGT", "AGAGGATCAACT", "AAGTGCACAAA", "TCACGGAAAA"});
    test_lazy_rates(ct, {"_CTTACGTAG", "CAAGG", "CACC_"});
    test_lazy_rates(ct, {"_GC", "GATCGAGTG", "CA", "TGGGTC", "GTG", "CGC", "GTTGAA", "TGGGAGG", "CCCGTCGGTT_"});
    test_lazy_rates(ct, {"_CAGCAA", "TTCCA", "TTGCACA", "TCCT_"});
    test_lazy_rates(ct, {"_AGAT", "AGGC", "GAAC", "GCCTG", "CGG", "CGCGTGGAGCCC", "GGGTCG", "CAATGAACCG", "CGCCGTAATTA", "TAAGTACCAT_"});
    test_lazy_rates(ct, {"GGGTCGATCAA_", "_GTGGGTG", "CAT", "AGA", "TCCCACGGTC", "GGAAGCA", "TATCTACCTA", "TATTCT", "AAGCGT", "AGTCAGC"});
    test_lazy_rates(ct, {"TAGAATGGCTT", "AGCT", "AC", "GCAAGA_", "_CCCA", "TAACT", "AGTA"});
    test_lazy_rates(ct, {"GG", "CGCGAAGGGGAG", "CCTTCGCAGTCG", "CAAT", "ACTTACCTC", "G_", "_GTCACC"});
    test_lazy_rates(ct, {"TTG_", "_CCG", "CTTAAGTT", "ACTTT", "AGAC", "GGTTATCGCCG", "CCC", "GTGAAGACTGGT", "ATCCCTCTCA"});
    test_lazy_rates(ct, {"ATCTCGACTGCC", "GGTGGCGC", "GTTGAAC", "GATACTGAGTG", "CTGGTCGCGAT_", "_GACCGTGAGAG", "CGGTAT"});
    test_lazy_rates(ct, {"AGTTGA_", "_GCCAT"});
    test_lazy_rates(ct, {"AGGCTCCTACA_", "_GTATTGGTCC", "GAGGA", "TATGCTCTATGT"});
    test_lazy_rates(ct, {"GT", "AACCGTG", "CTATTAG", "CTAC", "GCCGTTTGAG_", "_ACGA", "TATTGAC"});
    test_lazy_rates(ct, {"TCACAAGA", "TG", "CT", "AAATC", "G_", "_GAA", "TGGAACCCCA"});
    test_lazy_rates(ct, {"CAAGT", "ACT_", "_AC", "GGAACGT", "ACAGTTGCGG"});
    test_lazy_rates(ct, {"TT", "AGTA", "TG", "CCTT", "AACGGATC", "GCACTA_", "_TGACTCG", "CGTATTG", "CTCGTACGCGCA"});
    test_lazy_rates(ct, {"TC", "GTG", "C_", "_CCGCGACAG", "CTC", "GCGCCCCCT", "AA"});
    test_lazy_rates(ct, {"_GTG_"});
    test_lazy_rates(ct, {"_CGCTAGGCTT", "ACCCGGT", "ATAGC", "GCTCC", "GCTAACATAAAT", "AGGCTCT", "A_"});
    test_lazy_rates(ct, {"CAACGCTCTCAT", "ACAC_", "_A", "TTCTTTGAAG"});

    /*
    from random import randint, choice
    def gen():
        ret = []
        for i in range(randint(1, 10)):
            length = randint(2, 12)
            ret.append([choice(['A', 'C', 'G', 'T']) for _ in range(length)])
        for (i, r) in enumerate(ret):
            ret[(i + 1) % len(ret)][0] = {'A':'T', 'T':'A', 'C':'G', 'G':'C'}[r[-1]]

        nick = randint(0, len(ret) - 1)
        ret[nick][0] = '_'
        ret[(nick - 1) % len(ret)][-1] = '_'

        return 'test_lazy_rates(ct, {' + ', '.join('"' + ''.join(i) + '"' for i in ret) + '});'
    */
};

/******************************************************************************************/

}
