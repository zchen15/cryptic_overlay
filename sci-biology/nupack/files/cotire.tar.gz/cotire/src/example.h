// cotire example project

#include <string>

namespace example {

std::string get_message();

}

