from .glyphs import draw

try:
    from .static import MatplotlibBackend
except ImportError:
    pass

try:
    from .dynamic import *
except ImportError:
    pass



def default_interval():
    # if numberinterval == 0:  # Auto line numbering
    intok = [1.0, 2.0, 5.0, 10.0, 15.0, 25.0, 40.0, 50.0]
    realintv = intv = max(1.0, math.ceil(math.fabs(math.log(float(nbase)/4)))*2)
    mindiff = 1000
    for ok in intok:
      newdiff = math.fabs(intv-ok)
      if newdiff > mindiff:
          break
      if newdiff < mindiff:
        mindiff = newdiff
        realintv = ok

    return realintv
