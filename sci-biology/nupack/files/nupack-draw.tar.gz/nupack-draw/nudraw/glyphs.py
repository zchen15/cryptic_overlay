from functools import reduce
import math
import numpy
import copy


from . import options, render
from .constants import Constants
from . import geometric, newton, layout
from .classes import *

def draw(canvas, shape, structure, sequence, *, material,
         circles=False, numbers=None, ticks=False, unpairedcircle=False):

  s = structure
  seq = sequence
  constants = Constants(material)

  if len(s)==0:
      raise RuntimeError("No structure specified")

  smartrot = True  # 1: rotate leaves of tree for aesthetics
  stacknickedhelices = True # stack nicked helices

  # material = {'RNA': 1, 'DNA': 2}[material]
  # constants.init_globals(material, '')

  s=structure
  seq=sequence

  # Our indices begin at 0, not 1!
  ibase = 0
  loop=[]
  helix=[]
  coil=[]

  # Set up unit structure
  unit, base = layout.setup_units(s, seq)

  # Set up loop structure
  layout.setup_loops(unit, loop)

  geometric.calculate(constants.rdh, constants.dzb, loop, base, stacknickedhelices, constants.dsb, circle=unpairedcircle)

  #-----------------------------------------------------------------------------

  # Assign letters
  if len(seq)>0:
    ibase=0
    iseq=0
    seq=seq.upper()

    # Make sure correct letters are used
    if material=='RNA':
      ttable=str.maketrans('tT','uU')
    elif material=='DNA':
      ttable=str.maketrans('uU', 'tT')
    seq=seq.translate(ttable)

    oneseq=reduce(lambda x,y:x+y, seq.split('+'))
    while ibase<len(base) and iseq<len(oneseq):
      if oneseq[iseq] in ['A', 'C', 'G', 'T', 'U']:
        base[ibase].type=oneseq[iseq]
      iseq=iseq+1
      ibase=ibase+1

  iloop = 1
  ihelix = 0
  while iloop < len(loop):
  #
  #   define helices
  #   each helix has a pointer to the previous loop before the helix
  #   and the next loop after the helix as well as pointers to the
  #   appropriate side in these neighboring loops: these pointers
  #   are used to link helix ends to coil ends below
  #
      helix.append(helixClass())
      helixlength = 1
      firstloop = iloop

      l=loop[iloop]

      helixobj=helix[-1]
      while (loop[iloop].nside == 2 and \
            loop[iloop].sidenbase[0] == 0 and \
            loop[iloop].sidenbase[1] == 0 and \
            loop[iloop].nick[1,0] != -3):

        l=loop[iloop]

        helixlength = helixlength + 1
        helixobj.bases.append([l.sidebase[0],l.sidebase[1]+1])

        iloop = iloop + 1 # because loops in a helix are always numbered consecutively

      helix[ihelix].npair = helixlength
      l=loop[iloop]

      sn=0
      while sn<len(l.sidebase)-1 and l.sidebase[sn+1]>=0:
        sn+=1

      helixobj.bases.append([l.sidebase[0], l.sidebase[sn]+l.sidenbase[sn]+1])

      firstside = loop[firstloop].nside-1
      prevloop = loop[firstloop].toloop[firstside]
      prevside = loop[firstloop].toside[firstside]
      helix[ihelix].prevloop  = prevloop
      helix[ihelix].prevside  = prevside
      helix[ihelix].xc     =  loop[firstloop].geo[firstside].xc.copy() # coord of helix axis start
      helix[ihelix].nc     = -loop[firstloop].geo[firstside].nc.copy() # helix axis at start (into helix)
      helix[ihelix].thc    = 180./math.pi*(math.pi - constants.strutangle)
              #rotate so base-pair struct is parallel to plane of loop it borders
              # reversed sign of thc relative to nupack6 to get first
              # basepair strut into the plane of the loop it exits from
              # (works for A-DNA or B-DNA)

      if not smartrot:
          helix[ihelix].thc = helix[ihelix].thc  + 90. + \
          180./math.pi*numpy.arctan2(helix[ihelix].nc[1],helix[ihelix].nc[0])

      # rotate so that projection from canonical
      # u_z orientation creates helix that joins the loop
      # with the same rotation regardless of helix axis

      #
      # make pointers from loop sides to helix numbers: from root to
      # leaves (don't need pointers from loops to helix entering the loop
      # -- but could add below using nextloop, nextside
      #
      loop[prevloop].tohelix[prevside] = ihelix

      if helixlength == 1: #special treatment for isolated base pairs
          helix[ihelix].nextloop = firstloop
          helix[ihelix].nextside = firstside
      else:                # regular helix with two or more stacked pairs
          lastloop  = iloop - 1
          lastside = 0
          helix[ihelix].nextloop  = loop[lastloop].toloop[lastside]
          helix[ihelix].nextside  = loop[lastloop].toside[lastside]


      if stacknickedhelices and loop[prevloop].nickedhelix:
        helix[ihelix].thc = helix[ihelix-1].thc + \
        180./math.pi*constants.dthb*helix[ihelix-1].npair

      # this takes advantage of fact that helices connected by a nick are consecutive in the helix array
      # pass on rotation info from the previous helix (can't do this by
      # defining reference angles for the nicked loops because that would
      # pass on non-2D orientations to the subsequent loops)

      ihelix = ihelix + 1
      iloop = iloop + 1

  nhelix = ihelix


  #-----------------------------------------------------------------------------
  #
  #   define coils
  #

  iloop = 0
  icoil = 0



  while iloop < len(loop):
      l=loop[iloop]

      if not (loop[iloop].nside == 2 and loop[iloop].sidenbase[0] == 0 and \
            loop[iloop].sidenbase[1] == 0) or loop[iloop].nick[1,0] == -3 \
            or loop[iloop].nick[0,0] == -5 or loop[iloop].tohelix[0]>=0: # if not part of helix
          for jside in range(loop[iloop].nside):
              coil.append(coilClass(loop[iloop].nside))
              coil[icoil].nbase = loop[iloop].sidenbase[jside] + 2 # including end pts
              coil[icoil].loopnum = iloop # check
              coil[icoil].loopside = jside # check
              coil[icoil].center = loop[iloop].center
              loop[iloop].coilnum[jside] = icoil


              coil[icoil].strand = loop[iloop].strand[jside]
              coil[icoil].nick = loop[iloop].nick[:,jside]
              if loop[iloop].nside==1:
                coil[icoil].nick[1] = loop[iloop].nick[1,jside+1]
              if coil[icoil].nick[0] == -5:
                  coil[icoil].tohelix[0,:] = numpy.array([-1,-5],numpy.int32) # could change zero to istrand if need info later
                                                  # or just not use tohelix for strand ends and rely on coil.nick
              if coil[icoil].nick[1] == -3:
                  coil[icoil].tohelix[1,:] = numpy.array([-1, -3], numpy.int32)

              if loop[iloop].nick[0,jside] == -5:
                  startval = 0
              else:
                  startval = 1

              if loop[iloop].nick[1,jside] == -3:
                  stopval = loop[iloop].sidenbase[jside] + 1
              else:
                  stopval = loop[iloop].sidenbase[jside]

              jcount = 0
              coil[icoil].setSplineSize(stopval-startval+1)
              for jval in range(startval,stopval+1): # store spline pts for coil, including end point if a nick
                  jbase = jval + loop[iloop].sidebase[jside]
                  coil[icoil].xsplinepts[:,jcount] = base[jbase].x
                  coil[icoil].bases.append(jbase)
                  jcount = jcount + 1

              coil[icoil].nsplinepts = jcount
              icoil = icoil + 1

      iloop = iloop + 1

  #
  # drawing reality checks

  #-----------------------------------------------------------------------------
  #
  # make linked list between helix strand ends and coil strand ends
  # loop of helices
  # follow pointers helix -> end loops -> loop sides -> coil
  #
  # helix definitions in drawing program:
  # a chain runs from 5' -> 3' (indices 1 and 2, respectively, in drawing program)
  # b chain rums from 3' -> 5' (indices 1 and 2, respectively, in drawing program)
  #
  # helix definitions in automatic structure generation program:
  # a1 = 1, a2 = 2, b1 = 3, b2 = 4
  #
  for ihelix in range(nhelix):
      prevloop  = helix[ihelix].prevloop
      side1     = helix[ihelix].prevside
      ic1       = loop[prevloop].coilnum[side1]

      side3     = side1 + 1
      nside     = loop[prevloop].nside
      if side3 >= nside:
          side3 = 0

      ic3       = loop[prevloop].coilnum[side3]

      nextloop  = helix[ihelix].nextloop
      side4     = helix[ihelix].nextside
      ic4       = loop[nextloop].coilnum[side4]

      side2     = side4 + 1
      nside     = loop[nextloop].nside
      if side2  >= nside:
          side2 = 0

      ic2       = loop[nextloop].coilnum[side2]

      # coil number and position
      helix[ihelix].tocoil = numpy.array([[ic1, 1], [ic2, 0], [ic3, 0], [ic4, 1]])
      # strand number for chains a and b
      helix[ihelix].strand = numpy.array([coil[ic1].strand, coil[ic3].strand])

      coil[ic1].tohelix[1,:] = numpy.array([ihelix, 0]) # helix number and position (1->4)
      coil[ic2].tohelix[0,:] = numpy.array([ihelix, 1])
      coil[ic3].tohelix[0,:] = numpy.array([ihelix, 2])
      coil[ic4].tohelix[1,:] = numpy.array([ihelix, 3])

      #
      # if coil is at strand end and has no length then just draw cap on
      # relevant helix strand end and don't draw coil
      if coil[ic1].nick[0] == -5 and coil[ic1].nbase == 1:
        helix[ihelix].cap[0] = -5

      if coil[ic2].nick[1] == -3 and coil[ic2].nbase == 1:
        helix[ihelix].cap[1] = -3

      if coil[ic3].nick[1] == -3 and coil[ic3].nbase == 1:
        helix[ihelix].cap[2] = -3

      if coil[ic4].nick[0] == -5 and coil[ic4].nbase == 1:
        helix[ihelix].cap[3] = -5



  #-------------------------------------------------------------------------------
  # render 2D layout and pictures


  # render with and without multiple file options
  return render.draw_structure(canvas, constants, shape, base, unit,
    helix, loop, seq, s, constants.dsb, material, drawbases=circles,
    numbers=numbers, drawbaseticks=ticks, unpairedcircle=unpairedcircle)

