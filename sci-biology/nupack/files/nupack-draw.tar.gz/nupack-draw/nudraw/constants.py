# Global parameters
# Conrad D. Steenberg <conrad.steenberg@caltech.edu>
# Nov 20, 2008

import math, numpy as np
from . import newton
from collections import defaultdict


# letter offsets in base radius units
letter_offset = defaultdict(float, {
    'A': (-0.01, +0.0),
    'C': (-0.05, -0.025),
    'G': (-0.05, -0.0),
    'U': (-0.07, -0.04),
    'T': (+0.01, -0.07),
})

COLORS = {
  "light_green":     [109,  216./255,  45./255],
  "orange":          [1,       .2857,     0],
  "red":             [164./255, 0,        0],
  "lavender":        [181./255, 145./255,  209./255],
  "dark_green":      [0./255,   100./255,  0./255],
  "yellow":          [1.,       .9375,    0],
  "turquoise":       [0.,        0.9286,  1],
  "dark_blue":       [0.,        0.,      0.8571],
  "brown":           [142./255, 73./255,   5./255],
  "med_green":       [28./255,  206./255,  40./255],
  "pink":            [255./255, 160./255,  204./255],
  "dark_gray":       [0.4,      0.4,      0.4],
  "black":           [0./255,   0./255,   0./255],
  "purple":          [79./255,  0./255,   147./255],
  "magenta":         [229./255, 0./255,   153./255],
  "tan":             [242./255, 206./255, 204./255],
  "light_gray":      [.7778,   .7778,    .7778],
  "cornflowerblue":  [68./255,  102./255, 255./255],
  "light_blue":      [135./255, 206./255, 235./255],
  "navy_blue":       [0,        0,       128./255],
  "forest_green":    [34./255,  139./255, 34./255],
  "lawn_green":      [124./255, 252./255, 0.],
  "light_orange":    [255./255, 204./255, 102./255],
  "shady_blue":      [96./255,  114./255, 175./255],
  "shady_green":     [169./255, 212./255, 113./255],
  "sky_blue":        [24/255.,  73/255., 1.0],
  "leaf_green":      [34/255.,  139/255., 34/255.],
  "sea_green":       [0./255.,  120./255., 80./255.],
  "med_gray":        [.58,   .58,    .58]
}

COLORS = dict(zip(COLORS.keys(), map(np.array, COLORS.values())))

class Constants:

  def getDomainColors(self, ind):
    return self.domainColors[ind % len(self.domainColors)]

  def __init__(self, material):
    assert material in ('RNA', 'DNA')
    nh=[0,0]
    nb=[0,0]
    rbc=[0,0]
    nh[0]   = 20 + 1        # points along chain per base %20 default
    nh[1]   = 30 + 1        # points around chain         % 30 default
    nb[0]   = 1  + 1        # points along base pair
    nb[1]   = 30 + 1        # points around base pair   % 30 default

    rhc = None
    rhelix = None
    self.rdh = None
    self.dzb = None
    bturn = None
    brise = None
    dthb = None
    self.dsb = None
    majorgroove = None
    minorgroove = None
    self.strutangle = None
    inclination = None

    #Domain COLORS - extend this to all COLORS?
    domainCMap= np.array([
                [128,             208,              79],              #(med green -- NUPACK)
                [255,             153,               0],               #(med orange -- NUPACK)
                [ 68,             102,             255],             #(med blue -- NUPACK)
                [237,              31,              36],              #(bright red)
                [145,              74,             156],             #(magenta)
                [159,              95,              47],              #(med brown)
                #~ Dark COLORS
                [  1,             105,              55],              #(dark green)
                [241,              90,              36],              #(dark orange)
                [ 33,              28,              92],              #(dark blue)
                [133,               0,              14],              #(dark red)
                [ 77,              19,             110],             #(dark purple)
                [ 76,              61,              44],              #(dark brown)
                #~ Light COLORS
                [202,             224,             145],             #(pale green)
                [255,             218,               0],               #(yellow)
                [128,             242,             255],             #(pale blue)
                [247,             169,             168],             #(pink)
                [195,             156,             255],             #(lavender)
                [210,             180,             140]              #(tan)
              ]) / 255



    domainColors={}
    for i in range(len(domainCMap)):
      domainColors[i]="#%02x%02x%02x"%(int(domainCMap[i][0]*255), \
                              int(domainCMap[i][1]*255), int(domainCMap[i][2]*255))


    self.colorid = {
      "A": COLORS["leaf_green"],
      "C": COLORS["sky_blue"],
      "G": COLORS["black"],
      "T": COLORS["red"],
      "U": COLORS["red"],
      ".": COLORS["black"],
      "(": COLORS["yellow"],
      ")": COLORS["orange"],
      "?": "#999999"
    }

    cbrt2=math.pow(2.,0.2)

    rhc     = 0.5              # radius of helix chain
    rbc[0]  = .5/3             # major radius of base pair strut (elliptical: .5 default)
    rbc[1]  = .25/3            # minor radius of base pair strut (elliptical: .2 default)

    if material == 'RNA':      # A DNA (RNA/RNA duplex or RNA/DNA duplex)
      rhelix     = 3.0     # radius of double helix to outside of chain axis
      self.dzb     = rhelix     # stacking height per base along helix
      bturn   = 10.0       # bases per turn in the helix (10 is default value)
      majorgroove = .45*self.dzb*bturn          # height of major groove along helix axis in angstroms (less than .5 for narrow, deep major groove)
      inclination = -19*math.pi/180  # angle of strut relative x axis (spinning around y axis)
                                              # should tilt down from 5' (start
                                              # of A chain) to 3' (start of B
                                              # chain) strand
    elif material == 'DNA': # B DNA
      rhelix     = 2.6          # radius of double helix to outside of chain axis
      self.dzb     = 3.0             # stacking height per base along helix
      bturn   = 9.5            # bases per turn in the helix (10.5 is modern value)
      majorgroove = 22./34.*(self.dzb*bturn)          # height of major groove along helix axis in angstroms (22 is default, 17 for symmetric debugging)
                                  # take ratio of 22/34 and multiply by
                                  # modern value of brise
      inclination = 1.2*math.pi/180    # angle of strut relative x axis (spinning around y axis)
                                              # should tilt up from 5' (start
                                              # of A chain) to 3' (start of B
                                              # chain) (1.2 for B DNA)

    self.rdh     = rhelix - rhc     # radius of helix to center of chain

    brise   = self.dzb*bturn        # rise along helix axis per full turn
    dthb    = 2*math.pi/bturn       # stacking twist per base along helix
    self.dsb     = cbrt2*math.sqrt(math.pow(self.rdh*dthb,2) + math.pow(self.dzb,2)) # arc length along chain for one base
    minorgroove = brise - majorgroove

    self.strutangle = newton.groove(inclination, self.rdh, brise, minorgroove)[-1]


