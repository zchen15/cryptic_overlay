#
#
# Conrad Steenberg <conrad.steenberg@caltech.edu>
# 12 Oct 2008

import numpy as np
from numpy.linalg import norm
from numpy import ceil, log10, pi as PI, arccos, arctan, sin, cos, remainder

from .constants import letter_offset

################################################################################

def get_angle(center, point):
    # Returns the angle between the line point -> center and the line y==0


    # cos TH=(point.x-center.x)
    #                     point-center
    l=point-center
    th = remainder(arccos((point[0] - center[0])/ np.sqrt(np.vdot(l,l))), PI)

    if center[1]>point[1]:
        th = -th

    th *= 180/PI
    return th

################################################################################

def arrow_head(P1, P2, s):
    # Calculates points needed to draw arrow head, given a vector
    # s    : segment length
    # rdh: base radius

    rdh=s/7.
    v1=P2-P1
    nv1=v1/np.linalg.norm(v1) #Normalized vector

    v2=P2+nv1*rdh*1.85
    pv=np.array([-nv1[1],nv1[0]])
    a1=P2+rdh*pv*1.0
    a2=P2-rdh*pv*1.0

    b1=a1+rdh*nv1*0.85
    b2=a2+rdh*nv1*0.85
    v3=P2+nv1*rdh*1.0

    return b1, v2, b2, a2, v3, a1

################################################################################

def arrow_coil(unit, iunit, center, r, th, dth, s):
    # Get vector for arrow at the end of a coil
    th2=arctan(s/r)
    r2=s/sin(th2)
    th3=th-dth/abs(dth)*th2
    P1=unit[iunit].baseInfo.x
    P2=center+np.array([r2*cos(th3), r2*sin(th3)])

    return P1,P2

################################################################################

def arrow_helix(pts, s):
    # Get vector for arrow at the end of a helix

    P2 = pts[-1]
    v1 = P2 - pts[0]
    nv1 = v1/np.linalg.norm(v1) # Normalized vector

    v2 = P2 + nv1*s

    return np.array([P2, v2])

################################################################################

def arrow_helix2(pts, s):
    # Get vector for arrow at the end of a helix

    P2 = pts[-1]
    v1 = P2 - pts[0]
    nv1 = v1/np.linalg.norm(v1) # Normalized vector

    v2 = pts[-2] + nv1*s

    return pts[-2], v2

################################################################################

def arrow_helix_perp(pts, s):
    # Get vector for arrow at the end of a helix

    P2 = pts[-1]
    v1 = P2 - pts[0]

    nv1 = v1/np.linalg.norm(v1) # Normalized vector
    nv2=nv1[::-1]
    nv2[0]=-nv2[0]

    nv2=nv1[::-1]*-1 # Quick 'n Dirty rotate by 90deg

    v2 = P2 + nv2*s

    return P2, v2

################################################################################

def draw_arrow(canvas, index, arp, strand, dsb_in, bbonewidth, strutwidth):

    a1,a2,a3,a4,a5,a6=arrow_head(arp[0],arp[1], dsb_in)
    A2=np.vstack([a1,a2,a3,a4,a5,a6])

    canvas.terminus([arp[0][0], a5[0]], [arp[0][1], a5[1]], lw=bbonewidth, solid_capstyle='round', index=index)

    canvas.arrowhead(A2, lw=strutwidth/2, fill=True, index=index)

################################################################################

def is_nicked_helix(l, j, unit):
    if l.sidenbase[j]==0:
        u=l.sideunit[j]
        nbases=list(filter(lambda x: x>-1, l.sidenbase))

        if unit[u].pair>=0 and unit[u+1].pair>=0 and len(nbases)<2:
            return True
    return False

################################################################################


# Draw a possibly 2-colored line segment denoting the domain
def drawHelixLines(canvas, constants, base, baseInfo, *, hnb, lw):
    for i in range(hnb-1):
        pos=[base[baseInfo[i]].x, (base[baseInfo[i]].x+base[baseInfo[i+1]].x)/2, base[baseInfo[i+1]].x]

        for j in range(2):
            canvas.backbone_line([pos[j][0],pos[j+1][0]], [pos[j][1], pos[j+1][1]],
                lw=lw, solid_capstyle='butt', index=baseInfo[i+j])


def drawUnPairedDomains(canvas, constants, unit, base, *, lw):
    # Construct the bases array of arrays
    strands=[]
    for u in unit:
        if u.type == - 5:
            strands.append([])
        elif u.type != - 3:
            strands[-1].append(u.base)

    for baseInfo in strands:
        drawHelixLines(canvas, constants, base, baseInfo, hnb=len(baseInfo), lw=lw)


################################################################################

# Draw 2-colored arc segment denoting the domain
def drawSegment(canvas, constants, base, unit, l, nbasej, *, segment, lw, drawArc=True):
    b = segment[0]
    e = segment[1]

    pos = [base[b].x, (base[b].x+base[e].x)/2, base[e].x]

    for i in range(2):
        ang1 = get_angle(l.center, pos[i])
        ang2 = get_angle(l.center, pos[i+1])

        if is_nicked_helix(l, nbasej, unit) or not drawArc:
            canvas.backbone_line([pos[i][0], pos[i+1][0]], [pos[i][1], pos[i+1][1]], lw=lw, index=segment[i])
        else:
            canvas.backbone_arc(l.center, l.radius*2, ang2.real, ang1.real, lw=lw, index=segment[i])

################################################################################

def evenlySpaceBases(unit, base, box, dXin = 0.0):
    # Construct the bases array of arrays
    strands=[]
    for u in unit:
        if u.type == - 5:
            strands.append([])
        elif u.type != - 3:
            strands[-1].append(u.base)

    dY = (box[1][1] - box[1][0])/(len(strands)+1)

    # Calculate dX from the longest strand
    maxLen = max(map(len, strands))

    boxWidth = box[0][1] - box[0][0]
    if dXin ==0:
        dX = boxWidth/(maxLen + 2)
    else:
        dX = dXin

    for si, s in enumerate(strands):
        y = (si+1) * dY + box[1][0]
        xOffset = box[0][0] + (boxWidth - dX*len(s))/2

        for xi, bi in enumerate(s):
            base[bi].x = np.array([dX * xi + xOffset, y])

################################################################################

def draw_structure(canvas, constants, shape, base, unit, helix, loop, seq, dotparens, dsb, material,
         drawbases=True, drawbaseticks=False, numbers=None, unpairedcircle=False):
    # First do bases
    bases=[]
    strandmax = -1
    strands=[]
    numbers = [] if numbers is None else list(numbers)

    # Set up options for how bases will be drawn
    if drawbases and not drawbaseticks:
        baseradius=dsb/5
    else:
        baseradius=dsb/6

    endcaplen=baseradius+dsb/10
    baseTicklen=constants.rdh

    for b in base:
      assert len(b.x) == 2

    # Find mins/maxes for picture
    base_pos = [u.baseInfo.x for u in unit if u.baseInfo]
    maxx = np.max(base_pos, axis=0)
    minx = np.min(base_pos, axis=0)

    # Now pad the smaller edge
    dx = maxx - minx

    pad = max(dx) / 50 + baseradius * 2 + dsb #/ 3
    box = np.array([minx - pad, maxx + pad]).T

    drawArc = unpairedcircle or len(helix)
    if not drawArc:
        box[0, 1] += dsb/4

    j = int(dx[0] > dx[1])

    ddx = dx[1 - j] - dx[j]
    box[j, 0] -= ddx/2
    box[j, 1] += ddx/2

    # Set up line widths, dsb is the coil arc length
    scalefac = (box[0, 1]-box[0, 0]) / shape[0]

    bbonewidth = 24/scalefac
    strutwidth = 12/scalefac
    numsize = float(max(6.0, bbonewidth*2)) # In points
    numsize = float(min(numsize, 12.0)) # In points
    # labelsize = numsize*1.5
    numtmp = numsize/72.72*scalefac/2
    # numoffset_raw = max(baseradius*1.4, dsb/2*log10(float(len(base)))*log10(scalefac))
    # digits = ceil(log10(len(base)))
    # numoffset = max(baseradius*2.25, min(numoffset_raw+numtmp*digits, baseradius+numtmp*digits))

    tickwidth=strutwidth*1.5
    numwidthHelix = numwidthCoil = strutwidth/2

    numoffsetCoil = baseTicklen + numtmp #max(numoffset, baseTicklen+numtmp)# if drawbaseticks else numoffset
    numoffsetHelix = numtmp #z#numoffset

    # labeloffsetHelix=numoffsetHelix*1.3

    # Set up options for how bases will be drawn
    clw = 0.0 if drawbaseticks else strutwidth

    # Draw a base ID legend
    # strucdn_map = {}

    ddx = [dx[0]-dx[1], dx[1]-dx[0]]
    i, j = (1, 0) if ddx[0]<0 else (0, 1)
    minx[j] -= ddx[i]/2
    maxx[j] += ddx[i]/2

    # Draw bases -----------------------------------------------------------------
    if not drawArc:
        evenlySpaceBases(unit, base, box, dsb)

    for i, u in enumerate(unit):

        if u.baseInfo:
            btype = 0
            if i > 0 and unit[i-1].type == -5:
                btype = -5

            if i+1<len(unit) and unit[i+1].type==-3:
                btype=-3

            bases.append(0)
            if drawbases:
                if u.baseInfo.type:
                    # canvas.letter(*(u.baseInfo.x + np.array([0,0]) * letter_offset[u.baseInfo.type]), index=i-1-2*unit[i].strand, text=u.baseInfo.type, size=float(bbonewidth*3))
                    canvas.letter(*(u.baseInfo.x), index=i-1-2*unit[i].strand, text=u.baseInfo.type, size=float(bbonewidth*3))

            if u.type in ['.', '(', ')']:
                if not drawbaseticks or drawbases:
                    canvas.base_circle(u.baseInfo.x, radius=baseradius, index=i-1-2*unit[i].strand, label=u.type, lw=clw)

        if u.strand>strandmax:
            strandmax=u.strand
            strands.append({"id":int(u.strand)})

    # Start loops and helices
    loops, hloops, parentloops =[], [], []
    lastloop=-1
    lasthelix=-1

    loopmap, loopsdone, helicesdone = {},{},{} # Maps our loop ID to JSON loop ID
    lc=0

    # Iterate through loops
    for li, l in enumerate(loop):
        if l.coilnum[0]>-1:
            loopmap[li]=lc
            lc=lc+1
    todo = {0} # current work queue
    tlilist=[] # Special case work queue
    newstrand = True
    deltaH=0.0
    strnd = 0

    while len(loopsdone) < len(loop):
        i = todo.pop()
        l = loop[i]

        if l.coilnum[0]>=0 or l.tohelix[0]>=0: # This is a hairpin/multiloop

            # Determine bases and segments
            lastloop=lastloop+1

            if l.tohelix[0]>=0: # This loop has children
                parentloops.append(lastloop)

            baseInfo, segments, units, nbasej = [], [], [], []

            for j in range(len(l.sidenbase)):
                bnum=int(l.sidenbase[j])

                try:
                    btype=int(unit[l.sideunit[j]].type)
                except ValueError:
                    btype=0
                if bnum<0:
                    continue

                strand_id=l.strand[j]

                segunits=[]

                for k in range(bnum+2):
                    unit_id=l.sideunit[j] + k
                    base_id=l.sidebase[j] + k
                    addbase=False

                    if k==0 or k==int(bnum)+1:    #GRANT ROY, added int()

                        ind = 0 #int(k) #%#% (int(bnum)+1)
                        # ind = k+1 #int(k)%int(bnum) if bnum != 0 else 0 #GRANT ROY COMMENTED OUT
                        try:
                            btype=int(unit[l.sideunit[j]+k+ind].type)
                        except ValueError:
                            btype=0

                        if btype==-5 and (l.tohelix[j]>-1 or len(loop)==1 or l.toloop[j]>-1):
                            addbase=True

                        if    (k>0 and l.toloop[j]==-1 and l.tohelix[j]==-1):
                            addbase=True

                    if (k>0 and k<bnum+1):
                        addbase=True

                    if addbase:
                            baseInfo.append(int(base_id))
                            segunits.append(unit_id)

                    if k>0:
                        strnd=strand_id
                        segments.append([int(base_id-1), int(base_id), int(strnd), None])
                        nbasej.append(j)

                units.append(segunits)

            # Determine child helices
            childHelices = [int(ch) for ch in l.tohelix if ch >= 0]

            desc= {
                    "bases":baseInfo,
                    "childHelices": childHelices,
            }
            loops.append(desc)

            # Draw arc
            if segments:
                begin_ind=segments[0][0]
                strnd=segments[0][2]
                end_ind = segments[-1][1]

            if not drawArc:
                drawUnPairedDomains(canvas, constants, unit, base, lw=bbonewidth)

            icoil=0
            for s, seg in enumerate(segments):
                # Count nuber of bases
                end_ind=seg[1]

                if True and drawArc:
                    drawSegment(canvas, constants, base, unit, l, nbasej[s], segment=seg, lw=bbonewidth, drawArc=drawArc)

                if s==len(segments)-1 or segments[s+1][2]!=strnd or seg[1]!=segments[s+1][0]:
                    ang1 = get_angle(l.center, base[begin_ind].x)
                    ang2 = get_angle(l.center, base[end_ind].x)
                    begin_ang, end_ang = min(ang1, ang2), max(ang1, ang2)

                    if True:
                        if not is_nicked_helix(l, nbasej[s], unit) and drawArc:
                            pass
                            # not sure when this arc is needed?
                            # canvas.backbone_arc(l.center, l.radius*2, ang2.real, ang1.real, lw=bbonewidth, index=begin_ind)
                        else:
                            canvas.backbone_line([base[begin_ind].x[0],base[end_ind].x[0]],
                                        [base[begin_ind].x[1],base[end_ind].x[1]], lw=bbonewidth, index=begin_ind)

                    if s < len(segments)-1:
                        begin_ind=segments[s+1][0]
                        strnd=segments[s+1][2]

                    # Draw arrow
                    if units[icoil] and any(l.sideunit[ih] >= 0 and l.tohelix[ih] < 0 for ih in range(len(l.sideunit))):  # No helix but there is a coil:
                        ii=units[icoil][0]
                        ei=ii+len(units[icoil])-1
                        eb=unit[ei].base
                        bb=unit[ii].base

                        while ei-ii<len(units[icoil]) and unit[ei].base<=eb \
                            and ei-eb<len(units[icoil]) and type(unit[ei+1].type)==str:
                            ei=ei+1

                        arp=None
                        endcap=None
                        # Test for arrows
                        offset=numoffsetCoil
                        if units[icoil] and unit[ii].type==-3:
                            if drawArc:
                                delta_ang=PI/180*(end_ang-begin_ang)/len(units[icoil])/3
                                arp=arrow_coil(unit, ii, l.center, l.radius,
                                    PI/180*ang1, -delta_ang, dsb/3)
                            else:
                                arp=arrow_helix([base[eb].x, base[eb+1].x], dsb/3)
                        elif units[icoil] and unit[ei+1].type==-3 and (unit[ei].pair<0):
                            if drawArc:
                                delta_ang=PI/180*(end_ang-begin_ang)/len(units[icoil])/3
                                arp=arrow_coil(unit, ei, l.center, l.radius,
                                    PI/180*ang2, delta_ang, dsb/3)
                            else:
                                arp=(base[eb+1].x, base[eb+1].x+np.array([dsb/3,0]))


                        # We have an arrow vector
                        if arp is not None:
                            s = unit[units[icoil][0]].strand
                            draw_arrow(canvas, units[icoil][0] - 2 * s - 1, arp, unit[units[icoil][0]].strand, dsb*1.1, bbonewidth, strutwidth)

                        # Test for endcaps
                        if drawbaseticks:
                            endcap = None
                            if unit[ii].type==-5:
                                if drawArc:
                                    delta_ang=PI/180*(end_ang-begin_ang)/len(units[icoil])/5
                                    endcap=arrow_coil(unit, ii+1, l.center, l.radius,
                                        PI/180*ang1, -delta_ang, endcaplen)
                                else:
                                    endcap=[base[bb].x, base[bb].x-np.array([endcaplen,0])]
                            elif units[icoil] and unit[ei+1].type==-5 and (unit[ei].pair<0):
                                if drawArc:
                                    delta_ang=PI/180*(end_ang-begin_ang)/len(units[icoil])/5
                                    endcap=arrow_coil(unit, ei, l.center, l.radius,
                                        PI/180*ang2, -delta_ang, endcaplen)
                                else:
                                    endcap=arrow_helix([base[eb-1].x, base[eb].x], endcaplen)

                            # We have an endcap vector
                            if endcap is not None:
                                # 3' backbone of a strand that is not the first one
                                canvas.terminus([endcap[0][0],endcap[1][0]], [endcap[0][1],endcap[1][1]],
                                                index=eb, lw=bbonewidth, solid_capstyle='round')

                    icoil=icoil+1

            # Draw base numbers
            for bn in baseInfo:
                labeltext="%d"%(bn+1)
                fontsize=numsize
                offset=numoffsetCoil
                linewidth=numwidthCoil

                if drawArc:
                    tarp=arrow_helix([l.center, base[bn].x], offset)
                else:
                    tarp=[base[bn].x, base[bn].x + np.array([0,offset])]

                canvas.annotate(labeltext, xy=base[bn].x, index=bn, zorder=1, xytext=(tarp[1][0], tarp[1][1]), fontsize=fontsize, lw=linewidth)

            # Draw base ticks for unpaired bases
            if drawbaseticks:
                for bn in baseInfo:
                    if drawArc:
                        tarp=arrow_helix([l.center, base[bn].x], baseTicklen)
                    else:
                        tarp=[base[bn].x, base[bn].x + np.array([0,baseTicklen])]
                    canvas.tick([tarp[0][0],tarp[1][0]],
                        [tarp[0][1],tarp[1][1]], index=bn, lw=tickwidth, solid_capstyle='round')

            loopsdone[i]=l

            newstrand=False
            for t in l.toloop[::-1]:
                if t>0: todo.add(t)

            # Special case of a helix without a loop
            tlilist_new=[]
            sp_hi = len(l.toloop)-1

            for tli in l.toloop[::-1]:
                if tli < 0:
                    sp_hi -= 1
                    continue
                sl=loop[tli] # Special loop

                if sl.coilnum[0]>=0 and unit[sl.sideunit[0]].base==sl.sidebase[0] \
                    and l.tohelix[sp_hi]>=0 \
                    and not l.tohelix[sp_hi] in helicesdone:
                    tlilist_new.append((tli,l.tohelix[sp_hi],i))
                sp_hi-=1

            for ind_i in range(len(tlilist)-1,-1,-1):
                if tlilist and tlilist[ind_i][0]==i:
                    tli, hnum, parent_i=tlilist[ind_i]
                    del tlilist[ind_i]
                    helicesdone[hnum]=True
                    sl=loop[tli] # Special loop

                    hloops.append((tli,sl))
                    ci=tli
                    child=loop[ci]

                    lasthelix=lasthelix+1

                    while parentloops and not lasthelix in loops[parentloops[-1]]["childHelices"]:
                        parentloops.pop()

                    baseInfo=[]
                    unitInfo=[]
                    oldh=None
                    angle=0.0

                    hlength=0.0
                    for hindex, (_, h) in enumerate(hloops):
                        baseInfo.append(int(h.sidebase[0]))
                        unitInfo.append(int(h.sideunit[0]))
                        bi=h.sidebase[0]

                    # One special case
                    iside=0
                    # iside = next(i,)
                    while 1:
                        if iside+1>=len(h.sidebase) or h.sidebase[iside+1]<0: break
                        iside=iside+1

                    bi2=h.sidebase[iside]+h.sidenbase[iside]+1
                    baseInfo.append(int(bi2))
                    uis=int(h.sideunit[iside]+h.sidenbase[iside]+1)
                    while unit[uis].type not in ['(',')']:
                        uis+=1
                    unitInfo.append(uis)

                    # Draw helix lines to canvas
                    strnd=unit[unitInfo[0]].strand

                    pts=np.array([[base[baseInfo[0]].x[0],base[baseInfo[1]].x[0]],
                        [base[baseInfo[0]].x[1],base[baseInfo[1]].x[1]]]).T

                    # Draw arrow if needed
                    pts_vec=[pts[::-1],pts]

                    for ui, u in enumerate(unitInfo):
                        if unit[u+1].type==-3:
                            arp=arrow_helix_perp(pts_vec[ui], dsb/3)
                            astrnd=unit[u].strand

                            if arp:
                                draw_arrow(canvas, u+2, arp, unit[u+1].strand, dsb*1.1, bbonewidth, strutwidth)


                    for bn, t in zip(baseInfo[:2], [pts[::-1], pts]):
                        labeltext="%d"%(bn+1)
                        fontsize=numsize
                        offset=numoffsetHelix
                        linewidth=numwidthHelix

                        tarp=arrow_helix(t, offset)
                        canvas.annotate(labeltext, xy=base[bn].x, index=bn, zorder=0, xytext=tarp[1], fontsize=fontsize, lw=linewidth)

                    # Draw base ticks
                    tarp=arrow_helix2(pts[::-1], baseTicklen)
                    for i in [0, 1]:
                        x=base[baseInfo[i]].x
                        if drawbaseticks:
                            ladderWidth=tickwidth
                        else:
                            ladderWidth=strutwidth

                        # non-stack base pair
                        canvas.base_pair([x[0],tarp[1][0]], [x[1],tarp[1][1]], lw=ladderWidth, index=baseInfo[i], solid_capstyle='butt')

                    # Calculate angle
                    deltaX=(base[bi2].x[0]-base[bi].x[0])
                    deltaY=(base[bi2].x[1]-base[bi].x[1])

                    thP=arccos(deltaX/norm((deltaX, deltaY)))
                    angle = remainder(thP+PI/2 if deltaY > 0 else 2.5*PI-thP, 2*PI)

                    parentLoop = -1 if newstrand else loopmap.get(parent_i, -1)

                    childLoop=loopmap[ci]

                    newstrand=False

                    hloops=[]
                    todo.add(tli)

            tlilist=tlilist_new+tlilist # Prepend the new special loops

        # End Special case

        elif l.coilnum[0]<0: # We found a helix
            hloops.append((i,l))
            ci=l.toloop[0]
            child=loop[ci]

            if ci<0 or child.coilnum[0]>=0: # We came to the end of a helix
                lasthelix=lasthelix+1

                while parentloops and not lasthelix in loops[parentloops[-1]]["childHelices"]:
                    parentloops.pop()

                baseInfo=[]
                unitInfo=[]
                oldh=None
                angle=0.0

                hlength=0.0
                for hindex in range(len(hloops)):
                    ind,h=hloops[hindex]
                    loopsdone[ind]=h

                    baseInfo.append(int(h.sidebase[0]))
                    unitInfo.append(int(h.sideunit[0]))
                    if hindex>0:
                        bi=h.sidebase[0] # index of unit
                        oldbi=oldh.sidebase[0]
                        deltaH=norm((base[bi].x[0]-base[oldbi].x[0], base[bi].x[1]-base[oldbi].x[1]))

                        hlength=hlength+deltaH
                    oldh=h

                # Two special cases
                baseInfo.append(int(oldh.sidebase[0]+1))
                unitInfo.append(int(oldh.sideunit[0]+1))
                hlength=hlength+deltaH
                ind,h=hloops[0]
                baseInfo.append(int(h.sidebase[1]+1))
                unitInfo.append(int(h.sideunit[1]+1))

                # And now the second series of bases
                for ind,h in hloops:
                    baseInfo.append(int(h.sidebase[1]))
                    unitInfo.append(int(h.sideunit[1]))
                    oldh=h

                # Draw helix lines to canvas

                hnb = len(baseInfo)// 2 # helix_nbases

                strnd = unit[unitInfo[0]].strand

                # Draw arrow
                for s,e in [[0,hnb-1],[-1,hnb]]:
                    P1=base[baseInfo[s]].x    #GRANT ROY int() to convert to python3
                    P2=base[baseInfo[e]].x    #GRANT ROY int() to convert to python3

                    if unit[unitInfo[e]+1].type==-3:     #GRANT ROY int() to convert to python3
                        arp=arrow_helix([P1, P2], dsb/3)
                        astrnd = unit[unitInfo[e]].strand    #GRANT ROY int() to convert to python3
                        draw_arrow(canvas, baseInfo[e], arp, astrnd, dsb*1.1, bbonewidth, strutwidth)
                    if unit[unitInfo[s]-1].type==-5 and drawbaseticks:
                        if unitInfo[s]-1>0 and unit[unitInfo[s]-2].type==-3:
                            elen=baseradius/2
                        else:
                            elen=endcaplen
                        arp=arrow_helix([P2, P1], elen)

                        astrnd=unit[unitInfo[s]].strand
                        canvas.terminus([arp[0][0],arp[1][0]],
                            [arp[0][1],arp[1][1]], lw=bbonewidth, index=unitInfo[s]-1,
                            solid_capstyle='round')

                # Set parent and child loops
                childLoop=loopmap[hloops[-1][1].toloop[0]]
                parentLoop=loopmap[hloops[0][1].toloop[1]]

                strnd=unit[unitInfo[int(hnb)]].strand


                if True:
                    drawHelixLines(canvas, constants, base, baseInfo[:hnb], hnb=hnb, lw=bbonewidth)
                    drawHelixLines(canvas, constants, base, baseInfo[hnb:], hnb=hnb, lw=bbonewidth)
                if False:
                    canvas.backbone_line([base[baseInfo[0]].x[0], base[baseInfo[int(hnb-1)]].x[0]],
                                         [base[baseInfo[0]].x[1], base[baseInfo[int(hnb-1)]].x[1]],
                        lw=bbonewidth, index=(baseInfo[0], baseInfo[int(hnb-1)]), solid_capstyle='butt')

                    canvas.backbone_line([base[baseInfo[int(hnb)]].x[0], base[baseInfo[int(hnb*2-1)]].x[0]],
                                         [base[baseInfo[int(hnb)]].x[1],base[baseInfo[int(hnb*2-1)]].x[1]],
                                    lw=bbonewidth, index=(baseInfo[int(hnb)], baseInfo[int(hnb*2-1)]),
                                    solid_capstyle='butt')

                # Draw struts
                for bi in range(int(hnb)):
                    pts = np.array([[base[baseInfo[int(bi)]].x[0],base[baseInfo[int(hnb+bi)]].x[0]],
                                    [base[baseInfo[int(bi)]].x[1],base[baseInfo[int(hnb+bi)]].x[1]]])

                    # Move number away from loop
                    if hnb>=2 and (bi==0 or bi==hnb-1) :
                        if bi==0 and parentLoop>=0 and loops[parentLoop]["bases"] and \
                                unit[unitInfo[e]].type!=-3:
                            x1=(base[baseInfo[bi]].x*4 + base[baseInfo[bi+1]].x*1)/5
                            x2=(base[baseInfo[hnb+bi]].x*4 + base[baseInfo[hnb+bi+1]].x*1)/5
                            pts=np.array([[x1[0],x2[0]], [x1[1],x2[1]]])
                        elif bi==hnb-1 and childLoop>=0:
                            x1=(base[baseInfo[bi]].x*4 + base[baseInfo[bi-1]].x*1)/5
                            x2=(base[baseInfo[hnb+bi]].x*4 + base[baseInfo[hnb+bi-1]].x*1)/5
                            pts=np.array([[x1[0],x2[0]], [x1[1],x2[1]]])

                    for bn, t in zip([baseInfo[bi], baseInfo[hnb+bi]], [pts.T[::-1], pts.T]):
                        labeltext="%d"%(bn+1)
                        fontsize=numsize
                        offset=numoffsetHelix
                        linewidth=numwidthHelix

                        tarp=arrow_helix(t, offset)
                        canvas.annotate(labeltext, xy=base[bn].x, index=bn, zorder=0, xytext=tarp[1], fontsize=fontsize, lw=linewidth)


                    # Draw base ticks
                    x1=base[baseInfo[bi]].x
                    x2=base[baseInfo[hnb+bi]].x
                    pts=np.array([[x2[0],x1[0]],    [x2[1],x1[1]] ])

                    tarp=arrow_helix2(pts.T[::-1], baseTicklen)
                    for i in [0, 1]:
                        x=base[baseInfo[hnb*i+bi]].x
                        if drawbaseticks:
                            ladderWidth=tickwidth
                        else:
                            ladderWidth=strutwidth
                        # stack base pair
                        canvas.base_pair([x[0],tarp[1][0]], [x[1], tarp[1][1]], lw=ladderWidth, index=baseInfo[hnb*i+bi], solid_capstyle='butt')

                childLoop=loopmap[hloops[-1][1].toloop[0]]

                if childLoop>=0:
                    x1=hloops[-1][1].center
                    x2=loop[hloops[-1][1].toloop[0]].center

                    angle = arccos((x2[0]-x1[0])/norm((x2[0]-x1[0], x2[1]-x1[1])))

                    if (x2[1]<x1[1]):
                        angle=2*PI-angle

                newstrand=False

                hloops=[]
            if ci>=0:
                todo.add(ci)
    return box

################################################################################

