from bokeh.models import ColumnDataSource as Source, Range1d, Label, LabelSet, \
    Circle, Arrow, NormalHead, HoverTool, PointDrawTool, \
    LinearColorMapper, BasicTicker, ColorBar, LegendItem, Legend
from bokeh.plotting import figure
from bokeh.io import export_svgs
from bokeh.palettes import magma, viridis, gray, all_palettes

import numpy as np
from numpy.linalg import norm

import nupack

from . import glyphs

################################################################################

# Default strand palette which holds 70 distinct colors
STRAND_PALETTE = np.array(all_palettes['Category10'][10]
                        + all_palettes['Category20'][20]
                        + all_palettes['Category20b'][20]
                        + all_palettes['Category20c'][20])

# Default domain names
DOMAIN_NAMES = [chr(i) for i in range(ord('a'), ord('z')+1)]

# Default probability shading palette
PROBABILITY_PALETTE = np.array(gray(256))[::-1][10:]

# Default tooltips to display on hover
DISPLAY_FIELDS = [('Strand', '@strand_name'), ('Index', '@i'), ('Base', '@base')]

################################################################################

class Specification:
    '''Main class for specifying options for a secondary structure drawing
    To create a secondary structure drawing specification, use the following options:

    - `strands`: ordered strands in the complex (list of strings, or '+' delimited string)
    - `structure`: dot parens plus of the structure to draw
    - `kind`: kind of drawing: 'circles', 'ticks', or 'letters'
    '''

    def font_size(self):
        return np.clip(50 / np.sqrt(self.length), 8, 12)

    @property
    def length(self):
        return len(self.base)

    def __init__(self, strands, structure=None, *, kind='ticks'):
        assert kind in ('ticks', 'circles', 'letters')
        self.kind = kind
        self.strands = nupack.constants.as_sequences(strands)
        self.structure = structure
        self.strand_index = np.concatenate([[i] * len(s) for i, s in enumerate(self.strands)])
        self.strand_name = np.array(list(map(str, range(len(self.strands)))))[self.strand_index]

        self.base = np.array(list(''.join(self.strands)))
        full = lambda x, dtype=None: np.full(self.length, x, dtype=dtype)
        self.backbone = full('#000000')

        self.circle = full('#000000')
        self.circle_alpha = full(kind == 'circles')
        self.circle_outline = full(0)

        self.label = full('#000000')
        self.label_line = full('gray')

        self.letter = full('#000000')
        self.letter_alpha = full(kind == 'letters')
        self.background = full('#ffffff')
        self.background_alpha = full(kind == 'letters')

        self.label_text = full('', object)
        self.label_size = full('%.2fpt' % self.font_size())
        self.label_line_color = full('#808080')
        self.label_line_alpha = full(0.0)

        self.tick = full('#000000')
        if kind == 'circles':
            self.tick_alpha = np.array([i != j for i, j in enumerate(nupack.PairList(structure))])
        else:
            self.tick_alpha = full(True)
        self.legends = {}
        self.color_bar = None

    def label_numbers(self, numbers=None, lines=True, start=0):
        '''Add number annotations around the structure'''
        if numbers is None:
            numbers = range(self.length)
        elif isinstance(numbers, int):
            numbers = np.array(['' if i % numbers else str(i + start) for i in range(self.length)])
        self.label_text = np.array(list(map(str, numbers)))
        if lines:
            self.label_line_alpha[self.label_text != ''] = 1

    def label_strands(self, names):
        '''Add strand name annotations around the structure'''
        for i, name in enumerate(names):
            p = np.arange(self.length)[self.strand_index == i].mean().astype(int)
            self.label_text[p] = name

    def shade_probability(self, prob, palette=None):
        '''Color the ticks or circles according to a probability'''
        palette = PROBABILITY_PALETTE if palette is None else palette
        colored = self.circle if self.kind == 'circles' else self.tick
        colored[:] = palette[(prob * (len(palette) - 1)).astype(int)]
        self.color_bar = palette

    def color_domains(self, palette=None, names=None, domains=None, legend=False):
        '''Color the backbone according to the strand or domain index'''
        title = 'Strand' if domains is None else 'Domain'
        palette = STRAND_PALETTE if palette is None else palette
        domains = self.strand_index if domains is None else np.array(domains)
        names = list(map(str, np.unique(domains)) if names is None else names)
        self.backbone[:] = cycle_index(palette, domains)
        if legend:
            self.legends[title] = [(n, cycle_index(palette, i)) for n, i in enumerate(names)]

    def plot(self, structure, *, title=' ', material='RNA', size=400, data_fields={}, display_fields=None):
        '''
        Return a new figure plotting the given structure

        - `title` (str): plot title
        - `material` (str): RNA or DNA
        - `size` (int): length in pixels (will be square)
        - `data_fields` (dict): fields to annotate in the data
        - `display_fields` (list): fields to show in the hover tooltip
        '''
        tools = ','.join(['pan', 'wheel_zoom', 'reset', 'save'])
        display_fields = DISPLAY_FIELDS if display_fields is None else display_fields

        p = figure(frame_width=size, frame_height=size, title=title,
                tools=tools, match_aspect=True, aspect_scale=1)

        p.title.text_font = 'arial'
        p.title.text_font_style = 'normal'
        p.title.text_font_size = '12pt'
        p.title.align = 'center'
        p.axis.visible = False
        p.grid.visible = False

        canvas = BokehBackend(self.length)
        box = glyphs.draw(canvas, (1, 1), structure, ''.join(self.base), ticks=True, circles=True, material=material)
        p.x_range, p.y_range = Range1d(*box[0]), Range1d(*box[1])
        drawing = BokehDrawing(canvas, self, fields=data_fields)
        drawing.render(p, fields=display_fields)

        for k, v in self.legends.items():
            self.add_legend(p, v, title=k)

        if self.color_bar is not None:
            p.add_layout(probability_bar(self.color_bar), 'right')
        return p

    def add_legend(self, figure, items, title=None, width=5):
        '''Add a legend with given item names and colors'''
        items = [legend_segment(figure, str(k), v, width) for k, v in items]
        legend = Legend(title=title, items=items)
        figure.add_layout(legend)
        figure.legend.title_text_font_style = 'normal'

################################################################################

def simple_plot(strands, structure, kind='ticks', domains={}, fields=None, **kws):
    '''
    Generate a secondary structure drawing with no shading

    - `strands`: ordered strands in the complex (list of strings, or '+' delimited string)
    - `structure`: dot parens plus of the structure to draw
    - `kind`: kind of drawing: 'circles', 'ticks', or 'letters'
    - `domains`: options to pass to Specification.color_domains()
    - `**kws`: additional keywords for Specification.plot()
    '''
    spec = Specification(strands, structure, kind=kind)
    spec.color_domains(**domains)
    return spec.plot(structure, **kws, display_fields=fields)

################################################################################

def probability_plot(strands, structure, prob, kind='ticks', domains={},
                     palette=None, display_fields=None, **kws):
    '''
    Generate a secondary structure drawing with probability shading

    - `strands`: ordered strands in the complex (list of strings, or '+' delimited string)
    - `structure`: dot parens plus of the structure to draw
    - `prob`: 1D array of floats for each base, between 0 and 1
    - `kind`: kind of drawing: 'circles', 'ticks', or 'letters'
    - `domains`: options to pass to Specification.color_domains()
    - `**kws`: additional keywords for Specification.plot()
    '''
    palette = PROBABILITY_PALETTE if palette is None else palette
    fields = DISPLAY_FIELDS if display_fields is None else display_fields
    spec = Specification(strands, structure, kind=kind)

    spec.shade_probability(prob, palette)
    spec.color_domains(**domains)

    return spec.plot(structure, **kws, data_fields={'pp': prob},
        display_fields=fields + [('Probability', '@pp')])

################################################################################

def cycle_index(container, index):
    return container[index % len(container)]

################################################################################

def legend_segment(figure, label, color, line_width):
    '''Add a line to the legend'''
    r = figure.segment(0, 0, 0, 0, color=color, line_width=line_width)
    return LegendItem(label=label, renderers=[r])

################################################################################

def probability_bar(palette='Viridis256'):
    '''Return a probability shading bar for a given palette'''
    color_mapper = LinearColorMapper(palette=palette, low=0, high=1)
    return ColorBar(color_mapper=color_mapper, ticker=BasicTicker(), label_standoff=8, border_line_color=None, location=(0, 0))

################################################################################

def zip_array(x, n):
    '''Utility function to transpose and array-ify an object'''
    return map(np.array, zip(*x)) if x else [[] for _ in range(n)]

################################################################################

def line_to_rect(t, u):
    '''
    t: (x,y) of start points
    u: (x,y) of end points
    width: line width
    '''
    center = 0.5 * (t + u)
    residual = u - t
    height = norm(residual, axis=1)
    angle = np.arctan2(*residual.T)
    return dict(x=center[:,0], y=center[:,1], height=height, angle=np.pi-angle)

################################################################################

class BokehDrawing:
    '''
    Class containing all of the Bokeh glyphs that are plotted for a given
    secondary structure drawing
    '''

    def __init__(self, backend, sequence, *, fields={}, start=0):
        self.sequence = Specification(backend.length) if sequence is None else sequence

        def S(i, *args, **kws):
            kws['i'] = np.asarray(i) + start   # Add index of each base
            for a in args:
                kws[a] = getattr(self.sequence, a)[i]
            return Source(kws)

        # Labels (not base letters)
        i, xy, xyt, text = zip_array(backend.labels, 4)
        lengths = np.array([len(t) for t in sequence.label_text])[i]
        xyt = xy + (1 + lengths / norm(xyt - xy, axis=1))[:, None] * (xyt - xy)

        # if len(text) > 0:
        ratio = (np.maximum(0, norm(xyt - xy, axis=1) - 2) / norm(xyt - xy, axis=1))[:, None]
        mid = ratio * xyt + (1 - ratio) * xy
        x, y = np.array([xy, mid]).T
        x0, x1 = x.T
        y0, y1 = y.T

        self.labels = S(i, 'label', 'label_text', 'label_size', x=list(xyt[:, 0]), y=list(xyt[:, 1]))
        self.label_edges = S(i, 'label_line', 'label_line_alpha', 'label_line_color', x0=x0, x1=x1, y0=y0, y1=y1)
        # else:
            # self.labels = S([], 'label', x=[], y=[], text=[])
            # self.label_edges = S([], 'label_line', x0=[], x1=[], y0=[], y1=[])

        # Backbone
        i, t, u, lw = zip_array(backend.backbone_lines, 4)
        # print(len(i)) # < N
        self.backbones = S(i, 'backbone', width=lw/2, **line_to_rect(*np.transpose([t, u])))

        i, x, y, r, t1, t2, lw = zip_array(backend.arcs, 7)
        # print(len(i)) # > N
        t1 = t1 * np.pi/180
        t2 = t2 * np.pi/180
        self.arcs = S(i, 'backbone', x=x, y=y, r=r/2-lw/4, r2=r/2+lw/4, t1=t1, t2=t2)
        self.arc_starts = S(i, 'backbone', x=x + np.cos(t1) * r/2, y=y + np.sin(t1) * r/2, r=lw/4)
        self.arc_ends = S(i, 'backbone', x=x + np.cos(t2) * r/2, y=y + np.sin(t2) * r/2, r=lw/4)

        i, t, u, lw = zip_array(backend.termini, 4)
        # print(len(i)) # strands x 4
        self.termini = S(i, 'backbone', width=lw/2, **line_to_rect(*np.transpose([t, u])))
        self.termini_ends = S(i, 'backbone', x=t[:, 1], y=u[:, 1], r=lw/4)

        i, a = zip_array(backend.arrowheads, 2)
        # print(len(i)) # strands
        self.arrowheads = S(i, 'backbone', x=a[:,:,0].tolist(), y=a[:,:,1].tolist())

        # Circles
        i, x, y, r, lw = zip_array(backend.circles, 5)
        # print(len(i))
        self.circles = S(i, 'circle', 'circle_alpha', 'circle_outline', 'base', 'strand_name', x=x, y=y, r=r, **fields)
        self.backgrounds = S(i, 'background', 'background_alpha', x=x, y=y, r=r)

        # Letters
        i, x, y, text = zip_array(backend.letters, 4)
        # print(len(i)) # N
        self.letters = S(i, 'letter', 'letter_alpha', x=x, y=y, text=text)

        # Unpaired ticks
        i, t, u, lw, paired = zip_array(backend.ticks, 4)
        # print(len(i)) # U
        self.ticks = S(i, 'tick', 'tick_alpha', width=lw/2, xc=t[:, 1],
            yc=u[:, 1], r=lw/4, **line_to_rect(*np.transpose([t, u])))


    def render_labels(self, figure):
        figure.segment('x0', 'y0', 'x1', 'y1', line_color='label_line_color', line_width=1, line_alpha='label_line_alpha', source=self.label_edges)
        t = figure.text('x', 'y', 'label_text', level='glyph', text_align='center',
            text_font_size='label_size', text_baseline='middle', source=self.labels)
        figure.add_tools(PointDrawTool(renderers=[t]))


    def render_backbones(self, figure):
        figure.annular_wedge('x', 'y', 'r', 'r2', start_angle='t1', end_angle='t2', line_width=0,
            fill_color='backbone', source=self.arcs, line_cap='round')
        figure.circle('x', 'y', radius='r', line_width=0, fill_color='backbone', source=self.arc_starts, line_cap='round')
        figure.circle('x', 'y', radius='r', line_width=0, fill_color='backbone', source=self.arc_ends, line_cap='round')
        figure.rect('x', 'y', 'width', 'height', 'angle', fill_color='backbone', line_width=0, source=self.backbones)

        figure.rect('x', 'y', 'width', 'height', 'angle', fill_color='backbone', line_width=0, source=self.termini)
        figure.circle('x', 'y', radius='r', fill_color='backbone', line_width=0, source=self.termini_ends)
        figure.patches('x', 'y', line_width=0, fill_color='backbone', source=self.arrowheads)

    def render_ticks(self, figure):
        figure.rect('x', 'y', 'width', 'height', 'angle', fill_color='tick', fill_alpha='tick_alpha', line_width=0, source=self.ticks)
        figure.circle('xc', 'yc', radius='r', fill_color='tick', fill_alpha='tick_alpha', line_width=0, source=self.ticks)

    def render_bases(self, figure, hover=True, fields=()):
        '''
        Circles are always on, just kept invisible if not wanted
        They are used for the hovertool tooltips
        '''
        circles = Circle(x='x', y='y', radius='r', fill_alpha='circle_alpha',
                         fill_color='circle', line_alpha='circle_outline',
                         line_color='black', line_width=2)
        glyphs = figure.add_glyph(source_or_glyph=self.circles, glyph=circles)
        if hover == 1:
            figure.add_tools(HoverTool(renderers=[glyphs], tooltips=list(fields)))
            # figure.add_tools(HoverTool(tooltips=list(fields)))

        font_size = self.sequence.font_size()
        figure.circle('x', 'y', alpha='background_alpha', size=1.5*font_size, color='background', line_width=0, source=self.backgrounds)

        figure.text('x', 'y', 'text', alpha='letter_alpha', text_align='center',
            text_baseline='middle', text_font_size='%.1fpt' % font_size, source=self.letters)

    def render(self, figure, hover=True, fields=()):
        self.render_labels(figure)
        self.render_ticks(figure)
        self.render_backbones(figure)
        self.render_bases(figure, hover, fields)


################################################################################

class BokehBackend:
    '''This is used as a callback to track all the glyphs from render.draw_structure'''

    def __init__(self, length):
        # straight lines in the backbone
        self.backbone_lines = []
        # letters to annotate bases
        self.letters = []
        # Base ticks for unpaired bases
        self.ticks = []
        # Base ticks for paired bases
        self.base_pairs = []
        # 5' and 3' termini segments
        self.termini = []
        # circles for each base
        self.circles = []
        # arrowheads for 3' ends
        self.arrowheads = []
        # backbone arcs
        self.arcs = []
        # labels attached to individual bases
        self.labels = []

        self.length = int(length)

    def _index(self, index):
        i = int(index)
        assert i >= 0 and i < self.length, (i, self.length)
        return i

    def annotate(self, text, *, lw, index, xy, xytext, fontsize, zorder):
        self.labels.append((self._index(index), np.array(xy), np.array(xytext), text))

    def backbone_line(self, t, u, *, lw, solid_capstyle=None, index):
        self.backbone_lines.append((self._index(index), t, u, lw))

    def tick(self, x, y, *, lw, solid_capstyle=None, index):
        self.ticks.append((self._index(index), x, y, lw, False))

    def base_pair(self, x, y, *, lw, solid_capstyle=None, index):
        self.ticks.append((self._index(index), x, y, lw, True))

    def terminus(self, x, y, *, lw, solid_capstyle=None, index):
        self.termini.append((self._index(index), x, y, lw))

    def arrowhead(self, A, *, lw, fill, index):
        self.arrowheads.append((self._index(index), A))

    def backbone_arc(self, xy, radius, t1, t2, *, index, lw):
        self.arcs.append((self._index(index), *xy, radius, t1, t2, lw))

    def letter(self, x, y, *, text, size, index):
        self.letters.append((self._index(index), x, y, text))

    def base_circle(self, x, radius, *, label, lw, index):
        self.circles.append((self._index(index), *x, radius, lw))

################################################################################

def _save_svg(figure, path):
    '''This doesn't work well'''
    old = figure.output_backend
    figure.output_backend = 'svg'
    export_svgs(figure, filename=str(path))
    figure.output_backend = old
