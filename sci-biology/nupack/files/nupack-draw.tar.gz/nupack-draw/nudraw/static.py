import matplotlib as mpl

BLACK = '#000000'

class MatplotlibBackend:
    def __init__(self):
        self.glyphs = []

    def render(self, ax, box):
        ax.set_xlim(box[0])
        ax.set_ylim(box[1])
        for x in self.glyphs:
            if isinstance(x, dict):
                txt = x.pop('text')
                ax.annotate(txt, **x)
            else:
                ax.add_artist(x)

    def annotate(self, text, *, lw, index, **kws):
        kws.update(dict(text=text, ha='center', va='center'))
        kws['arrowprops'] = dict(ec="#777777", shrinkA=2, shrinkB=2, arrowstyle="-", lw=lw, fill=False)
        self.glyphs.append(kws)

    def backbone_line(self, x, y, *, lw, solid_capstyle=None, index):
        color = BLACK or 'red'
        self.glyphs.append(mpl.lines.Line2D(x, y, lw=lw, color=color, zorder=1, solid_capstyle=solid_capstyle))

    def tick(self, x, y, *, lw, solid_capstyle=None, index):
        color = BLACK or 'orange'
        self.glyphs.append(mpl.lines.Line2D(x, y, lw=lw, color=color, zorder=0, solid_capstyle=solid_capstyle))

    def base_pair(self, x, y, *, lw, solid_capstyle=None, index):
        color = BLACK or 'orange'
        self.glyphs.append(mpl.lines.Line2D(x, y, lw=lw, color=color, zorder=0, solid_capstyle=solid_capstyle))

    def terminus(self, x, y, *, lw, solid_capstyle=None, index):
        color = BLACK or 'pink'
        self.glyphs.append(mpl.lines.Line2D(x, y, lw=lw, color=color, zorder=1, solid_capstyle=solid_capstyle))

    def arrowhead(self, A, *, lw, fill, index):
        fc = color = BLACK or 'pink'
        self.glyphs.append(mpl.patches.Polygon(A, lw=lw, fill=fill, fc=fc, color=color))

    def backbone_arc(self, xy, radius, t1, t2, *, index, lw):
        ec = BLACK or 'purple'
        self.glyphs.append(mpl.patches.Arc(xy, radius, radius, 0, t1, t2, lw=lw, ec=ec, fill=False, zorder=1))


    def letter(self, x, y, *, text, size, index):
        color = BLACK or 'yellow'
        va = "center"
        ha = "center"
        family = "sans-serif"
        self.glyphs.append(mpl.text.Text(x, y, text=text, color=color, va=va, ha=ha, zorder=3, family=family, size=size))


    def base_circle(self, x, radius, *, label, lw, index):
        ec = BLACK or "#007700"
        fc = BLACK or '#770000'
        self.glyphs.append(mpl.patches.Circle(x, radius=radius, fill=True, label=label, ec=ec, lw=lw, zorder=2, fc=fc))

