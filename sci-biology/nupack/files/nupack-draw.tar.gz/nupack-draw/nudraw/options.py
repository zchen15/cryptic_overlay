# Parse Configuration options
# Conrad D. Steenberg <conrad.steenberg@caltech.edu>
# Sep 24, 2008


#~ -freeenergybuffer -drawbases -colorbarbuffer -svgfile 792_0_2_mfe.svg
#~ -freeenergy -energypreamble "Free energy of secondary structure:" -prob
#~ 792_0.ppairs 792_0.mfe &

import sys
import re
import string
import json

# ------------------------------------------------------------------------------
optionexp=re.compile("^-{1,2}([^ \t\n\r\f\v=]+)\=?(.*)")

def subst(name, elem):
  try:
    return name%elem
  except TypeError:
    return name


# ------------------------------------------------------------------------------
# def parse(execfile, argv, vars, vars_doc):
#   printhelp=False
#   for i in range(len(argv)):

#     res_o=optionexp.match(argv[i])
#     if not res_o: continue
#     res=res_o.groups()
#    #try:
#     if res[1]:
#       if res[0] in vars and type(vars[res[0]])!=int:
#         if type(vars[res[0]])==str:
#           vars[res[0]]=res[1]
#         if type(vars[res[0]])==StringList:
#           vars[res[0]]=StringList(res[1].split(","))
#         if type(vars[res[0]])==IntList:
#           vars[res[0]]=IntList(map(lambda n: n>0,map(int,res[1].split(","))))

#       else:
#         raise ValueError("*** Error: No such option '%s'"%res[0])
#     else:
#       if res[0].lower()=='help' or res[0].lower()=='h':

#         printhelp=True
#         continue
#       elif res[0] in vars:
#         if type(vars[res[0]])==type(1):
#           vars[res[0]]=True
#         elif type(vars[res[0]])==IntList:
#           vars[res[0]]=IntList([True])
#         else: raise ValueError("*** Error: Option '%s' takes an argument"%res[0])

#       else:
#         if string.find(res[0],'enable-')==0 and \
#           res[0][7:] in vars:
#             if type(vars[res[0]])==type(1):
#               vars[res[0][7:]]=True
#             elif type(vars[res[0]])==IntList:
#               vars[res[0][7:]]=IntList([True])
#         elif string.find(res[0],'disable-')==0 and \
#           res[0][8:] in vars:
#             if type(vars[res[0]])==type(1):
#               vars[res[0][7:]]=False
#             elif type(vars[res[0]])==IntList:
#               vars[res[0][7:]]=IntList([False])
#         else: raise ValueError("*** Error: No such switch '%s'"%res[0])
#    # except ValueError as v:
#    #   print(v.args[0])
#    #   sys.exit(0)
#    # except:
#    #   sys.exit(0)

#   if printhelp:
#     print_usage(execfile, vars, vars_doc)
#     sys.exit(0)

#   return vars


if False:
  def_option_vars={\
        "material"        : "rna",
        "svgfile2d"       : "",
        "pngfile2d"       : "",
        "filecounter2d"   : StringList(),
        "dotfile"         : "",
        "mfefile"         : "",
        "probfile"        : "",
        "jsonout"         : "",
        "jsonin"          : "",
        "scenefile3d"     : "",
        "show3d"          : 0,
        "show2d"          : 0,
        "drawbases"       : IntList(),
        "colorbases"      : IntList(),
        "colorbar"        : IntList(),
        "colorbarspace"   : IntList(),
        "colorstrands"    : IntList(),
  }

  option_vars_doc={ \
        "material"        : "Either rna or dna",
        "svgfile2d"       : "Name of the 2D svg file to be produced",
        "pngfile2d"       : "Name of the 2D PNG file to be produced",
        "dotfile"         : "Name of the Graphviz file. In this file loops are nodes and helices are edges",
        "mfefile"         : "Input file to read structure information from",
        "probfile"        : "Input file to read probability information from",
        "filecounter2d"   : "Comma separated list of strings to substitute in export filenames",
        "jsonout"         : "Name of json file to be created, skip if not provided",
        "jsonin"          : "Name of json file to be read, skip if not provided",
        "scenefile3d"     : "3D Scene file export for Tachyon raytracer",
        "show3d"          : "Show 3D OpenGL model",
        "show2d"          : "Show 2D layout",
        "drawbases"       : "Draw base letters if available from mfe file",
        "colorbases"      : "Shade bases according to probfile",
        "colorbar"        : "Draw probability colorbar",
        "colorbarspace"   : "Reserve space for colorbar, but draw only if colorbar option set",
        "colorstrands"    : "Draw strands in different colors"
  }
