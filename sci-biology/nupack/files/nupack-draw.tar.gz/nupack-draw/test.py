import nudraw, matplotlib.pyplot as plt, time, numpy as np
# nudraw.run_drawing('(...)', 'AAAAT')

from nudraw.static import MatplotlibBackend

def test(*args, **kws):
    fig = plt.figure(figsize=(4, 4))
    ax = fig.add_axes([0,0,1,1])

    canvas = MatplotlibBackend()
    box = nudraw.draw(canvas, (4, 4), *args, **kws)
    canvas.render(ax, box)

    plt.show()
    plt.close()


test('((.(...+..)))', 'CCCCAAA+AGGGG')
test('.......+.....', 'CCCCAAAAGGGG')#, domainnames=['a', 'b'], labeldomains=True, domains=[1,1,1,1,1,1,1,2,2,2,2,2])
test('((.(...+..)))', 'CCCCAAA+AGGGG', numbers=[1,2,3], drawbaseticks=True)
test('((.(...+..)))', 'CCCCAAA+AGGGG', numbers=[5,10], drawbaseticks=False, drawbases=True)

