
import pdb

import shutil

import json, jsonschema, sys, os
import chardet
import pprint
from tornado.web import RequestHandler, Application
from mimetypes import guess_type
from pathlib import Path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))


DEFAULT_PORT=8766

################################################################################

class DotPlotHandler(RequestHandler):

    def respond(self, status, scope, message, data):
        self.set_status(status)
        self.add_header('Content-Type', 'application/json') 
        
        images = []
        job_type = data["job_type"]
        for file in os.listdir(data["job_type"]):  
            if file.endswith(".svg"):

                images.append( { f'{file}' : Path(f'{job_type}/{file}').read_text()} ) 
        


        shutil.rmtree(Path(f'{job_type}'))
        os.makedirs(f'{job_type}/')    
        self.write(json.dumps(images))                                                                                                                                                                                                                                                                                                      
    def post(self):
        
        params = json.loads(self.request.body.decode(chardet.detect(self.request.body)["encoding"]))

        job_type = params["job_type"]
        print(f'job_type: {job_type}')
        for tube_index, tube in enumerate(params["tubes"], start=1):
            writeLabel(job_type,tube_index, tube)
            writeMFE(job_type,tube_index, tube)  
            writePPair(job_type,tube_index, tube)
            
        writeRunSH(job_type,params)
        return self.respond(200, None, None, {"job_type":job_type})
      

      

#################################################################################
def writeLabel(job_type, tube_index, tube):
    
    for complex_index,complex in enumerate(tube["complexes"], start=1):
        if complex[0]["mfe_structures"]:
            complex = complex[0]

            l_path = os.path.join('',f'{job_type}/{tube_index}_{complex_index}.label')
            l_file = open(l_path,'w')
            
            for strand in complex["strands"]:    
                l_file.write(f'{strand}\n')
            l_file.close()

def writeMFE(job_type, tube_index, tube):
    
    for complex_index,complex in enumerate(tube["complexes"], start=1):
        if complex[0]["mfe_structures"]:
           
            complex = complex[0]

            #path
            mfe_path = os.path.join('',f'{job_type}/{tube_index}_{complex_index}.mfe')
            mfe_file = open(mfe_path,'w')
           
            sequences_string=""
            for index, strand in enumerate(complex["strands"],start=1):
                for seq_obj in complex["strand_seq_key"]:
                    if strand == seq_obj["name"]:
                        if index > 1:
                            sequences_string += '+'
                        sequences_string += f'{seq_obj["sequence"]}'
           
            mfe_file.write(f'% Sequence: {sequences_string}\n')
            mfe_file.write(f'% Parameters: {tube["parameters"]} \n')
            mfe_file.write(f'% Dangles: {tube["dangles"]}\n')
            mfe_file.write(f'% Temperature (C): {complex["temperature"]} \n')
            mfe_file.write(f'% Sodium concentration: {tube["sodium"]}\n')
            mfe_file.write(f'% Magnesium concentration: {tube["magnesium"]} \n')
            mfe_file.write(f'% Number of strands: {len(tube["strands"])}\n')
            
            #for each complex do this:
            mfe_file.write('\n')
            mfe_file.write('% %\n')
            mfe_file.write(f'{len(sequences_string)-sequences_string.count("+")}\n')
            mfe_file.write(f'{complex["mfe_energy"]}\n')
            mfe_file.write(f'{complex["mfe_structures"][0]}\n')
            if '(' in complex["mfe_structures"][0]:
                pairsList=pairsListFromDotParens(complex["mfe_structures"][0])
                for pair in pairsList:
                    mfe_file.write(f'{pair[0]} {pair[1]}\n')
            mfe_file.write('% %\n')
            mfe_file.close()


def writePPair(job_type, tube_index, tube):
  

    for complex_index,complex in enumerate(tube["complexes"], start=1):
        if complex[0]["mfe_structures"]: 
            #path
            ppair_path = os.path.join('',f'{job_type}/{tube_index}_{complex_index}.ppair')
            ppair_file = open(ppair_path,'w')
            complex=complex[0]
            sequences_string=""
            for index, strand in enumerate(complex["strands"],start=1):
                for seq_obj in complex["strand_seq_key"]:
                    if strand == seq_obj["name"]:
                        if index > 1:
                            sequences_string += '+'
                        sequences_string += f'{seq_obj["sequence"]}'
                                  

            #comment lines
            ppair_file.write(f'% NUPACK 3.0\n')
            ppair_file.write(f'% Program: pairs \n')
            ppair_file.write(f'% Start time: Mon Apr 29 16:59:42 2019\n')
            ppair_file.write(f'% Command: /root/nupack/work/partition/utils_mpi -batch -material rna -T 36.0 -sodium 1.0 -magnesium 0.0 {tube_index}_{complex_index}\n')
            ppair_file.write(f'% Minimum printed pair probability: 0.001\n')
            ppair_file.write(f'% Sequence: {sequences_string}\n')
            ppair_file.write(f'% Structure: {complex["mfe_structures"][0]}\n')
            ppair_file.write(f'% v(pi): 1\n')
            ppair_file.write(f'% Parameters: RNA, 1995\n')
            ppair_file.write(f'% Dangles setting: 1\n')
            ppair_file.write(f'% Temperature: {complex["temperature"]}\n')
            ppair_file.write(f'% Sodium concentration: 1.0000 M\n')
            ppair_file.write(f'% Magnesium concentration: 0.0000 M\n')
            ppair_file.write(f'% Structure free energy: 0.00000000e+00 kcal/mol\n')
            ppair_file.write(f'% Ensemble free energy: -0.00000000e+00 kcal/mol\n')
            ppair_file.write(f'% Partition function: 1.00000000e+00\n')
            ppair_file.write(f'% Probability: 1.00000000e+00\n')
            ppair_file.write(f'% Ensemble defect: 0.00000000e+00\n')
            ppair_file.write(f'% Normalized ensemble defect: 0.00000000e+00\n\n')
            ppair_file.write(f'% Number of strands: {len(tube["strands"])}\n')
           
            #for each complex do this:
            ppair_file.write(f'{len(sequences_string)-sequences_string.count("+")}\n')
            
            for i,j,v in zip(complex["pairs"]["rows"], complex["pairs"]["cols"], complex["pairs"]["values"]):
                ppair_file.write(f'{i+1} {j+1} {v} \n')

            for i,v in enumerate(complex["pairs"]["diagonal"],start=1):
                ppair_file.write(f'{i} {len(sequences_string)-sequences_string.count("+")+1} {v} \n')     
           
            
            ppair_file.close()



def writeRunSH(job_type, params):
    sh_path = os.path.join('',f'{job_type}/analysis.sh')
    sh_file = open(sh_path,'w')

    for tube_index,tube in enumerate(params["tubes"], start=1):
        for complex_index, complex in enumerate(tube["complexes"], start=1):
            if complex[0]["mfe_structures"]:
                 complex=complex[0]
                 sequences_string=""
                 for index, strand in enumerate(complex["strands"],start=1):
                    for seq_obj in complex["strand_seq_key"]:
                        if strand == seq_obj["name"]:
                            if index > 1:
                                sequences_string += '+'
                            sequences_string += f'{seq_obj["sequence"]}'

                 sh_file.write(f'python /root/drawing_service/DotPlot.py -freeenergy -energypreamble "Free energy of strand (-kT log Q):" -grid -datafile {job_type}/{tube_index}_{complex_index}_0_dp.dat -mfetarget -labels {job_type}/{tube_index}_{complex_index}.label -title "Pair probabilities at {complex["temperature"]} C" -svgfile {job_type}/{complex["complex_id"]}_1_dp.svg {job_type}/{tube_index}_{complex_index}.ppair\n\n')

                 sh_file.write(f'python /root/drawing_service/nudraw.py --jsonout=single/{tube_index}_{complex_index}_0_mfe.json --colorbar=0,1 --filecounter2d=0,1 --colorbarspace=0,1 --colorbaseprob=0,1 --drawbases=1,0 --colorstrands=1,0 --drawbasenumbers=0,1 --colorbaseid=1,0 --baseidbar=1,0 --skipfirstnumber --svgfile2d={job_type}/{complex["complex_id"]}_1_mfe.svg --sequence="{sequences_string}" --structure="{complex["mfe_structures"][0]}" --mfefile={job_type}/{tube_index}_{complex_index}.mfe --probfile={job_type}/{tube_index}_{complex_index}.ppair\n\n')

               
    sh_file.close()
    os.system(f'sh /root/drawing_service/{job_type}/analysis.sh')             


####################UTILITY FUNCTIONS##########################################

def pairsListFromDotParens(dot_parens):
    forward_index=[]
    backward_index=[]
    pairs_list=[]
    for index, char in enumerate(dot_parens, start=1):
        if char=='(':
            forward_index.append(index)
    for index, char in enumerate(reversed(dot_parens), start=0):
        if char==')':
            backward_index.append(len(dot_parens)-dot_parens.count("+")-index)        
    for index, char in enumerate(forward_index):
        pairs_list.append([forward_index[index], backward_index[index]])

    return pairs_list    



################################################################################

def make_app():
    return Application([
        (r"/dot_plot", DotPlotHandler)
    ])

################################################################################

if __name__ == "__main__":
    from argparse import ArgumentParser

    parser = ArgumentParser(description='Run NUPACK dot_plot server')
    parser.add_argument('--port', type=int, default=DEFAULT_PORT)
    args = parser.parse_args()

    import tornado.ioloop
    app = make_app()
    app.listen(args.port)
    tornado.ioloop.IOLoop.current().start()


