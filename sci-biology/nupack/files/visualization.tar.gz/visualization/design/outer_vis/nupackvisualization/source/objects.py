import numpy as np

import pandas as pd
from pandas.errors import EmptyDataError

from bokeh.layouts import column
from bokeh.models import Button, HoverTool
from bokeh.palettes import *
from bokeh.plotting import figure
from bokeh.transform import linear_cmap, factor_cmap
from bokeh.layouts import gridplot, layout, row
from bokeh.models.layouts import Spacer
from bokeh.models.widgets import TextInput, Panel, Tabs
from bokeh.models.widgets.groups import CheckboxButtonGroup
from bokeh.plotting import figure, ColumnDataSource

from os.path import isfile

from copy import deepcopy as copy

class FileReader(object):
    """docstring for FileReader."""
    def __init__(self, filename):
        super(FileReader, self).__init__()
        self.filename = filename
        self.last = 0
        self.last_line = None
        self.cur = None

    def is_valid(self):
        if self.is_file() and self.last_line is None: # not accessed yet, but is a valid file
            return True
        if self.last_line is not None:
            data = self.read_data(1)
            if data is not None and len(data) >= 1 and data.iloc[0].equals(self.last_line):
                return True
        return False

    def is_file(self):
        return isfile(self.filename)

    def new_data(self):
        data = self.read_data()
        num_new = -1
        if data is not None:
            num_new = len(data) - 1
        if num_new > 0:
            self.last += num_new
            self.last_line = copy(data.iloc[-1])
            return data
        elif num_new == 0:
            return None
        elif num_new < 0:
            return False


    def read_data(self, nrows=None):
        try:
            data = pd.read_csv(self.filename, skiprows=range(1,self.last+1), nrows=nrows, sep=";")
        except EmptyDataError:
            data = None
        return data

    def reload(self):
        self.__init__(self.filename)


class LogVisualizer(object):
    def __init__(self, width=1600, height=1000, sub_width=400, sub_height=int(400*1.6), columns=3, notebook_layout=False, fn=""):
        self.width = width
        self.height = height
        self.sub_width = sub_width
        self.sub_height = sub_height
        self.columns = columns
        self.notebook_layout = notebook_layout
        self.fn = fn
        self.f = FileReader(self.fn)
        self.num_pts = 3000

        self.add_stages()
        self.add_colors()

        self.sources = dict()
        self.init = dict(stage=[], time=[], depth=[], psi_on=[], psi_off=[], defect=[], sequence=[])

    def add_stages(self):
        self.stages = ["mutation accepted", "mutation rejected", "reseeded",
                "merge successful", "merge unsuccessful",
                "redecomposed", "root accepted", "root rejected", "refocused", "post processed"]

    def add_colors(self):
        colors = brewer['Paired'][12]
        color_order = {
            "mutation accepted": 1,
            "mutation rejected": 0,
            "reseeded": 8,
            "merge successful": 5,
            "merge unsuccessful": 4,
            "best merge": 11,
            "redecomposed": 6,
            "root accepted": 3,
            "root rejected": 2,
            "refocused": 7,
            "post processed": 9,
        }
        self.colors = {k: colors[v] for k, v in color_order.items()}

    def reset_data(self):
        for s in self.sources.values():
            s.data = copy(self.init)

    def __call__(self, doc):
        self.f = FileReader(self.fn)
        TOOLTIPS = [('time', '@time'),
                ('defect', '@defect'),
                ('stage', '@stage'),
                ('depth', '@depth'),
                ('Psi active', '@psi_on'),
                ('Psi passive', '@psi_off'),
                ]


        hover = HoverTool(
            tooltips=TOOLTIPS,
            mode='mouse'
        )

        # create summary plot of all data sources
        summary = figure(title="All", x_axis_label="time", y_axis_label="defect", plot_width=self.width, plot_height=self.height)
        summary.add_tools(hover)

        figs = list()
        for stage in self.stages:
            self.sources[stage] = ColumnDataSource(copy(self.init))
            source = self.sources[stage]

            summary.line(source=source, x="time", y="defect", color=self.colors[stage])
            summary.circle(source=source, x="time", y="defect", color=self.colors[stage])

            if not self.notebook_layout:
                pw = self.sub_width
                ph = self.sub_height
                fig = figure(title=stage, x_axis_label="time", y_axis_label="defect", x_range=summary.x_range, plot_height=ph, plot_width=pw)
                fig.add_tools(hover)

                fig.line(source=source, x="time", y="defect", color=self.colors[stage])
                fig.circle(source=source, x="time", y="defect", color=self.colors[stage])
                figs.append(fig)


        def update():
            nonlocal doc
            translate_header = {"stage": "type", "psi_on": "psi_active", "psi_off": "psi_passive",}

            if not self.f.is_file():
                self.reset_data()
                return

            if not self.f.is_valid():
                self.reset_data()
                self.f.reload()

            data = self.f.new_data()
            if data is not None and data is not False:
                sts = set(data["type"]) & set(self.stages)
                for stage in sts:
                    selection = data["type"] == stage
                    sub_data = data[selection]
                    keys = ["stage", "time", "depth", "psi_on", "psi_off", "defect", "sequence"]
                    # keys.append("image")
                    stuff = {k: sub_data[translate_header.get(k, k)] for k in keys}
                    self.sources[stage].stream(stuff, rollover=self.num_pts)

            doc.title = self.f.filename + " data"


        # Filename handling
        def file_update(attr, old, new):
            nonlocal doc
            if old != new:
                self.f = FileReader(new)
                if self.f.is_valid():
                    doc.title = new + " data"
                else:
                    doc.title = "Bad file name: " + new

                self.reset_data()


        def forward_file(attr, old, new):
            file_update(attr, old, new)

        get_filename = TextInput(title="Current file: ", value=self.fn)
        get_filename.on_change("value", forward_file)

        # Points handling
        def points_update(attr, old, new):
            try:
                n = int(new)
            except:
                return

            self.num_pts = n
            self.reset_data()
            self.f.reload()

        get_points_per_series = TextInput(title="# Points per series: ", value=str(self.num_pts))
        get_points_per_series.on_change("value", points_update)


        if self.notebook_layout:
            lay = row(summary)
        else:
            col = self.columns
            nf = len(figs)
            rows = int(np.ceil(nf / col))

            fig_layout = [figs[k] if k < nf else Spacer() for i in [x*col for x in range(rows)] for k in range(i, i+col)]

            agg = Panel(child=summary, title="all")
            indiv = Panel(child=gridplot(fig_layout, ncols=col), title="individual")

            tabs = Tabs(tabs=[agg, indiv], sizing_mode="stretch_both")
            lay = layout([[get_filename, get_points_per_series], [tabs]])


        doc.add_periodic_callback(update, 300)

        update()

        doc.add_root(lay)
