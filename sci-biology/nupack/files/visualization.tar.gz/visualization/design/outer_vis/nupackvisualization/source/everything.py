# from .sequence_drawing import *
from .objects import FileReader, LogVisualizer

from bokeh.io import show, output_notebook, output_file
from concurrent.futures import ThreadPoolExecutor
from tempfile import NamedTemporaryFile

pool = ThreadPoolExecutor()
base = LogVisualizer()

def make_doc(w=base.width, h=base.height, sw=base.sub_width, sh=base.sub_height, c=base.columns):
    width, height, columns, sub_width, sub_height = w, h, c, sw, sh

    return LogVisualizer(width=width, height=height, columns=columns, sub_width=sub_width, sub_height=sub_height)

def make_server_doc(doc):
    make_doc()(doc)

def notebook_log(filename=""):
    ret = make_doc(w=900, h=500, sw=900, sh=500, c=1)
    ret.fn = filename
    ret.notebook_layout = True
    return ret

def run_and_display(design, url=None):
    output_notebook()

    if design.parameters.log == "":
        design.parameters.log = NamedTemporaryFile(delete=False).name

    def bg(design):
        result = design()
        return result

    if url is None:
        url = input('Input your notebook URL (default: \'localhost:8888\'):').strip()
    url = url or 'localhost:8888'

    show(notebook_log(str(design.parameters.log)), notebook_url=url)

    return pool.submit(bg, design)
