from setuptools import setup

setup(
    name='nupackvisualization',
    version='0.0.0',
    packages=['nupackvisualization',],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description="blah blah blah",
    install_requires=[
        "bokeh",
        "pandas",
        "numpy",
        "scikit-image"
    ]
)
