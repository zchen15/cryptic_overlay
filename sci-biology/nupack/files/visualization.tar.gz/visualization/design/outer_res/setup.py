from setuptools import setup

setup(
    name='nupackresiduals',
    version='0.0.0',
    packages=['nupackresiduals',],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description="nupack residual plotting",
    install_requires=[
        "bokeh",
        "pandas",

    ]
)
