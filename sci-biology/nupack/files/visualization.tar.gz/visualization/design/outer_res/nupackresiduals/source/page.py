from copy import deepcopy as copy
import json
from glob import glob
from os.path import isfile
from bokeh.plotting import figure
from bokeh.models.widgets import TextInput, Select, AutocompleteInput, Slider, Panel, Tabs, RadioButtonGroup, Button
from bokeh.models.callbacks import CustomJS
from bokeh.layouts import gridplot, layout, row, column, Spacer
from bokeh.transform import linear_cmap, factor_cmap, dodge
from bokeh.plotting import figure, curdoc
from bokeh.palettes import *
from bokeh.models import Button, HoverTool, TapTool, ColumnDataSource, FactorRange, Range1d
from bokeh.core.properties import value
from bokeh.layouts import column
import numpy as np
import pandas as pd
from .cpathway_lib import OutputParser3, OutputParser4

BLUE = '#1f78b4'
GREEN = '#33a02c'
PURPLE = '#6a3d9a'
RED = '#e31a1c'


class SourceAggregate(object):
    '''docstring for SourceAggregate.'''
    def __init__(self):
        super(SourceAggregate, self).__init__()
        self._summary = None
        self._per_tube_defects = None
        self._concentrations = None
        self._complexes = None


    @property
    def tube_names(self):
        return list(self._per_tube_defects.keys())

    @property
    def summary(self):
        return ColumnDataSource(self._summary)

    @summary.setter
    def summary(self, df: pd.DataFrame):
        self._summary = df

    @property
    def complexes(self):
        return ColumnDataSource(self._complexes)

    @complexes.setter
    def complexes(self, df: pd.DataFrame):
        self._complexes = df

    def per_tube_defects(self, tube_name):
        x = self._per_tube_defects
        return ColumnDataSource(x[x['tube_name'] == tube_name])

    def concentrations(self, tube_name):
        x = self._concentrations
        y = copy(x[x['tube_name'] == tube_name])
        y['x'] = list(zip(y["type"], y["complex_name"]))
        return ColumnDataSource(y)



class Page(object):
    '''docstring for Page.'''

    def __init__(self):
        super(Page, self).__init__()
        self.sources = SourceAggregate()
        self.loglin = RadioButtonGroup(labels=['linear', 'log'], active=0)
        self.loglin.on_change("active", self.update_all)
        self.summary_rw = row(children=[])
        self.tube_col = column(children=[])
        self.complex_col = column(children=[])
        self.sel = Select(title='Tube', value='Unset', options=[])
        self.sel.on_change('value', self.change_tube_plot)

        self.width_box = TextInput(title='width (px)', value=str(1400))
        self.width_box.on_change('value', self.update_all)

        self.height_box = TextInput(title='height (px)', value=str(500))
        self.height_box.on_change('value', self.update_all)

        self.get_filename = TextInput(title='Design results file', value='Enter filename here')
        self.get_filename.on_change('value', self.file_update)

        self.reload = Button(label="Reload file", button_type='default')
        self.reload.on_click(lambda: self.file_update("value", "", self.get_filename.value))

        self.summary_panel = Panel(child=self.summary_rw, title='Summary')
        self.tube_panel = Panel(child=layout([[self.sel], [self.tube_col]]), title='Individual tubes')
        self.complexes_panel = Panel(child=self.complex_col, title='On-targets')
        self.tabs = Tabs(tabs=[self.summary_panel, self.tube_panel, self.complexes_panel], width=self.width)

        self.lay = layout([[self.get_filename, self.reload, self.width_box, self.height_box, self.loglin], self.tabs])

    def change_tube_plot(self, attr, old, new):
        self.tube_col.children = [
            self.make_tube_defect_fig(new),
            self.make_concentration_fig(new)
        ]

    def change_summary_plot(self):
        self.summary_rw.children = [self.make_summary_fig()]

    def change_complexes_plot(self):
        self.complex_col.children = list(self.make_complex_defects())

    @property
    def axis_type(self):
        return self.loglin.labels[self.loglin.active]

    @property
    def width(self):
        return int(self.width_box.value)


    @property
    def height(self):
        return int(self.height_box.value)

    def update_all(self, attr, old, new):
        self.tabs.width = self.width
        self.change_tube_plot(None, None, self.sel.value)
        self.change_summary_plot()
        self.change_complexes_plot()


    def make_layout(self, notebook=False):
        if notebook:
            return layout([[self.get_filename, self.reload, self.loglin], self.tabs])
        return self.lay


    def make_complex_defects(self):
        source = self.sources.complexes

        specs = [
            dict(title='Complex ensemble defects', yaxis='Defect (nt)', series='defect'),
            dict(title='Normalized complex ensemble defects', yaxis='Normalized defect', series='normalized_defect'),
        ]

        def make_fig(title=None, yaxis=None, series=None):
            TIPS = [
                ('Name', '@name'),
                ('Defect (nt)', '@defect'),
                ('Normalized defect', '@normalized_defect'),
            ]

            hover = HoverTool(tooltips=TIPS, mode='mouse')

            fig = figure(title=title, x_axis_label='complex', x_range=source.data['name'],
                        y_axis_label=yaxis, plot_width=self.width, plot_height=self.height,
                        y_axis_type=self.axis_type)

            if (self.axis_type == "linear"):
                fig.vbar(x='name', top=series, width=0.75, source=source, color=BLUE)
            elif (self.axis_type == "log"):
                w = 10 * np.sqrt(2)
                fig.circle(x='name', y=series, radius=w/2, source=source, color=BLUE, radius_units='screen')


            fig.xaxis.major_label_orientation = 'vertical'
            # fig.legend.orientation = 'vertical'
            # fig.legend.location = 'top_right' # no need; default!
            fig.add_tools(hover)
            return fig
            # return Spacer()

        return tuple(make_fig(**x) for x in specs)


    def make_concentration_fig(self, key):
        source = self.sources.concentrations(key)
        TIPS = [
            ('Name', '@complex_name'),
            ('Target concentration (M)', '@target_concentration'),
            ('Actual concentration (M)', '@concentration'),
        ]

        frange = FactorRange(*source.data['x'])
        fig = figure(title='Concentrations', x_axis_label='complex', x_range=frange,
                y_axis_label='concentration (M)', plot_width=self.width, plot_height=self.height, y_axis_type=self.axis_type)

        if (self.axis_type == "linear"):
            w = 0.75
            hover = HoverTool(tooltips=TIPS, mode='vline')
            fig.vbar(x=dodge('x', -w/4, range=fig.x_range), top='target_concentration', width=w/2, source=source,
                    color=PURPLE, legend=value('target concentration'))
            fig.vbar(x=dodge('x',  w/4, range=fig.x_range), top='concentration', width=w/2, source=source,
                    color=RED, legend=value('concentration'))
        elif (self.axis_type == "log"):
            w = 10
            hover = HoverTool(tooltips=TIPS, mode='mouse')
            mn = min((x for x in source.data["concentration"] if x > 0)) / 10
            mx = max(source.data["concentration"]) * 10
            fig.circle(x="x", y='target_concentration', radius=w*np.sqrt(2)/2, source=source,
                    fill_color=None, line_color=PURPLE, legend=value('target concentration'), radius_units='screen')
            fig.x(x="x", y='concentration', size=w, source=source,
                    color=RED, legend=value('concentration'))
            fig.y_range = Range1d(mn, mx)

        fig.xaxis.major_label_orientation = 'vertical'
        fig.legend.orientation = 'vertical'
        # fig.legend.location = 'top_right' # no need; default!
        fig.add_tools(hover)

        return fig


    def make_tube_defect_fig(self, key):
        source = self.sources.per_tube_defects(key)
        TIPS = [('Name', '@complex_name'),
                ('Structural defect', '@structural_defect'),
                ('Concentration defect', '@concentration_defect'),
                ('Total defect', '@complex_defect'),
                ]
        hover = HoverTool(tooltips=TIPS, mode='mouse')
        fig = figure(title='Defect contributions', x_axis_label='complex', x_range=source.data['complex_name'],
                y_axis_label='contribution to defect', plot_width=self.width, plot_height=self.height,
                y_axis_type=self.axis_type)

        stack = ['structural_defect', 'concentration_defect']
        colors = [BLUE, GREEN]
        legend = ['structural defect', 'concentration defect']

        if (self.axis_type == "linear"):
            w = 0.75
            fig.vbar_stack(stack, source=source, x='complex_name', width=w, color=colors,
                    legend=legend)
        elif (self.axis_type == "log"):
            w = 10 * np.sqrt(2)
            mn = min((x for x in (list(source.data[stack[0]]) + list(source.data[stack[1]])) if x > 0)) / 10
            mx = max((x for x in (list(source.data[stack[0]]) + list(source.data[stack[1]])) if x > 0)) * 10
            for i in range(2):
                fig.circle(x='complex_name', y=stack[i], radius=w/2, source=source,
                        color=colors[i], legend=value(legend[i]), radius_units='screen')
            fig.y_range = Range1d(mn, mx)

        fig.xaxis.major_label_orientation = 'vertical'
        fig.add_tools(hover)
        fig.legend.orientation = 'horizontal'
        fig.legend.location = 'top_center'
        return fig


    def make_summary_fig(self):
        source = self.sources.summary
        TIPS = [('Name', '@tube_name'),
                ('Structural defect', '@structural_defect'),
                ('Concentration defect', '@concentration_defect'),
                ('Total defect', '@tube_defect'),
                ]
        hover = HoverTool(tooltips=TIPS, mode='mouse')

        callback = CustomJS(args=dict(tabs=self.tabs, source=source, sel=self.sel), code='''
        var active_tube = source.data['tube_name'][source.selected.indices[0]]
        sel.value = active_tube
        tabs.active = 1
        source.selected.indices = Array()
        ''')
        tap = TapTool(callback=callback)

        fig = figure(title='Summary', x_axis_label='tube', x_range=source.data['tube_name'],
                y_axis_label='normalized tube defect', plot_width=self.width, plot_height=self.height,
                y_axis_type=self.axis_type)

        stack = ['structural_defect', 'concentration_defect']
        colors = [BLUE, GREEN]
        legend = ['structural defect', 'concentration defect']
        if (self.axis_type == 'linear'):
            w = 0.75
            fig.vbar_stack(stack, source=source, x='tube_name', width=w, color=colors, legend=legend)
        elif (self.axis_type == 'log'):
            w = 10 * np.sqrt(2)
            mn = min((x for x in (list(source.data[stack[0]]) + list(source.data[stack[1]])) if x > 0)) / 10
            mx = max((x for x in (list(source.data[stack[0]]) + list(source.data[stack[1]])) if x > 0)) * 10
            for i in range(2):
                fig.circle(x='tube_name', y=stack[i], radius=w/2, source=source,
                        color=colors[i], legend=value(legend[i]), radius_units='screen')
            fig.y_range = Range1d(mn, mx)
        fig.xaxis.major_label_orientation = 'vertical'
        fig.add_tools(hover, tap)
        fig.legend.orientation = 'horizontal'
        fig.legend.location = 'top_center'
        return fig


    def file_update(self, attr, old, new):
        if isfile(new):
            try:
                json.load(open(new))
                x = OutputParser4(new)
            except:
                x = OutputParser3(new)

            self.sources = SourceAggregate()
            tubes = x.set_sources(self.sources)

            self.sel.options = tubes
            # clear_plot()
            self.sel.value = 'Crosstalk' if 'Crosstalk' in tubes else tubes[0]
            self.update_all(*tuple([None]*3))
