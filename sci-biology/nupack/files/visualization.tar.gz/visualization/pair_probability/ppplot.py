#!/usr/bin/env python3
import bokeh.plotting
import bokeh.models
import bokeh.palettes
import bokeh.io
import numpy as np
import pandas as pd
from extract_pairs import remove_header
import sys



# I initially attempted to add in all of the zero entries explicitly,
# but this killed performance, so I ended up making the plot background match
# vir[0] instead. This way there isn't a huge visual jump between computed
# tuples which are near zero and the omitted values which are 

# def zeroed_df(size):
#     x = np.array([i + 1 for i in range(size) for j in range(size)])
#     y = np.array([j + 1 for i in range(size) for j in range(size)])
#     df = pd.DataFrame({'i': x, 'j': y})
    
#     return df
    
# def extend(df, zero):
#     merged = pd.merge(df, zero, on=['i', 'j'], how="right")
#     return merged

def main(args):
    prefix = args[1]
    remove_header(prefix + ".ppairs")
    pairs = np.loadtxt(prefix + ".ppairs-processed")
    pair_probabilities_plot(pairs, prefix)

def random_structure(size):
    i = np.random.choice(range(1,size+1), size=size, replace=False)
    j = np.random.choice(range(1,size+1), size=size, replace=False)
    return i, -j
    
def mfe_structure(dotparens):
    assert dotparens.count('(') == dotparens.count(')')
    i = []
    j = []
    openparens = []
    for x in range(len(dotparens)):
        cur = dotparens[x]
        if cur == '(':
            openparens.append(x)
        elif cur == ')':
            i.append(openparens.pop())
            j.append(x)
        elif cur == '.':
            i.append(x)
            j.append(x)
        else:
            raise ValueError()
    
    # one based indexing
    return np.array(i + j) + 1, -(np.array(j + i) + 1)

def add_grid(fig, size, outline=False):
    offset = 0
    if outline:
        size = size + 1
        offset = 0.5
    x0 = np.array([1 for i in range(size)])
    x1 = np.array([size for i in range(size)])
    y0 = np.array([-(i+1) for i in range(size)])
    y1 = np.copy(y0)
    
    fig.segment(np.append(x0, -y0)-offset, np.append(y0, -x0)-offset, 
                np.append(x1, -y1)-offset, np.append(y1, -x1)-offset, 
                color='white', alpha=0.1)
    
def pair_probabilities_plot(pair_tuples, prefix, cmap=bokeh.palettes.viridis(256), grid=True):
    gradation = len(cmap)
    
    x = pair_tuples[:, 0].astype(int)
    y = pair_tuples[:, 1].astype(int)
    seq_size = np.max(y) - 1

    # convert from P(i, N+1) indicating unpaired probability to 
    # P(i, i) indicating unpaired probability (self-pairing)
    y[y == np.max(y)] = x[y == np.max(y)]

    # for symmetrizing the matrix
    i = np.append(x,y,axis=0)
    j = np.append(y,x,axis=0)

    # duplicate to match length of i and j
    ppairs = np.append(pair_tuples[:, 2],pair_tuples[:, 2],axis=0)

    df = pd.DataFrame({'i': i, 'j': j, 'pair probability': ppairs})

    # remove repeated diagonal entries (unpaired probabilities)
    df = df.drop_duplicates()

    # for displaying as matrix with row index increasing with y coordinate decreasing
    # y axis ticks now read the negative of i
    df['y'] = -df['i']

    # match pair probability with nearest discrete color in viridis; shrink i by small factor to avoid index out of bounds when i == 1.0
    df['color'] = [cmap[np.floor((i*0.999999999999) * gradation).astype(int)] for i in df['pair probability']]

    # create plot 
    fig = bokeh.plotting.figure(plot_width=700, plot_height=700, toolbar_location="above")

    # Create background on data
    fig.rect((seq_size+1)/2, -(seq_size+1)/2, width=seq_size, height=seq_size, color=cmap[0])
    
    if grid:
        add_grid(fig, seq_size)

    # series of squares of unit side length colored by 
    render = fig.rect('j', 'y', width=1, height=1, color='color', source=df)

    # add a hover tool which prints bases in pair and its probability
    hover = bokeh.models.HoverTool(tooltips="P(@i, @j) = @{pair probability}", renderers=[render])
    fig.add_tools(hover)

    # activate wheel zoom as scroll tool by default
    for tool in fig.toolbar.tools:
        if type(tool) == type(bokeh.models.WheelZoomTool()):
            fig.toolbar.active_scroll = tool

    # add colorbar for viridis map to figure
    color_mapper = bokeh.models.LinearColorMapper(palette=cmap, low=0, high=1)
    color_bar = bokeh.models.ColorBar(color_mapper=color_mapper, ticker=bokeh.models.BasicTicker(max_interval=0.1),
                     label_standoff=10, border_line_color=None, location=(0,0))
    fig.add_layout(color_bar, 'right')
    bokeh.io.output_file(prefix + ".html", title="{}'s pair probability matrix".format(prefix))
    bokeh.io.save(fig)
    return fig

if __name__ == '__main__':
    main(sys.argv)
