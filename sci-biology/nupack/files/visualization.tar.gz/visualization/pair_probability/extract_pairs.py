import numpy as np
import re

def remove_header(filename):
    tup = re.compile('[0-9]+\s+[0-9]+\s+[0-9][.]*[0-9]*.*')
    lines = []
    with open(filename, 'r') as f:
        for line in f:
            if tup.match(line):
                lines.append(line)
                
    with open(filename + "-processed", 'w') as f:
        for line in lines:
            f.write("\t".join(re.split('[ \t]+', line)))
            
    
            
