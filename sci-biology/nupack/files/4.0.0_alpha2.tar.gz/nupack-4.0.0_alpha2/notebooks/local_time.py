## A set of useful functions for calculating properties related to Gamma (the covariance of R)

import nupack, numpy as np
import numpy.linalg as la

#############################################################################################################

# use Nupack Analysis to sample a set of structures based on the Boltzmann distribution

def equilibrium_info(num, sequences, run_model = nupack.Model(gt = True)):

    analysis = nupack.Analysis(model= run_model)
    analysis.boltzmann_sample(sequences, num) # generates set # of sample structures within the boltzmann distribution
    analysis.pair_probability(sequences)

    results = analysis.compute() # compute partition function, MFE, PP matrix, etc. for each sequence in boltzmann sample

    pairs = results[sequences].pair_probability
    free_energy = results[sequences].free_energy
    samples = [s.dp() for s in results[sequences].boltzmann_sample]  # return dot-parens for each structure in sample

    return pairs, samples, free_energy

#############################################################################################################

# generates indices of "num_pairs" pairs with the greatest variance over the set "pairs"

def generate_locs(pairs, num_pairs=3):

    variance = np.triu(pairs * (1 - pairs))
    threshold = np.sort(variance.ravel())[-num_pairs]

    rows, cols = np.where(variance >= threshold)
    ordered = rows <= cols
    rows = rows[ordered]
    cols = cols[ordered]

    return rows, cols

#############################################################################################################

# Calculates the structure matrix from a state, with S(i,j) = 1 indicating i and j are paired, zero value for unpaired

def structure_matrix_from_state(w):
    pairs = w.pairs.view()
    F = np.zeros((len(pairs), len(pairs)))
    for i, j in enumerate(pairs):
        F[i, j] = 1
    return F[1:-1, 1:-1]

#############################################################################################################

# Calculates Z from R and stationary distribution, pi

def Z_from_R(pi, R):
    print(np.diagonal(R).sum())
    return np.linalg.inv(-R + 1e6 * pi[None]) - 1e-6 * pi[None]

#############################################################################################################

# Performs a number of runs to use local time integrals to estimate Gamma for a range of tau values
#       Gamma_actual is the precisely calculated Gamma for all pairs/states
#       Gamma_values is the local time integral estimate
#       Gamma_error is the L1 norm of Gamma_values and Gamma_actual

def Gamma_path_estimate(tau_range, sequences, runs = 1, sample_num = 1e4, traj_num = 10000, nupack_model = nupack.Model(gt = True)):

    Gamma_error = []
    Gamma_values = []
    Gamma_actual = []

    # Retrieve some values to calculate Gamma_actual
    # nupack_model = nupack.Model(gt = True)
    w_unpaired = nupack.State(sequences, kind='full', model = nupack_model)
    states, pi, R, _ = w_unpaired.rate_matrix()

    S = nupack.markov.S_from_R(R, pi)

    for n in range(runs):

        pairs, samples, free_energy = equilibrium_info(num = sample_num, sequences = sequences) # generate new sample distribution each time
        locs = generate_locs(pairs)

        # Calculate Gamma_actual for each run. This shouldn't change much from run to run
        bigF = np.array([structure_matrix_from_state(w)[locs] for w in states])
        Gamma = bigF.T @ (np.diag(pi) @ S @ np.diag(pi)) @ bigF

        avgF = pairs[locs] # approximately the mean PP for pairs[locs]. F will approach equilibrium probabilitiy distribution

        Gamma_error_run = []
        Gamma_values_run = []

        # generate starting states from dp of structures in samples
        starts = [nupack.State(sequences[0], dp=dp) for dp in samples]

        # Check whether tau_range is a list or one value
        if (len(np.array(tau_range)) == 1):

            paths = [nupack.path.sample_path(w, tau_range[0]) for w in starts[:traj_num]] # run trajetories from sample distribution

            # 'times' is the integrated pair probability matrix for the sample path, i.e. the amount of time a base pair exists during the trajectory
            # have to multiply mean PP (avg_F) by time to have equivalent units to 'times'. Subtract off from local value to calculate covariance from mean value

            times = np.array([p.base_pair_time()[locs] - p.time * avgF for p in paths])
            total_time = sum(p.time for p in paths)

            G_estimate = times.T @ times / 2 / total_time  # transpose turns columns into rows, then times columns of times, means multiplying each element by itself & summing
            Gamma_error_run.append((np.linalg.norm(G_estimate - Gamma) / np.linalg.norm(Gamma)))
            Gamma_values_run.append(G_estimate)

        else:
            for tau in enumerate(tau_range):

                paths = [nupack.path.sample_path(w, tau[1]) for w in starts[:traj_num]]

                times = np.array([p.base_pair_time()[locs] - p.time * avgF for p in paths])
                total_time = sum(p.time for p in paths)

                G_estimate = times.T @ times / 2 / total_time
                Gamma_error_run.append((np.linalg.norm(G_estimate - Gamma) / np.linalg.norm(Gamma)))
                Gamma_values_run.append(G_estimate)

        Gamma_error.append(Gamma_error_run)
        Gamma_values.append(Gamma_values_run)
        Gamma_actual.append(Gamma)

        print(n) # just to check how fast it runs

    return Gamma_actual, Gamma_values, Gamma_error

#############################################################################################################

# Obtains a corrected estimate of Gamma from G1 = Gamma(tau) and G2 = Gamma(2*tau)

def corrected_gamma(G1,G2):
    '''
    Returns G1 @ inv(2 * G1 - G2) @ G1
    '''
    return G1 @ la.inv(2 * G1 - G2) @ G1
    evals, evecs = la.eigh(G1)
    proj = (evecs * ((2 * G1 - G2) @ evecs).sum(1))
    # make sure timescale estimate is only increased
#     evals = np.maximum(evals,evals**2/proj)
    evals = evals**2/proj
    return evecs @ np.diag(evals) @ evecs.T