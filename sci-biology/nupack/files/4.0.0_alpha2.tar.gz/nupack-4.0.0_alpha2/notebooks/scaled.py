
# coding: utf-8

# In[1]:


import numpy as np
from scipy.linalg import eigh, inv
from nupack4 import *

import pandas as pd
table = lambda *ks: print(*map(pd.DataFrame, ks), sep='\n\n')

# Define the model used for all the states (temperature and gt-pairs, dangles always have to be none)
model = Model(dangles='none', gt=True)
model.unimolecular_scaling /= 1e0
model.bimolecular_scaling /= 1e0
engine = Engine(model=model)
count = Engine(model=model, count=True)
state = lambda s, dp=None: State(s, dp, kind='slow', model=model)

join_scale = model.bimolecular_scaling * model.molarity / model.unimolecular_scaling / 10


# In[ ]:


# System defined
sequences, dps = 'GCGUCGCGUCGCUAUGC', ['.....((((....))))', '((((.((...)).))))', '(((......))).....']
#sequences, dps = 'CAGTGCTAGCTAGCTAGCTAGCTC', []
#dps, sequences = [], 'AGTCTAGGATTCGGCGTGGGTTAACACGCCGAATCCTAGACTACTTTG+AGTCTAGGATTCGGCGTGGGTTAA+TTAACCCACGCCGAATCCTAGACTCAAAGTAGTCTAGGATTCGGCGTG'
#dps, sequences = ['.....((((((........)))))).......', '................................'], 'CTAGTCGATCGACTGATCACGATCGTAGCTTA'
#dps, sequences = ['.....((((........))))......(((...)))', '(((((......)))))..(((......)))......'], 'GUUGGCCAGAACCAACGCUGGGUUGCACCAAUGUGG'
#dps, sequences = ['..(((((....)))))', '................'], 'AAAAAAAATTTTTTTT'
#sequences = 'AAAATTTT'
#sequences, dps = 'GUCGCGUCGCGUCGCUAUGCGAC', ['..(((...)))((((...)))).', '...((...))(((((...)))))', '..........(((((...)))))', '(((((((.((...)).)))))))','.....((((((......))))))']

unpaired = state(sequences)
#w = State('AUCUGGUCCCAAGUUUCCCCGAUCGUAGGAUCGGCCCAAAUUAACAGGGUCACUCAUCGGAGUGAGGAAACAUCCAGCCGGAGGUCCGGCUGGGGGACCAGU',kind='slow',model=mod)

state_with = lambda dp: unpaired.with_structure(dp)

pfs = engine.partitions(sequences, ordered=True)
sampler = complex_sampler(sequences, pfs, join_scale)

for i in sampler.weights: print(len(i[0]), i[1])
    
total_pf = sum(i[1] for i in sampler.weights)

#dps = ['((...))..........','(((......))).....','((.(.((...)).).))']

bstates = list(map(state_with, dps))

while len(bstates) < 3:
    w = state_with(sampler(engine, 1)[0])
    if not bstates or min(w ^ b for b in bstates) > 8:
        print(len(w.complexes.complex_indices), '%.2f' % w.energy, w.dp, sep='\t')
        bstates.append(w)

bstates = sorted(bstates)
basis = [y.pairs for y in bstates]

launches = sampler(engine, 1)

decay = 1e4
t = 2e+3
print('Simulation timescale: \t%e\nDecay timescale: \t%e' % (t, decay))

def get_one(launch):
    ham = hamming_integrator(hamming_observer(basis, 0), 1/decay, 0)
    stuff = state_with(launch).run(time=t, observers=[ham])
    return ham

speed = (state_with(launches[0]).run(time=1e-3, observers=[stopwatch(), hamming_observer(basis, 0)])[2].seconds / 1e-3)
print('ETA: %.2f minutes' % (speed * t * len(launches) / 6 / 60))


# In[ ]:


speed = state_with(launches[0]).run(time=1e-3, observers=[stopwatch()])[2].seconds / 1e-3
hams = thread_map(get_one, launches, 6)
ham = hams[0]
for h in hams[1:]: ham.add(h)


# In[ ]:


print('Total simulation time: %e' % ham.time)
O = np.where(ham.times / ham.time / ham.time > 1e-7)[0]
Overlap = symmetrized(ham.overlap[:, O][O] / ham.time)
#print('Overlap\n', np.diagonal(Overlap))

norms = np.sqrt(np.diagonal(Overlap))
#print('Norms', norms)

Gamma = symmetrized(ham.gamma[:, O][O] / ham.time / np.outer(norms, norms))
#print('Gamma eigs\n', eigh(Gamma)[0])

Grad = symmetrized(ham.gradient[:, O][O] / ham.time / np.outer(norms, norms))
#print('Gradient\n', Grad)

mu = ham.times[O] / norms / ham.time

pi0, G0, _ = projected_G(Gamma, mu)
pi1, G1, _ = first_order_G(Gamma, mu, Grad, 1/decay)


# In[ ]:


if False and count(sequences) < 2e4:
    all_states, pi, R = unpaired.rate_matrix(sparse=False)
    factor = abs(avg_trace(R))
    Z = (pi - inv(R/factor + pi)) / factor
    S = Z @ np.diag(1/pi)
    indices = [all_states.index(b) for b in bstates]
    Sm = S[:, indices][indices]
    print(H_from_S(Sm)[A, A], '\n')
    
_, H0, R0, S0, p0 = reduce_G(G0, mu)
_, H1, R1, S1, p1 = reduce_G(G1, mu)

table(H0[:5,:5], H1[:5,:5])


# In[ ]:


t2 = 5e0

def hits(w, pairs):
    obs = hitting_time_observer(pairs)
    w.run(time=t2, observers=[obs])
    return obs.samples, obs.numbers, obs

starts = bstates*8

print('ETA: %.2f minutes' % (speed * t2 * len(starts) / 6 / 60))


# In[ ]:


data = thread_map(lambda w: hits(w, basis), starts, 6)
samples = sum(d[0] for d in data)
numbers = sum(d[1] for d in data)
samples = samples / np.maximum(1, numbers)
Hs = samples - np.diag(np.diagonal(samples))


# In[ ]:


table(Hs[:7, :7])


# In[ ]:


find_dp = lambda x: next(i for i, p in enumerate(basis) if p.dp([len(p)])[1:-1] == x)
a, b = find_dp(dps[0]), find_dp(dps[1])
print(a, b)


# In[ ]:


print(H0[a, b], H0[b, a], sep='\t')
print(H1[a, b], H1[b, a], sep='\t\t')
print(Hs[a, b], Hs[b, a], sep='\t')

