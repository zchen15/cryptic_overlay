#include <rebind/Document.h>
#include <boost/exception/diagnostic_information.hpp>

namespace nupack {

/// Perform functions declared elsewhere one time; the order should reflect dependencies
void render_submodules(rebind::Document &doc) {
#   define NUPACK_TMP(F) void F(rebind::Document &); F(doc)
    NUPACK_TMP(render_constants);
    NUPACK_TMP(render_model);
    NUPACK_TMP(render_thermo);
    NUPACK_TMP(render_concentration);
    NUPACK_TMP(render_design);
#   undef NUPACK_TMP
}

/******************************************************************************************/

/// Top level module initializer running at library load time
bool write_document(rebind::Document &doc) {
    try {
        return render_submodules(doc), true;
    } catch (...) {
        std::cerr << "C++ import failed:\n" << boost::current_exception_diagnostic_information() << std::endl;
        throw;
    }
}

/// Static variable used to initialize document. It has no other use.
static bool boot_document = write_document(rebind::document());

/******************************************************************************************/

}
