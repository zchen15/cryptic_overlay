#pragma once
#include "Set.h"
#include "Map.h"

#include <boost/container/flat_set.hpp>
#include <boost/container/flat_map.hpp>

namespace nupack {

template <class ...Ts> using FlatMap = boost::container::flat_map<Ts...>;
NUPACK_EXTEND_VARIADIC(is_map, boost::container::flat_map, class);

template <class ...Ts> using FlatMultimap = boost::container::flat_multimap<Ts...>;
NUPACK_EXTEND_VARIADIC(is_map, boost::container::flat_multimap, class);

template <class ...Ts> using FlatSet = boost::container::flat_set<Ts...>;
NUPACK_EXTEND_VARIADIC(is_set, boost::container::flat_set, class);

template <class ...Ts> using FlatMultiset = boost::container::flat_multiset<Ts...>;
NUPACK_EXTEND_VARIADIC(is_set, boost::container::flat_multiset, class);

}
