#pragma once
#include "../Forward.h"
#include "../thermo/Cache.h"
#include "../thermo/Models.h"
#include "../execution/Local.h"

namespace nupack { namespace newdesign {

using thermo::Tensor;
using thermo::PFModel;
using ProbabilityMatrix = arma::sp_mat;

}}
