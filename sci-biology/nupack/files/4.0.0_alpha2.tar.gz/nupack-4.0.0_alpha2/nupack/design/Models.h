#pragma once

#include "TypeImports.h"
#include "../thermo/Models.h"
#include "../model/Model.h"
#include "../reflect/Dump.h"
#include <shared_mutex>

namespace nupack { namespace newdesign {
using thermo::PFModel;

template <class D>
using DesignCache = thermo::Cache<3, D, real32, real64, overflow<real32>, overflow<real64>>;

using DesignCacheVariant = Variant<DesignCache<NoDangles>, DesignCache<MinDangles>, DesignCache<AllDangles>, DesignCache<CoaxDangles>>;


/**
 * @brief A way of storing the relevant thermodynamic parameters necessary to
 * specify a model for use in design. Used with ModelMap to obtain the actual
 * model in cached manner.
 *
 */
struct ModelKey : MemberOrdered {
    ParameterFile parameters;
    string dangle_type;
    ModelConditions conditions;
    NUPACK_REFLECT(ModelKey, parameters, dangle_type, conditions);

    ModelKey(string material="RNA",
            string dangle_type="none",
            real temperature=DefaultTemperature,
            real sodium=1.0,
            real magnesium=0.0,
            string dG_file={},
            string dH_file={}
            ) :
            parameters(material, dG_file, dH_file), dangle_type(dangle_type), conditions{temperature, sodium, magnesium} {}

    template <class T>
    operator PFModel<T>() const {return PFModel<T>(dangle_type, true, parameters, conditions);}

    auto temperature() const {return conditions.temperature;}
    auto sodium() const {return conditions.na_molarity;}
    auto magnesium() const {return conditions.mg_molarity;}
};

inline void render(Document &doc, Type<ModelKey> t) {
    doc.type(t, "design.components.ModelSettings");
    // doc.method(t, "new", rebind::construct<string, string, real, real, real, string, string>(t));
    doc.method<0>(t, "new", rebind::construct<string, string, real, real, real, string, string>(t));

    doc.method(t, "{}", dumpable(t));
    render_public(doc, t);
}


/**
 * @brief interface adapter that "doubles" the length of a set of models to
 * support non-overflow and overflow versions of the thermo code and allow
 * fallback while still only using 2 underlying models
 *
 * @tparam T type of paired 32- and 64-bit models
 * @param t the paired models
 * @return tuple of references to the underlying models in the correct doubled
 * order
 */
template <class T>
auto double_models(T &&t) {
    return std::tie(std::get<0>(t), std::get<1>(t), std::get<0>(t), std::get<1>(t));
};


using ModelsTuple = std::tuple<PFModel<real32>, PFModel<real64>>;

struct CopyableMutex {
    CopyableMutex() = default;
    CopyableMutex(CopyableMutex const &) : CopyableMutex() {};
    CopyableMutex(CopyableMutex &&) : CopyableMutex() {};
    CopyableMutex & operator=(CopyableMutex const &) { return *this; };
    CopyableMutex & operator=(CopyableMutex &&) { return *this; };

    std::shared_mutex mutable mut;
};

struct ThermoEnviron {
    ThermoEnviron() = default;
    /* create cache of correct type immediately when environment is made */
    ThermoEnviron(ModelsTuple mods) : models(mods) {initialize_cache(0);};

    void initialize_cache(std::size_t ram);
    auto doubled() const { return double_models(models); }
    void add_pfunc(NickSequence const &s, real log_pfunc);
    Variant<bool, real> get_pfunc(NickSequence const &s) const;
    void clear_cache();

    ModelsTuple models;
    DesignCacheVariant cache;
    std::map<NickSequence, real> log_pfuncs;
    CopyableMutex mut;

    NUPACK_REFLECT(ThermoEnviron, models, cache, log_pfuncs);
};


/**
 * @brief Maintains cache of all models needed during design to avoid constantly
 * recreating the model. Furthermore, keeps 32-bit and 64-bit versions of the
 * same model together to support model fallback operations in a relatively
 * seamless manner when calling thermo code.
 *
 */
class ModelMap : MemberOrdered {
    mutable std::map<ModelKey, ThermoEnviron> mod_map;

public:
    NUPACK_REFLECT(ModelMap, mod_map);
    ModelMap() = default;

    /**
     * @brief Create new model if key has not been seen before and return
     * pointer to model.
     *
     * @param key specification of the requested model
     * @return reference to the requested pair of models
     */
    ThermoEnviron & get(ModelKey const & key) const;
    auto const & get_model(ModelKey const & key) const {
        return get(key).models;
    }

    void create_caches(std::size_t ram);
    void clear_caches();
    auto size() const {return len(mod_map);}
    std::size_t ram() const;
};



}}
