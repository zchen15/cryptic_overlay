#include "Structure.h"
#include "../reflect/Dump.h"

#include <regex>

namespace nupack { namespace newdesign {

/**
 * @brief Convert a hybrid dpp/dpp-rle structure specification string into a
 *     pure dpp string
 * @details Takes the input string, which is either in dot-parens-plus (dpp)
 *     (e.g. (((+....))) ), dot-parens-plus run-length-encoded (dpp-rle) (e.g.
 *     (3+.4)3 ), or any hybrid of the two (e.g. ((2+...2)3 ), and converts
 *     this string into the pure dpp representation. Throws if the input
 *     string is not a hybrid (including pure dpp or dpp-rle).
 *
 * @param s the hybrid string to convert to pure dpp representation
 * @return a pure dpp representation of the structure implied by s.
 */
string Structure::parse_struc(string const &s) {
    /* Return simple dpp structure */
    static std::regex pure_dpp("[().+]*");
    if (std::regex_match(s, pure_dpp)) return s;

    /* If not a simple dpp structure, make sure it's a valid hybrid */
    static std::regex rle_dpp_whole("([().][0-9]*|[+])+");
    if (!std::regex_match(s, rle_dpp_whole)) throw std::invalid_argument(s + " is not in dpp or rle_dpp format");

    static std::regex rle_dpp_component("([().])([0-9]*)|([+])");
    auto beg = std::sregex_iterator(s.begin(), s.end(), rle_dpp_component);
    auto end = std::sregex_iterator();

    std::stringstream ss;
    for (auto i = beg; i != end; ++i) {
        auto m = indirect_view(view(i->begin(), i->end()), [](auto const &j) {return j.str();});
        int repeats = m[2].empty() ? 1 : std::stoi(m[2]);
        string cur = m[3].empty() ? m[1] : m[3];
        for (auto i : range(repeats)) ss << cur;
    }

    return ss.str();
}


/**
 * @brief Return a minimal length run-length enconding of the dot-parens-plus structure
 * @details For single character runs, e.g. the unpaired base in (((+.))), the
 *     number "1" will not be included in the output string as it is
 *     redundant.
 * @return a minimal length dpp-rle string representation of the Structure.
 */
string Structure::dp_rle() const {
    auto s = dp();
    static std::regex dp_run("\\(+|\\.+|\\)+|\\+");

    std::stringstream ss;
    auto end = std::sregex_iterator();
    for (auto i = std::sregex_iterator(s.begin(), s.end(), dp_run); i != end; ++i) {
        auto run = i->str();
        auto n = len(run);
        if (n == 1) ss << run;
        else ss << run[0] << std::to_string(n);
    }

    return ss.str();
}


void render(Document &doc, Type<Structure> t) {
    doc.type(t, "design.components.Structure");
    doc.method(t, "new", rebind::construct<string>(t));
    doc.method(t, "dp",     &Structure::dp);
    doc.method(t, "dp_rle", &Structure::dp_rle);

    doc.method(t, "{}", dumpable(t));
    render_public(doc, t);
}

}}
