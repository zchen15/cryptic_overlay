/** \file IO.cc
 * @brief Defines IO functions and stream operators for many basic objects, and parameter read-in
 */

#include "PairList.h"
#include "Sequence.h"
#include "IO.h"
#include "LRU.h"

#include "../reflect/Print.h"
#include "../iteration/Patterns.h"
#include "../algorithms/Utility.h"

#include <stack>
#include <boost/functional/hash.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/predicate.hpp>


namespace nupack {

constexpr std::array<char, 16> Base::names;

constexpr std::array<std::array<bool, 4>, 16> Base::masks;

constexpr Base::from_index_t const Base::from_index;

std::array<std::discrete_distribution<BaseIndex>, 15> const Base::distributions = {{
    discrete_distribution<BaseIndex>(Base::masks[0]),
    discrete_distribution<BaseIndex>(Base::masks[1]),
    discrete_distribution<BaseIndex>(Base::masks[2]),
    discrete_distribution<BaseIndex>(Base::masks[3]),
    discrete_distribution<BaseIndex>(Base::masks[4]),
    discrete_distribution<BaseIndex>(Base::masks[5]),
    discrete_distribution<BaseIndex>(Base::masks[6]),
    discrete_distribution<BaseIndex>(Base::masks[7]),
    discrete_distribution<BaseIndex>(Base::masks[8]),
    discrete_distribution<BaseIndex>(Base::masks[9]),
    discrete_distribution<BaseIndex>(Base::masks[10]),
    discrete_distribution<BaseIndex>(Base::masks[11]),
    discrete_distribution<BaseIndex>(Base::masks[12]),
    discrete_distribution<BaseIndex>(Base::masks[13]),
    discrete_distribution<BaseIndex>(Base::masks[14])
}};

void render(Document &doc, Type<PairList> t) {
    doc.type(t, "core.PairList");
    render_public(doc, t);
    static_assert(has_lt<PairList>);
    render_comparisons(doc, t);
    doc.method(t, "new", rebind::construct<std::string_view>(t));
    doc.method(t, "new", rebind::construct<typename PairList::data_type>(t));
    doc.method(t, "^", [](PairList const &v, PairList const &w) {return v ^ w;});
    doc.method(t, "dp", &PairList::dp<pair_data_type const &>);
}

/******************************************************************************************/

auto sequence_separator() {return boost::is_any_of(",+ \n\t");}

namespace io {

bool iequals(char const *s, char const *t) {return boost::iequals(s, t);}
bool iequals(std::string const &s, std::string const &t) {return boost::iequals(s, t);}

std::ostream *default_out = &std::cout;
std::mutex default_out_guard;

bool is_on_next_line(std::istream &is, string const &s) {
    string line;
    auto cur = is.tellg();
    if (!is.good()) return false;
    std::getline(is, line);
    bool ret = (line.find(s) != line.npos);
    is.seekg(cur);
    return ret;
}

/******************************************************************************************/

std::istream & go_to_number(std::istream &is) {
    auto cur = is.tellg();
    string line;
    while (std::getline(is, line)) {
        auto number_pos = line.find_first_of("+-.1234567890");
        if (number_pos != line.npos)
            if (line.find_first_not_of(" \n\r\t") == number_pos) return is.seekg(cur);
        cur = is.tellg();
    }
    throw std::runtime_error("Reached end of file while looking for numbers");
}

/******************************************************************************************/

std::istream & goto_line_after(std::istream &is, string const &s){
    NUPACK_ASSERT(is.good());
    string line;
    while (std::getline(is, line) && is.good()) {
        if (line.find(s) != line.npos) return is;
    }
    throw std::runtime_error("Reached end of file while looking for: " + s);
}

/******************************************************************************************/

std::istream & skip_comments(std::istream &is, string const &comment_start) {
    NUPACK_ASSERT(is.good());
    string line;
    while (is_on_next_line(is, comment_start)) {
        if (!is.good()) throw std::runtime_error("Reached end of file while skipping comments");
        std::getline(is, line);
    }
    return is;
}

/******************************************************************************************/

string peek(std::istream &is){
    string line;
    auto cur = is.tellg();
    std::getline(is, line);
    is.seekg(cur);
    return line;
}

/******************************************************************************************/

std::pair<std::size_t, bool> repeat_char_length(std::string_view s) noexcept {
    std::pair<std::size_t, bool> out{0u, false};
    auto const sep = sequence_separator();
    for (auto b=s.begin(), e = s.end(); b != e;) {
        if (sep(*b)) ++b;
        else if (std::isdigit(*b)) {
            out.first += std::strtoul(b, const_cast<char **>(&b), 10) - 1u;
            out.second = true;
        } else {++out.first; ++b;}
    }
    return out;
}

/******************************************************************************************/

/// Convert dot-parens to pair array
void to_pairs(iseq *v, iseq const n, char const *dp) {
    auto const sep = sequence_separator();
    iseq i = 0, s = n - 1;
    // Number of times to repeat a character, 1 if not given
    auto repeat = [](auto &c) {
        auto d = std::strtoul(++c, const_cast<char **>(&c), 10);
        return d ? d : 1u;
    };
    char const *c = dp;
    while (*c) {
        if (*c == '(') {
            for (auto d = repeat(c); d--; ++i) v[s--] = i; // push on stack
        } else if (*c == ')') {
            auto d = repeat(c);
            if (s + d >= n) NUPACK_ERROR("unmatched ) parenthesis", dp, i);
            for (; d--; ++i) {
                v[i] = v[++s]; // pop off stack
                v[v[i]] = i;
            }
        } else if (*c == '.') {
            for (auto d = repeat(c); d--; ++i) v[i] = i;
        } else if (sep(*c)) {
            ++c;
        } else {
            auto index = c - dp;
            NUPACK_ERROR("bad dot-parens character", dp, index, *c, int(*c));
        }
    };
    if (s != n - 1) NUPACK_ERROR("unmatched ( parenthesis");
    if (i != n) NUPACK_ERROR("dot-parens-plus parsing failed");
}

}

/******************************************************************************************/

Sequence::Sequence(std::string_view letters) {
    NUPACK_ASSERT(!letters.empty(), "sequence should contain one or more nucleotides");
    auto n = io::repeat_char_length(letters).first;
    base_type::resize(n);
    auto e = io::repeat_char(base_type::begin(), letters);
    if (e != base_type::end())
        NUPACK_ERROR("invalid nucleic acid sequence", letters);
}

/******************************************************************************************/

vec<string> split_sequence_string(string s) {
    vec<string> strs;
    boost::trim_if(s, sequence_separator());
    boost::split(strs, s, sequence_separator(), boost::token_compress_on);
    return strs;
}

PairList PairList::with_null_bases(small_vec<iseq> const &strand_lengths) const {
    constexpr auto null = std::numeric_limits<iseq>::max();
    data_type out(len(contents) + 2 * len(strand_lengths), null);
    // Copy in old contents, skip null bases
    auto d = contents.begin();
    auto o = out.begin() + 1;
    for (auto l : strand_lengths) {
        std::copy_n(d, l, o);
        d += l;
        o += l + 2;
    }
    // Offset values
    iseq offset = 2 * len(strand_lengths) - 1, end = len(contents);
    for (auto l : reversed(strand_lengths)) {
        auto next_end = end - l;
        for (auto &i : out) if (i >= next_end && i < end) i += offset;
        end = next_end;
        offset -= 2;
    }
    // Fix up null bases
    izip(out, [](auto i, auto &j) {if (j == null) j = i;});
    if (!Release) izip(out, [&](auto i, auto &j) {NUPACK_REQUIRE(out[j], ==, i, contents, out);});
    return PairList{std::move(out)};
}

void render(Document &doc, Type<Sequence> t) {doc.type(t, "core.Sequence");}
void render(Document &doc, Type<Base> t) {doc.type(t, "core.Base");}

/******************************************************************************************/

std::optional<Sequence> request(Type<Sequence>, rebind::Variable const &r, rebind::Dispatch &msg) {
    if (auto p = r.request<std::string_view>()) return Sequence(*p);
    if (auto p = r.request<std::string>()) return Sequence(*p);
    return msg.error("not convertible to Sequence");
}

std::optional<Base> request(Type<Base>, rebind::Variable const &r, rebind::Dispatch &msg) {
    if (auto p = r.request<char>()) return Base(*p);
    if (auto p = r.request<std::string_view>()) if (p->size() == 1) return Base((*p)[0]);
    if (auto p = r.request<std::string>()) if (p->size() == 1) return Base((*p)[0]);
    return msg.error("not convertible to Base");
}

/******************************************************************************************/

void render(Document &doc, Type<NickSequence> t) {
    doc.type(t, "core.NickSequence");
    doc.method(t, "sequences", [] (NickSequence const &x) {return x.sequences();});
}

auto response(std::type_index, NickSequence const &v) {return v.sequences();}

std::optional<NickSequence> request(Type<NickSequence> t, rebind::Variable const &v, rebind::Dispatch &msg) {
    if (auto p = v.request<SequenceList>()) return NickSequence(*p);
    return msg.error("Cannot convert to NickSequence", t);
}

void render(Document &doc, Type<MemoryLimit> t) {
    doc.type(t, "core.MemoryLimit");
    render_public(doc, t);
}

}

/******************************************************************************************/

namespace std {
    size_t hash<nupack::Sequence>::operator()(nupack::Sequence const &s) const {
        return nupack::range_hash(nupack::ptr_view(&(s.data()->value), s.size()));
    }

    size_t hash<nupack::NickSequence>::operator()(nupack::NickSequence const &m) const {
        return nupack::hash_of(m.catenated, m.positions);
    }
}

