/** \file Fenwick.h
 * @brief Contains Fenwick class, implementing a Fenwick/binary index tree
 * @todo Fix test error for fenwick.find
 */

#pragma once
#include "../standard/Vec.h"
#include "../common/Error.h"
#include "../common/Random.h"
#include "../algorithms/Utility.h"

namespace nupack {

/******************************************************************************************/

// make the rightmost 1 into a 0
template <class T> inline T pop_one(T t) {return t & plus_one(t);}
// make the rightmost 0 into a 1
template <class T> inline T push_one(T t) {return t | plus_one(t);}

/******************************************************************************************/

template <class T, class V=vec<T>>
struct Fenwick : MemberOrdered {
    using is_fenwick = True;
    using container_type = V;
    using value_type = T;
    using size_type = size_type_of<container_type>;
    using difference_type = difference_type_of<container_type>;
    using iterator = iterator_of<container_type>;
    using const_iterator = const_iterator_of<container_type>;

private:
    /// Manually keep track of sum for easy lookup
    T total=T(::nupack::zero);

    /// Increments value of i-th element by delta. O(log(n))
    void increment_tree(size_type i, T delta) {
        for (; i < len(tree); i = push_one(i)) tree[i] += delta;
    };

    /// Redo position in a tree, assuming it has been set to values[p]
    /// and that tree[:p] has been correctly set (O(1) amortized)
    /// note - must be signed for now since i goes negative
    void extend_to(difference_type const p) {
        for (auto i = minus_one(p); i >= pop_one(p); i = minus_one(pop_one(i))) tree[p] += tree[i];
    }

public:

    NUPACK_REFLECT(Fenwick, tree, values, total);

    /// The actual Fenwick tree values
    container_type tree;
    /// For convenience in updating, hold the marginal values as well
    container_type values;

    Fenwick() = default;
    /// Initialize tree from a vector of values
    Fenwick(container_type v) : values(std::move(v)) {redo_tree();}

    /************************************************************************************/

    /// Bracket operator to marginal values
    value_type operator[](size_type i) const {return values[i];}
    /// First value
    value_type front() const {return values.front();}
    /// Last value
    value_type back() const {return values.back();}
    /// Length of tree
    size_type size() const {return values.size();}
    /// Begin iterator
    iterator begin() {return values.begin();}
    /// Begin const_iterator
    const_iterator begin() const {return values.cbegin();}
    /// End iterator
    iterator end() {return values.end();}
    /// End const_iterator
    const_iterator end() const {return values.cend();}
    /// Resize values and tree
    void resize(size_type s) {values.resize(s, T(::nupack::zero)); tree.resize(s, T(::nupack::zero));}
    /// Reserve space for values and tree
    void reserve(size_type s) {values.reserve(s); tree.reserve(s);}

    /************************************************************************************/

    /// Add to the value of a position in the tree
    void increment(size_type i, T const &t) {
        values[i] += t;
        total += t;
        increment_tree(i, t);
    }
    /// Update the value of a position in the tree
    void update(size_type i, T const &t) {
        if (!Release) NUPACK_REQUIRE(i, <, values.size());
        increment_tree(i, t - values[i]);
        total += t - values[i]; values[i] = t;
    }
    /// Zero the value of a position in the tree
    void zero(size_type i) {update(i, T(::nupack::zero));}
    /// Swap two positions in the tree
    void swap_pos(size_type i, size_type j) {
        auto delta = values[j] - values[i];
        increment_tree(i, delta); increment_tree(j, -delta);
        swap(values[i], values[j]);
    }

    /************************************************************************************/

    /// Redo the whole tree from the values. O(n)
    void redo_tree() {
        tree.assign(values.begin(), values.end());
        auto const n = len(tree);
        for (size_type i = 0u; i != n; ++i) extend_to(i);
        total = sum(values.size());
    };

    /************************************************************************************/

    /// Access sum O(1)
    friend T sum(Fenwick const &f) {return f.total;}
    /// Sum of all elements of "values" with index < i
    T sum(size_type i) const {
        T ret{::nupack::zero};
        while (i--) {ret += tree[i]; i = pop_one(i);}
        return ret;
    }
    /// Construct all prefix sums - for testing (n log n)
    auto sums() const -> decltype(values) {
        decltype(values) sums;
        auto const n = len(values);
        for (size_type i = 0u; i != n; ++i) sums.emplace_back(sum(plus_one(i)));
        return sums;
    }

    /************************************************************************************/

    /// Assign values
    template <class... Args>
    void assign(Args&&... args) {values.assign(fw<Args>(args)...); redo_tree();}
    /// Add a value
    template <class... Args>
    void emplace_back(Args&&... args) {
        auto const p = values.size();
        values.emplace_back(T(fw<Args>(args)...)); total += values[p];
        tree.emplace_back(values[p]); extend_to(p);
    }
    /// Erase last value
    void pop_back() {total -= values.back(); values.pop_back(); tree.pop_back();}
    /// Append a range to the back
    template <class It> void extend(It b, It e) {
        values.insert(values.end(), b, e);
        tree.insert(tree.end(), b, e);
        for (int i = len(tree) - e + b; i != len(tree); ++i)
            {extend_to(i); total += values[i];}
    }
    /// Append a range to the back
    template <class V2> void extend(V2 const &v) {extend(v.begin(), v.end());}
    /// Unordered erase by swapping back and position, then popping the back
    void swap_erase(size_type i) {swap_pos(i, minus_one(values.size())); pop_back();}

    template <class ...Ts> void erase(Ts ...ts) {NUPACK_ERROR("not implemented yet");}

    template <class ...Ts> void insert(Ts ...ts) {NUPACK_ERROR("not implemented yet");}

    /******************************************************************************************/

    /// Search for "t" in the cumulative sum function for this tree
    template <class Value, class Unary_Op=Identity, NUPACK_IF(can_convert<decltype(declref<Unary_Op>()(declref<value_type>()) < declref<Value>()), bool>)>
    auto find(Value t, Unary_Op U=Identity()) const {
        if (!Release) NUPACK_REQUIRE(t, <=, U(total));
        uint ret = 0, mask = next_power_of_two(len(tree));
        auto const isize = static_cast<int>(size());
        while (mask) {
            int cur = ret + (mask >>= 1);
            if (cur >= isize) continue;
            if (U(tree[cur]) < t) {ret = cur + 1; t -= U(tree[cur]);}
        }
        if (ret == size() && std::abs(t / U(total)) < 1e-7) {t = Value(::nupack::zero); --ret;}
        if (!Release) NUPACK_REQUIRE(ret, <, size());
        return std::make_pair(ret, t);
    }

    template <class RNG=decltype(StaticRNG)>
    auto sample(RNG &rng, True replace) const {return find(rng() * total).first;}

    template <class RNG=decltype(StaticRNG)>
    auto sample(RNG &rng, False replace) {auto i = sample(rng, True()); zero(i); return i;}

    /******************************************************************************************/
};

/******************************************************************************************/

NUPACK_DETECT(is_fenwick, void_if<T::is_fenwick::value>);

/******************************************************************************************/

/// Search for "t" in the cumulative sum function C(f1) + s * C(f2)
template <class Matrix>
auto find2(Fenwick<Matrix> const &f1, Fenwick<Matrix> const &f2,
                           uint i, uint j, real t, real const &scale) {
    if (!Release) NUPACK_REQUIRE(t, <=, sum(f1)(i, j) * scale - sum(f2)(i, j));
    uint ret = 0, mask = next_power_of_two(len(f1));
    while (mask) {
        int cur = ret + (mask >>= 1);
        if (cur >= len(f1)) continue;
        auto threshold = f1.tree[cur](i, j) * scale - f2.tree[cur](i, j);
        if (t > threshold) {ret = cur + 1; t -= threshold;}
    }
    return std::make_pair(ret, t);
}

/******************************************************************************************/

/// Search for "t" in the cumulative sum function C(f1) + s * C(f2)
template <class Matrix>
auto find1(Fenwick<Matrix> const &f, uint i, uint j, real t) {
    uint ret = 0, mask = next_power_of_two(len(f));
    while (mask) {
        int cur = ret + (mask >>= 1);
        if (cur >= len(f)) continue;
        auto threshold = f.tree[cur](i, j);
        if (t > threshold) {ret = cur + 1; t -= threshold;}
    }
    return std::make_pair(ret, t);
}

/******************************************************************************************/

template <class F, NUPACK_IF(is_fenwick<F>)>
void render(Document &doc, Type<F> t) {
    doc.type(t, "core.Fenwick");
    doc.method(t, "sum", &F::sum);
};


}
