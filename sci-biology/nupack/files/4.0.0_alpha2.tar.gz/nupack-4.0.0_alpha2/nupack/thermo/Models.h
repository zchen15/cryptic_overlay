/**
 * @brief User level aliases for common CachedModels to use in dynamic programs
 *
 * @file Models.h
 * @author Mark Fornace
 * @date 2018-05-31
 */
#pragma once
#include "CachedModel.h"
#include "../Forward.h"

namespace nupack { namespace thermo {

template <class T=real, class D=DangleType const &, class ...Ts>
auto pf_model(D &&d, Ts &&...ts) {return PFModel<T>(fw<D>(d), fw<Ts>(ts)...);}

template <class T=real>
auto pf_model() {return PFModel<T>(MinDangles());}

template <class T=real, class D=DangleType const &, class ...Ts>
auto mfe_model(D &&d, Ts &&...ts) {return MFEModel<T>(fw<D>(d), fw<Ts>(ts)...);}

template <class T=real>
auto mfe_model() {return MFEModel<T>(MinDangles());}

}}
