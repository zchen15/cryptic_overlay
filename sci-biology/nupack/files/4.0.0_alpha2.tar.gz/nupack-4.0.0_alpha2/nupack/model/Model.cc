#include "Model.h"
#include "ParameterSet.h"
#include "../common/Error.h"
#include "../common/Runtime.h"
#include "../state/State.h"
#include <fstream>

namespace nupack {

/******************************************************************************************/

ParameterFile::ParameterFile(string mat, string g, string h) : material(std::move(mat)), dG(std::move(g)), dH(std::move(h)) {
    if (material != "RNA" && material != "DNA") NUPACK_ERROR("invalid nucleic acid material", material);
    if (dG.empty() && dH.empty() && material == "RNA") {dG = "rna1995.dG"; dH = "rna1995.dH";}
    if (dG.empty() && dH.empty() && material == "DNA") {dG = "dna1998.dG"; dH = "dna1998.dH";}
}

std::ifstream ParameterFile::open(string kind) const {
    if (kind != "dG" && kind != "dH") NUPACK_ERROR("parameter kind is invalid", kind);
    string name = (kind == "dG") ? dG : dH, path = name;
    if (name.empty()) NUPACK_ERROR("parameter file was not entered and could not be found", kind);
    if (!path_exists(path)) {
        auto s = get_env("NUPACKHOME");
        if (!s.empty()) path = path_join(path_join(s, "parameters"), name);
    }
    if (!path_exists(path)) path = path_join(DefaultParametersPath, name);

    std::ifstream file(path);
    if (!file.good()) NUPACK_ERROR("failed to open parameter file ", path);
    return file;
}

#define NUPACK_TMP(OP) bool operator OP(ParameterMetadata const &t, ParameterMetadata const &u) {return members_of(t) OP members_of(u);}
    NUPACK_TMP(==); NUPACK_TMP(!=); NUPACK_TMP(<); NUPACK_TMP(>); NUPACK_TMP(<=); NUPACK_TMP(>=);
#undef NUPACK_TMP

std::array<char const *, 4> DangleNames = {"none", "min", "all", "coax"};

DangleType as_dangle_type(string const &s) {
    if (s == DangleNames[0]) return NoDangles();
    if (s == DangleNames[1]) return MinDangles();
    if (s == DangleNames[2]) return AllDangles();
    if (s == DangleNames[3]) return CoaxDangles();
    NUPACK_ERROR("invalid dangle type", s);
}

template ParameterData<float>::ParameterData(std::istream &&);

template ParameterData<double>::ParameterData(std::istream &&);

/******************************************************************************************/

void render(Document &doc, Type<ParameterFile> t) {
    doc.type(t, "model.ParameterFile");
    doc.method(t, "new", rebind::construct<string, string, string>(t));
    NUPACK_PUBLIC(ParameterFile, material, dG, dH);
}

void render(Document &doc, Type<ModelConditions> t) {
    doc.type(t, "model.Conditions");
    doc.method(t, "new", rebind::construct<>(t));
    NUPACK_PUBLIC(ModelConditions, temperature, na_molarity, mg_molarity);
}

void render(Document &doc, Type<ParameterMetadata> t) {
    doc.type(t, "model.ParameterMetadata");
    NUPACK_PUBLIC(ParameterMetadata, temperature, loop_bias, kind, file);
}

void render(Document &doc, Type<Pairable> t) {
    doc.type(t, "model.Pairable");
    doc.method(t, "()", &Pairable::can_pair);
}

/******************************************************************************************/

void render(Document &doc, Type<Kawasaki> t) {
    doc.type(t, "model.Kawasaki");
    render_public(doc, t);
    doc.method(t, "unimolecular_rate",   &Kawasaki::unimolecular_rate);
    doc.method(t, "bimolecular_rate",    &Kawasaki::bimolecular_rate);
    doc.method(t, "nondimensional_rate", &Kawasaki::nondimensional_rate);
}

/******************************************************************************************/

void render(Document &doc, Type<ParameterData<real32>> t) {render(doc, t, 0);}
void render(Document &doc, Type<ParameterData<real64>> t) {render(doc, t, 0);}
void render(Document &doc, Type<ParameterSet<real32>> t) {render(doc, t, 0);}
void render(Document &doc, Type<ParameterSet<real64>> t) {render(doc, t, 0);}
void render(Document &doc, Type<Model<real64>> t) {render(doc, t, 0);}
void render(Document &doc, Type<Model<real32>> t) {render(doc, t, 0);}

void render_model(Document &doc) {
    doc.render<ParameterSet<real64>>();
    doc.render<Model<real64>>();
    doc.render<ParameterSet<real32>>();
    doc.render<Model<real32>>();
    doc.render<Kawasaki>();

    doc.function("model.structure_energy", &structure_energy<SequenceList, Model<real64>>);
    doc.function("model.structure_energy", &structure_energy<SequenceList, Model<real32>>);
}

/******************************************************************************************/

}

