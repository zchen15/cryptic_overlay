#pragma once
#include <cmath>

namespace nupack {

template <class V = vec<int>>
vec<vec<int>> get_masks(V const & lengths) {
    vec<int> stackable;
    izip(lengths, [&stackable](auto i, auto const & l) {if (l == 2) stackable.emplace_back(i);});

    int num = std::pow(2, len(stackable));
    vec<vec<int>> masks(num);
    // https://stackoverflow.com/questions/2686542/converting-integer-to-a-bit-representation
    // find all unconstrained stackings
    for (auto x : range(num)) {
        auto & ret = masks[x];
        while (x) {
            ret.push_back(int(x & 1));
            x >>= 1;
        }
        ret.resize(len(stackable), 0);
    }

    // spread out maps onto Full length vector.
    auto full_masks = vmap(masks, [&](auto const & mask) {
        vec<int> full_mask(len(lengths));
        zip(mask, stackable, [&](auto m, auto s) {if (m) full_mask[s] = 1;});
        return full_mask;
    });

    return full_masks;
}

// remove stack configurations with consecutive stacks => conflicting stacks on a pair.
template <class V = vec<vec<int>>>
void filter_masks(V & masks) {
    erase_if(masks, [](auto const & c) {
        bool check = false;
        zip(view(c, 0, len(c) - 1), view(c, 1, len(c)), [&](auto l, auto r) {
            if (l && r) check = true;
        });
        return check;
    });
}

/******************************************************************************************/
/*              Full enumerated partition function with optional counting                 */
/******************************************************************************************/

// compute the number of dangle configurations for each coaxial stacking state
template <class V = vec<vec<int>>, class S, class M>
real mask_pf(V const & masks, S seqs, M const & m, bool circ = true, real left = 1,
             real right = 1) {

    auto lengths = vmap(seqs, len);
    if (!circ) lengths = vmap(view(seqs, 1, len(seqs) - 1), len);

    if (circ) {
        seqs.insert(begin_of(seqs), copy(back(seqs)));
        seqs.push_back(seqs[1]);
    }

    auto factors = vmap(masks, [&](auto mask) {

        // multiply in outermost dangles if outermost stacks are inactive
        // logic reduces to outside = 1 for multiloops
        auto outside = mask.front() ? 1 : left;
        outside *= mask.back() ? 1 : right;

        // default for exterior loop
        auto first = 0, last = 0;
        // circular; multiloop
        if (circ) {first = mask.front(); last = mask.back();}
        // for creating shifted views
        mask.insert(begin_of(mask), last);
        mask.insert(end_of(mask), first);

        real boltz_product = 1;
        zip(range(len(lengths)).shift(1), lengths, view(mask, 0, len(mask) - 2), view(mask, 2, len(mask)),
            view(mask, 1, len(mask) - 1), [&](auto i, auto length, auto l, auto r, auto c) {
            if (c) {
                boltz_product *= m.boltz(m.coaxial_stack_energy(back(seqs[i - 1]), front(seqs[i]),
                                                           back(seqs[i]), front(seqs[i + 1])));
            }
            if (length >= 3) {
                auto left = [&]{return m.boltz(m.dG().dangle5[back(seqs[i-1])] [front(seqs[i])] [front(seqs[i], 1)]);};
                auto right = [&]{return m.boltz(m.dG().dangle3[back(seqs[i], -1)] [back(seqs[i])] [front(seqs[i+1])]);};
                if (!l && r) {
                    boltz_product *= (1 + left());
                }
                else if (l && !r) {
                    boltz_product *= (1 + right());
                }
                else if (l + r == 0) {
                    if (length == 3) {
                        boltz_product *= (1 + left() + right());
                    }
                    else if (length > 3) {
                        boltz_product *= (1 + left()) * (1 + right());
                    }
                }
            }
        });
        return outside * boltz_product;
    });
    return sum(factors);
}

/******************************************************************************************/

template <class V, class M>
real exterior_loop_stacking_states(V seqs, M const & m) {
    if (len(seqs) == 1) return 1;

    // pre-underscore first; post-underscore last.
    std::rotate(begin_of(seqs), max_element(seqs), end_of(seqs));

    real left = 1, right = 1;

    // dangle states for 5' end of loop
    auto first = seqs.front();
    if (len(first) > 2) {
        auto & second = seqs[1];
        left = 1 + m.boltz(m.dG().dangle3[back(first, -1)] [back(first)] [second[0]]);
    }
    // dangle states for 3' end of loop
    auto last = seqs.back();
    if (len(last) > 2) {
        auto & penultimate = back(seqs, -1);
        right = 1 + m.boltz(m.dG().dangle5[back(penultimate)] [last[0]] [last[1]]);
    }

    if (len(seqs) == 2) { // only dangles
        return left * right;
    } else if (len(seqs) > 2) {
        auto mask_seqs = view(seqs, 1, len(seqs) - 1);
        auto lengths = vmap(mask_seqs, len);
        auto masks = get_masks(lengths);
        filter_masks(masks);
        return mask_pf(masks, seqs, m, false, left, right);
    }
    return 1;
}

/******************************************************************************************/

template <class V, class M>
real multiloop_stacking_states(V const &seqs, M const & m) {
    auto lengths = vmap(seqs, len);
    auto masks = get_masks(lengths);

    // so that first and last stacks are consecutive for filtering
    for (auto & mask : masks) mask.push_back(mask[0]);
    filter_masks(masks);
    // remove auxiliary repeated first base
    for (auto & mask : masks) mask.pop_back();

    return mask_pf(masks, seqs, m);
}

/******************************************************************************************/

template <class O, class M>
real pf_loop_stacking_states(O const & o, M const & m) {
    if (!o.exterior() && len(o.seqs) < 3) { // hairpin, interior, bulge, stack
        return m.boltz(m.loop_energy(o.sequences(), o.nick()));
    } else if (o.exterior()) {
        return exterior_loop_stacking_states(o.sequences(), m);
    } else {
        return m.boltz(m.linear_multi_energy(o.sequences())) * multiloop_stacking_states(o.sequences(), m);
    }
}

/******************************************************************************************/

}
