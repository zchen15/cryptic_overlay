#pragma once

#include "ModelVariants.h"
#include "ParameterSet.h"
#include "../algorithms/Utility.h"
#include "../algorithms/Numeric.h"
#include "../standard/Ptr.h"

#include "CoaxialModel.h"

namespace nupack {

/******************************************************************************************/

/// Condition descriptors, these are fine as reals since they aren't often used
struct ModelConditions {
    real temperature = DefaultTemperature;
    real na_molarity = 1.0;
    real mg_molarity = 0.0;

    NUPACK_REFLECT(ModelConditions, temperature, na_molarity, mg_molarity);
    using is_member_ordered = True;
};

void render(Document &doc, Type<ModelConditions>);

/******************************************************************************************/

template <class T>
struct Model : MemberOrdered {
    using value_type = T;
    using RateFunction = Variant<Kawasaki>;
    Model() = default;
    explicit Model(DangleType, gu=gu::on, ParameterFile const &p={}, ModelConditions const &cs={}, RateFunction const &rf={});
    Model(string const &s, bool gt, ParameterFile const &p, ModelConditions const &cs, RateFunction const &rf={}) : Model(as_dangle_type(s), gt ? gu::on : gu::off, p, cs, rf) {}

    /**************************************************************************************/

    NUPACK_REFLECT(Model, parameters, beta, conditions, possible_pairs, has_terminal_penalty, pairable, rate_function, dangle);

    std::array<small_vec<Base, 4>, 4> possible_pairs;
    std::shared_ptr<ParameterSet<T> const> parameters;
    ModelConditions conditions;
    RateFunction rate_function;
    DangleType dangle;
    T beta;
    Pairable pairable;
    bool has_terminal_penalty = false;

    void check() const {if (!parameters) NUPACK_ERROR("Model has no parameters; it may have been default-constructed");}
    auto const & dG() const noexcept(!Debug) {if (Debug) check(); return *parameters;}

    template <class U>
    Model(Model<U> const &o) {
        static_assert(!is_same<U, T>, "Should use normal copy constructor");
        constexpr auto N = tuple_size<decltype(members_of(*this))>;
        slice<1, N>(members_of(*this)) = slice<1, N>(members_of(o));
        if (o.parameters) parameters = std::make_shared<ParameterSet<T> const>(*o.parameters);
    }

    auto boltz(T e) const {return boltzmann_factor(beta, e);};

    /**************************************************************************************/

    template <class S> T hairpin_energy(const S &) const;
    template <class S1, class S2> T interior_energy(const S1 &, const S2 &) const;
    template <class V> T linear_multi_energy(V const &) const;
    template <class V> T multi_energy(V const &) const;
    template <class V> T exterior_energy(V const &, int const) const;
    template <class V> T loop_energy(V const &, int) const;

    /**************************************************************************************/

    T interior_size_energy(int) const;
    T interior_asymmetry(int, int) const;
    T interior_mismatch(Base, Base, Base, Base) const;

    T join_penalty() const {return dG().join_penalty;}
    T multi_closing() const {return dG().multi_closing;}
    T multi_base() const {return dG().multi_base;}
    T multi_interior() const {return dG().multi_interior;}
    auto pairs(Base i) const {return possible_pairs[i];}
    T terminal_penalty(Base i, Base j) const {return dG().terminal_penalty[i][j];}
    T coaxial_stack_energy(Base, Base, Base, Base) const;

    /**************************************************************************************/

    template <class F>
    auto dangle_fork(F &&f) const {return fork(dangle, [&](auto d) {return fw<F>(f)(dangle_function(d, dG()));});}

    T dangle5(Base i, Base j, Base k) const {return dG().dangle5[i][j][k];}
    T dangle3(Base i, Base j, Base k) const {return dG().dangle3[i][j][k];}
};

NUPACK_DEFINE_TEMPLATE(is_model, Model, class);

template <class T=real, class ...Ts>
auto model(DangleType d, Ts && ...ts) {return Model<T>(d, fw<Ts>(ts)...);}

template <class T=real>
auto model() {return Model<T>(MinDangles());}

/******************************************************************************************/

template <class T>
Model<T>::Model(DangleType d, gu gt, ParameterFile const &p, ModelConditions const &cs, RateFunction const &rf)
    : conditions(cs), dangle(d), beta(1.0 / (Kb * cs.temperature)), pairable{gt}, rate_function(rf),
        parameters{ParameterSet<T>::shared({p, "dG",
            dna_salt_correction(cs.temperature, cs.na_molarity, cs.mg_molarity), cs.temperature})} {
    fork(rate_function, [&](auto &rf) {rf.beta = beta;});
    for (auto i : CanonicalBases) for (auto j : CanonicalBases) if (pairable(i, j)) {
        possible_pairs[i].emplace_back(j);
        has_terminal_penalty |= terminal_penalty(i, j) != 0;
    }
}

/******************************************************************************************/

template <class T> template <class V>
T Model<T>::loop_energy(V const &v, int nick) const {
    if (nick != -1) return exterior_energy(v, nick);
    else if (len(v) == 1) return hairpin_energy(v[0]);
    else if (len(v) == 2) return interior_energy(v[0], v[1]);
    else return multi_energy(v);
}

/******************************************************************************************/

template <class T>
T Model<T>::interior_size_energy(int s) const {
    NUPACK_REQUIRE(s, >, 0);
    if (s <= 30) return dG().interior[s - 1]; // Interior with >2, <30 total
    return static_cast<T>(back(dG().interior) + log((s) / 30.0) * dG().log_loop_penalty); // Big interior loop
}

/******************************************************************************************/

template <class T>
T Model<T>::interior_asymmetry(int n1, int n2) const {
    auto ninio_number = std::min((decltype(n2)) 4, std::min(n2, n1)) - 1;
    auto asymmetry = std::abs(n1 - n2);
    return std::min<T>(asymmetry * dG().ninio[ninio_number], back(dG().ninio));
}

/******************************************************************************************/

template <class T> /// Interior mismatch energy for (b1, b2, b3, b4) where b2 and b3 are paired, b1 left of b2, b4 right of b3
T Model<T>::interior_mismatch(Base b1, Base b2, Base b3, Base b4) const {
    return dG().int_mismatch [b1] [b2] [b3] [b4];
}

/******************************************************************************************/

/// Coaxial stack energy for (b1, b2, b3, b4) where b1 and b2 are paired, b3 and b4 are paired,
template <class T> /// and b2 and b3 are on the same strand
T Model<T>::coaxial_stack_energy(Base b1, Base b2, Base b3, Base b4) const {
    return dG().coax_stack [b2] [b3] [b4] [b1];
}

/******************************************************************************************/

// Input 5' ---seq1--> 3'
//       3' <--seq2--- 5'
template <class T> template <class S1, class S2>
T Model<T>::interior_energy(S1 const &seq1, S2 const &seq2) const {
    T en = T();
    int const n1 = len(seq1) - 2, n2 = len(seq2) - 2;
    if (n1 == 0 && n2 == 0) { // Stack loop
        return en + dG().stack [seq1[0]] [seq1[1]] [seq2[0]] [seq2[1]];
    } else if (n1 == 0 || n2 == 0) { // Bulge loop
        auto sz = std::max(len(seq1), len(seq2)) - 2;

        if (sz <= len(dG().bulge)) en += dG().bulge[sz - 1];
        else en += back(dG().bulge) + log(sz / 30.0) * dG().log_loop_penalty;

        if (sz == 1) {
            // add stacking term for single-base bulges. No terminal penalty here
            return en + dG().stack [front(seq1)] [back(seq1)] [front(seq2)] [back(seq2)] - dG().metadata.loop_bias;
        } else {
            // Terminal penalty applies otherwise
            if (has_terminal_penalty) en += terminal_penalty(front(seq1), back(seq2))
                                          + terminal_penalty(front(seq2), back(seq1));
            return en;
        }
    } else if (n1 == 1 && n2 == 1) { // Interior 1x1
        return en + dG().int_1_1 [seq1[0]] [seq2[2]] [seq1[2]]
                                [seq2[0]] [seq1[1]] [seq2[1]];
    } else if (n1 == 1 && n2 == 2) { // Interior 1x2
        return en + dG().int_1_2 [seq1[0]] [seq2[3]] [seq1[1]] [seq1[2]]
                                [seq2[0]] [seq2[1]] [seq2[2]];
    } else if (n1 == 2 && n2 == 1) { // Interior 2x1
        return en + dG().int_1_2 [seq2[0]] [seq1[3]] [seq2[1]] [seq2[2]]
                                [seq1[0]] [seq1[1]] [seq1[2]];
    } else if (n1 == 2 && n2 == 2) { // Interior 2x2
        return en + dG().int_2_2 [seq1[0]] [seq2[3]] [seq1[1]] [seq1[2]]
                                [seq1[3]] [seq2[0]] [seq2[1]] [seq2[2]];
    } else { // Big interior loop
        en += interior_size_energy(n1 + n2);
    }
    // interior loops n1 > 4 x n2 > 4 are size + asymmetry + mismatch
    en += interior_asymmetry(n1, n2); // after n1 > 4 && n2 > 4 this just depends on |n1-n2|

    if ((n1 == 1 && n2 > 2) || (n2 == 1 && n1 > 2)) {
        en += interior_mismatch(Base('A'), back(seq2), front(seq1), Base('A'));
        en += interior_mismatch(Base('A'), back(seq1), front(seq2), Base('A'));
    } else {
        en += interior_mismatch(back(seq2, -1), back(seq2), front(seq1), front(seq1, 1));
        en += interior_mismatch(back(seq1, -1), back(seq1), front(seq2), front(seq2, 1));
    }
    return en;
}

/******************************************************************************************/

template <class T> template <class S>
T Model<T>::hairpin_energy(S const &seq) const {
    T en = T();
    if (len(seq) <= 32) en += dG().hairpin[len(seq) - 3];
    else en += back(dG().hairpin) + log((len(seq) - 2) / 30.0) * dG().log_loop_penalty;

    if (len(seq) == 5) { // triloop
        // terminal penalty is unintuitive but correct
        if (has_terminal_penalty) en += terminal_penalty(back(seq), front(seq));
        return en + dG().hp_tri [seq[0]] [seq[1]] [seq[2]] [seq[3]] [seq[4]];
    } else if (len(seq) == 6) { // tetraloop
        en += dG().hp_tetra [seq[0]] [seq[1]] [seq[2]] [seq[3]] [seq[4]] [seq[5]];
    }
    return en + dG().hp_mismatch [back(seq, -1)] [back(seq)] [front(seq)] [front(seq, 1)];
}

/******************************************************************************************/

template <class T> template <class V>
T Model<T>::linear_multi_energy(V const &v) const {
    auto const n_unpaired = sum(v, len) - 2 * len(v);
    return len(v) * dG().multi_interior + dG().multi_closing + dG().multi_base * n_unpaired;
}

template <class T> template <class V>
T Model<T>::multi_energy(V const &v) const {
    T const t = linear_multi_energy(v);
    if (!is_coaxial(dangle)) return t + exterior_energy(v, -1);
    else return t + inverse_boltzmann(beta, multiloop_stacking_states(convert_from_view(v), *this));
}

/******************************************************************************************/

// A list of sequences. nick indicates which one the strand break is before
// For example, the starting loop always has a nick of 0
template <class T> template <class V>
T Model<T>::exterior_energy(V const &v, int const nick) const {
    if (pairable.gt_allowed) {
        if (front(front(v)) + back(back(v)) == 5) return *inf;
        for (auto it : iterators(v).offset(0, -1))
            if (front(it[1]) + back(it[0]) == 5) return *inf;
    }

    T term{};
    if (has_terminal_penalty) {
        for (auto it = begin_of(v); it != end_of(v) - 1; ++it) if (it != begin_of(v) + nick - 1)
            term += terminal_penalty(front(it[1]), back(it[0]));
        if (nick) term += terminal_penalty(front(front(v)), back(back(v)));
    }

    return term + fork(dangle, [&](auto d) -> T {return dangle_energy(d, *this, v, nick);});
}

/******************************************************************************************/

template <class M, class V>
auto loop_energy(M const &m, V v, int nick=-2) {
    NUPACK_REQUIRE(nick, >=, -2);
    NUPACK_REQUIRE(nick, <, int(len(v)));
    for (auto const &s : v)
        NUPACK_ASSERT(!s.empty(), "Loop contains an empty sequence");

    if (nick == -2) nick = find_nick(v);

    if (nick >= 0) {
        auto &s5 = v[nick];
        if (s5.front() != Base('_')) s5.insert(s5.begin(), Base('_'));
        auto &s3 = v[(nick + 1) % len(v)];
        if (s3.back() != Base('_')) s3.push_back(Base('_'));
    }
    for (auto const &s : v)
        NUPACK_REQUIRE(len(s), >=, 2, "Loop contains a sequence without enough nucleotides");

    auto const n_null = sum(v, [](auto const &s) {return count(s, Base('_'));});
    NUPACK_REQUIRE(n_null, ==, ((nick >= 0) ? 2 : 0), "Incorrect number of null bases encountered");
    return m.pairable.check_loop(v) ? m.loop_energy(v, nick) : *inf;
};

/******************************************************************************************/

template <class T>
void render(Document &doc, Type<Model<T>> t, int=0) {
    using M = Model<T>;
    doc.type(t, "model.Model", CHAR_BIT * sizeof(T));
    render_public(doc, t);
    render_comparisons(doc, t);
    doc.method(t, "new",                  rebind::construct<string, bool, ParameterFile, ModelConditions>(t));
    doc.method(t, "join_penalty",         &M::join_penalty);
    doc.method(t, "multi_closing",        &M::multi_closing);
    doc.method(t, "multi_base",           &M::multi_base);
    doc.method(t, "multi_interior",       &M::multi_interior);
    doc.method(t, "interior_size_energy", &M::interior_size_energy);
    doc.method(t, "interior_asymmetry",   &M::interior_asymmetry);
    doc.method(t, "interior_mismatch",    &M::interior_mismatch);
    doc.method(t, "dangle5",              &M::dangle5);
    doc.method(t, "dangle3",              &M::dangle3);
    // doc.method(t, "dangle" ,              [](M const &m) {return std::string_view(dangle_name(m.dangle));});
    doc.method(t, "boltz",                &M::boltz);
    doc.method(t, "hairpin_energy",       &M::template hairpin_energy<Sequence>);
    doc.method(t, "loop_energy",          &loop_energy<M, SequenceList>);
    doc.method(t, "multi_energy",         &M::template multi_energy<SequenceList>);
    doc.method(t, "exterior_energy",      &M::template exterior_energy<SequenceList>);
    doc.method(t, "interior_energy",      &M::template interior_energy<Sequence, Sequence>);
    doc.method(t, "coaxial_stack_energy", &M::coaxial_stack_energy);
}

void render(Document &doc, Type<Model<real32>>);
void render(Document &doc, Type<Model<real64>>);

/******************************************************************************************/

}

namespace rebind {

template <> struct ImplicitConversions<nupack::Model<float>> {using types = Pack<nupack::Model<double>>;};
template <> struct ImplicitConversions<nupack::Model<double>> {using types = Pack<nupack::Model<float>>;};

}
