#include "SequenceSet.h"
#include "StaticLoop.h"

namespace nupack {

/******************************************************************************************/

std::pair<iseq, iseq> SequenceSet::associate(SequenceSet & k, iseq ps, iseq ks, BaseIter pb, BaseIter kb) {
    auto &p = *this;
    SubsequenceList pseqs = {p.seqs[ps]};
    front(pseqs).set_begin(pb);
    circular_cat(pseqs, p.vec(), next(p, ps + 1), next(p, p.nick()));
    circular_cat(pseqs, k.vec(), next(k, k.nick()), next(k, ks));
    pseqs.emplace_back(k.vec()[ks]);
    back(pseqs).set_end(kb + 1);

    SubsequenceList kseqs = {k.vec()[ks]};
    front(kseqs).set_begin(kb);
    circular_cat(kseqs, k.vec(), next(k, ks + 1), next(k, k.nick()));
    circular_cat(kseqs, p.vec(), next(p, p.nick()), next(p, ps));
    kseqs.emplace_back(p.seqs[ps]);
    back(kseqs).set_end(pb + 1);

    p.seqs = std::move(pseqs); k.seqs = std::move(kseqs);

    auto shift1 = rotate_min_begin(p.seqs), shift2 = rotate_min_begin(k.seqs);

    p.n = find_nick(p.seqs); k.n = find_nick(k.seqs);

    return std::make_pair(shift1, shift2);
}

/******************************************************************************************/

std::pair<iseq, iseq> SequenceSet::dissociate(SequenceSet &k, iseq pk, iseq kp) {
    std::tie(seqs, k.seqs) = get_split_seqs(seqs, k.seqs, static_cast<iseq>(n),
                                            static_cast<iseq>(k.n), pk, kp);
    std::pair<iseq, iseq> ret = {rotate_min_begin(seqs), rotate_min_begin(k.seqs)};
    n = find_nick(seqs); k.n = find_nick(k.seqs);
    return ret;
}

/******************************************************************************************/

std::pair<iseq, iseq> SequenceSet::split(BasePairAddition const &m, SequenceSet & d) {
    std::tie(seqs, d.seqs) = split_midway(seqs, next(seqs, m.s1), next(seqs, m.s2), m.b1, m.b2);
    auto shift1 = rotate_min_begin(seqs);
    auto shift2 = rotate_min_begin(d.seqs);
    n = find_nick(seqs); d.n = find_nick(d.seqs);
    return std::make_pair(shift1, shift2);
}

/******************************************************************************************/


void render(Document &doc, Type<StaticLoop<>> t) {render(doc, t, 0);}

/******************************************************************************************/

void render(Document &doc, Type<BasePairDeletion> t) {
    doc.type(t, "kmc.BasePairDeletion");
};

/******************************************************************************************/

void render(Document &doc, Type<EdgeSet> t) {
    doc.type(t, "kmc.EdgeSet");
    doc.method(t, "is_root", &EdgeSet::is_root);
    doc.method(t, "_check", &EdgeSet::check);
    doc.method(t, "find_edge", &EdgeSet::find_edge_index);
}

/******************************************************************************************/

void render(Document &doc, Type<SequenceSet> t) {
    doc.type(t, "kmc.SequenceSet");
    doc.method(t, "exterior", &SequenceSet::exterior);
    doc.method(t, "nick", &SequenceSet::nick);
    doc.method(t, "vec", [](SequenceSet const &s) {return s.vec();});
    doc.method(t, "sequence_string", &SequenceSet::sequence_string);
    doc.method(t, "name", &SequenceSet::name);
}

/******************************************************************************************/

}
