from .generic import Runner
from subprocess import check_call

COAX_EXECUTABLE = '/Users/Mark/Projects/NUPACK_Coax/llvm/utest'

class Coax_Executable:
    def __init__(self, count):
        self.args = [COAX_EXECUTABLE, 'run-count-benchmark' if count else 'run-pf-benchmark']

    def __call__(self, strands):
        with open('data.in', 'w') as f:
            for strand in strands:
                print(strand, file=f)
        f.flush()
        check_call(self.args)
        with open('data.out', 'r') as f:
            return float(f.readlines()[0])


pfunc, count = [Runner('Ji\'s vectorized code', Coax_Executable(c)) for c in (0, 1)]

