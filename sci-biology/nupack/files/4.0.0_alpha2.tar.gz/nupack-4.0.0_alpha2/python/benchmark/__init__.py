from .generic import default_gen, param_gen
