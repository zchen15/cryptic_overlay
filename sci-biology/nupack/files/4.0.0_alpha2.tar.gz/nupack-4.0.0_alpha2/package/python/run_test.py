from nupack import Model

mod = Model()

assert mod.loop_energy(['AAAAATTTT']) == 4
