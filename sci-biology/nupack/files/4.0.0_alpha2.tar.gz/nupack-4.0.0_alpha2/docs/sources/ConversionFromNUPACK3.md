```python
import nupack
import math
import matplotlib.pyplot as plt
```

# Secondary structure model specification

Specify a free energy model including:
- `parameters`: the parameter set description to use. If 'RNA' or 'DNA' are specified, the default parameter sets for those materials will be used. A full parameter file may be specified, for example, by `parameters=nupack.ParameterFile(material='RNA', dG='rna1995.dG', dH='rna1995.dH')`
- `T`: the temperature, in Kelvin (default=`310.15`)
- `mg`: the magnesium ion concentration $`\textrm{Mg}^{2+}`$, in moles per liter (default=`0.0`)
- `na`: the sodium ion concentration $\textrm{Na}^{+}$, in moles per liter (default=`1.0`)
- `gt`: whether wobble pairs (G$\cdot$U or G$\cdot$T) are allowed (default=`True`)
- `dangles`: the recursions to use, from `['none', 'min', 'all', 'coax']` (default=`'min'`). Using `'none'`, no dangle or stacking energies will be incorporated. Using `'min'`, a dangle energy is incorporated for each unpaired base flanking a duplex (a base flanking two duplexes contributes only the minimum of the two possible dangle energies). Using `'all'`, a dangle energy is incorporated for each base flanking a duplex regardless of whether it is paired. Using `'coax'`, every possible coaxial stacking and dangle state is incorporated into the recursions.


```python
model = nupack.Model(parameters='DNA', T=(23+273.15), mg=0, na=0.1, gt=True, dangles='min')
```

# Example 2: Partition function for a complex.
Calculate the partition function for a complex of four DNA strands at 23 ◦C, two of which are indistinguishable.

## Input file contents:

```
3
AGTCTAGGATTCGGCGTGGGTTAA 
TTAACCCACGCCGAATCCTAGACTCAAAGTAGTCTAGGATTCGGCGTG
AGTCTAGGATTCGGCGTGGGTTAACACGCCGAATCCTAGACTACTTTG
1223
```

## Command: 

```bash
pfunc -T 23 -multi -material dna $NUPACKHOME/doc/examples/complex-analysis/advanced/input/hcr
```


```python
analysis = nupack.Analysis(model=model)

strands = (
    'AGTCTAGGATTCGGCGTGGGTTAA',
    'TTAACCCACGCCGAATCCTAGACTCAAAGTAGTCTAGGATTCGGCGTG',
    'TTAACCCACGCCGAATCCTAGACTCAAAGTAGTCTAGGATTCGGCGTG',
    'AGTCTAGGATTCGGCGTGGGTTAACACGCCGAATCCTAGACTACTTTG'
)

analysis.partition_function(strands)
complex_result = analysis.compute()[strands]

print('Free energy = %.2f kcal/mol' % complex_result.free_energy)
print('Partition function = %.3e' % math.exp(complex_result.log_partition_function))
```

    Free energy = -104.47 kcal/mol
    Partition function = 1.254e+77


# Example 3: Test tube analysis. 

Calculate the partition function, equilibrium pair probabilities, MFE structure(s), and equilibrium concentration for each complex in a test tube containing three DNA strand species that interact to form all complex species of up to four strands, plus additional larger complexes specified in a .list file.

## Input file contents:

```
3
AGTCTAGGATTCGGCGTGGGTTAA
TTAACCCACGCCGAATCCTAGACTCAAAGTAGTCTAGGATTCGGCGTG
AGTCTAGGATTCGGCGTGGGTTAACACGCCGAATCCTAGACTACTTTG
4
```

## List file contents:

```
1 2 2 3 3
1 2 3 2 3
2 3 2 3 2
1 2 2 2 3 3
```

## Strand concentrations file contents:

```
1e-6
1.1e-6
0.9e-6
```

## Commands: 

```bash
complexes -T 23 -material dna -pairs -mfe -degenerate $NUPACKHOME/doc/examples/tube-analysis/advanced/input/hcr
concentrations -pairs $NUPACKHOME/doc/examples/tube-analysis/advanced/input/hcr
```


```python
analysis = nupack.Analysis(model=model)

strands = (
    "AGTCTAGGATTCGGCGTGGGTTAA",
    "TTAACCCACGCCGAATCCTAGACTCAAAGTAGTCTAGGATTCGGCGTG",
    "AGTCTAGGATTCGGCGTGGGTTAACACGCCGAATCCTAGACTACTTTG",
)

analysis.pair_probability(strands, max_size=4)
analysis.min_free_energy(strands, max_size=4)

larger_complex_specs = [
    [1, 2, 2, 3, 3],
    [1, 2, 3, 2, 3],
    [2, 3, 2, 3, 2],
    [1, 2, 2, 2, 3, 3],
]

additional_complexes = [[strands[i-1] for i in x] for x in larger_complex_specs]

for cx in additional_complexes:
    analysis.pair_probability(cx)
    analysis.min_free_energy(cx)

complex_results = analysis.compute()

tube_solver = nupack.ConcentrationSolver(strands, complex_results)

strand_concentrations = [1e-6, 1.1e-6, 0.9e-6]

complex_concentrations = tube_solver.compute(strand_concentrations).complex_concentrations()

# tube = Tube(strands=strands, max_size=4, additional_complexes=additional_complexes)
# shows the sequences of the complexes in the tube
for cx, result in complex_concentrations.items():
    complex_result = complex_results[cx]
    print('Complex =', '+'.join(cx))
    print('    Strand indices =', [strands.index(strand) for strand in cx])
    print('    Concentration = %.3e M' % result)
    print('    Complex free energy = %.3f kcal/mol' % complex_result.free_energy)
    print('    MFE = %.3f kcal/mol' % complex_result.min_free_energy)
    print('    MFE structure = %s' % complex_result.suboptimal_structure[0][0])
    plt.matshow(complex_result.pair_probability, cmap='viridis')
    plt.colorbar()
    plt.grid(False)
    plt.show()    
```

    Complex = AGTCTAGGATTCGGCGTGGGTTAA+AGTCTAGGATTCGGCGTGGGTTAA+AGTCTAGGATTCGGCGTGGGTTAACACGCCGAATCCTAGACTACTTTG
        Strand indices = [0, 0, 2]
        Concentration = 3.380e-13 M
        Complex free energy = -38.941 kcal/mol
        MFE = -38.026 kcal/mol



    ---------------------------------------------------------------------------

    AttributeError                            Traceback (most recent call last)

    <ipython-input-4-d0d1f458d482> in <module>
         40     print('    Complex free energy = %.3f kcal/mol' % complex_result.free_energy)
         41     print('    MFE = %.3f kcal/mol' % complex_result.min_free_energy)
    ---> 42     print('    MFE structure = %s' % complex_result.suboptimal_structure[0][0])
         43     plt.matshow(complex_result.pair_probability, cmap='viridis')
         44     plt.colorbar()


    AttributeError: 'ComplexResult' object has no attribute 'suboptimal_structure'


# Example 4: 

Design a sequence for a complex of three DNA strands intended to adopt a target secondary structure at 23 ◦C. The first 24 nucleotides are constrained to nucleotide H (corresponding to a 3-letter alphabet) and the specified list of patterns are prevented throughout. A seed is set to make the design repeatable.

# Input file contents:

```
((((((((((((((((((((((((+((((((((((((((((((((((((.......................
.+))))))))))))))))))))))))))))))))))))))))))))))))
HHHHHHHHHHHHHHHHHHHHHHHH
```

# Prevent file contents:

```
AAAA
CCCC
GGGG
UUUU
KKKKKK
MMMMMM
RRRRRR
SSSSSS
WWWWWW
YYYYYY
```

# Seed file contents:

```
93
```

# Command: 

```bash
complexdesign -T 23 -material dna -pairs -loadseed -prevent $NUPACKHOME/doc/examples/complex-design/advanced/input/hcr-design.prevent $NUPACKHOME/doc/examples/complex-design/advanced/input/hcr-design
```


```python
structure = "((((((((((((((((((((((((+((((((((((((((((((((((((........................+))))))))))))))))))))))))))))))))))))))))))))))))"
design = nupack.design.complex_design(structure)

design.model = nupack.design.ModelSettings(material="DNA", temperature=(23+273.15))
design.parameters.seed = 93

design.domains[0].allowed_bases = "HHHHHHHHHHHHHHHHHHHHHHHH"

patterns = ["AAAA", "CCCC", "GGGG", "UUUU", "KKKKKK", "MMMMMM", "RRRRRR", "SSSSSS", "WWWWWW", "YYYYYY"]
design.add_pattern_constraints(patterns)

print(design)
print("\n")
print(design())
```

# Example 5: Test tube design. 

Design a sequence for a target test tube at default temperature 37 ◦C. The target test tube contains 1 on-target dimer (with a target structure and target concentration) and all off-target complexes of up to 2 strands (each with vanishing target concentration).

## Script file contents:

```python
# set properties
material = dna
seed = 93 # set seed to make design repeatable
# define target structure for 1 on-target complex
structure legs = ((((((((((((((((((((.......................+.......................))))))))))))))))))))
# define target test tube containing 1 on-target complex
tube walker = legs
# define target concentration for 1 on-target complex (molar)
# default: 1.0e-6
walker.legs.conc = 1.0e-6
# augment tube with all off-target complexes of up to 2 strands
# default: 0
walker.maxsize = 2
```

## Command: 

```bash
tubedesign $NUPACKHOME/doc/examples/tube-design/simple/input/walker-design
```


```python
design = nupack.design.Design()
design.model = nupack.design.ModelSettings(material='DNA')

structure = '((((((((((((((((((((.......................+.......................))))))))))))))))))))'
lengths = [len(s) for s in structure.split('+')]

design.add_domain('left', 'N'*lengths[0])
design.add_domain('right', 'N'*lengths[1])

design.add_strand('sleft', ['left'])
design.add_strand('sright', ['right'])

design.add_complex("legs", ['sleft', 'sright'], structure=structure)

design.add_tube("walker", {"legs": 1e-6})
design.add_off_targets("walker", maxsize=2)

design.parameters.seed = 93

print(design)
print("\n")
print(design())
```

# Example 6: Test tube ensemble defect. 

Calculate the test tube ensemble defect for a specified set of sequences and target test tube at default temperature 37 ◦C. The target test tube contains 1 on-target dimer (with a target structure and target concentration) and all off-target complexes of up to 2 strands (each with vanishing target concentration).

## Script file contents:

```python
# set properties
material = dna
# define 2 sequence domains
domain a = CGTGAACATCGGCGTGGTCGACCAACCCCACACAAAAAACCTA
domain b = TTCCCTCTATATTTCTACACTCCCGACCACGCCGATGTTCACG
# define 2 strands
strand leg1 = a
strand leg2 = b
# define target structure for 1 on-target complex
structure legs = ((((((((((((((((((((.......................+.......................))))))))))))))))))))
# define strand ordering for 1 on-target complex
legs.seq = leg1 leg2
# define target test tube containing 1 on-target complex
tube walker = legs
# define target concentration for 1 on-target complex (molar)
# default:  1.0e-6
walker.legs.conc = 1.0e-6
# augment tube with all off-target complexes of up to 2 strands
# default:  0
walker.maxsize = 2
```

## Command: 

```bash
tubedefect $NUPACKHOME/doc/examples/tube-design/simple/input/walker-defect
```


```python
design = nupack.design.Design()
design.model = nupack.design.ModelSettings(material='DNA')

design.add_domain('a', 'CGTGAACATCGGCGTGGTCGACCAACCCCACACAAAAAACCTA')
design.add_domain('b', 'TTCCCTCTATATTTCTACACTCCCGACCACGCCGATGTTCACG')

design.add_strand('leg1', ['a'])
design.add_strand('leg2', ['b'])
structure = '((((((((((((((((((((.......................+.......................))))))))))))))))))))'

design.add_complex('legs', ['leg1', 'leg2'], structure=structure)
design.add_tube('walker', {'legs': 1e-6})
design.add_off_targets('walker', maxsize=2)

print(design.evaluate())
```


```python

```
