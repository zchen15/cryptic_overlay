# Installation

## Requirements

NUPACK 4 is a C++ library distributed as a Python package for portability and ease of use. Before installing NUPACK, you must have Python 3 and a few common packages installed on your computer. Note that Python 2 is not currently supported. The specific Python package requirements for NUPACK 4 are:

- Python 3.5+
- numpy
- scipy

For full visualization capabilities, the following packages are recommended:

- matplotlib
- bokeh
- notebook

## Installing NUPACK via the Anaconda Python package

The easiest way to install NUPACK is to install [Anaconda](https://www.anaconda.com/distribution/), which comes with many Python packages preinstalled. Alternatively, you can install [Miniconda](https://docs.conda.io/en/latest/miniconda.html) for a smaller installation size. Make sure the distribution you use contains Python 3.5 or newer. You can verify your installation by running the terminal command:

```bash
conda info
```

The output of this command should show your Python version and other information. (If this command cannot be run, troubleshoot your Anaconda installation. You may not have your `$PATH` environmental variable set correctly.)

After installing your preferred distribution, download the NUPACK package `nupack-4.0.a1` into your Downloads folder. Then open Terminal and run the following command:

```bash
conda install -c conda-forge -c ~/Downloads/nupack-4.0.a1 nupack
```

You can change the path of your downloaded directory as you want, but be aware that you must use a full (not relative) path. This command will install the NUPACK C++ and Python packages. To validate your installation, run the following:

```bash
conda install pytest
pytest -v --pyargs nupack
```

Example notebooks are provided within the distributed package. In Terminal, navigate to the `nupack-4.0.a1` directory (for example, `cd ~/Downloads/nupack-4.0.a1`). Then run the following:

```bash
conda install notebook
jupyter notebook
```

If no browser window appears, you may try navigating to the displayed link in your terminal (this URL should look like <http://127.0.0.1:8889/?token=78f1ffcdcf04cec0e97e74912e36b4eb5b530aa546411ea3>). If this doesn't work, troubleshoot your Jupyter installation.

For each example notebook `Analysis.ipynb`, `Design.ipynb`, and `ConversionFromNUPACK3.ipynb`, open the notebook from your browser and click `Cell->Run All` to run the entire notebook.

## Installing NUPACK from source

### Dependencies for C++ libraries

- C++17 compliant compiler (works with Clang 3.6+, AppleClang, maybe GCC 5+)
- [Boost](https://www.boost.org) (1.58+, optionally including Boost Context)
- [Intel TBB](https://github.com/wjakob/tbb)
- [Armadillo matrix library](https://arma.sourceforge.net/) (9.5+)

All are available on [Homebrew](https://brew.sh) for Mac. For example, after Homebrew is installed, run `brew install tbb armadillo boost`. They are also commonly available in Linux package managers (e.g. `apt-get`, `pacman`).

### Directions

Make sure `python` points to your desired version of Python. On a Unix-like system, clone the repository and install in Terminal via the following commands.

Clone the git repository for NUPACK.
```bash
git clone --recurse-submodules git@github.com:mfornace/nupack.git
```
Make a build folder and navigate into it.
```bash
cd nupack
mkdir build
cd build
```
Run the CMake configuration. You may add any custom compilation options as flags to the `cmake` command if desired. For instance, you could add `-DCMAKE_INSTALL_PREFIX=/usr/local -DCMAKE_CXX_COMPILER=clang++` to use a specified install directory and C++ compiler.
```
cmake ..
```
Build the NUPACK Python module.
```bash
cmake --build . --target python
```
Install the NUPACK Python module and binding module.

```bash
pip3 install ../external/rebind
pip3 install .
```

## Bundled packages

### Included C++ packages

- [JSON for Modern C++](https://github.com/nlohmann/json>)
- [Boost.SIMD](https://github.com/nickporubsky/boost-simd-clone>)

### Included CMake packages

- [cotire.cmake](https://github.com/sakra/cotire>)
- [FindTBB.cmake](https://github.com/justusc/FindTBB>)
- [CMake common modules](https://github.com/Eyescale/CMake>)
- [CMake modules (for git revision)](https://github.com/rpavlik/cmake-modules>)

