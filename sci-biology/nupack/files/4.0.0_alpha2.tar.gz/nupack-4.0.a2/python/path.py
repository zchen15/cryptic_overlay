import numpy as np
from .kmc import State
from .std import Vector

################################################################################

class BasePairPath:
    '''Path containing the list of base pairing steps that occurred during a simulation'''
    steps: Vector
    time: float

################################################################################

class Path(BasePairPath):
    '''Augments BasePairPath to also include initial and final states'''
    # start: State
    # stop: State

    def base_pair_time(self, relative=False) -> np.ndarray:
        '''
        Returns the integrated pair probability over the path as a full N x N matrix
        relative: bool
            whether to divide the result by the path time
        '''

    def structure_time(self, structures, relative=False) -> np.ndarray:
        '''
        Returns the amount of time the path spent in a set of given different secondary structures
        structures: List[PairList]
            list of structures to measure the occupancy time for
        relative: bool
            whether to divide the result by the path time
        '''

def sample_path(state, time) -> Path:
    '''Return a sample path of a given length from a given start state'''

################################################################################
