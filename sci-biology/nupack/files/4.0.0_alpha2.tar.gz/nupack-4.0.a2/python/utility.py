'''
General purpose utility functions
'''
import re, json, uuid, datetime
import numpy as np
from random import choice
from multiprocessing import cpu_count, pool

##########################################################################

def str_repr(obj):
    return '{}.{}({})'.format(obj.__module__, type(obj).__name__, str(obj))

##########################################################################

def dtype_index(dtype):
    from . import rendered_document
    return rendered_document['scalars'][getattr(dtype, '__name__', str(dtype))]

##########################################################################

def match(gen):
    for x in gen:
        return x
    raise ValueError('Match not found')

##########################################################################

def nbits(x):
    try:
        x = np.dtype(x).itemsize * 8
    except TypeError:
        pass
    return int(x)

##########################################################################

def is_iterable(obj):
    try: return (True, iter(obj))[0]
    except TypeError: return False

##########################################################################

def thread_map(Iterable, function, threads=None, chunksize=None, index=False):
    if not is_iterable(Iterable):
        Iterable = range(Iterable)
    if threads is None:
        threads = cpu_count()
    if isinstance(threads, int):
        threads = pool.ThreadPool(threads)
    stuff = list(Iterable)
    if index:
        def f(x, i=[0]):
            function(i[0], stuff.pop(0))
            i[0] += 1
        return threads.map(f, tuple(range(len(stuff))), chunksize)
    else:
        def f(x): function(stuff.pop(0))
        return threads.map(f, tuple(range(len(stuff))), chunksize)

##########################################################################

def time_string(time=None, delta=None):
    if time is None: time = datetime.datetime.now()
    if delta is not None: time += datetime.timedelta(seconds=delta)
    return time.strftime('%H:%M')

##########################################################################

def exp_string(exponent):
    exp = np.exp(exponent, dtype=np.float128)
    if np.isfinite(exp):
        return exp
    exponent /= np.log(10.0)
    ie = int(np.floor(exponent))
    fe = 10.0 ** (exponent - ie)
    return '{}e{}'.format(fe, '%+d' % ie) if ie else str(fe)

##########################################################################

def can_convert(x, type):
    try: return (True, type(x))[0]
    except Exception: return False

##########################################################################

def specified_args(*args):
    return (i for i in args if i is not None)

##########################################################################

# see https://stackoverflow.com/questions/12397279/custom-json-encoder-in-python-with-precomputed-literal-json
class JSONEncoder(json.JSONEncoder):
    """
    JSON encoder which will work for objects containing NUPACK C++ types
    Works by using the default encoder, then carrying out replacements in the result
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._replacements = {}

    def default(self, o):
        if isinstance(o, Value):
            key = uuid.uuid4().hex
            self._replacements[key] = o.dump(-1 if self.indent is None else self.indent, True)
            return key
        else:
            return super().default(o)

    def encode(self, o):
        out = super().encode(o)
        for k, v in self._replacements.items():
             out = out.replace('"{}"'.format(k), v)
        return out

##########################################################################

def pair_matshow(ax, matrix, strands, period=4, line_options={'color': 'white'}, **kws):
    ax.matshow(matrix, **kws)
    s = list(''.join(strands))
    ax.set_xticks(range(len(s)))
    ax.set_yticks(range(len(s)))
    ax.set_xticklabels(['%d\n%s' % (i, s) if (i % period == 0) else s for i, s in enumerate(s)])
    ax.set_yticklabels(['%d %s' % (i, s) if (i % period == 0) else s for i, s in enumerate(s)])
    for i in np.cumsum(tuple(map(len, strands)))[:-1]:
        ax.plot([i+0.5,i+0.5], [-0.5, len(s)-0.5], **line_options)
        ax.plot([-0.5, len(s)-0.5], [i+0.5,i+0.5], **line_options)

##########################################################################

def DUp_recursion(toks):
    def match_left_paren(toks):
        toks = toks[2:]
        stack = 1
        for i, z in enumerate(toks):
            if isinstance(z, str):
                if z == "(":
                    stack += 1
                elif z == ")":
                    stack -= 1

            if stack == 0:
                return i + 2

    if not toks:
        return "", []
    tok = toks[0]

    if len(tok) == 1:
        assert tok == "+", "misplaced {}".format(tok)
        return tok, toks[1:]

    typ, n = tok

    if typ == "U":
        return "." * n, toks[1:]

    elif typ == "D":
        assert len(toks) > 1, "Duplex must have either strand break or internal structure"
        nxt = toks[1]
        if len(nxt) == 2 and nxt[0] == "D":
            mid, rest = DUp_recursion(toks[1:])
            intermediate = "("*n + mid + ")"*n
            return intermediate, rest

        if nxt == "(":
            matching = match_left_paren(toks)
            middle = toks[2:matching]
        else:
            matching = 1
            middle = [nxt]


        intermediate = ""
        while middle:
            string, middle = DUp_recursion(middle)
            intermediate += string
        return "(" * n + intermediate + ")" * n, toks[matching+1:]

##########################################################################

def DUp_to_dpp(string):
    def tokenize(string):
        token_types = r"\(|\)|D[1-9][0-9]*|U[1-9][0-9]*|[+]"
        components = r"D|U|[0-9]+"
        temp = re.findall(token_types, string)
        ret = list()
        for x in temp:
            j = re.findall(components, x)
            if j:
                ret.append((j[0], int(j[1])))
            else:
                ret.append(x)
        return ret

    toks = tokenize(string)
    ret = ""
    while toks:
        string, toks = DUp_recursion(toks)
        ret += string
    return ret

