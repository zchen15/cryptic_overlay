from typing import Tuple
import numpy as np
from .utility import str_repr, DUp_to_dpp

##########################################################################

class SimpleType:
    def __str__(self):
        return '{}({})'.format(type(self).__name__, ', '.join(k + '=' + repr(getattr(self, k)) for k in self.__annotations__))

    def annotated(self):
        return {k: getattr(self, k) for k in self.__annotations__}

##########################################################################

class PairList:
    def __init__(self, pairs, _fun_=None):
        if isinstance(pairs, str):
            if 'D' in pairs or 'U' in pairs:
                pairs = DUp_to_dpp(pairs)
            _fun_(self, pairs)
        else:
            _fun_(self, np.asarray(pairs, dtype=np.uint32))

    def dp(self, nicks=()) -> str:
        '''Return equivalent dot-parens-plus string'''

    def array(self):
        '''Return numpy array of pair list indices'''
        self.view().copy()

    def view(self):
        return self.contents.cast(np.ndarray)

    def __iter__(self):
        return iter(self.view())

    def __getitem__(self, i):
        return self.view()[i]

##########################################################################

class Structure:
    def __init__(self, pairs, nicks):
        self.pairs = pairs
        self.nicks = tuple(map(int, nicks))

    def dp(self):
        return self.pairs.dp(self.nicks)

    def __str__(self):
        return self.dp()

    def __repr__(self):
        return "Structure('%s')" % str(self)

##########################################################################

class NickSequence:
    def sequences(self) -> Tuple[str, ...]:
        pass

##########################################################################

class Local:
    def __init__(self, threads=1):
        '''Initialize with given number of threads'''

    # @classmethod
    # def from_object(cls, env=None):
    #     if env is None:
    #         return cls(1)
    #     if isinstance(env, int):
    #         return cls(env)
    #     return env

##########################################################################

class Sequence:
    def __str__(self):
        return self.cast(str)

##########################################################################

class Base:
    def __str__(self):
        return self.cast(str)

##########################################################################

class Fenwick:
    def __len__(self):
        pass

##########################################################################

class MemoryLimit:
    length: int
    capacity: int

##########################################################################

class LRU:
    pass
