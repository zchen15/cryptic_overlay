import json, jsonschema, sys, os
from tornado.web import RequestHandler, Application
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from nupack.analysis import ConcentrationSolver, AnalysisResult, ComplexResult
from nupack import Model, Analysis, ParameterFile
from nupack.numeric import SparsePairMatrix

DEFAULT_PORT = 8765

################################################################################

def merge(*dicts):
    out = {}
    for d in dicts:
        out.update(d)
    return out

def load_model(x):
    params = ParameterFile(x['material'], x['parameter_dG'], x['parameter_dH'])
    return Model(bits=64, dangles=x['dangles'], gt=True, parameters=params,
                 T=x['temperature'], na=x['sodium'], mg=x['magnesium'])

def save_complex_result(res):
    out = {k: v for k, v in zip(res._fields, res) if v is not None}
    if res.pair_probability is not None:
        out['pair_probability'] = SparsePairMatrix(res.pair_probability, 10).save()
    if res.suboptimal_structure is not None:
        out['mfe_structures'] = [(s.dp(), e) for s, e in out.pop('suboptimal_structure')]
    print(out)
    return out

def save_analysis_result(res):
    return [merge({'strands': k}, save_complex_result(v)) for k, v in res.contents.items()]

################################################################################

def complex_analysis(inputs):
    lim = inputs['pair_probability_limit']
    ensembles = []
    for e in inputs['ensembles']:
        model = load_model(e['model'])
        analysis = Analysis(model)
        for c in e['complexes']:
            analysis.min_free_energy(c['strands'], max_size=c['max_complex_size'])
            analysis.pair_probability(c['strands'], max_size=c['max_complex_size'])
        result = save_analysis_result(analysis.compute())
        ensembles.append({'model': e['model'], 'complexes': result})
    return {'ensembles': ensembles, 'pair_probability_limit': lim}


def tube_analysis(inputs):
    out = []
    for tube in inputs['tubes']:
        strands = [s['sequence'] for s in tube['strands']]
        concentrations = [s['concentration'] for s in tube['strands']]
        m = {'strands': tube['strands'], 'ensembles': []}
        for mod in tube['models']:
            try:
                results = next(e['complexes'] for e in inputs['ensembles'] if e['model'] == mod)
            except StopIteration:
                raise ValueError('Model not found')
            res = {}
            for r in results:
                k = tuple(r.pop('strands'))
                res[k] = ComplexResult(**r)
            a = AnalysisResult(load_model(mod), res)
            c = ConcentrationSolver(strands, a)
            r = c.compute(concentrations)
            m['ensembles'].append({'model': mod, 'complexes': [{'indices': x, 'concentration': c} for x, c in zip(r.complexes, r.concentrations)]})
        out.append(m)

    return {'tubes': out}

ComputeFunctions = {
    'complex-analysis': complex_analysis,
    'tube-analysis': tube_analysis
}

################################################################################

class ComputeHandler(RequestHandler):

    def post_json(self, status, scope, message, data):
        self.set_status(status)
        if scope and message:
            response = dict(scope=scope, message=message)
        elif data:
            response = dict(data=data)

        try:
            None and self.output_schema.validate(response)
        except jsonschema.ValidationError as e:
            self.set_status(500)
            response = dict(scope=(['output-validation'] + list(e.absolute_path)), message=str(e))

        self.write(json.dumps(response))

    def post(self):
        try:
            inputs = json.loads(self.request.body)
        except json.JSONDecodeError as e:
            return self.post_json(400, ['input'], str(e), None)

        try:
            None and self.input_schema.validate(inputs)
        except jsonschema.ValidationError as e:
            return self.post_json(400, ['validation'] + list(e.absolute_path), str(e), None)

        try:
            output = ComputeFunctions[inputs['type']](inputs['data'])
            return self.post_json(200, None, None, output)
        except Exception as e:
            import traceback
            traceback.print_exc()
            return self.post_json(500, ['runtime'], str(e), None)

with open('../docs/analysis_input_schema.json') as f:
    ComputeHandler.input_schema = None and jsonschema.Draft4Validator(json.load(f))

with open('../docs/analysis_output_schema.json') as f:
    ComputeHandler.output_schema = None and jsonschema.Draft4Validator(json.load(f))

################################################################################

def make_app():
    return Application([
        (r"/", ComputeHandler),
    ])

################################################################################

if __name__ == "__main__":
    from argparse import ArgumentParser

    parser = ArgumentParser(description='Run NUPACK analysis server')
    parser.add_argument('--port', type=int, default=DEFAULT_PORT)
    args = parser.parse_args()

    import tornado.ioloop
    app = make_app()
    app.listen(args.port)
    tornado.ioloop.IOLoop.current().start()

################################################################################

def test(path='../docs/complex_input.json', error=False, port=DEFAULT_PORT):
    import requests

    with open(path) as f:
        input_data = json.load(f)

    if error:
        input_data['tubes'][0]['models'][0]['material'] = 'styrofoam'

    r = requests.post("http://127.0.0.1:%d/" % port, data=json.dumps(input_data))
    if r.status_code != 200:
        print(r.status_code, r.reason)

    return json.loads(r.text)
