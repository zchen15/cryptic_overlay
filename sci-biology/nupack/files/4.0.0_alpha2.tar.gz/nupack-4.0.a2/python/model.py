import os, pkg_resources

from .utility import nbits, match
from .constants import as_sequences as _seqs
from .core import PairList

################################################################################

class Conditions:
    '''
    Specification of environmental conditions for the simulated system
    '''
    temperature: float
    na_molarity: float
    mg_molarity: float

    def __init__(self, T=310.15, na=1.0, mg=0.0, _fun_=None):
        _fun_(self)
        self.temperature = T
        self.na_molarity = na
        self.mg_molarity = mg

    def save(self):
        return dict(temperature=self.temperature, sodium=self.na_molarity, magnesium=self.mg_molarity)

################################################################################

class ParameterFile:
    '''
    Descriptor of the chosen parameter files
    '''
    material: str
    dG: str
    dH: str

    default_parameters = {'rna': 'rna1995', 'dna': 'dna1998'}
    default_materials = {'rna1995': 'rna', 'rna1999': 'rna', 'dna1998': 'dna'}

    def __init__(self, material='rna', dG=None, dH=None, _fun_=None):
        if dG is None:
            prefix = self.default_parameters.get(material.lower(), material)
            dG, dH = (_find_file('parameters/%s.d%s' % (prefix, s)) for s in 'GH')

        material = self.default_materials.get(material.lower(), material).lower()
        assert material in ('rna', 'dna')

        _fun_(self, material.upper(), dG, dH)

################################################################################

class ParameterMetadata:
    '''
    Unique descriptor of a parameter set
    '''
    # file: ParameterFile

################################################################################

class ParameterSet:
    '''
    Parameters loaded from parameter files
    '''
    # metadata: 'ParameterMetadata'

################################################################################

class Model:
    dangle: str
    beta: float
    parameters: ParameterSet
    # conditions: Conditions

    def __init__(self, bits=64, dangles='min', gt=True, parameters="RNA", T=310.15, na=1.0, mg=0.0, _fun_=None):
        '''
        Construct a Model

        - `bits`: number of bits in the floating type used (probably 32 or 64)
        - `gt`: enable wobble pairs or not
        - `parameters`: ParameterFile object
        - `dangles`: one of ('min', 'all', 'none', 'coax')
        - `conditions`: Conditions object with temperature and salt concentrations
        '''
        if isinstance(parameters, str):
            parameters = ParameterFile(parameters)
        conditions = Conditions(T, na, mg)
        if dangles == 'some':
            dangles = 'min'
        assert dangles in ('min', 'all', 'none', 'coax')
        bits = nbits(bits)
        cls = match(k for k, v in self._metadata_.items() if v.cast(int) == bits)
        _fun_(self, dangles, gt, parameters, conditions, return_type=cls)

    def save(self):
        out = dict(pseudoknots=False, dangles=self.dangle)
        out.update(self.conditions.save())
        out.update(self.parameters.save())
        return out

    @property
    def bits(self):
        return self._metadata_[self.type()].cast(int)

    @property
    def temperature(self):
        return self.conditions.temperature

    def boltz(self, energy) -> float:
        '''Return the Boltzmann factor'''

    def dangle5(self, b, c, d) -> float:
        '''Return dangle energy on 5' side'''

    def dangle3(self, b, c, d) -> float:
        '''Return dangle energy on 5' side'''

    def loop_energy(self, sequences, nick=None, _fun_=None):
        '''Return energy of loop'''
        return _fun_(self, _seqs(sequences), -2 if nick is None else nick).cast(float)

    def structure_energy(self, strands, structure):
        '''Free energy of a given secondary structure'''
        return structure_energy(_seqs(strands), PairList.from_object(structure), self)

################################################################################

def structure_energy(sequences, structure, model) -> float:
    '''Free energy of a given secondary structure'''

################################################################################

class Kawasaki:
    '''Kawasaki rate function'''

    molarity: float
    bimolecular_scaling: float
    unimolecular_scaling: float
    beta: float

    __new__ = NotImplemented

    def nondimensional_rate(self, dE) -> float:
        pass

    def unimolecular_rate(self, dE) -> float:
        pass

    def bimolecular_rate(self, dE) -> float:
        pass

################################################################################

def _find_file(name):
    name = pkg_resources.resource_filename('nupack', name)
    return name if os.path.exists(name) else ''
