__version__ = '4.0.0'

import numpy, scipy.sparse
from typing import Tuple

from .model import Model, ParameterFile, Conditions
from .analysis import Analysis, ConcentrationSolver
from .design import Design
from .core import PairList, Local, Sequence, Base, Structure
from .constants import reverse_complement, random_sequence
from . import drawing, concentration

try:
    from .nupack_cpp import document
except ImportError:
    raise ImportError('C++ module object "nupack.nupack_cpp" cannot be imported')

def _input_csc(A):
    return (numpy.asfortranarray(A.indices, dtype=numpy.ulonglong),
            numpy.asfortranarray(A.indptr, dtype=numpy.ulonglong),
            numpy.asfortranarray(A.data), *A.shape)

def _output_csc(A):
    data, ind, ptr, shape = A.cast(Tuple[numpy.ndarray, numpy.ndarray, numpy.ndarray, Tuple[int, int]])
    return scipy.sparse.csc_matrix((data, ind, ptr[:-1]), shape)

def render():
    from rebind import render_module
    doc, cfg = render_module(__name__, document)
    cfg.set_input_conversion(numpy.ndarray, numpy.asfortranarray)
    cfg.set_input_conversion(scipy.sparse.csc_matrix, _input_csc)

    cfg.set_output_conversion(numpy.ndarray, lambda a: numpy.asarray(a.cast(memoryview)))
    cfg.set_output_conversion(scipy.sparse.csc_matrix, _output_csc)

    return doc, cfg

rendered_document, config = render()

constants.TypeIndex = rendered_document['TypeIndex']

def _set_paths():
    from pkg_resources import resource_filename
    from . import constants
    path = resource_filename('nupack', 'parameters')
    constants.set_default_parameters_path(path)

_set_paths()
