import json, os

import datetime
from ..constants import random_sequence
from random import randint, betavariate, uniform, choice
from functools import partial

# Couldn't get to be parallel due to C++ object not releasing thread (maybe?)
from multiprocessing.dummy import Pool
POOL = Pool(4)
MAP = POOL.map

# MAP = map


def default_gen(min_strands=1, max_strands=8, n_bases=200):
    while True:
        strands = [random_sequence(1 + int(betavariate(1, 3) * (n_bases-1))) for _ in range(randint(min_strands, max_strands))]
        if sum(len(s) for s in strands) <= 1000:
            return strands

def param_gen(min_strands=1, max_strands=8, n_bases=200):
    strands = default_gen(min_strands, max_strands, n_bases)
    temperature = uniform(10, 90)
    material = choice(('rna1995', 'dna1998'))
    Na = 1.0 if material == "rna1995" else uniform(0.5, 1.1)
    Mg = 0 if material == "rna1995" else uniform(0, 0.2)
    return dict(seqs=strands, T=temperature, material=material, sodium=Na, magnesium=Mg)

def temperature_gen(min_strands=1, max_strands=8, n_bases=200):
    strands = default_gen(min_strands, max_strands, n_bases)
    temperature = uniform(10, 90)
    material = choice(('rna1995', 'dna1998'))
    Na = 1.0
    Mg = 0
    return dict(seqs=strands, T=temperature, material=material, sodium=Na, magnesium=Mg)

class Run_Function:
    def __init__(self, function):
        self.function = function

    def __call__(self, k):
        if isinstance(k, dict):
            try: return ({'key': '+'.join(k['seqs']), 'value': self.function(**k)})
            except ValueError: return None
        else:
            try: return ({'key': '+'.join(k), 'value': self.function(k)})
            except ValueError: return None


def make_dict(rev, function, gen=None, notes=None):
    if gen is None: gen = 100
    if isinstance(gen, int): gen = (default_gen() for _ in range(gen))

    ret = {} if notes is None else dict(notes)
    ret['Data'] = [i for i in MAP(Run_Function(function), gen) if i is not None]
    ret['Revision'] = rev
    ret['Modified time'] = str(datetime.datetime.utcnow())
    return ret


class Runner:
    def __init__(self, revision, function):
        self.revision, self.function = revision, function
        self.json = lambda fn: fn if fn.endswith('.json') else fn + '.json'

    def __call__(self, fn, *args, gen=None, notes=None, **kwargs):
        fn = self.json(fn)
        f = self.append if os.path.exists(fn) and open(fn).read() else self.write
        f(fn, *args, gen=gen, notes=notes, **kwargs)

    def write(self, fn, *args, gen=None, notes=None, **kwargs):
        fn = self.json(fn)
        func = partial(self.function, *args, **kwargs)
        with open(fn, 'w') as f:
            json.dump(make_dict(self.revision, func, gen, notes), f, indent=4)

    def append(self, fn, *args, gen=None, notes=None, **kwargs):
        fn = self.json(fn)
        with open(fn, 'r') as f:
            old = json.load(f)
        func = partial(self.function, *args, **kwargs)
        new = make_dict(self.revision, func, gen, notes)

        for k, v in new.items():
            if k == 'Data': old[k] += v
            else: old[k] = v

        with open(fn, 'w') as f:
            json.dump(old, f, indent=4)
