from typing import Tuple, List, Dict, Union, Callable
import json

class Partition:
    """Partition of complexes in design between active and passive sets"""
    # mask: 'std.Vector' # Tuple[bool, ...]
    deflate: float


class Stats:
    """Run statistics of a finished design"""
    num_leaf_evaluations: int
    num_reseeds: int
    # num_redecompositions: 'std.Vector' # Tuple[int, ...]
    # offtargets_added_per_refocus: 'std.Vector' # Tuple[int, ...]
    design_time: float
    analysis_time: float
    # final_Psi: 'Partition'


class Complex:
    """Result of a complex calculation"""
    name: str
    # sequence: 'core.NickSequence'
    # structure: 'components.Structure'
    log_pfunc: float
    defect: float
    normalized_defect: float


class TubeComplex:
    """Result of a complex in a tube"""
    name: str
    concentration: float
    target_concentration: float
    nucleotide_defect: float
    structural_defect: float
    concentration_defect: float
    defect_contribution: float


class Tube:
    """Result of a tube calculation"""
    name: str
    nucleotide_concentration: float
    nucleotide_defect: float
    normalized_defect: float
    # complexes: 'std.Vector' # Tuple['TubeComplex', ...]


class Single:
    """One of the pareto optimal results at end of design"""
    domains: Dict[str, str]
    strands: Dict[str, str]
    defects: List[float]
    weighted_defects: List[float]


class Result:
    """Result of a design"""
    # model: 'components.ModelSettings'
    # parameters: 'components.Parameters'
    # stats: 'Stats'
    # complexes: 'std.Vector' # Tuple['Complex', ...]
    # tubes: 'std.Vector' # 'std.Vector' # Tuple['Tube', ...]
    success: bool

    def __init__(self, json=None, _fun_=None):
        """create a new Result, loading from json string if available"""
        _fun_(self)
        if json:
            self.from_json(json)

    def from_json(self, json=None):
        """load from JSON string"""

    def to_json(self, _fun_=None, **kwargs) -> str:
        """convert to JSON string"""
        temp = json.loads(_fun_(self).cast(str))
        return json.dumps(temp, **kwargs)

