#pragma once
#include "Engine.h"
#include "Engine.h"
#include "../execution/Local.h"

namespace nupack::thermo {

template <class D>
std::true_type check_cache_dangle(D, real);

template <class D, int N, class D2, class ...Ts>
std::is_same<D2, D> check_cache_dangle(D, Cache<N, D2, Ts...>);

template <class Rig, int N, bool ...Bs, class ...Types, class ...Dangles>
void render_engine(rebind::Document &doc, pack<Types...> ts, pack<Dangles...> ds) {
    using Caches = rebind::Pack<real, Cache<N, Dangles, oflow<Bs, Types>...> &...>;
    using Models = std::tuple<CachedModel<Rig, Model<Types>> &...>;

    pack<oflow<Bs, Types>...>::for_each([&doc](auto t) {
        NUPACK_UNPACK(doc.render<Message<decltype(*t), Dangles, N>>());
        doc.render<XTensor<decltype(*t)>>();
    });

    using Obs = rebind::Callback<void>;
    using boolCall = rebind::Callback<bool>;

    Caches::for_each([&doc](auto cache) {
        using C = decltype(*cache);
        doc.function("analysis.dynamic_program", [](rebind::Caller call, Local env, NickSequence const &seq, Models m, C c, Obs o, PairingAction const &a) {
            return dynamic_program<N, Bs...>(env, seq, m, c, std::move(o), a);
        });

        doc.function("analysis.pair_probability", [](rebind::Caller call, Local env, NickSequence const &seq, Models m, C c, Obs o, PairingAction const &a) {
            return pair_probability<N, Bs...>(env, seq, m, c, std::move(o), a);
        });

        doc.function("analysis.permutations", [](Local env, usize n, SequenceList const &seq, Models m, C c, Obs o, PairingAction const &a) {
            return permutations<N, Bs...>(env, n, seq, m, c, std::move(o), a);
        });

        if constexpr(std::is_same_v<Rig, PF>) {
            doc.function("analysis.sample", [](Local env, usize n, usize m, NickSequence const &seq, Models ms, C c, Obs o, PairingAction const &a) {
                return sample<N, Bs...>(env, n, m, seq, ms, c, std::move(o), a);
            });
        } else {
            doc.function("analysis.subopt", [](Local env, float gap, NickSequence const &seq, Models m, C c, Obs o, PairingAction const &a, bool print_segments) {
                return subopt<Outer_Stack, N, Bs...>(env, gap, seq, m, c, std::move(o), a, print_segments);
            });
            doc.function("analysis.subopt_stream", [](Local env, float gap, NickSequence const &seq, Models m, C c, boolCall cb, Obs o, PairingAction const &a) {
                auto wrap = [&](auto it) {return cb(*it);};
                subopt_stream<Outer_Stack, N, Bs...>(env, gap, seq, m, wrap, c, std::move(o), a);
            });
        }

        doc.function("analysis.block", [](Local env, NickSequence const &seq, Models m, C c, Obs o, PairingAction const &a) {
            rebind::Sequence out;
            fork(first_of(m).energy_model.dangle, [&](auto d) {
                if constexpr(decltype(check_cache_dangle(d, c))::value) {
                    auto b = block<N, Bs...>(env, d, seq, m, c, std::move(o), a);
                    out.emplace_back(b.second);
                    fork(b.first, [&](auto &block) {
                        out.emplace_back(block.names());
                        for_each(block.members(), [&](auto &m) {out.emplace_back(std::move(m));});
                    });
                }
                else throw std::runtime_error("Cache and Model types do not have same dangle setting");
            });
            return out;
        });
    });
}

template <int N, class... Ts>
void render_lru(Document &doc) {
    for (auto dangle : AllDangleTypes) fork(dangle, [&](auto d) {
        static_assert(traits::is_cache<Cache<N, decltype(d), Ts...>>, "");
        doc.render<Cache<N, decltype(d), Ts...>>();
    });
}

}
