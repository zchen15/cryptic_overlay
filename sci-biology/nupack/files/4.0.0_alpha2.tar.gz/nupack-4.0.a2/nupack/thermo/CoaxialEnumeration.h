/**
 * @brief Enumerated coaxial partition function
 *
 * @file CoaxialEnumeration.h
 * @author Nick Porubsky
 * @date 2018-05-31
 */
#pragma once
#include "../markov/Enumerate.h"
#include "../model/Model.h"

namespace nupack {
namespace thermo {

template <class S>
auto enumerated_coaxial_pf(S &&s, bool count) {
    auto start = jump_state(s, {}, moves::full);
    Model<real> model(start.model);
    model.dangle = CoaxDangles();
    if (count) model.beta = 0;

    real pf = 0;
    for_complex_states(start, [&](auto const &w) {
        pf += product(w, [&](auto const &o) {return pf_loop_stacking_states(o, model);});
    });
    return model.boltz(model.join_penalty() * (len(to_sequences(s))-1)) * pf;
}


/******************************************************************************************/
/*                          simple count without energies                                 */
/******************************************************************************************/


// compute the number of dangle configurations for each coaxial stacking state
template <class V = vec<vec<int>>, class V2>
real mask_count(V const & masks, V2 const & lengths, bool circ = true, int left = 1,
                int right = 1) {
    auto counts = vmap(masks, [&](auto mask) {
        // multiply in outermost dangles if outermost stacks are inactive
        // logic reduces to outside = 1 for multiloops
        auto outside = mask.front() ? 1 : left;
        outside *= mask.back() ? 1 : right;

        // default for exterior loop
        auto first = 0, last = 0;
        // circular; multiloop
        if (circ) {first = mask.front(); last = mask.back();}
        // for creating shifted views
        mask.insert(begin_of(mask), last);
        mask.insert(end_of(mask), first);

        auto count = 1;
        zip(lengths, view(mask, 0, len(mask) - 2), view(mask, 2, len(mask)), [&](auto length, auto l,
        auto r) {
            if (length >= 3 && l != r) {count *= 2;}
            else if (length == 3 && (l + r == 0)) {count *= 3;}
            else if (length > 3 && (l + r == 0)) {count *= 4;}
        });

        return outside * count;
    });
    return sum(counts);
}

/******************************************************************************************/

template <class O>
real exterior_loop_stacking_states(O const & o) {
    auto seqs = o.sequences();

    // pre-underscore first; post-underscore last.
    auto it = max_element(seqs);
    std::rotate(begin_of(seqs), it, end_of(seqs));

    auto left = (len(seqs.front()) > 2) ? 2 : 1;
    auto right = (len(seqs.back()) > 2) ? 2 : 1;

    if (len(seqs) == 2) { // only dangles
        return left * right;
    } else if (len(seqs) > 2) {
        seqs = decltype(seqs)(view(seqs, 1, len(seqs) - 1));
        auto lengths = vmap(seqs, len);
        auto masks = get_masks(lengths);
        filter_masks(masks);
        return mask_count(masks, lengths, false, left, right);
    }
    return 1;
}

/******************************************************************************************/

template <class O>
real multiloop_stacking_states(O const & o) {
    auto seqs = o.sequences();

    auto lengths = vmap(seqs, len);
    auto masks = get_masks(lengths);

    // so that first and last stacks can be compared
    for (auto & m : masks) m.push_back(m[0]);
    filter_masks(masks);
    // remove extraneous end points
    for (auto & m : masks) m.pop_back();

    return mask_count(masks, lengths);
}

/******************************************************************************************/

template <class O>
real count_loop_stacking_states(O const & o) {
    if (!o.exterior() && len(o.seqs) < 3) { // hairpin, interior, bulge, stack
        return 1;
    } else if (o.exterior()) {
        return exterior_loop_stacking_states(o);
    } else {
        return multiloop_stacking_states(o);
    }
}

/******************************************************************************************/

template <class S>
auto enumerated_coaxial_count(S &&s) {
    real count = 0;
    for_complex_states(jump_state(s, {}, moves::full), [&](auto const &w) {
        count += product(w, NUPACK_FUNCTOR(count_loop_stacking_states));
    });
    return count;
}

}}
