#pragma once
#include "../standard/Array.h" // for multi_array
#include "../common/Constants.h" // for temperature
#include "../types/IO.h" // for goto_line_after
#include "../types/Sequence.h"

#include <mutex>


namespace nupack {

/******************************************************************************************/
multi_array<bool, 4, 4> const terminal_locs = {{{{0, 0, 0, 1}},   // A
                                                {{0, 0, 0, 0}},   // C
                                                {{0, 0, 0, 1}},   // G
                                                {{1, 0, 1, 0}}}}; // T

/******************************************************************************************/

 // Hard-coded parameter file ordering
constexpr multi_array<Base, 6, 2> Pair_Indices{{
    {{Base('A'), Base('T')}},
    {{Base('C'), Base('G')}},
    {{Base('G'), Base('C')}},
    {{Base('T'), Base('A')}},
    {{Base('G'), Base('T')}},
    {{Base('T'), Base('G')}}
}};

/******************************************************************************************/


struct ParameterFile : MemberOrdered {

    string material, dG, dH;
    NUPACK_REFLECT(ParameterFile, material, dG, dH);

    /* Take a material type and optional dG and dH paths, to look up the parameter file
    Priority ranking:
        1) the specified path
        2) "NUPACKHOME" environment variable
        3) then the NUPACK parameters folder (set by CMake)
    */
    ParameterFile(string material="RNA", string dG={}, string dH={});

    std::ifstream open(string s) const;
};

NUPACK_DEFINE_TYPE(is_parameter_file, ParameterFile);

void render(Document &doc, Type<ParameterFile>);

/******************************************************************************************/

template <class T>
struct ParameterData {
    using value_type = T;

    auto & as_array() {
        static_assert(alignof(ParameterData) >= alignof(std::array<T, sizeof(*this)/sizeof(T)>), "reinterpret_cast will fail");
        return * reinterpret_cast<std::array<T, sizeof(*this)/sizeof(T)> *>(this);
    }
    auto const & as_array() const {return remove_const(*this).as_array();}

    ParameterData() = default;
    explicit ParameterData(std::istream &&is);
    explicit ParameterData(ParameterFile const &f, std::string const &s) : ParameterData(f.open(s)) {}

    template <class U>
    ParameterData(ParameterData<U> const &p) {zip(as_array(), p.as_array(), assign_eq);}

    multi_array<T, 4, 4, 4, 4, 4, 4, 4, 4> int_2_2;
    multi_array<T, 4, 4, 4, 4, 4, 4, 4> int_1_2;
    multi_array<T, 4, 4, 4, 4, 4, 4> int_1_1;
    multi_array<T, 4, 4, 4, 4> int_mismatch;
    multi_array<T, 4, 4, 4, 4> stack;
    multi_array<T, 4, 4, 4, 4> coax_stack;
    multi_array<T, 4, 4, 4, 4, 4, 4> hp_tetra;
    multi_array<T, 4, 4, 4, 4, 4> hp_tri;
    multi_array<T, 4, 4, 4, 4> hp_mismatch;
    multi_array<T, 4, 4, 4> dangle3, dangle5;
    multi_array<T, 4, 4> terminal_penalty;

    std::array<T, 30> interior;
    std::array<T, 30> bulge;
    std::array<T, 30> hairpin;
    std::array<T, 5> ninio;

    T multi_base, multi_closing, multi_interior;
    T log_loop_penalty;
    T join_penalty;

    template <class F>
    void scale_by(ParameterData const &o, F &&f) {
        zip(as_array(), o.as_array(), [&f](auto &x, auto const &y) {x = f(std::move(x), y);});
    }

    NUPACK_REFLECT(ParameterData, int_2_2, int_1_2, int_1_1,
        int_mismatch, stack, coax_stack, hp_tetra, hp_tri, hp_mismatch,
        dangle3, dangle5, terminal_penalty, interior, bulge, hairpin, ninio,
        multi_base, multi_closing, multi_interior, log_loop_penalty, join_penalty);

    void add_loop_bias(T t) {
        multi_closing += t;
        for_each(std::tie(stack, bulge, interior, hairpin, int_1_1, int_1_2, int_2_2),
            [t](auto &v) {for (auto &i : flat_view(v)) i += t;});
        join_penalty += t;
    }
};

template <class T>
void render(Document &doc, Type<ParameterData<T>> t, int=0) {
    doc.type(t, "model.ParameterData");
    render_public(doc, t);
}

void render(Document &doc, Type<ParameterData<real>>);
void render(Document &doc, Type<ParameterData<float>>);


struct ParameterMetadata {
    ParameterFile file;
    string kind;
    real loop_bias;
    real temperature;

    NUPACK_REFLECT(ParameterMetadata, temperature, loop_bias, kind, file);
    using is_member_ordered = True;
};

void render(Document &doc, Type<ParameterMetadata>);

/******************************************************************************************/

template <class T>
struct ParameterSet : ParameterData<T> {
    using base_type = typename ParameterSet::ParameterData;
    ParameterMetadata metadata;
    NUPACK_EXTEND_REFLECT(ParameterSet, base_type, metadata);

    template <class U>
    ParameterSet(ParameterSet<U> const &o) : metadata{o.metadata} {
        static_assert(!is_same<T, U>, "Should use normal copy constructor");
        zip(base_type::as_array(), o.as_array(), assign_eq);
    }

    ParameterSet() = default;

    explicit ParameterSet(ParameterMetadata data);

    friend std::ostream & operator<<(std::ostream &os, ParameterSet const &p) {
        return os << "ParameterSet(" << p.metadata.file.material << ", " << p.metadata.kind
                  << ", " << p.metadata.temperature << " K)";
    }

    static vec<std::weak_ptr<ParameterSet<T> const>> cache;

    static std::mutex cache_mutex;

    static auto shared(ParameterMetadata key);
};

template <class T>
std::mutex ParameterSet<T>::cache_mutex{};

template <class T>
vec<std::weak_ptr<ParameterSet<T> const>> ParameterSet<T>::cache{};


template <class T>
auto ParameterSet<T>::shared(ParameterMetadata key) {
    std::shared_ptr<ParameterSet<T> const> out;

    std::lock_guard<std::mutex> lk{cache_mutex};
    auto b = cache.begin(), e = cache.end();
    for (; b != e; ++b) {
        if (b->expired()) {
            if (b != --e) std::iter_swap(b, e);
            else break;
        } else {
            auto ptr = b->lock();
            if (ptr->metadata == key) {out = std::move(ptr); break;}
        }
    }
    cache.erase(e, cache.end());
    if (!out) {
        out = std::make_shared<ParameterSet<T> const>(std::move(key));
        cache.emplace_back(out);
    }
    return out;
}

NUPACK_DEFINE_TEMPLATE(isParameterSet, ParameterSet, class);

template <class P, NUPACK_IF(isParameterSet<P>)>
void render(Document &doc, Type<P> t, int=0) {
    doc.type(t, "model.ParameterSet");
    render_public(doc, t);
    doc.method(t, "new", rebind::construct<ParameterMetadata>(t));
}

void render(Document &doc, Type<ParameterSet<real32>>);
void render(Document &doc, Type<ParameterSet<real64>>);

/******************************************************************************************/

/// Read hairpin triloop array from parameter file
template <class A>
void set_triloop_array(A &a, std::istream &is) {
    string s;
    double value;
    std::array<char, 5> bases;
    while (is.good()) {
        is >> s >> value;
        for (auto i : range(5)) bases[i] = Base(s[i]);
        a [bases[0]] [bases[1]] [bases[2]] [bases[3]] [bases[4]] = value;
        if (io::is_on_next_line(getline(is, s), ">")) return;
    }
    NUPACK_ERROR("error reading in triloop parameters");
}

/******************************************************************************************/

/// Read hairpin tetraloop array from parameter file
template <class A>
void set_tetraloop_array(A &a, std::istream &is) {
    string s;
    double value;
    std::array<char, 6> bases;
    while (is.good()) {
        is >> s >> value;
        for (auto i : range(6)) bases[i] = Base(s[i]);
        a [bases[0]] [bases[1]] [bases[2]] [bases[3]] [bases[4]] [bases[5]] = value;
        if (io::is_on_next_line(getline(is, s), ">")) return;
    }
    NUPACK_ERROR("error reading in tetraloop parameters");
}

/******************************************************************************************/

/// Read interior loop 1x1 array from parameter file
template <class A>
void set_1x1_loops(A &a, std::istream &is) {
    while (is.good()) {
        string s;
        is >> s;
        io::load_array(a[Base(s[0])] [Base(s[1])] [Base(s[4])] [Base(s[5])], is);
        if (io::is_on_next_line(getline(is, s), ">")) return;
    }
    NUPACK_ERROR("error reading in 1x1 parameters");
}

/******************************************************************************************/

/// Read interior loop 1x2 array from parameter file
template <class A>
void set_1x2_loops(A &a, std::istream &is) {
    while (is.good()) {
        string s;
        is >> s;
        io::load_array(a[Base(s[0])] [Base(s[1])] [Base(s[3])] [Base(s[6])] [Base(s[7])], is);
        if (io::is_on_next_line(getline(is, s), ">")) return;
    }
    NUPACK_ERROR("error reading in 1x2 parameters");
}

/******************************************************************************************/

/// Read interior loop 2x2 array from parameter file
template <class A>
void set_2x2_loops(A &a, std::istream &is) {
    while (is.good()) {
        string s;
        is >> s;
        io::load_array(a[Base(s[0])] [Base(s[1])] [Base(s[3])] [Base(s[4])] [Base(s[7])] [Base(s[8])], is);
        if (io::is_on_next_line(getline(is, s), ">")) return;
    }
    NUPACK_ERROR("error reading in 2x2 parameters");
}

/******************************************************************************************/

/// Read stack loop array from parameter file
template <class A>
void set_stack(A &a, std::istream &is) {
    for (auto i : Pair_Indices) for (auto j : Pair_Indices){
        if (!is.good()) NUPACK_ERROR("error reading in stack parameters");
        is >> a[i[0]] [j[0]] [j[1]] [i[1]];
    }
}
/******************************************************************************************/

/// Read mismatch array from parameter file
template <class A>
void set_mismatch(A &a, std::istream &is){
    for_pairs(0, 4, [&](int i, int j) {for (auto k : Pair_Indices) {
        if (!is.good()) NUPACK_ERROR("error reading in mismatch parameters");
        is >> a [j] [k[1]] [k[0]] [i];
    };});
}

/******************************************************************************************/

/// Read dangles array from parameter file
template <class A>
void set_dangles(A &a, std::istream &is, bool is3){
    for (auto i : Pair_Indices) for (auto j : {0, 1, 2, 3}) {
        if (!is.good()) NUPACK_ERROR("error reading in dangle parameters");
        is >> (is3 ? a [j] [i[1]] [i[0]] : a [i[1]] [i[0]] [j]);
    }
}

/******************************************************************************************/

template <class T>
ParameterSet<T>::ParameterSet(ParameterMetadata data)
        : base_type(data.file.open(data.kind)), metadata{std::move(data)} {
    auto const &s = metadata.kind;
    auto const &t = metadata.temperature;
    auto const &p = metadata.file;
    if (s != "dG" && s != "dH" && s != "dS") NUPACK_ERROR("Invalid parameter type", s);
    base_type::log_loop_penalty = (s == "dH") ? 0 : 1.75 * Kb * DefaultTemperature; // include entropic terms

    if (s == "dG") {
        if (t != DefaultTemperature)
            base_type::scale_by(base_type(p.open("dH")), [=](auto dG, auto dH) {return (dG - dH) * t / (DefaultTemperature) + dH;});
        base_type::join_penalty -= std::log(water_molarity(t)) * Kb * t;
        base_type::add_loop_bias(metadata.loop_bias);
    }

    if (s == "dS") base_type::scale_by(base_type(p.open("dH")), [=](auto dG, auto dH) {return (dH - dG) / DefaultTemperature;});
}

/******************************************************************************************/

template <class T>
ParameterData<T>::ParameterData(std::istream &&is) {
    using namespace io;
    fill(as_array(), 0);
    goto_line_after(is, ">Stacking 5' X1 Y1 3'");
    set_stack(stack, go_to_number(is));
    goto_line_after(is, ">Coaxial Stacking");
    set_stack(coax_stack, go_to_number(is));
    goto_line_after(is, ">Hairpin Loop Energies:");
    load_array(hairpin, go_to_number(is));
    goto_line_after(is, ">Bulge loop Energies:");
    load_array(bulge, go_to_number(is));
    goto_line_after(is, ">Interior Loop Energies:");
    load_array(interior, go_to_number(is));
    goto_line_after(is, ">NINIO asymmetry");
    load_array(ninio, go_to_number(is));
    goto_line_after(is, ">Triloops ");
    set_triloop_array(hp_tri, skip_comments(is));
    goto_line_after(is, ">Tetraloops ");
    set_tetraloop_array(hp_tetra, skip_comments(is));
    goto_line_after(is, ">Mismatch HP");
    set_mismatch(hp_mismatch, go_to_number(is));//hp_mismatch,0);
    goto_line_after(is, ">Mismatch Interior");
    set_mismatch(int_mismatch, go_to_number(is));//int_mismatch,0);
    goto_line_after(is, ">Dangle Energies: 5' X1 Y 3'");
    set_dangles(dangle5, go_to_number(is), false);
    goto_line_after(is, ">Dangle Energies: 5' X1 . 3'");
    set_dangles(dangle3, go_to_number(is), true);
    goto_line_after(is, ">Multiloop terms:");
    go_to_number(is) >> multi_closing >> multi_interior >> multi_base;
    goto_line_after(is, ">AT_PENALTY:");
    double tmp; go_to_number(is) >> tmp;
    for (auto i : range(4)) for (auto j : range(4))
        terminal_penalty[i][j] = terminal_locs[i][j] ? tmp : 0;
    goto_line_after(is, ">Interior Loops 1x1");
    set_1x1_loops(int_1_1, skip_comments(is));
    goto_line_after(is, ">Interior Loops 2x2");
    set_2x2_loops(int_2_2, skip_comments(is));
    goto_line_after(is, ">Interior Loops 1x2");
    set_1x2_loops(int_1_2, skip_comments(is));
    goto_line_after(is, ">BIMOLECULAR");
    go_to_number(is) >> join_penalty;
    for (auto &i : this->as_array()) i *= 0.01; // convert to kcal/mol
}

extern template ParameterData<float>::ParameterData(std::istream &&);

extern template ParameterData<double>::ParameterData(std::istream &&);

/******************************************************************************************/

}
