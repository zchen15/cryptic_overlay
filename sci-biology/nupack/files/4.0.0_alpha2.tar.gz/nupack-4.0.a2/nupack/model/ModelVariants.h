#pragma once
#include <cmath>
#include "../types/Sequence.h"
#include "../standard/Variant.h"

namespace nupack {

/******************************************************************************************/

template <class F>
struct RateFunction : MemberOrdered {
    real molarity = 1.e-6;
    real bimolecular_scaling = 5.0e5, unimolecular_scaling = 1.6e6;
    real beta = 0;

    NUPACK_REFLECT(RateFunction, molarity, bimolecular_scaling, unimolecular_scaling, beta);

    template <class E>
    auto operator() (E dE) const {return F()(dE, beta);};

    auto nondimensional_rate(real dE) const {return (*this)(dE);}
    auto unimolecular_rate(real dE) const {return unimolecular_scaling * (*this)(dE);};
    auto bimolecular_rate(real dE) const {return molarity * bimolecular_scaling * (*this)(dE);};
};

template <class F>
void render(Document &doc, Type<RateFunction<F>> t) {doc.type(t, "model.RateFunction");}

/******************************************************************************************/

NUPACK_BINARY_FUNCTOR(kawasaki, exp(-0.5 * t * u));
NUPACK_BINARY_FUNCTOR(metropolis, (t > 0 ? exp(-t * u) : 1));

using Kawasaki = RateFunction<kawasaki_t>;
void render(Document &doc, Type<Kawasaki>);

using Metropolis = RateFunction<metropolis_t>;

/******************************************************************************************/

struct MinDangles : Empty {
    template <class T> constexpr T reduce(T e1, T e2, usize s=3) const {return s == 3 ? std::min(e1, e2) : e1 + e2;}
};

struct AllDangles : Empty {
    template <class T> constexpr T reduce(T e1, T e2, usize s=3) const {return e1 + e2;}
};

struct NoDangles : Empty {
    template <class T> constexpr T reduce(T, T, usize s=3) const {return *zero;}
};

struct CoaxDangles : Empty {
    template <class T> constexpr T reduce(T, T, usize s=3) const {NUPACK_ERROR("should not use."); return *zero;}
};

template <class Dangles, class P>
struct DangleFunction : Dangles {
    P const *p;
    DangleFunction(P const &pset) : p(&pset) {}
    auto energy5(Base i, Base j, Base k) const {return p->dangle5[i][j][k];}
    auto energy3(Base i, Base j, Base k) const {return p->dangle3[i][j][k];}
};

template <class P>
struct DangleFunction<NoDangles, P> : NoDangles {
    DangleFunction(P const &pset) {}
    value_type_of<P> energy5(Base, Base, Base) const {return *zero;}
    value_type_of<P> energy3(Base, Base, Base) const {return *zero;}
};

template <class D, class P>
DangleFunction<D, P> dangle_function(D, P const &p) {return {p};}

/******************************************************************************************/

using DangleType = Variant<NoDangles, MinDangles, AllDangles, CoaxDangles>;
static std::array<DangleType, 4> const AllDangleTypes = {NoDangles(), MinDangles(), AllDangles(), CoaxDangles()};
extern std::array<char const *, 4> DangleNames;

inline auto dangle_name(DangleType d) {return DangleNames[d.index()];}
inline bool is_active(DangleType const &d) {return !maybe_get<NoDangles>(d);}
inline bool is_coaxial(DangleType const &d) {return maybe_get<CoaxDangles>(d);}

DangleType as_dangle_type(string const &s);

void render(Document &doc, Type<DangleType>);

/******************************************************************************************/

template <class Model, class V>
value_type_of<Model> dangle_energy(NoDangles, Model const &, V const &, int const) {return *zero;}

template <class Model, class V>
value_type_of<Model> dangle_energy(CoaxDangles, Model const &m, V const &v, int const) {
    return inverse_boltzmann(m.beta, exterior_loop_stacking_states(convert_from_view(v), m));
}

// A list of sequences. nick indicates which one the strand break is before
// For example, the starting loop always has a nick of 0
template <class D, class M, class V, NUPACK_IF(is_same<D, MinDangles, AllDangles>)>
value_type_of<M> dangle_energy(D dangle, M const &model, V const &v, int const nick) {
    using T = value_type_of<M>;
    if (len(v) == 1) return *zero;
    auto const si = begin_of(v), sf = end_of(v) - 1;

    auto get = [&, sn=begin_of(v) + nick](auto s, auto t, auto u) {
        T e5, e3;
        if (sn != t) e5 = model.dG().dangle5[back(*s)] [front(*t)] [front(*t, 1)];
        if (sn != u) e3 = model.dG().dangle3[back(*t, -1)] [back(*t)] [front(*u)];
        if (sn == t) return e3;
        if (sn == u) return e5;
        return dangle.reduce(e5, e3, len(*t));
    };

    T en = *zero;

    if (len(*si) != 2) en += get(sf, si, si + 1);
    for (auto s = begin_of(v) + 1; s != end_of(v) - 1; ++s)
        if (len(*s) != 2) en += get(s - 1, s, s + 1);
    if (len(*sf) != 2) en += get(sf - 1, sf, si);

    return en;
}

/******************************************************************************************/


/// Dangle at the beginning of an edge, return 0 if s == sn
template <class D, class V, class It>
real safe_dangle5(D const &dangle, V const &v, It s) {
    if (len(*s) <= 2 || front(*s) == Base('_')) return *zero;
    auto const lo = cyclic_prev(v, s);
    return dangle.energy5(back(*lo), front(*s), front(*s, 1));
}

/******************************************************************************************/

/// Dangle at the end_of of an edge, return 0 if s == sn - 1
template <class D, class V, class It>
real safe_dangle3(D const &dangle, V const &v, It s) {
    if (len(*s) <= 2 || back(*s) == Base('_')) return *zero;
    auto const up = cyclic_next(v, s);
    return dangle.energy3(back(*s, -1), back(*s), front(*up));
}

/******************************************************************************************/

}

namespace rebind {

template <>
struct Response<nupack::DangleType> {
    bool operator()(Variable &out, TypeIndex t, nupack::DangleType d) const {
        if (t.equals<std::string_view>()) return out = std::string_view(nupack::dangle_name(d)), true;
        if (t.equals<std::string>()) return out = std::string(nupack::dangle_name(d)), true;
        return false;
    }
};


template <>
struct Request<nupack::DangleType> {
    std::optional<nupack::DangleType> operator()(Variable const &r, Dispatch &msg) const {
        if (auto p = r.request<std::string>()) return nupack::as_dangle_type(*p);
        return msg.error();
    }
};

}
