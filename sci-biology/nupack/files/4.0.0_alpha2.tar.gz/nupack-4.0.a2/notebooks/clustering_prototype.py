import nupack, numpy as np
from local_time import equilibrium_info
import random, scipy


# RESOLVE ISSUE OF STARTING STATE


# Boltzmann sample of states, store pair list & state info for each state
    # BOLTZMANN HAS PAIRLISTS, NEED TO INCORPORATE ENERGY INTO CODE
def pull_state_samples(sample_number, sequence, model = nupack.Model(gt = True)):

    # Boltzmann sample states
    analysis = nupack.Analysis(model=model)
    analysis.boltzmann_sample(sequence, sample_number) # generates set # of sample structures within the boltzmann distribution
    results = analysis.compute() # compute partition function, MFE, PP matrix, etc. for each sequence in boltzmann sample
    
    samples = [s.dp() for s in results[sequence].boltzmann_sample]  # return dot-parens for each structure in sample
    
    # pull state info & pair lists for each sampled state
    samples_state = []
    samples_pairs = []
    for i in range(sample_number):
        sample_state = nupack.State(sequence,dp = samples[i], kind='full', model=model) 
        samples_state.append(sample_state)
        samples_pairs.append(sample_state.pairs)
    samples_state = np.array(samples_state)
    samples_pairs = np.array(samples_pairs)
    
    # return samples, samples_state, samples_pairs
    return samples_state, samples_pairs


#################################################################################################


# K-means++ initialization of K-means

def kmeans_init(k, sample_number, samples_pairs):

        init_cluster_centers = []
        init_cluster_index = []

        # choose initial cluster center
        starting_cluster_index = round(random.uniform(0,sample_number)) 
        first_cluster_center = samples_pairs[starting_cluster_index]
    
        # compute distance from each state to initial cluster center
        initial_distances = np.array([(int(first_cluster_center ^ samples_pairs[w])) for w in range(sample_number)])
    
        # set distribution of states w.r.t. initial cluster center, favoring states that are further away
        cluster_distribution = (initial_distances**2) / sum(initial_distances**2)
    
        init_cluster_index = [starting_cluster_index]
    
        # Generate (k-1) more initial cluster centers (indices) based on the distribution of distances from the first cluster
        if k != 1:
            for m in range(k-1):

                # choose the next cluster center
                next_cluster_index = int(np.random.choice(np.arange(0,sample_number), p = cluster_distribution)) 
        
                # check that choice for next cluster center is not equal to the previous ones
                check_distances = [(samples_pairs[init_cluster_index[j]] ^ samples_pairs[next_cluster_index]) for j in range(len(init_cluster_index))]
                check_distances = np.array(check_distances)

                # generate more guesses for cluster centers until they are all unique states
                while check_distances[check_distances==0].size != 0:
                    next_cluster_index = int(np.random.choice(np.arange(0,sample_number), p = cluster_distribution)) # choose the next cluster center
        
                    check_distances = [(samples_pairs[init_cluster_index[j]] ^ samples_pairs[next_cluster_index]) for j in range(len(init_cluster_index))]
                    check_distances = np.array(check_distances)

                # store indices of unique cluster centers
                init_cluster_index.append(next_cluster_index)
        
        # Compile the pair lists of these initial cluster centers
        init_cluster_centers = np.array([(samples_pairs[init_cluster_index[m]].view()) for m in range(k)])
        # print(init_cluster_centers)

        return init_cluster_centers


#################################################################################################


# K-means algorithm

def kmeans(k, samples_pairs, samples_state, init_cluster_centers, sample_number):
    strand_length = len(samples_pairs[0].view()) 
    v = np.zeros([k]) # initialize counts for each cluster
    c = init_cluster_centers # initialize cluster centers
    clustered_states = np.zeros([sample_number,2]) # to store state index # with associated cluster #

    # initialize these distance sums:
    new_distance = np.zeros(sample_number)
    new_distance_sum = 0
    old_distance_sum = sample_number
    convergence_sums = []

    # for i in range(iter_num):
    # iterate to convergence (when sum of distances between points and clusters does not change between iterations)
    while (new_distance_sum != old_distance_sum):
        old_distance_sum = new_distance_sum
        for x in range(sample_number):
            # find the closest cluster center to state x
            x_distances = [(scipy.spatial.distance.hamming(c[m], samples_pairs[x].view()) * strand_length) for m in range(k)]
            x_cluster_number = np.argmin(x_distances)

            # store the state #, cluster #
            clustered_states[x,:] = [x, x_cluster_number]
            # store state's distance to nearest cluster
            new_distance[x] = x_distances[x_cluster_number]

            # increment the counter for that cluster
            v[x_cluster_number] += 1
            eta = 1/v[x_cluster_number]

            #take gradient step
            c[x_cluster_number] = (1 - eta) * c[x_cluster_number] + eta * samples_pairs[x].view()
        new_distance_sum = np.sum(new_distance)
        convergence_sums.append(new_distance_sum)

    # compile the final batch of clustered states with their Nupack state info & associated cluster #
    clustered_state_list = []
    for n in range(sample_number):
        clustered_state_list.append([samples_state[int(clustered_states[n,0])], clustered_states[n,1]])
    
    return clustered_states, clustered_state_list, convergence_sums


#################################################################################################


# Mini-Batch K-means algorithm

def minibatchkmeans(k, samples_pairs, samples_state, init_cluster_centers, iter_num, batch_size):
    strand_length = len(samples_pairs[0].view()) 
    v = np.zeros([k]) # initialize counts for each cluster
    c = init_cluster_centers # initialize cluster centers
    clustered_states = np.zeros([batch_size,2]) # to store state index # with associated cluster # for each batch analyzed

    # initialize these distance sums:
    new_distance_batch = np.zeros(batch_size)
    convergence_sums_batch = []

    for i in range(iter_num):
        # random sample of states to cluster stored as a list with each row: (sample state index, sample state pairs)
        minibatchset = random.sample(list(enumerate(samples_pairs)),batch_size)

        # assign each state from batch to a cluster center
        for x in range(batch_size):
            # find the closest cluster center to state x
            x_distances = [(scipy.spatial.distance.hamming(c[m], minibatchset[x][1].view()) * strand_length) for m in range(k)]
            x_cluster_number = np.argmin(x_distances)

            #store the state # and cluster #
            clustered_states[x,:] = [minibatchset[x][0], x_cluster_number]
            # store state's distance to nearest cluster
            new_distance_batch[x] = x_distances[x_cluster_number]

        convergence_sums_batch.append(np.sum(new_distance_batch))

        # update the cluster centers in a separate loop. This is the "mini-batch" processing part
        for x in range(batch_size):
            # increment the counter for that cluster
            v[int(clustered_states[x,1])] += 1
            eta = 1/v[int(clustered_states[x,1])]

            #take gradient step
            c[int(clustered_states[x,1])] = (1 - eta) * c[int(clustered_states[x,1])] + eta * minibatchset[x][1].view()

    # compile the final batch of clustered states with their Nupack state info & associated cluster #
    clustered_state_list = []
    for n in range(batch_size):
        clustered_state_list.append([samples_state[int(clustered_states[n,0])], clustered_states[n,1]])
    
    return clustered_states, clustered_state_list, convergence_sums_batch


#################################################################################################


# Find the MFE of each cluster

def find_cluster_mfe(k, clustered_states, samples_state):

    # sort microstates by their associated cluster
    clustered_states = clustered_states[np.argsort(clustered_states[:,1]),:]
    cluster_mfe = []
    cluster_mfe_states = []

    # find the MFE structure of the cluster
    for m in range(k):
        # find states corresponding to a cluster
        cluster_m = clustered_states[(clustered_states[:,1]==m),:]

        # check that there are states in that cluster
        if cluster_m.size != 0:
            # find the index of the MFE state in the cluster
            cluster_mfe_index = np.argmin([samples_state[int(cluster_m[n,0])].energy() for n in range(len(cluster_m))])

            # store the index of the state and cluster # for the MFE
            cluster_m_mfe = cluster_m[cluster_mfe_index,:]
            cluster_mfe.append(cluster_m_mfe)
    
    cluster_mfe = np.array(cluster_mfe) # array of state indices corresponding to MFEs
    # compile array of state info for each MFE for each cluster
    cluster_mfe_states = [(samples_state[int(cluster_mfe[p,0])]) for p in range(len(cluster_mfe))]
    
    return cluster_mfe_states


#################################################################################################


# function to run the preceding clustering algorithm, with minimal inputs

def run_clustering(k, sequence, sample_number, model = nupack.Model(gt = True), iter_num = 5, minibatch = False, batch_size = 1000):

    # samples state space, return structures, pair lists, energies
    samples_state, samples_pairs = pull_state_samples(sample_number, sequence, model = model)

    # initialize k-means with k-means++, return index and pair list of starting cluster center states
    init_cluster_centers = kmeans_init(k, sample_number, samples_pairs)

    # run k-means algorithm, iterating for iter_num to achieve convergence
    if minibatch == False:
        clustered_states, clustered_state_list, convergence_sums = kmeans(k, samples_pairs, samples_state, init_cluster_centers, sample_number)
    else:
        clustered_states, clustered_state_list, convergence_sums = minibatchkmeans(k, samples_pairs, samples_state, init_cluster_centers, iter_num, batch_size)

    # search clusters for corresponding mfe structure
    cluster_mfe_states = find_cluster_mfe(k, clustered_states, samples_state)

    print('Cluster MFEs:',)
    print(cluster_mfe_states)

    return clustered_state_list, cluster_mfe_states, convergence_sums