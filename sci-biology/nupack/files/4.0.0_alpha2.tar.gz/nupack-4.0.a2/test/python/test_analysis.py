from nupack import Analysis
import numpy as np

def test_partition_function():
    a = Analysis()
    v = a.partition_function('A' * 100).value()

    assert v.log_partition_function == 0
    assert v.free_energy == 0


def test_impossible_complex():
    strands = ['A', 'A']
    a = Analysis()
    a.partition_function(strands)
    a.boltzmann_sample(strands, 10)
    a.min_free_energy(strands)
    a.pair_probability(strands)
    v = a.value()

    assert v.log_partition_function == -np.inf
    assert v.free_energy == np.inf
    assert np.all(v.pair_probability == 0)
    assert len(v.mfe_structures) == 0
    assert len(v.suboptimal_structures) == 0
    assert len(v.sampled_structures) == 10
    for s in v.sampled_structures:
        assert str(s) == '.+.'
    assert v.min_free_energy == np.inf


def test_matrices():
    a = Analysis()
    a.partition_function('AAAAA', matrices=True)
    v = a.value()
    assert v.log_partition_function == 0
    assert v.pf_matrices['B'].sum() == 0



def test_overflow():
    a = Analysis()
    a.partition_function(300 * 'C' + 300 * 'G')
    v = a.value()
    assert abs(v.log_partition_function - 1393.4600830078125) < 0.01

    a.pair_probability(300 * 'C' + 300 * 'G')
    v = a.value()
    assert abs(v.pair_probability.sum(0) - 1).max() < 0.01



